<?php
/**
 * 凌云免流管理中心
 * by 天木兮 2018年10月15日
 */
exit("<script language='javascript'>window.location.href='./Lyun';</script>");
?>