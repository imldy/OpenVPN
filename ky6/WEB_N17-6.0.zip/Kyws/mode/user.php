<?php
$u = $_GET['username'];
$my_tj = db('openvpn')->where(array(_iuser_=>$u))->find();	
$my = $my_tj['tj_u'];
if ($my == ''){
$my = 0;	
}
$mb = $my_tj['tj_u']*$reg[user_reg_cash];
$h=date('G');
if ($h<11){
$s = '早上好哦';	
}elseif ($h<13){
$s = '中午好哦';
}elseif ($h<17){
$s = '下午好哦';
}else{
$s = '晚上好哦';	
} 

$mytop = db(_openvpn_)->where("tj_u >= :tj_u",array(":tj_u"=>$my))->getnums();	

   echo '<div style="margin:10px 10px;"><div class="alert alert-info"><h5>尊敬的'.$u.','.$s.'!</h5>
   我已成功推广 '.$my.'人的成绩,位居平台第 <font style="color:red">'.$mytop.'</font>名<br>
   到目前为止平台累积已赠送我 '.$mb.'M流量</div></div><div class="main">';
      $tj_top = db('openvpn')->limit('10')->where("tj_u > 0",array())->order('tj_u DESC')->select();
		 $i=1;
		foreach($tj_top as $voo){	
		 if($voo['tj_u'] == ''){
			$voo['tj_u']=0;
		    }
			$mb2 = $voo['tj_u']*$reg[user_reg_cash];
			echo '<ul class="list-group"><li class="list-group-item"><h5>'.$i.' 用户'.substr_replace($voo["iuser"],'****',3,4).' 成功推荐'.$voo['tj_u'].'人 获得 '.$mb2.'M流量</h4></li></ul>';
		 $i++;
		 }
  ?>
  </div>
  <center>
		<div style="color:#ccc;font-size:12px;">我们一直在努力创新 只为给你带来更完美</div>
	</center>