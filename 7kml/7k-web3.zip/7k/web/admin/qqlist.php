<?php
$mod='blank';
include("../api.inc.php");
$title='账号列表';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<!-- Body -->
<body>
        <?php include 'nav.php';?>
		      <section>
         <!-- Page content-->
         <div class="content-wrapper">
            <h3><?php echo $title ?>
               <small>当前平台所有账户列表.</small>
            </h3>


<?php

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='del'){
echo '<div class="alert';
$user=$_GET['user'];
$sql=$DB->query("DELETE FROM `openvpn` WHERE iuser='$user'");
if($sql){echo ' alert-success">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除成功！';}
else{echo ' alert-danger">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除失败！';}
echo '</div>';
}else
{
if(!empty($_GET['kw'])) {
  $sql=" `iuser`='{$_GET['kw']}'";
  $numrows=$DB->count("SELECT count(*) from `openvpn` WHERE{$sql}");
  $con='包含 '.$_GET['kw'].' 的共有 '.$numrows.' 个账号';
}else{
  $numrows=$DB->count("SELECT count(*) from `openvpn` WHERE 1");
  $sql=" 1";
  $con='平台共有 '.$numrows.' 个账号';
}
?>

 
            <div class="row">
               <div class="col-md-12">
                      <form action="qqlist.php" method="get" role="form" class="form-inline">
					  		                       <div class="panel panel-default">
                        <div class="panel-heading">
                           <div class="panel-title"><?php echo $con; ?></div>
                        </div>
                        <div class="panel-body">
                      <a href="addqq.php" class="btn btn-info">添加账号</a>
                      <a href="daochu.php" class="btn btn-blue" onclick="if(!confirm('你确实要执行批量导出吗？')){return false;}">导出所有账号数据</a>
                        
                        <div class="form-group pull-right">
                        <div class="form-group">
                          <input type="text" class="form-control" size="25" name="kw" placeholder="帐号">
                        </div>

                        <div class="form-group">
                          <button type="submit" class="btn btn-secondary btn-single">查询</button>
                        </div>
                        
                        </div>
                        
                      </form>
					  <br><br>

                      <div class="table-responsive">
                      
                                  <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                                      <thead>
                                          <tr>
                                            <th>服务器ID</th>
                                            <th data-priority="1">账号</th>
                                            <th data-priority="3">密码</th>
                                            <th data-priority="6">添加时间</th>
                                            <th data-priority="6">到期时间</th>
                                            <th data-priority="6">剩余流量</th>
                                            <th data-priority="6">总流量</th>
                                            <th data-priority="6">激活天数</th>
                                            <th data-priority="6">状态</th>
                                            <th data-priority="6">备注</th>
                                            <th data-priority="6">推荐人</th>
                                            <th data-priority="6">充值送推荐人流量</th>
                                            <th data-priority="6">操作</th>
                                          </tr>
                                      </thead>
                                      <tbody>
                                        <?php
                                        $pagesize=30;
                                        $pages=intval($numrows/$pagesize);
                                        if ($numrows%$pagesize)
                                        {
                                         $pages++;
                                         }
                                        if (isset($_GET['page'])){
                                        $page=intval($_GET['page']);
                                        }
                                        else{
                                        $page=1;
                                        }
                                        $offset=$pagesize*($page - 1);
                                        //$zt = array('0'=>'<font color=green>正常</font>','1'=>'<font color=red>密码错误</font>','2'=>'<font color=red>冻结</font>','3'=>'<font color=red>开启设备锁</font>');
										if($site_id==1){
                                        $rs=$DB->query("SELECT * FROM `openvpn` WHERE{$sql} order by id desc limit $offset,$pagesize");
										}else{
										$url = $_SERVER['HTTP_HOST'];//获取当前url		
										$rs=$DB->query("SELECT * FROM `openvpn` WHERE url='$url' and 1=1 order by id desc limit $offset,$pagesize");	
										}
                                        while($res = $DB->fetch($rs))
                                        { ?>
                                        <tr>
                                        <th><span class="co-name"><?=$res['fwqid']?></span></th>
                                        <td><?=$res['iuser']?></td>
                                        <td><?=$res['pass']?></td>
                                        <td><?=date("Y-m-d",$res['starttime'])?></td>
                                        <td><?=date("Y-m-d",$res['endtime'])?></td>
                                        <td><?=round(($res['maxll']-$res['isent']-$res['irecv'])/1024/1024)?>MB</td>
                                        <td><?=round(($res['maxll'])/1024/1024)?>MB</td>
                                        <td><?=$res['tian']?></td>
                                        <td><?=($res['i']?'<span class="badge btn-green">开通</span>':'<span class="badge badge-danger">禁用</span>')?></td>
                                        <td><?=$res['notes']?></td>
                                        <td><?=$res['tj_user']?></td>
                                        <td><?=($res['tj_ok']?'<div class="label label-info">有</div>':'<div class="label label-white">无</div>')?></td>
                                        <td><a class="btn btn-xs btn-green" href="./qset.php?user=<?=$res['iuser']?>">配置</a>&nbsp;<a href="./qqlist.php?my=del&user=<?=$res['iuser']?>" class="btn btn-xs btn-danger" onclick="if(!confirm('你确实要删除此账号吗？')){return false;}">删除</a></td>
                                        </tr>

                                        <?php }
                                        ?>
                                      </tbody>
                                  </table>
                      
                      </div>
                      <br>
                      <?php
                      echo'<ul class="pagination pagination-sm">';
                      $first=1;
                      $prev=$page-1;
                      $next=$page+1;
                      $last=$pages;
                      if ($page>1)
                      {
                      echo '<li><a href="qqlist.php?page='.$first.$link.'">首页</a></li>';
                      echo '<li><a href="qqlist.php?page='.$prev.$link.'">&laquo;</a></li>';
                      } else {
                      echo '<li class="disabled"><a>首页</a></li>';
                      echo '<li class="disabled"><a>&laquo;</a></li>';
                      }
                      for ($i=1;$i<$page;$i++)
                      echo '<li><a href="qqlist.php?page='.$i.$link.'">'.$i .'</a></li>';
                      echo '<li class="disabled"><a>'.$page.'</a></li>';
                      for ($i=$page+1;$i<=$pages;$i++)
                      echo '<li><a href="qqlist.php?page='.$i.$link.'">'.$i .'</a></li>';
                      echo '';
                      if ($page<$pages)
                      {
                      echo '<li><a href="qqlist.php?page='.$next.$link.'">&raquo;</a></li>';
                      echo '<li><a href="qqlist.php?page='.$last.$link.'">尾页</a></li>';
                      } else {
                      echo '<li class="disabled"><a>&raquo;</a></li>';
                      echo '<li class="disabled"><a>尾页</a></li>';
                      }
                      echo'</ul>';
                      #分页
                      }
                      ?>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>

<script type="text/javascript">
    /*function del(){
      var str="";
      $("input[name='ids']").each(function(){ 
          if($(this).prop('checked')){
            str += $(this).val()+","
          }
      })
      $.post('delall.php?action=delall',{ids:str},function(data){
        alert(data);
        window.location.reload();
      });
      
    }
   function checkAll(obj){
      $("input[type='checkbox']").prop('checked', $(obj).prop('checked'));
  }*/
</script>