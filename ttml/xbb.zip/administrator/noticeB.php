<?php
    $mod = 'blank';
    include ('../api.inc.php');
    $title = '公告信息';
    include './head.php';
    if ($islogin2 == 1) {
    } else exit ("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<?php
    require_once ('head.php');
?>
<?php
    echo '<section id="content">
<section class="vbox">
<section class="scrollable padder">
<ul class="breadcrumb no-border no-radius b-b b-light pull-in">
<section class="panel panel-default">
              <header class="panel-heading font-bold">公告信息 </header>
              <div class="panel-body">
          <form action="./noticeB.php" method="post" class="form-horizontal" role="form">

			 
			 
            <div class="input-group">
			  <span class="input-group-addon">公告内容：</span>
              <input type="text" name="content" value="';
    echo file_get_contents('../remote/ldmk.php');
?><?php
    echo '" class="form-control" required/>
            </div><br/>

';
    header('Content-type: text/html; charset=utf-8');
    if (isset($_POST['content'])) {
        $file = '../remote/ldmk.php';
        $content = $_POST['content'];
        if ($f = file_put_contents($file, $content)) {
            echo '写入成功。<br />';
        } else {
            echo '写入失败。<br />';
        }
    }
?>
<?php
    echo '
            <input type="submit" value="确认写入" class="btn btn-primary form-control"/>
          </form>
        </div>
      </div>
    </div>
  </div>
  <script src="../datepicker/WdatePicker.js"></script>
                  <div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
                    
                  
              </div>
            </section>
</section>
</section>

<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a></section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
<div class="wrapper">
	Notification
</div>
</aside>
<!-- end -->
';
    include './nav.php';
?>