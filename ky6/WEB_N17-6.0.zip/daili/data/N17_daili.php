<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
$dlid=$_SESSION['dlid'];
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='../Kyun/login.php';</script>");
$km=$DB->count("SELECT count(*) from auth_kms WHERE daili=$dlid");
$user=$DB->count("SELECT count(*) from `openvpn` WHERE `dlid`=$dlid");
$dl_km=$DB->count("SELECT count(*) from `auth_kms` WHERE isuse=0 and daili='$dlid'");
$online_user=$DB->count("SELECT count(*) from `openvpn` WHERE online=1 and dlid='$dlid'");
$row=$DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$rs=$DB->get_row("SELECT * FROM auth_config WHERE 1");
$vip=$row['vip'];
$rmb=$row['rmb'];
if($vip==1){
	$dljg=$rs['dl1'];
	$dljgs=$rs['dls1'];
	$v="<font color='#FFB200'>白银代理</font>";
}elseif($vip==2){
	$dljg=$rs['dl2'];
	$dljgs=$rs['dls2'];
	$v="<font color='#80FE80'>黄金代理</font>";
}elseif($vip==3){
	$dljg=$rs['dl3'];
	$dljgs=$rs['dls3'];
	$v="<font color='#FEE680'>铂金代理</font>";
}elseif($vip==0){
	$dljg=$rs['dl0'];
	$dljgs=$rs['dls0'];
	$v="<font color='#B26B00'>青铜代理</font>";
}elseif($vip==4){
	$dljg=$rs['dl4'];
	$dljgs=$rs['dls4'];
		$v="<font color='#2D006B'>钻石代理</font>";
}elseif($vip==5){
	$dljg=$rs['dl5'];
	$dljgs=$rs['dls5'];
	$v="<font color='red'>王</font><font color='green'>者</font><font color='#2D006B'>代</font><font color='#E60066'>理</font>";
}
$config = $DB->get_row("SELECT * FROM auth_config");
$gonggao=$config['gg'];//公告获取
if($_POST['my'] && $_POST['km']){
$km = daddslashes($_POST['km']);
$kmrow = $DB->get_row("SELECT * FROM auth_kms WHERE km='{$km}' and kind=2 limit 1");	
if(!$kmrow){
	exit("<script>alert('卡密不存在');window.location.href='./N17_daili.php';</script>");
	}elseif($kmrow['isuse']>0){
		exit("<script>alert('卡密已被使用');window.location.href='./N17_daili.php';</script>");
	}else{
		$value = $kmrow['value'];
		$now_rmb = $rmb + $value;
		$DB->query("UPDATE auth_daili SET rmb='{$now_rmb}' WHERE id='{$dlid}'");
		$DB->query("UPDATE auth_kms SET isuse=1,usetime='".date("Y-m-d")."' WHERE km='{$km}' and kind=2");
		wlog('代理充值','代理'.$row['user'].'使用卡密'.$km.'充值'.$value.'元['.$date.']');
		exit("<script>alert('成功充值".$value."元');window.location.href='./N17_daili.php';</script>");
	}
}
$img = rand(1,9);
?>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="renderer" content="webkit">

    <title>管理员平台 - N17-3.0</title>

    <meta name="keywords" content="快云免流，快云流控，快云流量，NB免流，NB流控">
    <meta name="description" content="快云免流，快云流控，快云流量，NB免流，NB流控">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
</head>	
<body class="gray-bg">
    <div class="wrapper wrapper-content">
        <div class="row">
			    <div class="col-sm-4">
					<div>
                       <div class="ibox-content text-center">
                               <div class="m-b-sm">
                                    <img alt="image" class="img-circle" src="../../assets/img/a<?php echo $img;?>.jpg">
                                </div>
                                <p class="font-bold">用户名：<?php echo $row['user'];?></p>

                                <div class="text-center">
                                    <a class="btn btn-xs btn-primary">级别：<?php echo $v;?></a>
                                    <a class="btn btn-xs btn-info">剩余余额: <?php echo $rmb;?></a>
                                </div>
                            </div>
							 </div>
							<br>
						</div>
                  <div class="col-sm-2"> 
                        <div class="row row-sm text-center">
                            <div class="col-xs-12">
                                <div class="panel padder-v item bg-info">
                                    <div class="h1 text-fff font-thin h1"><?php echo $user ?></div>
                                    <span class="text-muted text-xs">账号数量</span>
                                    <div class="top text-right w-full">
                                        <i class="fa fa-caret-down text-warning m-r-sm"></i>
                                    </div>
                                </div>
                            </div>
							<br>
                            <div class="col-xs-12">
                                <div class="panel padder-v item bg-primary">
                                    <div class="h1 text-fff font-thin h1"><?php echo $online_user?></div>
                                    <span class="text-muted text-xs">总在线人数</span>
                                    <div class="top text-right w-full">
                                        <i class="fa fa-caret-down text-warning m-r-sm"></i>
                                    </div>
                                </div>
						      </div>
						</div>
                     </div>
                 <div class="col-sm-6">
                <div class="ibox float-e-margins">
					   <div class="ibox-content" style="border-top:none;background-color:#e4eaec;">
					     <h4>平台卡密使用信息</h4>
						    <br>
                                 <h5>未使用卡密数量</h5>
                                <div class="progress progress-striped active">
                                    <div style="width: 100%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="75" role="progressbar" class="progress-bar progress-bar-warning"><h5><?php echo floor($dl_km);?> 张</h5>
                                        <span class="sr-only"></span>
                                    </div>
                                </div>
								<h5>平台总卡密数量</h5>
                                <div class="progress progress-striped active">
                                    <div style="width: 100%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="75" role="progressbar" class="progress-bar"><h5><?php echo $km;?> 张</h5>
                                        <span class="sr-only"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                     </div>
				 </div>
             <div class="row">
			  <div class="col-sm-6">
                 <div class="panel panel-default">
                    <div class="ibox-title">
                        <h5>代理余额充值<small> 充值余额</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                   <div class="panel-body">
				  <div class="form-group">  
			  <div class="panel-heading w h">
			  <h3 class="panel-title">请在下方输入激活码</h3></div>
               <div class="panel-body box">
               <form action="./N17_daili.php" method="post" class="form-inline" role="form">
			   <input type="text" name="my" value="cz" hidden/>
             <div class="form-group">
              <input type="text" name="km" value="" class="form-control" required/>
            </div>
            <input type="submit" value="充值" class="btn btn-primary"/>
          </form>
			    </div>
				   </div>
                    </div>
                </div>
            </div>
				 <div class="col-sm-6">
				    <div class="ibox float-e-margins">

                            <div id="vertical-timeline" class="vertical-container light-timeline">
                                    <div class="vertical-timeline-icon navy-bg">
                                        <i class="fa fa-volume-up"></i>
                                    </div>

                                    <div class="vertical-timeline-content">
                                        <h2>最新公告信息</h2>
                                        <p><?php echo $gonggao;?></p>
                                        <small class="btn btn-sm">来自超级管理员</small>
                                        <span class="vertical-date">
                                     <small><?php echo date( "Y年m月d日") ?></small>
                                </span>
                            </div>
                         </div>
                    </div>
                </div>
            </div>
    </div>

