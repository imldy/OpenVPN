<?php

include('head.php');
include('nav.php');
$m = new Map();
if($_GET['act'] == 'update'){
$info = file_put_contents('/home/cfm',$_POST['content']);
tip_success('导入成功',$_SERVER['HTTP_REFERER']);
}else{
$url = trim($_SERVER['SERVER_NAME']);
$DNS = 'http://dns.haotml.com/dns/CFM.php?url='.$url;
$action = '?act=update';
$info = file_get_contents("$DNS");
;echo '<div class="box">
<div class="main">
<span class="label label-default">穿越火线</span>
<div style="clear:both;height:10px;"></div>
<div class="alert alert-danger">穿越火线DNS推送列表！<br>请等页面加载完毕再操作，导入后点立即拦截！<br>如果快捷命令报错请进入ssh输入 vpn restart 命令重启vpn服务</div>
		<form class="form-horizontal" role="form" method="POST" action="';echo $action;echo '">
			<textarea class="form-control" rows="20" name="content">';echo $info ;echo '</textarea>
			<br>
			<button type="submit" class="btn btn-info btn-block">一键导入</button>
			<input type="button" class="btn btn-success btn-block" onclick="cmds(\'service dnsmasq restart\')" value="立即生效（导入后再执行）">
	        <input type="button" class="btn btn-danger btn-block" onclick="DNS(\'dns.sh cfm\')" value="清除数据">
	</form> 
	</div>
</div>
<script>
function cmds(line){
	if(confirm("立即生效穿越火线拦截列表？")){
		$.post(\'fas_service.php\',{
			  "cmd":line  
		},function(data){
			if(data.status == "success"){
				alert("执行完毕");
				 location.reload();
			}else{
				alert(data.msg);
					}
		},"JSON");
	}
	
}
</script>
<script>
function DNS(line){
	if(confirm("确定清除穿越火线的拦截列表吗？")){
		$.post(\'fas_service.php\',{
			  "cmd":line  
		},function(data){
			if(data.status == "success"){
				alert("清除成功");
				 location.reload();
			}else{
				alert(data.msg);
					}
		},"JSON");
	}
	
}
</script>
';
}
include('haosky.php');
?>