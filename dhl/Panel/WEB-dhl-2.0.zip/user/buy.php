<?php
$mod = 'blank';
include "../api.inc.php";
$title = '用户中心';
include './head.php';
$u = daddslashes($_GET['user']);
$p = daddslashes($_GET['pass']);
$res = $DB->get_row("SELECT * FROM `openvpn` where `user`='{$u}' && `pass`='{$p}' limit 1");
if (!$res) {
	header('location: login.php');
	die;
}
?>

<?php
require_once ("head.php");

?>
<nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">导航按钮</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="./">管理中心</a>
      </div><!-- /.navbar-header -->
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
		<li class="active">
            <a href="./buy.php?user=<?=$u?>&pass=<?=$p?>"><span class="glyphicon glyphicon-user"></span>购买流量</a>
          </li>
		<li class="active">
            <a href="./addpay.php?user=<?=$u?>&pass=<?=$p?>"><span class="glyphicon glyphicon-user"></span>用户充值</a>
          </li>
          <li class="active">
            <a href="./login.php"><span class="glyphicon glyphicon-user"></span>退出登录</a>
          </li>
        </ul>
      </div><!-- /.navbar-collapse -->
    </div><!-- /.container -->
  </nav><!-- /.navbar -->
				    <div class="panel panel-primary">
<div class="panel-heading w h"><h3 class="panel-title"><?php echo $title ?></h3></div>
<div class="panel-body box">
<?php

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='buy'){
}
else
{
?>
<div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th>价格</th><th>流量包</th><th>时长</th></tr></thead>
          <tbody>
<?php
$pagesize=30;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
$sql=" 1";
$rs=$DB->query("SELECT * FROM `auth_price` WHERE{$sql} order by id desc limit $offset,$pagesize");
while($res = $DB->fetch($rs))
{ ?>
<tr>
<td><?=$res['price']?></td>
<td><?=$res['llpg']?></td>
<td><?=$res['day']?></td>
<td><a href="./buy2.php?id=<?=$res['id']?>&user=<?=$u?>&pass=<?=$p?>" class="btn btn-xs btn-danger" onclick="if(!confirm('你确实要购买吗？')){return false;}">购买</a></td>
</tr>

<?php }
?>
          </tbody>
        </table>
      </div>
<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="buy.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="buy.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="buy.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="buy.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="buy.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="buy.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
}
?>
    </div>
  </div>
                  
                    
                  
              </div>
            </section>
</section>
</section>

<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a></section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
<div class="wrapper">
	Notification
</div>
</aside>
<!-- end -->
<?php
require_once ("foot.php");
?>

