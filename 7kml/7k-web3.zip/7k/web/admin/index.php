<?php
/**
 * 管理中心
**/
$mod='blank';
include("../api.inc.php");
$title='管理中心';

if(isset($_GET['id'])){
    $id = $_GET['id'];
    $rs = $DB->get_row("SELECT * FROM `auth_fwq` WHERE `id`='$id' limit 1");
    if(!$rs){
        echo "此服务器不存在";
    }else{
        $file = 'http://'.$rs['ipport'].'/res/openvpn-status.txt';
		$file2 = 'http://'.$rs['ipport'].'/udp/openvpn-status2.txt';
    }
}else{
    $file = '../res/openvpn-status.txt';
	$file2 = '../udp/openvpn-status2.txt';
}
?>
<?='<!DOCTYPE html>
<html lang="en">
';include '../head.php';?>
<?='
<body>
';include 'nav.php';?>

			
<?='
      <!-- Main section-->
      <section>
         <!-- Page content-->
         <div class="content-wrapper">
            <div class="content-heading">

               平台首页
               <small data-localize="dashboard.WELCOME"></small>
            </div>
            <!-- START widgets box-->
            <div class="row">
               <div class="col-lg-3 col-sm-6">
                  <!-- START widget-->
                  <div class="panel widget bg-primary">
                     <div class="row row-table">
                        <div class="col-xs-4 text-center bg-primary-dark pv-lg">
                           <em class="icon-user fa-3x"></em>
                        </div>
                        <div class="col-xs-8 pv-lg">
                           <div class="h2 mt0">';echo $count?><?='
						   <small>个</small></div>
                           <div class="text-uppercase">已注册用户数量</div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-lg-3 col-sm-6">
                  <!-- START widget-->
                  <div class="panel widget bg-purple">
                     <div class="row row-table">
                        <div class="col-xs-4 text-center bg-purple-dark pv-lg">
                           <em class="icon-people fa-3x"></em>
                        </div>
                        <div class="col-xs-8 pv-lg">
                           <div class="h2 mt0">';echo $countdaili?><?='
                              <small>个</small>
                           </div>
                           <div class="text-uppercase">已注册代理数量</div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-lg-3 col-md-6 col-sm-12">
                  <!-- START widget-->
                  <div class="panel widget bg-green">
                     <div class="row row-table">
                        <div class="col-xs-4 text-center bg-green-dark pv-lg">
                           <em class="icon-bubbles fa-3x"></em>
                        </div>
                        <div class="col-xs-8 pv-lg">
                           <div class="h2 mt0">';echo $countkm?><?='
						   <small>张</small></div>
                           <div class="text-uppercase">已生成卡密数量</div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-lg-3 col-md-6 col-sm-12">
                  <!-- START date widget-->
                  <div class="panel widget">
                     <div class="row row-table">
                        <div class="col-xs-4 text-center bg-green pv-lg">
                           <!-- See formats: https://docs.angularjs.org/api/ng/filter/date-->
                           <div data-now="" data-format="MMMM" class="text-sm"></div>
                           <br>
                           <div data-now="" data-format="D" class="h2 mt0"></div>
                        </div>
                        <div class="col-xs-8 pv-lg">
                           <div data-now="" data-format="当前时间" class="text-uppercase"></div>
                           <br>
                           <div data-now="" data-format="h:mm" class="h2 mt0"></div>
                           <div data-now="" data-format="a" class="text-muted text-sm"></div>
                        </div>
                     </div>
                  </div>
                  <!-- END date widget    -->
               </div>
            </div>
			
            <div class="row">
               <div class="col-lg-4">
                  <!-- START widget-->
                  <div class="panel widget">
                     <div class="panel-body">
                        <div class="text-right text-muted">
                           <em class="fa icon-user fa-2x"></em>
                        </div>
                        <h3 class="mt0">';echo $count2?><?='个</h3>
                        <p class="text-muted">当前正常账号数量</p>
                        <div class="progress progress-striped progress-xs">
                           <div role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="70" class="progress-bar progress-bar-warning progress-100">

                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- END widget-->
               </div>
               <div class="col-lg-4">
                  <!-- START widget-->
                  <div class="panel widget">
                     <div class="panel-body">
                        <div class="text-right text-muted">
                           <em class="fa icon-people fa-2x"></em>
                        </div>
                        <h3 class="mt0">';echo $countdaili2?><?='个</h3>
                        <p class="text-muted">当前激活代理数量</p>
                        <div class="progress progress-striped progress-xs">
                           <div role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" class="progress-bar progress-bar-green progress-100">
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- END widget-->
               </div>
               <div class="col-lg-4">
                  <!-- START widget-->
                  <div class="panel widget">
                     <div class="panel-body">
                        <div class="text-right text-muted">
                           <em class="fa icon-bubbles fa-2x"></em>
                        </div>
                        <h3 class="mt0">';echo $countkm2?><?='张</h3>
                        <p class="text-muted">当前未使用卡密数量</p>
                        <div class="progress progress-striped progress-xs">
                           <div role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" class="progress-bar progress-bar-info progress-100">

                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- END widget-->
               </div>
            </div>
            <!-- END row-->

					';?>

					
					
           <!-- START Widgets-->
            <div class="row">
               <div class="col-lg-3">
                  <!-- START loader widget-->
            <script type="text/javascript">
                jQuery(document).ready(function($)
                {   


                    // Pageviews Visitors Chart
                    var i = 0,
                        line_chart_data_source = [
                        //{ id: ++i, part1: 4, part2: 2 },
                        <?php
                        $str=file_get_contents($file);
                        $num=(substr_count($str,date('Y'))-1)/2;
                        $fp=fopen($file,"r");
                        fgets($fp);
                        fgets($fp);
                        fgets($fp);
                        for($i=0;$i<$num;$i++){
                        $j=$i+1;
                            $line=fgets($fp);
                            $arr=explode(",",$line);
                            $recv=round($arr[2]/1024)/1000;
                            $sent=round($arr[3]/1024)/1000;
                        echo "{ id: ++i, part2: ".$recv.", part1: ";
                        echo "".$sent."},";
                        }
                        ?>

                    ];
                    
                    $("#pageviews-visitors-chart").dxChart({
                        dataSource: line_chart_data_source,
                        commonSeriesSettings: {
                            argumentField: "id",
                            point: { visible: true, size: 5, hoverStyle: {size: 7, border: 0, color: 'inherit'} },
                            line: {width: 1, hoverStyle: {width: 1}}
                        },
                        series: [
                            { valueField: "part1", name: "下载", color: "#68b828" },
                            { valueField: "part2", name: "上传", color: "#cdedb3" },
                        ],
                        legend: {
                            position: 'inside',
                            paddingLeftRight: 5
                        },
                        commonAxisSettings: {
                            label: {
                                visible: false
                            },
                            grid: {
                                visible: true,
                                color: '#f9f9f9'
                            }
                        },
                        valueAxis: {
                            max: 100
                        },
                        argumentAxis: {
                            valueMarginsEnabled: false
                        },
                    });
                    
                    
                    
                    // CPU Usage Gauge
                    $("#cpu-usage-gauge").dxCircularGauge({
                        scale: {
                            startValue: 0,
                            endValue: 100,
                            majorTick: {
                                tickInterval: 10
                            }
                        },
                        rangeContainer: {
                            palette: 'pastel',
                            width: 3,
                            ranges: [
                                { startValue: 0, endValue: 25, color: "#68b828" },
                                { startValue: 25, endValue: 50, color: "#68b828" },
                                { startValue: 50, endValue: 75, color: "#68b828" },
                                { startValue: 75, endValue: 100, color: "#d5080f" },
                            ],
                        },

                        <?php //echo $DB->
                        //在线人数接口
                        $str=file_get_contents('../res/openvpn-status.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
                        $onlinenum2 = (int)((substr_count($str,date('Y'))-1)/2);
                        $tj = round($onlinenum2/$count2*100);
                        ?>
                        value: <?php echo $tj; ?>,
                        valueIndicator: {
                            offset: 10,
                            color: '#68b828',
                            type: 'rectangleNeedle',
                            spindleSize: 12
                        }
                    });
                    

                    
                });
                

                         <?php //echo $DB->
                        //在线人数接口
                        $str=file_get_contents('../udp/openvpn-status2.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
                        $onlinenum2 = (int)((substr_count($str,date('Y'))-1)/2);
                        $tj1 = round($onlinenum2/$count2*100);
                        ?>
                        value: <?php echo $tj1; ?>,
                        valueIndicator: {
                            offset: 10,
                            color: '#68b828',
                            type: 'rectangleNeedle',
                            spindleSize: 12
                        }
                    });
                    

                    
                });               

                
                function between(randNumMin, randNumMax)
                {
                    var randInt = Math.floor((Math.random() * ((randNumMax + 1) - randNumMin)) + randNumMin);
                    
                    return randInt;
                }
            </script>					
                  <div class="panel panel-default">
                     <div class="panel-body">
                        <a href="#" class="text-muted pull-right">
                           <em class="fa fa-arrow-right"></em>
                        </a>
                        <div class="text-info">当前TCP在线人数</div>
                        <canvas data-classyloader="" data-percentage="<?php echo $tj; ?>" data-speed="20" data-font-size="40px" data-diameter="70" data-line-color="#23b7e5" data-remaining-line-color="rgba(200,200,200,0.4)" data-line-width="10"
                        data-rounded-line="true" class="center-block"></canvas>
                        
                     </div>
                     <div class="panel-footer">
                        <p class="text-muted">
                           <em class="fa fa-upload fa-fw"></em>
                           <span>当前TCP在线人数：</span>
                           <span class="text-dark"><?php //echo $DB->
                                            //在线人数接口
                                            $str=file_get_contents('../res/openvpn-status.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
                                            echo $onlinenum = (int)((substr_count($str,date('Y'))-1)/2);
                                            ?>个</span>
                        </p>
                     </div>
                  </div>
                  <!-- END loader widget-->
               </div>
               <div class="col-lg-3">
                  <!-- START loader widget-->
                  <div class="panel panel-default">
                     <div class="panel-body">
                        <a href="#" class="text-muted pull-right">
                           <em class="fa fa-arrow-right"></em>
                        </a>
                        <div class="text-info">当前UDP在线人数</div>
                        <canvas data-classyloader="" data-percentage="<?php echo $tj1; ?>" data-speed="20" data-font-size="40px" data-diameter="70" data-line-color="#23b7e5" data-remaining-line-color="rgba(200,200,200,0.4)" data-line-width="10"
                        data-rounded-line="true" class="center-block"></canvas>
                        
                     </div>
                     <div class="panel-footer">
                        <p class="text-muted">
                           <em class="fa fa-upload fa-fw"></em>
                           <span>当前UDP在线人数：</span>
                           <span class="text-dark"><?php //echo $DB->
                                            //在线人数接口
                                            $str=file_get_contents('../udp/openvpn-status2.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
                                            echo $onlinenum = (int)((substr_count($str,date('Y'))-1)/2);
                                            ?>个</span>
                        </p>
                     </div>
                  </div></div>
                  <!-- END loader widget-->
                     <div class="col-lg-6">
                        <div class="panel panel-default">
                           <div class="panel-heading">
                              <div class="panel-title">官方公告</div>
                           </div>
                           <!-- START list group-->
                           <div data-height="249" data-scrollable="" class="list-group">
                              <!-- START list group item-->
							  <?php 
                         $url = "http://www.7kml.com/gonggao/"; 
                         $contents = file_get_contents($url); 
                         //如果出现中文乱码使用下面代码 
                         //$getcontent = iconv("gb2312", "utf-8",$contents); 
                         echo $contents; 
                         ?>

                           </div>
                           <!-- END list group-->

                        </div>
                     </div>
                  </div>
               </div>
               <!-- END dashboard main content-->
      </section>          
           <?php include("../copy.php");?>
