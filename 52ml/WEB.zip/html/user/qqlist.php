<?php
require_once ("head.php");
$title = '主界面 / QQ管理';
if ($row['active'] != 1) {
    msg("权限不足！", "/user");
}
$qid=is_numeric($_GET['qid'])?$_GET['qid']:'0';
$page = is_numeric($_GET['page']) ? $_GET['page'] : '1';
if ($_GET['do'] == 'delete') {
		$DB->query("delete from " . DBQZ . "_qq where qid='$qid'");
        msg("删除QQ成功", "qqlist.php");
}
$pagein = $page + 8;
$pagesize = 20;
$start = ($page - 1) * $pagesize;
if ($_GET['do'] == 'search' && $content = $_GET['content']) {
    $pagedo = 'seach';
    $rows = $DB->query("select * from " . DBQZ . "_qq where uid='{$content}' or qid like'%{$content}%' or uin like'%{$content}%' order by (case when uid='{$content}' then 8 else 0 end)+(case when qid like '%{$content}%' then 3 else 0 end)+(case when uin like '%{$content}%' then 3 else 0 end) desc limit 20");
} else {
    $pages = ceil($DB->count("select count(uid) as count from " . DBQZ . "_qq where 1=1") / $pagesize);
    $rows = $DB->query("select * from " . DBQZ . "_qq order by uid desc limit $start,$pagesize");
}
if ($pagein > $pages) $pagein = $pages;
if ($page == 1) {
    $prev = 1;
} else {
    $prev = $page - 1;
}
if ($page == $pages) {
    $next = $page;
} else {
    $next = $page + 1;
}
?>
<section id="content">
<section class="vbox">
<section class="scrollable padder">
<ul class="breadcrumb no-border no-radius b-b b-light pull-in">
	<li><a href="#"><i class="fa fa-home"></i> <?php echo $title ?></a></li>
</ul>
			<div class="col-lg-2-4 navbar-right">
                  			<form action="?" method="GET">
			<div class="input-group">
				<input type="hidden" name="do" value="search">
				<input type="text" name='content' class="form-control" placeholder="Search">
				<span class="input-group-btn">
                  <button type="submit" class="btn btn-info btn-icon"><i class="fa fa-search"></i></button>
                </span>
				</div>
			</form>
              </div>
			<h3 class="page-header">用户列表</h3>
			<div class="table-responsive">
				<table class="table table-striped m-b-none" data-ride="datatables">
				<thead>
				<tr>
					<th>#UID</th>
					<th>#QID</th>
					<th>账号</th>
					<th>添加时间</th>
					<th>操作</th>
				</tr>
				</thead>
				<tbody>
				<?php
while ($qq = $DB->fetch($rows)) { ?>
				<tr>
					<td><?php echo $qq['uid'] ?></td>
					<td><?php echo $qq['qid'] ?></td>
					<td><?php echo $qq['uin'] ?></td>
					<td><?php echo $qq['addtime'] ?></td>
					<td><a href="?do=delete&p=<?=$p?>&qid=<?=$qq['qid']?>" onClick="if(!confirm('确认删除？')){return false;}" class="dropdown-toggle"><i class="fa fa-times"></i></a></td>
				</tr>
<?php
} ?>
				</tbody>
				</table>
			</div>
			<?php
if ($pagedo != 'seach') { ?>
			<div class="row" style="text-align:center;">
				<ul class="pagination pagination-lg">
					<li <?php
    if ($page == 1) {
        echo 'class="disabled"';
    } ?>><a href="?page=1">首页</a></li>
					<li <?php
    if ($prev == $page) {
        echo 'class="disabled"';
    } ?>><a href="?page=<?php echo $prev ?>">&laquo;</a></li>
					<?php
    for ($i = $page; $i <= $pagein; $i++) { ?>
					<li <?php
        if ($i == $page) {
            echo 'class="active"';
        } ?>><a href="?page=<?php echo $i ?>"><?php echo $i ?></a></li>
					<?php
    } ?>
					<li <?php
    if ($next == $page) {
        echo 'class="disabled"';
    } ?>><a href="?page=<?php echo $next ?>">&raquo;</a></li>
					<li <?php
    if ($page == $pages) {
        echo 'class="disabled"';
    } ?>><a href="?page=<?php echo $pages ?>">末页</a></li>
				</ul>
			</div>
			<?php
} ?>
</section>
</section>
<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a></section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
<div class="wrapper">
	Notification
</div>
</aside>
<!-- end -->
<?php
require_once ("foot.php");
?>
