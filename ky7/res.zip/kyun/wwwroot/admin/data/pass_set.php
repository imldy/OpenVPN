<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：修改管理员账号密码
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

if($is_login == 'ok'){
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>高级管理 - 修改密码</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
                      <div class="col-sm-12">
			<div class="ibox-mulu">
          <h3> &nbsp;&nbsp; <i class="fa fa-user-md fa-lg"></i> 高级管理 > 修改密码</h3>
            </div>
			   <br>	
<?php
if($_POST['setpass']=="ok"){
// 双MD5加密
$uA = md5(daddslashes($_POST['user']));
$user = md5($uA);
$pA = md5(daddslashes($_POST['pass']));
$pass = md5($pA);
if(db('ky_gl')->where(array())->update(array('username'=>u.$user,'password'=>p.$pass))){
      file_put_contents("/kyun/admin_twopass.key",$_POST['twopass']); 	
      echo Skip('修改密码',success);
  }else{
      echo Skip('修改密码',error);
  }
exit;
}
?>
                 <div class="ibox">
                   <div class="ibox-content">		
                        <form action="./pass_set.php" method="post" class="form-horizontal m-t">
						 <input type="hidden" name="setpass" value="ok" />
						 
						    <div class="form-group has-success"> 
                                <label class="col-sm-2 control-label">管理员账号：</label>
                                <div class="col-sm-8">
                                    <input name="user" placeholder="请输入新账号" class="form-control" type="text">
                                 </div>
								</div>
							 <div class="hr-line-dashed"></div>
							 
							 <div class="form-group has-error">
                                <label class="col-sm-2 control-label">管理员密码：</label>
                                <div class="col-sm-8">
                                    <input name="pass" placeholder="请输入新密码" class="form-control" type="text">
                                </div>
							  </div>
							   <div class="hr-line-dashed"></div>
							   
							 <div class="form-group has-warning">
                                <label class="col-sm-2 control-label">本地二级密码：</label>
                                <div class="col-sm-8">
                                    <input name="twopass" placeholder="请输入新二级密码" class="form-control" type="text">
                                </div>
							  </div>
							 <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-6 col-sm-offset-2">
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                                </div>
                            </div>
                        </form>					
                    </div>
                </div>
            </div>
        </div>

    </div>
    
</body>

</html>
<?php
}else{ 
    exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
}
?>