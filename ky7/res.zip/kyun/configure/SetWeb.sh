#!/bin/bash
# 修改WEB端口
  read weba < <(netstat -ntlp|grep httpd|awk '{print $4}') # 获取httpd端口
  webb=${weba/:::/}
  webdk=${webb/0.0.0.0:/}
  sed -i 's/'$webdk'/'$1'/g' /etc/httpd/conf/httpd.conf
  read has < <(cat /etc/sysconfig/iptables | grep "dport $2 -j ACCEPT" ) #是否已放行端口
  if [ -z "$has" ];then
    iptables -A INPUT -p tcp -m tcp --dport $1 -j ACCEPT
    service iptables save >/dev/null 2>&1
  fi
  systemctl restart httpd.service
  echo 'ok'
 exit 0