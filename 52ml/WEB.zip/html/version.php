<?php
return array (
  'ver' => '1.7',
  'release' => '20160512',
  'vername' => '变脸狗控流 QQ:1356935605商业版',
);
?>