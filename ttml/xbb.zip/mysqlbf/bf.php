<?php 

$LCHOST = 'localhost';       //填写你的数据库地址
$LCNAME = 'ov';              //填写你的数据库名
$HSNAME = 'root';            //填写你的数据库账号
$HSWORD = 'root';            //填写你的数据库密码
$mysqlname = date('Y-m-d-H:i:s');


$command = "mysqldump -h$LCHOST -u$HSNAME -p$HSWORD $LCNAME >$mysqlname.sql";

system($command);//执行命令

echo date('Y-m-d-H:i:s').'成功备份数据库文件';

?> 