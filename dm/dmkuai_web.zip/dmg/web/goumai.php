<?php
$mod='blank'; 
include("api.inc.php");
$rs=$DB->get_row("SELECT * FROM auth_config");
$shopUrl_con=$rs['shopUrl'];
//echo "<script language='javascript'>window.location.href=".$shopUrl_con.";</script>";
//echo $shopUrl_con;
header("location: ".$shopUrl_con."");
?>