<?php
/*数据库配置*/
$host = "localhost"; //MYSQL主机
$port = 3306; //MYSQL主机
$user = "root"; //MYSQL用户
$pwd ="xyrsql"; //MYSQL密码
$dbname = "mydata"; //数据库名
//***提示：管理员账号和密码请登录流控后台后在后台修改！***
