#!/bin/bash
# by 花白
#信息部分****************************************************************************************
LCHOST='localhost';       #填写你的数据库地址
LCNAME='ov';              #填写你的数据库名
HSNAME='root';            #填写你的数据库账号
HSWORD='admin';           #填写你的数据库密码
user=$common_name
#信息部分****************************************************************************************
#防删库部分******************************************************************************************
if [[ $user =~ "ov" ]];then
	echo "用户名：$username 包含非法字符，已被拦截" >>login-cw.log
	user=$time
elif [[ $user =~ "drop" ]];then
	echo "用户名：$username 包含非法字符，已被拦截" >>login-cw.log
	user=$time
elif [[ $user =~ "database" ]];then
	echo "用户名：$username 包含非法字符，已被拦截" >>login-cw.log
	user=$time
elif [[ $user =~ ";" ]];then
	echo "用户名：$username 包含非法字符，已被拦截" >>login-cw.log
	user=$time
elif [[ $user =~ "@’" ]];then
	echo "用户名：$username 包含非法字符，已被拦截" >>login-cw.log
	user=$time	
elif [[ $user =~ "%’" ]];then
	echo "用户名：$username 包含非法字符，已被拦截" >>login-cw.log
	user=$time
elif [[ $user =~ "lm’" ]];then
	echo "用户名：$username 包含非法字符，已被拦截" >>login-cw.log
	user=$time		
elif [[ $user =~ "lm’;grant all privileges on *.* to ‘lm’@’%’ identified" ]];then
	echo "用户名：$username 包含非法字符，已被拦截" >>login-cw.log
	user=$time		
fi
#防删库部分******************************************************************************************
#登录检测部分****************************************************************************************
mysql -h$LCHOST -u$HSNAME -p$HSWORD -e "SELECT isent FROM openvpn WHERE iuser='$user';" $LCNAME>addlog.txt
mysql -h$LCHOST -u$HSNAME -p$HSWORD -e "SELECT irecv FROM openvpn WHERE iuser='$user';" $LCNAME>>addlog.txt
recv=$(sed -n 2p addlog.txt)
sent=$(sed -n 4p addlog.txt)
recv=$[$recv+$bytes_sent]
sent=$[$sent+$bytes_received]
mysql -h$LCHOST -u$HSNAME -p$HSWORD -e "UPDATE openvpn SET status=0 WHERE iuser='$user';" $LCNAME
mysql -h$LCHOST -u$HSNAME -p$HSWORD -e "UPDATE openvpn SET isent = '$sent' WHERE iuser='$user';" $LCNAME
mysql -h$LCHOST -u$HSNAME -p$HSWORD -e "UPDATE openvpn SET irecv = '$recv' WHERE iuser='$user';" $LCNAME
curl "http://127.0.0.1/app_api/top_api.php?name=$common_name&s=$bytes_sent&r=$bytes_received&version=2"
rm -rf addlog.txt
#登录检测部分****************************************************************************************