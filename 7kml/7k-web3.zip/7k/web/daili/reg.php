<?php 
$mod = 'blank';
include('../api.inc.php');
$dlconfig = $DB->get_row('SELECT * FROM auth_config WHERE id='."'{$site_id}'");
$tj_user = $_REQUEST['tj_user'];
if (isset($_POST['user']) && isset($_POST['pass'])) {//JXL_add for 2016-04-16 begin
	$tj_user = $_REQUEST['tj_user_c'];//echo "<script language='javascript'>alert('".$tj_user."');</script>";
//JXL_add for 2016-04-16 end
	$user = daddslashes($_POST['user']);
	$pass = daddslashes($_POST['pass']);
	$name = daddslashes($_POST['name']);
	$tel = daddslashes($_POST['tel']);
	$qq = daddslashes($_POST['qq']);
	$verifycode = daddslashes($_POST['verifycode']);
	$row = $DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
	$dlid = $row['id'];
	if ($dlconfig['regok'] == 0) {
		if ($row['active'] == '0' || $dlid <> '') {
			exit('<script language=\'javascript\'>alert(\'代理用户已经注册但未激活，请联系管理员激活！\');window.location.href=\'./login.php\';</script>');
		}
		if ($user && $pass) {
			if (!is_username($user)) {
				exit('<script language=\'javascript\'>alert(\'用户名只能是2~20位的字母数字！\');history.go(-1);</script>');
			} elseif (!$verifycode || $verifycode != $_SESSION['verifycode']) {
				exit('<script language=\'javascript\'>alert(\'验证码不正确！\');history.go(-1);</script>');
			} elseif ($dlconfig['activeok'] == 0) {/*JXL_add for 2016-04-16
            $DB->query("insert `auth_daili`(`id`,`user`,`pass`,`rmb`,`vip`,`kmlist`,`active`,`regdate`) values(null,'$user','$pass','0',0,null,1,'$date');");
            */
				$DB->query("insert `auth_daili`(`id`,`tj_user`,`user`,`pass`,`rmb`,`vip`,`kmlist`,`active`,`regdate`,`name`,`tel`,`qq`) values(null,'$tj_user','$user','$pass','0',0,null,1,'$date','$name','$tel','$qq');");
				$row = $DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");//赠送金额给推荐人
				$rs = $DB->get_row('SELECT * FROM auth_config where id='."'{$site_id}'");
				$daili_cash_con = $rs['daili_cash'];
				$rs2 = $DB->get_row("SELECT * FROM auth_daili where `user`='{$tj_user}'");
				$tj_rmb = round($rs2['tj_rmb'] + $daili_cash_con);//echo "<script language='javascript'>alert('返现为：".$daili_cash_con."');</script>";
//echo "<script language='javascript'>alert('该代理已有的返现金额：".$tj_rmb."');</script>";
//echo "<script language='javascript'>alert('加起来".$tj_rmb."');</script>";
				$sql = $DB->query("update `auth_daili` set `tj_rmb`='$tj_rmb' where `user`='{$tj_user}'");
				if ($row['id']) {
					unset($_SESSION['verifycode']);
					exit('<script language=\'javascript\'>alert(\'注册成功，账号已经激活，请联系管理员充值使用！\');window.location.href=\'./login.php\';</script>');
				} else {
					exit('<script language=\'javascript\'>alert(\'注册失败，请联系管理员！\');history.go(-1);</script>');
				}
			} else {/*JXL_add for 2016-04-16
            $DB->query("insert `auth_daili`(`id`,`user`,`pass`,`rmb`,`vip`,`kmlist`,`active`,`regdate`) values(null,'$user','$pass','0',0,null,0,'$date');");
            */
				$DB->query("insert `auth_daili`(`id`,`tj_user`,`user`,`pass`,`rmb`,`vip`,`kmlist`,`active`,`regdate`,`name`,`tel`,`qq`) values(null,'$tj_user','$user','$pass','0',0,null,1,'$date','$name','$tel','$qq');");
				$row = $DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
				if ($row['id']) {
					unset($_SESSION['verifycode']);
					exit('<script language=\'javascript\'>alert(\'注册成功，请联系管理员激活！\');window.location.href=\'./login.php\';</script>');
				} else {
					exit('<script language=\'javascript\'>alert(\'注册失败，请联系管理员！\');history.go(-1);</script>');
				}
			}
		}
	} else {
		exit('<script language=\'javascript\'>alert(\'网站已经关闭注册，请联系管理员注册！\');window.location.href=\'./login.php\';</script>');
	}
}
$title = '代理注册';
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body>
			
				<script type="text/javascript">
					jQuery(document).ready(function($)
					{
						// Reveal Login form
						setTimeout(function(){ $(".fade-in-effect").addClass(\'in\'); }, 1);
						
						
						// Validation and Ajax action
						$("form#login").validate({
							rules: {
								user: {
									required: true
								},
								
								pass: {
									required: true
								},
								
								verifycode: {
									required: true
								}
							},
							
							messages: {
								user: {
									required: \'此为必填项！\'
								},
								
								pass: {
									required: \'此为必填项！\'
								},
								
								verifycode: {
									required: \'请填写！\'
								}
							},
							
						});
						
						// Set Form focus
						$("form#login .form-group:has(.form-control):first .form-control").focus();
					});
				</script>
				
   <div class="wrapper">
      <div class="block-center mt-xl wd-xl">
         <!-- START panel-->
         <div class="panel panel-dark panel-flat">
            <div class="panel-heading text-center">
               <a href="#">
                  <img src="../assets/img/logo.png" alt="Image" class="block-center img-rounded">
               </a>
            </div>
            <div class="panel-body">
               <p class="text-center pv"><?php
  $rs=$DB->get_row("SELECT * FROM website");
  $webtitle=$rs['title'];
   echo $webtitle
    ?></p> 
				<form action="./reg.php?tj_user_c=<?php echo $tj_user;?>" method="post" role="form" id="login" class="login-form fade-in-effect">
					

	
					
					<div class="loginbox-textbox">
						<label class="text-muted">请输入您的帐号</label>
						<input type="text" class="form-control" name="user" id="user" placeholder="请输入您的帐号" autocomplete="off" />
					</div>
					
					<div class="loginbox-textbox">
						<label class="text-muted">请输入您的密码</label>
						<input type="password" class="form-control" name="pass" id="pass" placeholder="请输入您的密码" autocomplete="off" />
					</div>
					<div class="loginbox-textbox">
						<label class="text-muted">请输入您的昵称</label>
						<input type="text" id="name" name="name" class="form-control" placeholder="请输入您的昵称" required="required"/>
							
					</div>

					<div class="loginbox-textbox">
						<label class="text-muted">请输入您的电话</label>
						<input type="text" id="tel" name="tel" class="form-control" placeholder="请输入您的电话" required="required"/>
							
					</div>
					
					<div class="loginbox-textbox">
						<label class="text-muted">请输入您的QQ</label>
						<input type="text" id="qq" name="qq" class="form-control" placeholder="请输入您的QQ" required="required"/>
							
					</div>

					<div class="loginbox-textbox">
		            	<label class="text-muted">验证码信息</label><img title="点击刷新" src="../verifycode.php" onclick="this.src=\'../verifycode.php?\'+Math.random();" style="max-height:32px;vertical-align:middle;" class="img-rounded">
		            	<input type="text" id="verifycode" name="verifycode" class="form-control" placeholder="验证码" required="required"/>
		            </div>
					
						<button type="submit" class="btn btn-block btn-primary mt-lg">
							立即注册
						</button>
               <p class="pt-lg text-center">已有账号？立即登录！</p><a href="login.php" class="btn btn-block btn-default">立即登录</a>
            </div>						
					
				</form>
				

				</div>
				
			</div>


         <div class="p-lg text-center">
            <span>&copy;</span>
            <span>2016</span>
            <span>-</span>
            <span><?php
  $rs=$DB->get_row("SELECT * FROM website");
  $webtitle=$rs['title'];
   echo $webtitle
    ?></span>
         </div>
      </div>
   </div>

   <script src="../assets/modernizr/modernizr.custom.js"></script>
   <script src="../assets/jquery/dist/jquery.js"></script>
   <script src="../assets/bootstrap/dist/js/bootstrap.js"></script>
   <script src="../assets/jQuery-Storage-API/jquery.storageapi.js"></script>
   <script src="../assets/parsleyjs/dist/parsley.min.js"></script>
   <script src="../assetsjs/app.js"></script>
</body>
</html>