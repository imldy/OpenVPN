#!/bin/bash
name=$1
rm -rf /etc/$name
echo '#浩天流控官网：www.haotml.com
#浩天流控系统屏蔽host文件' >> /etc/$name && chmod 777 /etc/$name