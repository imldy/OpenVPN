<?php
/**
 * 凌云免流管理中心
 * by 天木兮 2018年10月15日
 */
include("../../Data/api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='../Lyun/index.php';</script>");
function secsToStr($secs) {
    if($secs>=86400){$days=floor($secs/86400);
    $secs=$secs%86400;
    $r=$days.'天 ';}
    if($secs>=3600){$hours=floor($secs/3600);
    $secs=$secs%3600;
    $r.=$hours.'小时 ';}
    if($secs>=60){$minutes=floor($secs/60);
    $secs=$secs%60;
    $r.=$minutes.'分钟 ';}
    $r.=$secs.'秒 ';
    return $r;
} 
$onlinenumtcp = $DB->count("SELECT count(*) from `openvpn` WHERE `online`='1'&&`xieyi`='tcp-server'");
$onlinenumudp = $DB->count("SELECT count(*) from `openvpn` WHERE `online`='1'&&`xieyi`='udp'");
$numrows = $onlinenumtcp+$onlinenumudp;
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>实时监控 - 在线检测</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    
	<script src="../../assets/js/jquery.min.js"></script>
	<script src="../../assets/js/bootstrap.min.js"></script>
    <!-- Data Tables -->
    <link href="../../assets/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">

    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>实时监控 >><small>在线检测</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
                        <div class="">
                            <a href="./add_user.php" class="btn btn-primary ">添加新用户</a>
				     <?php echo '<a href="#" class="btn btn-info"><b>TCP有',$onlinenumtcp,'人在线</b></a>
					 <a href="#" class="btn btn-warning"><b>UDP有',$onlinenumudp,'人在线</b></a>';?>
                        </div>
                         <div class="table-responsive">
                           <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th class="text-center">用户名</th>
									<th class="text-center">协议</th>
									<th class="text-center">剩余流量</th>
                                    <th class="text-center">用户链接地址</th>
									<th class="text-center">来自地区</th>
									<th class="text-center">连接设备</th>
									<th class="text-center">连接的线路</th>
									<th class="text-center">开始时间</th>
									<th class="text-center">已连接时间</th>
									<th class="text-center">管理操作</th>
                                </tr>
                            </thead>
							 </tbody>  
<?php
$pagesize=40;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
$rs=$DB->query("SELECT * FROM `openvpn` WHERE `online`='1' order by id desc limit $offset,$pagesize");
while($res = $DB->fetch($rs)){
if($res['xieyi']=='tcp-server'){
$xy='TCP';	$ys='primary';
if($res['remote_port']=='666'){
  $outdk='7506';	
}elseif($res['remote_port']=='1194'){
  $outdk='7507';	
}elseif($res['remote_port']=='443'){
  $outdk='7508';	
 }else{
  $outdk='7509'; 
}
}else{
$xy='UDP';	$ys='warning';
if($res['remote_port']=='53'){
$outdk='7504';
}else{
$outdk='7505';	
}}
$login = time()-$res['login_time'];
$output = secsToStr($login);
$row = $DB->get_row("select * from `line` where id='{$res['line_id']}'")
?>
<tr>
<td class="text-center"><?=$res['iuser']?></td>
<td class="text-center"><span class="label label-<?=$ys?>"><?=$xy.' '.$res['remote_port']?></span></td>
<td class="text-center"><?=round(($res['maxll']-$res['isent']-$res['irecv'])/1024/1024)?> MB</td>
<td class="text-center"><?=$res['last_ip'].':'.$res['remote_port'];?></td>
<td class="text-center"><?=$res['area'],$res['isp']?></td>
<td class="text-center"><?=$res['client']?></td>
<td class="text-center"><?=$row['name']?></td>
<td class="text-center"><?=date("Y-m-d h:i:s",$res['login_time'])?></td>
<td class="text-center"><?=$output?></td>
<td class="text-center"><a class="btn btn-xs btn-success" href="./uesr_set.php?user=<?php echo $res['iuser']?>">查看</a>&nbsp;
	<button class="btn btn-warning btn-xs" data-toggle="modal" data-target="#user_xsu" onclick="UserXsu('<?php echo $res['iuser']?>')">限速</button>&nbsp;
<a class="btn btn-danger btn-xs" onclick="if(!confirm('暂只能强制下线本机在线用户,你确定要强制他下线吗？')){return false;};Outline('<?php echo $res['iuser'];?>',<?php echo $outdk;?>)">踢出</a></td>
<?php }
                                            ?>
                            </tbody>
                        </table>
                    </div>
<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="online_list.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="online_list.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="online_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="online_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="online_list.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="online_list.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
?>
				</div>
                </div>
            </div>
        </div>
    </div>
<!-- 模态框（Modal） -->
<div class="modal fade" id="user_xsu" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
					&times;
				</button>
				<h4 class="modal-title">
			  用户限速 <small id="myModalLabel"></small>
			</h4>
			</div>
			<div class="modal-body">
				<div id="xinxi" class="form-group">
                  <label for="name">请输入用户限速值(单位/KB)</label><br>
					<input id="zhi" class="form-control" value="10240" style="border-radius:6px;"/> 
				</div>
			  <p>注:暂只能对本机用户进行限速，操作成功请重启vpn</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">
				   Close
				</button>
				<button onclick="Xsu()" class="btn btn-primary">
					保持内容
				</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal -->
</div>
<!-- 模态框（Modal）end --> 
</body>
<script>
var username = 0;

function Xsu(){
	var content = $("#zhi").val();
	$.post(
			'GetNet.php?act=xsu',
			{
				'user':username,
				'zhi':content
			},function(data){
				if(data.status == 'success'){
				  $('#user_xsu').modal('hide');
				    alert("为用户"+username+"限速 "+content+"KB成功");
				}else{
					alert(data.msg);
				}
			},"JSON");
    }
	
function UserXsu(user){
    $("#myModalLabel").html(user);
    username =	user;
}

function Outline(user,opdk){
	$.get(
			'GetNet.php',
			{    
			    'act':'outline',
				'user':user,
				'opdk':opdk
			},function(data){
				if(data.status == 'success'){
				    alert("强制用户"+user+"下线成功");
				}else{
					alert(data.msg);
				}
			},"JSON");
    }
</script>
</html>
