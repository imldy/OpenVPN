-- phpMyAdmin SQL Dump
-- version 4.4.15.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2016-09-17 01:20:42
-- 服务器版本： 5.5.52
-- PHP Version: 5.4.45

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- 表的结构 `lyj_article`
--

CREATE TABLE IF NOT EXISTS `lyj_article` (
  `id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '无题',
  `content` text NOT NULL,
  `visit_count` int(10) unsigned NOT NULL DEFAULT '0',
  `timeline` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='文章表';

-- --------------------------------------------------------

--
-- 表的结构 `lyj_category`
--

CREATE TABLE IF NOT EXISTS `lyj_category` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT '默认栏目',
  `description` varchar(255) NOT NULL DEFAULT '栏目简介',
  `sortby` int(5) NOT NULL DEFAULT '0',
  `hidden` int(2) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='栏目表';

--
-- 转存表中的数据 `lyj_category`
--

INSERT INTO `lyj_category` (`id`, `name`, `description`, `sortby`, `hidden`) VALUES
(1, '移动', '', 1, 0),
(2, '联通', '', 2, 0),
(3, '电信', '', 3, 0);

-- --------------------------------------------------------

--
-- 表的结构 `lyj_link`
--

CREATE TABLE IF NOT EXISTS `lyj_link` (
  `id` int(8) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `name` varchar(200) NOT NULL DEFAULT '链接名称',
  `description` varchar(255) NOT NULL DEFAULT '链接简介',
  `url` varchar(255) NOT NULL DEFAULT 'http://',
  `icon` varchar(255) NOT NULL DEFAULT 'http://',
  `sortby` int(5) NOT NULL DEFAULT '0',
  `hidden` int(2) NOT NULL DEFAULT '0',
  `timeline` int(8) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='友链表';

--
-- 转存表中的数据 `lyj_link`
--

LOCK TABLES `lyj_link` WRITE;
/*!40000 ALTER TABLE `lyj_link` DISABLE KEYS */;
INSERT INTO `lyj_link` VALUES (1,1,'流控地址','我的加速器我做主','http://IPAddress:88/','http://www.baidu.com/',1,0,0),(2,1,'卡密地址','链接简介','http://IPAddress:88','.',0,0,1471028321),(3,1,'官方商城','链接简介','http://ip:port/','.',2,0,1471029048),(4,1,'使用说明','链接简介','http://ip:port/index.html','.',3,0,1471029100),(5,1,'背景图片','链接简介','http://图片','.',4,0,1471029221),(6,1,'淘口令','链接简介','http://sd','.',5,0,1471029271);
/*!40000 ALTER TABLE `lyj_link` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------

--
-- 表的结构 `lyj_setting`
--

CREATE TABLE IF NOT EXISTS `lyj_setting` (
  `id` int(10) unsigned NOT NULL,
  `skey` varchar(100) NOT NULL DEFAULT '要设置的键',
  `sval` varchar(1024) NOT NULL DEFAULT '要设置的值'
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='设置表';

--
-- 转存表中的数据 `lyj_setting`
--

INSERT INTO `lyj_setting` (`id`, `skey`, `sval`) VALUES
(1, 'contact', 'QQnumber'),
(2, 'seo_title', 'QQkey'),
(3, 'seo_keywords', 'http://www.baidu.com/1.jpg'),
(4, 'seo_description', '河南移动用户今天请更新线路'),
(5, 'copyright', 'http://IPAddress:88/');

-- --------------------------------------------------------

--
-- 表的结构 `lyj_token`
--

CREATE TABLE IF NOT EXISTS `lyj_token` (
  `id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `token` varchar(32) NOT NULL,
  `expire_timeline` int(10) NOT NULL,
  `update_timeline` int(10) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='登录令牌表';

--
-- 转存表中的数据 `lyj_token`
--

INSERT INTO `lyj_token` (`id`, `user_id`, `token`, `expire_timeline`, `update_timeline`) VALUES
(1, 1, 'md5Toeken', 1473619585, 1473619585);

-- --------------------------------------------------------

--
-- 表的结构 `lyj_user`
--

CREATE TABLE IF NOT EXISTS `lyj_user` (
  `id` int(10) unsigned NOT NULL,
  `account` varchar(15) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `nick` varchar(15) NOT NULL,
  `face` varchar(255) DEFAULT NULL,
  `sex` int(2) DEFAULT '0',
  `device_id` varchar(20) NOT NULL,
  `is_forbidden` int(10) NOT NULL DEFAULT '0',
  `is_app` int(2) DEFAULT '0',
  `timeline` int(10) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='用户表';

--
-- 转存表中的数据 `lyj_user`
--

INSERT INTO `lyj_user` (`id`, `account`, `password`, `nick`, `face`, `sex`, `device_id`, `is_forbidden`, `is_app`, `timeline`) VALUES
(1, 'admin', 'SuperPass', '管理员', '', 1, '1163844562', 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lyj_article`
--
ALTER TABLE `lyj_article`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `title` (`title`);

--
-- Indexes for table `lyj_category`
--
ALTER TABLE `lyj_category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `lyj_link`
--
ALTER TABLE `lyj_link`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `url` (`url`);

--
-- Indexes for table `lyj_setting`
--
ALTER TABLE `lyj_setting`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `skey` (`skey`);

--
-- Indexes for table `lyj_token`
--
ALTER TABLE `lyj_token`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `lyj_user`
--
ALTER TABLE `lyj_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `account` (`account`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `lyj_article`
--
ALTER TABLE `lyj_article`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `lyj_category`
--
ALTER TABLE `lyj_category`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `lyj_link`
--
ALTER TABLE `lyj_link`
  MODIFY `id` int(8) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `lyj_setting`
--
ALTER TABLE `lyj_setting`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `lyj_token`
--
ALTER TABLE `lyj_token`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `lyj_user`
--
ALTER TABLE `lyj_user`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
