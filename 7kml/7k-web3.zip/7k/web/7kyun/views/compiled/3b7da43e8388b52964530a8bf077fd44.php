﻿<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <meta name="Viewport" content="width=device-width, initial-scale=1, user-scalable=no"/>
    <meta name="MobileOptimized" content="480"/>
    <meta name="Author" content="<?php echo $author; ?>"/>
    <meta name="robots" content="allow"/>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/mui.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/jquery.js"></script>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/default.js"></script>
    <title>请先登录</title>
    <link href="<?php echo $base_url; ?>/views/assets/css/mui.min.css" rel="stylesheet"/>
    <link href="<?php echo $base_url; ?>/views/assets/css/default.css" rel="stylesheet"/>
    <style type="text/css">
        .mui-content {
            padding: 10px;
            background: transparent;
        }

        .mui-input-group .mui-input-row::after {
            left: 0px;
        }

        .mui-btn {
            padding: 5px;
        }
    </style>
</head>

<body>
<noscript class="error">
    很遗憾，由于你的浏览器不支持或禁用了JavaScript，导致无法获得正常体验。
</noscript>
<header class="mui-bar mui-bar-nav">
    <h1 class="mui-title">登录</h1>
</header>
<div class="mui-content">
    <form id='login-form' class="mui-input-group">
        <div class="mui-input-row">
            <label>账号</label>
            <input id='userName' type="text" class="mui-input-clear mui-input" placeholder="请输入账号">
        </div>
        <div class="mui-input-row">
            <label>密码</label>
            <input id='userPass' type="password" class="mui-input-clear mui-input" placeholder="请输入密码">
        </div>
    </form>
    <div class="mui-content-padded">
        <button id='login' class="mui-btn mui-btn-block mui-btn-primary" onclick="login()">登录</button>
    </div>
    <div class="loader hide"></div>
</div>
<script type="text/javascript">
    function login() {
        var userName = jQuery.trim(jQuery("#userName").val());
        var userPass = jQuery.trim(jQuery("#userPass").val());
        if (userName == "") {
            alert("用户名不能为空！");
            //noinspection JSValidateTypes
            return false;
        } else if (userPass == "") {
            alert("密码不能为空！");
            //noinspection JSValidateTypes
            return false;
        }
        userName = encodeURIComponent(userName);
        userPass = encodeURIComponent(userPass);
        jQuery(".loader").show();
        jQuery.post("<?php echo $base_url; ?>/api.php?c=User&a=login", {
            account: userName,
            password: userPass
        }, function (result) {
            jQuery(".loader").hide();
            if (result.code == 1) {
                window.location = "<?php echo $base_url; ?>/smhoud.php?token=" + result.data;
            } else {
                alert(result.msg);
            }
        }, "json");
        //noinspection JSValidateTypes
        return false; // 阻止表单提交
    }
</script>
</body>

</html>
<!-- Created By Template Engineer At 2016/08/28,16:36 -->
