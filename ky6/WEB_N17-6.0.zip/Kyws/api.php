<?php
require('system.php');	
	$reg = db(auth_config)->where(array('id'=>'1'))->find();
	$kyun = db(kyun)->where(array())->find();
	if($_GET['act'] == 'user_spread'){
		include('api_head.php');
		include('mode/user.php');
	}elseif($_GET['act'] == 'app_check'){
		$data["status"] = "success";
	    $data["versionCode"] = $kyun['versionCode'];
	    $data["url"] = $kyun['url']; 
	    $data["content"] = $kyun['content'];
		die(json_encode($data));
	}elseif($_GET['act'] == 'pay'){
		include('api_head.php');
		include('mode/pay.php');
	}elseif($_GET['act'] == 'spread'){
		include('api_head.php');
		include('mode/spread.php');
	}elseif($_GET['act'] == 'line'){
		include('api_head.php');
		include('mode/note.php');
	}elseif($_GET['act'] == 'line2'){
	    include('api_head.php');
		include('mode/line.php');
	}elseif($_GET['act'] == 'reg_in'){
		$username = $_POST['username'];
		$password = $_POST['password'];
		$mail = $_POST['mail'];
		$tjuser = $_POST['tj_user'];	
		$tj = db(_openvpn_)->where(array(_iuser_=>$tjuser))->find();	
		if($tj){
		$tj_cs = $tj['tj_u'];
		$tj_kb = $tj['maxll']/1024/1024;
		}else{
		$tj_cs = 'no';	
		}
		if(trim($username) == '' || trim($password) == '' ){
			die(json_encode(array('status'=>'error','msg'=>'用户密码不能为空')));
		}

		if(!checkUsername($username)){
			die(json_encode(array('status'=>'error','msg'=>'用户名只能是英文和数字')));
		}
		if(!checkUsername($password)){
			die(json_encode(array('status'=>'error','msg'=>'密码只能是英文和数字')));
		}

		$db= db(_openvpn_);
		
		if($db->where(array(_iuser_=>$username))->find()){
			
			die(json_encode(array('status'=>'error','msg'=>'该账号已经注册过了哦')));
		}
		if($db->where(array('mail'=>$mail))->find()){
			
			die(json_encode(array('status'=>'error','msg'=>'该邮箱已经注册过了哦')));
		}else{
			if($_GET[dlapp]){
			$llv = 0;
            $lly = 0;
            $lli = 0;			
			}else{
			$llv = $reg[reg_cash];
            $lly = $reg[reg_endtime];
            $lli = 1;		
			}
			$date[_iuser_] = $username;
			$date[_ipass_] = $password;
			$date[_maxll_] = $llv*1024*1024;
			$date[_isent_] = '0';
			$date[_irecv_] = '0';
			$date[_i_] = $lli;
			$date[_starttime_] = SYSTEM_T;
			$date[_endtime_] = SYSTEM_T+($lly*24*60*60);
			$date["mail"] = $mail;
			
			$arr = explode(",",_other_);
			foreach($arr as  $v){
				$date[$v] = "";
			}
			if($db->insert($date,true)){
				if($tj_cs == 'no'){
				die(json_encode(array('status'=>'success','msg'=>'100')));
				}else{
				$la = $tj_kb+$reg['user_reg_cash'];
				$lb = $tj_cs+1;
				$lc = $la*1024*1024;
				db(_openvpn_)->where(array(_iuser_=>$tjuser))->update(array('maxll'=>$lc,'tj_u'=>$lb));
				die(json_encode(array('status'=>'success','msg'=>'100')));}
			}else{
				die(json_encode(array('status'=>'error','msg'=>'无法正常注册用户 请检查数据库')));
				
			}
			
		}
	}elseif($_GET['act'] == 'dx_reg'){
		include("api_head.php");
		if($_GET['dlapp']){
		    include("mode/app_reg.php");
		}else{
		if($reg['user_reg']=='1'){
			include("mode/mail_reg.php");
		  }else{
			include("mode/app_reg.php");  
		  }}
	}elseif($_GET['act'] == 'info'){
		include("api_head.php");
		include("mode/llog.php");
	}elseif($_GET['act'] == 'fank'){
		$user = $_POST['user'];
		$wang = $_POST['wang'];
		$diqu = $_POST['diqu'];
		$lineid = $_POST['id'];
	    $old = db("ky_fk")->where(array('user'=>$user))->order('id DESC')->find();
		 if($old){
				if(time()-$old["time"] < 60*30){
					die(json_encode(array("status"=>"old")));
				}
            }
		$fk = db("ky_fk")->insert(array('user'=>$user,'diqu'=>$diqu,'wang'=>$wang,'lid'=>$lineid,'time'=>time()));
		if($fk){
		die(json_encode(array('status'=>'success')));	
		}else{
		die(json_encode(array('status'=>'erorr','msg'=>'反馈失败，请骚后重新尝试')));	
		}
	}elseif($_GET['act'] == 'user_info'){
		header("location:user/index.php?user=".$_GET['username'].'&pass='.$_GET['password']);
	}elseif($_GET['act'] == 'Shop'){
		include("api_head.php");
		include("mode/ad.php");
	}elseif($_GET['act'] == 'list_gg'){
		include('api_head.php');
     	$u = $_GET['username'];
		$p = $_GET['password'];
		if($_GET['dlapp']){
			$dlid=$_GET['dlapp'];
		}else{
			$dlid='0';	
		}
		$db = db('ky_gg');
		$list = $db->where(array('dlid'=>$dlid))->order('id DESC')->select();
		echo '<div style="margin:10px 10px;">';
			echo '<div class="alert alert-warning">您可以在这看到最近30条消息通知</div>';
			echo '</div>';
		if($list){
			echo '<div class="main"><ul class="list-group">';
			foreach($list as $v){
				$is_read = db("ky_yd")->where(array('readid'=>$v['id'],"username"=>$u))->find();
				$pre = $is_read ? '' :'<span class="badge">未读</span>';
				echo '<li class="list-group-item"><a href="?act=gg&id='.$v['id'].'&username='.$u.'">'.$pre.$v['name'].'</a></li>
				';
			}
		echo '</ul><div>';
		}else{
			echo '消息已经删除或者不存在！';
		}
	}elseif($_GET['act'] == 'gg'){
		include('api_head.php');
		include('mode/gg_view.php');
	}elseif($_GET['act'] == 'load_gg'){
		$u = $_POST['username'];
		$db = db('ky_gg');
		if($_GET['dlapp']){
		$vo = $db->where(array('dlid'=>$_GET['dlapp']))->order('id DESC')->find();
		}else{
		$vo = $db->where(array('dlid'=>'0'))->order('id DESC')->find();	
		}
		$is_read = db("ky_yd")->where(array('readid'=>$vo['id'],"username"=>$u))->find();
		if($vo && !$is_read){
			db("ky_yd")->insert(array('username'=>$u,'readid'=>$vo['id']));
			die(json_encode(array('status'=>'success','url'=>'http://'.$_SERVER["HTTP_HOST"].':'.$_SERVER["SERVER_PORT"].'/Kyws/api.php?act=gg&id='.$vo['id'].'&username='.$u.'&','title'=>$vo['name'],'content'=>$vo['content'])));
		}else{
			die(json_encode(array('status'=>'error','url'=>'no data','title'=>'no data')));
		}
		
	}elseif($_GET['act'] == 'load_info'){
		$u = $_POST['username'];
		$p = $_POST['password'];
		$ud = new U($u,$p,true);
		$u = db(_openvpn_)->where(array(_iuser_=>$u,_ipass_=>$p))->find();
		if($u){
			$now = getInfo_i($_POST['username']);
			$uinfo = $u;
			
			$count =  printmb($uinfo[_maxll_]);
		
			$isuse = printmb($uinfo[_irecv_]+$uinfo[_isent_]+$now[2]+$now[3]);
		
			$sy = printmb($uinfo[_maxll_]-($uinfo[_irecv_]+$uinfo[_isent_]));
		
			
			$upload = printmb($uinfo[_irecv_]+$now[2]);
			$download = printmb($uinfo[_isent_]+$now[3]);
			//system("/home/wwwroot/default/res/sha ".$u[_iuser_]);
			if($sy['n'] <= 0 && $sy['p'] == 'M'){
				$t = 'tips_user';
				$s = round($sy['n'],1).$sy['p'];
			}elseif($sy['n'] <= 100 && $sy['p'] == 'M'){
				$t = 'tips_user';
				$s = round($sy['n'],1).$sy['p'];
			}else{
				$t = 'success';
				$s = round($sy['n'],1).$sy['p'];
			}
			$_sy = $ud->getDatadays();
			$_all = $uinfo[_maxll_] >= _MAX_LIMIT_*1024*1024*1024 ? "NO_LIMIT" : $s;
			die(json_encode(array('status'=>$t,'all'=>$uinfo[_maxll_]-($uinfo[_irecv_]+$uinfo[_isent_]),'sy'=>$_all,'stime'=>'2','etime'=>'2','bl'=>$_sy."天")));
			exit;
		}else{
			
			die(json_encode(array('status'=>'success','all'=>'0','sy'=>'未知','stime'=>'2','etime'=>'2','bl'=>$_sy."天")));
			exit;
		}
		
	//=======================================
	}elseif($_GET['act'] == 'top'){
		include('api_head.php');
		$u = $_GET['username'];
		$p = $_GET['password'];
		$db = db('top');
		$list = $db->limit('60')->where(array("time"=>date("Y-m-d",time())))->order('data DESC')->select();
		$my = $db->where(array("username"=>$u,"time"=>date("Y-m-d",time())))->find();
		$mytop = db("top")->where("data >= :data AND time = :time",array(":data"=>$my["data"],":time"=>date("Y-m-d",time())))->getnums();
		$ml = printmb($my['data']);
		echo ' 	<div class="alert alert-success">
		<b>当前我的排名:以'.round($ml["n"],2).$ml["p"].'的成绩位居今天第<font style="color:red">'.$mytop.'</font>名！</b>
		<br>每天流量使用排名前60的会显示在这里哦！【按日结算】</div>
		<style>.topline{border:1px solid #ccc;height:100px;margin:10px;background:#6aafd7;background-image:url("images/topbg.png");background-repeat:no-repeat;color:#fff;}
		.topline h3{color:#fff}
		.topn{font-size:40px;color:#fff;float:left;line-height:100px;margin-left:15px;width:100px;}
		.topc{
			float:left;
			margin-top:10px;
			text-align:left;
		}
		</style>';
  $i = 1;
		foreach($list as $vo){	
			$l = printmb($vo['data']);
			$user = db(openvpn)->where(array('iuser'=>$vo['username']))->find();	
			$area = $user["area"]; 
			if($area == '广西壮族自治区'){
			$area = '广西';
			}elseif($area == '宁夏回族自治区'){
			$area = '宁夏';	
			}elseif($area == '新疆维吾尔自治区'){
			$area = '新疆'; 
			}elseif($area == '西藏自治区'){
			$area = '西藏';
			}elseif($area == '内蒙古自治区'){
			$area = '内蒙古';}
			echo '<div class="topline">
			<div class="topn">'.$i.'</div>
			<div class="topc"><h3>'.round($l['n'],2).$l['p'].'</h3>
			<div class="topu"><img src="../assets/img/user.png" height="13" width="11"/> '.substr_replace($vo["username"],'****',3,4).'&nbsp;
			<img src="mode/pay/shouji.png" height="13" width="8"/> <i>'.$area.''.$user["isp"].'</i> '.$user['client'].'</div>
			</div>
			</div>
			</div>';
	$i++;
		}
		echo '</tbody>
</table>';
		include("api_footer.php");
	}elseif($_GET['act'] == 'login_in'){
		
		$u = $_POST['username'];
		$p = $_POST['password'];
		
		$ud = new U($u,$p,true);
       
		if($ud->isuser){
			$uinfo = $ud->getNative();
			$sydata =$ud->getDatasurplus();
			$_sy = $ud->getDatadays();
			$max = $ud->getDatamax();
			$count =  printmb($max);
			$isuse = printmb($ud->getDataused());
			$sy = printmb($sydata);
			$s = $count>=100*1024*1024*1024 ? "NO_LIMIT" : round($sy['n'],1)." ".$sy['p'];
			die(json_encode(array(
				'status'=>'success',
				'msg'=>base64_encode($u[_iuser_]."\n".$u[_ipass_]."\n".round($sy['n'],1).$sy['p']."\n".$count."\n".round($_sy,0)),
				'username'=>$uinfo[_iuser_],
				'password'=>$uinfo[_ipass_],
				'liuliang'=>$s,
				'all'=>$sydata,
				'bl'=>$_sy."天"
			)));
		}else{
			die(json_encode(array(
				'status'=>'error',
				'msg'=>'用户不存在或者密码错误'
			)));
		}
		
	}elseif($_GET['act'] == 'login_check'){
		$u = $_POST['username'];
		$p = $_POST['pass'];
		$ud = new U($u,$p,true);
		$png = $kyun['splash'];
		$url = $kyun['splashurl'];
		if($ud->isuser){
			$ru = db(_openvpn_)->where(array(_iuser_=>$u,pass=>$p))->find();
			if($ru[i]=='2'){
			   $tian = $ru['tian'];	
			   $endtime = time()+3600*24*$tian;
			   db(_openvpn_)->where(array(_iuser_=>$u))->update(array(_i_=>'1',_endtime_=>$endtime,_starttime_=>time()));
		    }
			
			$ip = getvip(); 
			$agent=getAgent();
			if($ip == 'Unknow'){
				db(_openvpn_)->where(array(_iuser_=>$u))->update(array('area'=>'未知地区','isp'=>'未知','client'=>$agent));
			}else{
			   $api_uri = "http://ip.taobao.com/service/getIpInfo.php?ip={$ip}";
			   $json = file_get_contents($api_uri); 
			   $arr = json_decode($json,true); 
			   $region = $arr["data"]["region"];
			   $isp = $arr["data"]["isp"]; 
			   db(_openvpn_)->where(array(_iuser_=>$u))->update(array('area'=>$region,'isp'=>$isp,'client'=>$agent));
			}
			
			$uinfo = $ud->getNative();
			$sydata =$ud->getDatasurplus();
			$_sy = $ud->getDatadays();
			$max = $ud->getDatamax();
			$count =  printmb($max);
			$isuse = printmb($ud->getDataused());
			$sy = printmb($sydata);
			
			
			$s = $max>=100*1024*1024*1024 ? "NO_LIMIT" : round($sy['n'],1)." ".$sy['p'];
			$data = "success_need_login\n";
			$data .= $uinfo[_iuser_]."\n";
			$data .= $uinfo[_ipass_]."\n";
			$data .= $s."\n";
			$data .= $sydata."\n";
			$data .= $_sy."天\n";
			$data .= $png."\n";
			$data .= $url;
			
			die($data);
			
			exit;
		}else{
			$data = "error_need_login\n";
			$data .= "0\n";
			$data .= "0\n";
			$data .= "0\n";
			$data .= "0\n";
			$data .= "0\n";
			$data .= $png."\n";
			$data .= $url;
			
			die($data);
			exit;
		}
			
	//=======================================
	}elseif($_GET['act'] == 'theme'){
		include('api_head.php');
		include('mode/theme.php');	
	}elseif($_GET['act'] == 'help'){
		   include('api_head.php');
           include("mode/help.php");
	}elseif($_GET['act'] == 'more'){
		include('api_head.php');
		include('mode/all.php');  
	}else{
		
		include('api_head.php');
		?>
		<div class="main">

			<ul class="list-group">
	      <li class="list-group-item"><div style="width:160px;margin:20px auto;">网页走丢了哦<br><a href="http://kuaiyum.com">GO 快云官网</div></a></li>

         </ul>
		</div>	
		
	<?php
	} ?>