<?php
return array (
  'base_url' => 'http://getip:8888/sbwremote',
  'db.type' => 'mysql',
  'db.host' => 'localhost',
  'db.port' => 3306,
  'db.user' => 'root',
  'db.pass' => 'MySQLPass',
  'db.name' => 'ov',
)
?>