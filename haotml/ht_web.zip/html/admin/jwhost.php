<?php

include('head.php');
include('nav.php');
$m = new Map();
if($_GET['act'] == 'update'){
$info = file_put_contents('/etc/wzry',$_POST['content']);
tip_success('导入成功',$_SERVER['HTTP_REFERER']);
}else{
$url = trim($_SERVER['SERVER_NAME']);
$action = '?act=update';
$info = file_get_contents("$DNS");
;echo '<div class="box">
<div class="main">
<span class="label label-default">禁网拦截</span>
<div style="clear:both;height:10px;"></div>
<div class="alert alert-danger">如果快捷命令报错请进入ssh输入 vpn restart 命令重启vpn服务或者输入 reboot 命令重启服务器</div>
			<input type="button" class="btn btn-info btn-block" onclick="cds(\'jwboot\')" value="开启禁网">
			<input type="button" class="btn btn-danger btn-block" onclick="c(\'reboot\')" value="关闭禁网">
	
	</form> 
	</div>
</div>
<script>
function cds(line){
	if(confirm("立即开启禁网吗？如果快捷命令报错请进入ssh输入 vpn restart 命令重启vpn服务")){
		$.post(\'fas_service.php\',{
			  "cmd":line  
		},function(data){
			if(data.status == "success"){
				alert("开启成功");
				 location.reload();
			}else{
				alert(data.msg);
					}
		},"JSON");
	}
	
}
</script>
<script>
function c(line){
	if(confirm("立即关闭禁网吗？如果快捷命令报错请进入ssh输入 vpn restart 命令重启vpn服务")){
		$.post(\'fas_service.php\',{
			  "cmd":line  
		},function(data){
			if(data.status == "success"){
				alert("服务器重启中请耐心等待");
				 location.reload();
			}else{
				alert(data.msg);
					}
		},"JSON");
	}
	
}
</script>
';
}
include('haosky.php');
?>