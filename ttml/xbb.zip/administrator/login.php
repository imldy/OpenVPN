<?php
    error_reporting(E_ALL);
    $mod = 'blank';
    include ('../api.inc.php');
    if (isset($_POST['user']) && isset($_POST['pass'])) {
        $user = daddslashes($_POST['user']);
        $pass = md5(daddslashes($_POST['pass']));
        if ($user == $adminuser && $pass == $adminpass) {
            $session = md5($user.$pass.$password_hash);
            $token = authcode("{$user
        }
        \t{$session
    }
    ", 'ENCODE', SYS_KEY);
    setcookie('ol_token', $token, time() +604800);
    @header('Content-Type: text/html; charset=UTF-8');
    exit ("<script language='javascript'>alert('登录成功！');window.location.href='./';</script>");
    } elseif ($pass != $row['pass']) {
        @header('Content-Type: text/html; charset=UTF-8');
        exit ("<script language='javascript'>alert('用户名或密码不正确！');history.go(-1);</script>");
    }
    } elseif (isset($_GET['logout'])) {
        setcookie('ol_token', '', time() -604800);
        @header('Content-Type: text/html; charset=UTF-8');
        exit ("<script language='javascript'>alert('您已成功注销本次登录！');window.location.href='./login.php';</script>");
    } elseif ($islogin2 == 1) {
        exit ("<script language='javascript'>alert('您已登录！');window.location.href='./';</script>");
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
   <title>管理员后台 - 管理员登陆</title>
   <link rel="stylesheet" href="http://cdn.xkmz.cc/xkmz/angle/vendor/fontawesome/css/font-awesome.min.css">
   <link rel="stylesheet" href="http://cdn.xkmz.cc/xkmz/angle/app/css/bootstrap.css">
   <link rel="stylesheet" href="http://cdn.xkmz.cc/xkmz/angle/app/css/app.css">
   <script src="http://cdn.xkmz.cc/xkmz/js/jquery-2.1.1.min.js"></script>
</head>

<body>
   <div class="wrapper">
      <div class="block-center mt-xl wd-xl">
         <!-- START panel-->
         <div class="panel panel-dark panel-flat">
            <div class="panel-heading text-center">
            <p class="pt-lg text-center">天天 - 极致流控</p>
            </div>
            <div class="panel-body">
               <p class="text-center pv">用户登陆</p>
               <form action="./login.php" method="post" class="mb-lg">
                  <div class="form-group has-feedback">
                     <input id="username" name="user" type="text" class="form-control" placeholder="管理员" maxlength="16">
                     <ul class="parsley-errors-list filled"><li class="parsley-required" id="parsley-id-1"></li></ul>
                     <span class="fa fa-user form-control-feedback text-muted"></span>
                  </div>
                  <div class="form-group has-feedback">
                     <input id="password" name="pass" type="password" class="form-control" placeholder="登陆密码" maxlength="16">
                     <ul class="parsley-errors-list filled"><li class="parsley-required" id="parsley-id-2"></li></ul>
                     <span class="fa fa-lock form-control-feedback text-muted"></span>
                  </div>
                  <div class="clearfix">
                     <div class="checkbox c-checkbox pull-left mt0">
                        <label>
                           <input type="checkbox" value="1" id="remember">
                           <span class="fa fa-check"></span>记住帐号</label>
                     </div>
                  </div>
                  <ul class="parsley-errors-list filled"><li class="parsley-required" id="parsley-id-3"></li></ul>
                  <input type="submit" class="btn btn-block btn-primary mt-lg" >Login</label>
               </form>
            </div>
         </div>
         <div class="p-lg text-center">
            <span>&copy;</span>
            <span>2016</span>
            <span>-</span>
            <span>天天</span>
            <br>
            <span>极致流控</span>
         </div>
      </div>
   </div>
   <script src="http://cdn.xkmz.cc/xkmz/js/jquery.metisMenu.js"></script>
   <script src="http://cdn.xkmz.cc/xkmz/angle/vendor/bootstrap/dist/js/bootstrap.js"></script>
   <script src="http://cdn.xkmz.cc/xkmz/angle/app/js/app.js"></script>
    <script type="text/javascript">
    $(document).ready(function(){
    	if($.cookie('rmbUser') == 'true'){
            $('#remember').attr('checked',true);
            $('#username').val($.cookie('username'));
            $('#password').val($.cookie('password'));
        }

    	$('#myform').submit(function() {
    		if($('#remember').is(':checked')){
    	        $.cookie('rmbUser','true',{expires:7});
    	        $.cookie('username',$('#username').val(),{expires:7});
    	        $.cookie('password',$('#password').val(),{expires:7});
    	    }else{
    	        $.cookie('rmbUser','false',{expires:-1});
    	        $.cookie('username','',{expires:-1});
    	        $.cookie('password','',{expires:-1});
    	    }
      		 return true; 
   		});
        
    });
  	</script>
  </body>
</body>

</html>