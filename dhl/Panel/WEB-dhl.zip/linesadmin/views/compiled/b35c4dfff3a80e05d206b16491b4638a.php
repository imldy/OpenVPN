﻿<!DOCTYPE HTML>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <meta name="viewport"
          content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no"/>
    <meta name="MobileOptimized" content="320"/>
    <meta name="author" content="<?php echo $author; ?>"/>
    <meta name="robots" content="none"/>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/mui.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/jquery.js"></script>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/default.js"></script>
    <title><?php echo $title; ?></title>
    <link type="image/x-icon" rel="icon" href="<?php echo $base_url; ?>/favicon.ico"/>
    <link type="image/x-icon" rel="shortcut icon" href="<?php echo $base_url; ?>/favicon.ico"/>
    <link href="<?php echo $base_url; ?>/views/assets/css/mui.min.css" rel="stylesheet"/>
    <link href="<?php echo $base_url; ?>/views/assets/css/default.css" rel="stylesheet"/>
    <style type="text/css">
        html, body {
            height: 100%;
            overflow: hidden;
            background: #FFFFFF;
        }

        .mui-content {
            padding: 10px;
            background: #FFFFFF;
        }

        .mui-table-view:after {
            height: 0;
        }

        .mui-table-view-cell:after {
            left: 1px;
        }

        .mui-input-group .mui-input-row::after {
            left: 0;
        }

        .mui-input-group::before,
        .mui-input-group::after {
            height: 0;
        }

        .mui-btn {
            padding: 5px;
        }
    </style>
</head>

<body>
<noscript class="error">
    很遗憾，由于你的浏览器不支持或禁用了JavaScript，导致无法获得正常体验。
</noscript><header class="mui-bar mui-bar-nav">
    <a class="mui-icon mui-icon-home mui-pull-left" href="<?php echo $base_url; ?>/index.php" target="_blank"></a>

    <h1 class="mui-title"><?php echo $title; ?></h1>
</header>
<div class="mui-content">
    <ul class="mui-table-view mui-table-view-chevron content">
        <li class="mui-table-view-cell">
            <a href="<?php echo $base_url; ?>/admin.php?c=Admin&a=setting&token=<?php echo $token; ?>" class="mui-navigate-right">APP设置</a>
        </li>
        <li class="mui-table-view-cell">
            <a href="<?php echo $base_url; ?>/admin.php?c=Admin&a=modifyPassword&token=<?php echo $token; ?>" class="mui-navigate-right">修改密码</a>
        </li>
        <li class="mui-table-view-cell">
            <a href="<?php echo $base_url; ?>/admin.php?c=CategoryManage&a=add&token=<?php echo $token; ?>" class="mui-navigate-right">添加分类</a>
        </li>
        <li class="mui-table-view-cell">
            <a href="<?php echo $base_url; ?>/admin.php?c=CategoryManage&token=<?php echo $token; ?>" class="mui-navigate-right">管理分类</a>
        </li>
        <li class="mui-table-view-cell">
            <a href="<?php echo $base_url; ?>/admin.php?c=ArticleManage&a=add&token=<?php echo $token; ?>" class="mui-navigate-right">添加线路</a>
        </li>
        <li class="mui-table-view-cell">
            <a href="<?php echo $base_url; ?>/admin.php?c=ArticleManage&token=<?php echo $token; ?>" class="mui-navigate-right">管理线路</a>
        </li>
        <li class="mui-table-view-cell">
            <a href="<?php echo $base_url; ?>/admin.php?c=LinkManage&a=add&token=<?php echo $token; ?>" class="mui-navigate-right">添加友链</a>
        </li>
        <li class="mui-table-view-cell">
            <a href="<?php echo $base_url; ?>/admin.php?c=LinkManage&token=<?php echo $token; ?>" class="mui-navigate-right">管理友链</a>
        </li>
    </ul>
    <ul class="mui-table-view">
        <li class="mui-table-view-cell">
            <a href="javascript:logout();">退出登录</a>
        </li>
    </ul>
</div>
<script type="text/javascript">
    function logout() {
        if (confirm("真的要退出吗？")) {
            jQuery.post("<?php echo $base_url; ?>/api.php?c=Token&a=revoke", {
                token: "<?php echo $token; ?>"
            }, function (result) {
                if (result.code == 1) {
                    window.location = "<?php echo $base_url; ?>/admin.php?c=Unlogin";
                } else {
                    alert(result.msg);
                }
            }, "json");
        }
    }
</script><div style="width:100%;background:#FFFFFF;display:block;border-top:1px dotted #CCCCCC;position:fixed;bottom:0;">
    <div class="center">
        <?php echo isset($copyright) ? $copyright : ''; ?>
    </div>
</div>
</body>

</html>
<!-- Created By Template Engineer At 2016/07/22,22:39 -->
