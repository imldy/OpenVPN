<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：修改平台线路证书配置
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

if($is_login == 'ok'){
$db = db("ky_zs");
$res = $db->where(array())->find();
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>负载集群管理 - 修改证书</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
         <div class="col-sm-12">
			<div class="ibox-mulu">
      <h3> &nbsp;&nbsp; <i class="fa fa-sitemap fa-lg"></i> 负载集群管理 > 修改证书</h3>
              </div>
			  <br>	
<?php
if($_POST["ca"]){	
$ca=daddslashes($_POST["ca"]);
$tls=daddslashes($_POST["tls"]);
  if($db->where(array())->update(array('ca'=>$ca,'tls'=>$tls))){		 
      echo Skip('修改证书',success);
  }else{
      echo Skip('修改证书',error);
  }
 exit;
}
?>             <div class="ibox">
                   <div class="ibox-content">
                        <form action="./set_zhshu.php" method="post" class="form-horizontal m-t">
						  <div class="form-group has-warning">
                                <label class="col-sm-2 control-label">CA证书</label>
                                <div class="col-sm-9">
                                   <textarea class="form-control" rows="16" name="ca"><?php echo $res['ca'];?></textarea>
                                 </div>
                            </div>
							 <div class="hr-line-dashed"></div>
						    <div class="form-group has-success"> 
                                <label class="col-sm-2 control-label">TLS证书</label>
                                 <div class="col-sm-9">
                                   <textarea class="form-control" rows="10" name="tls"><?php echo $res['tls'];?></textarea>
                                 </div>
								</div>
							  <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-4 col-sm-offset-2"> 
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                                </div>
                            </div>
                        </form>					
                    </div>
                </div>
            </div>
        </div>

    </div>   

</body>

</html>
<?php
}else{ 
    exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
}
?>