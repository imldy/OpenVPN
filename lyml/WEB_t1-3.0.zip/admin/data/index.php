<?php
/**
 * 凌云免流管理中心
 * by 天木兮 2018年10月15日
 */
include("../../Data/api.inc.php");
if($islogin2==1){
$user=$DB->count("SELECT count(*) from `openvpn` WHERE 1");	
$kms=$DB->count("SELECT count(*) from auth_kms WHERE kind=1");
$kms2=$DB->count("SELECT count(*) from auth_kms WHERE kind=2");
$line=$DB->count("SELECT count(*) from line");
$line2=$DB->count("SELECT count(*) from line WHERE `show`='0'");
$gg=$DB->count("SELECT count(*) from Ly_gg");
$row = $DB->get_row("SELECT * FROM Lyun"); 	
echo '
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>管理员平台 - '.$row[logo].'</title>
	<meta name="renderer" content="webkit|ie-comp|ie-stand">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <meta http-equiv="Cache-Control" content="no-siteapp" />

    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="./css/font.css">
	<link rel="stylesheet" href="./css/xadmin.css">
    <script type="text/javascript" src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
    <script src="./lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="./js/xadmin.js"></script>

</head>
<body>
    <!-- 顶部开始 -->
    <div class="container">
        <div class="logo"><a href="./index.html">管理员平台 - '.$row[logo].'</a></div>
        <div class="left_open">
            <i title="展开左侧栏" class="iconfont">&#xe699;</i>
        </div>
        <ul class="layui-nav right" lay-filter="">
          <li class="layui-nav-item to-index"><a href="/">前台首页</a></li>
		  <li class="layui-nav-item to-index"><a href="../Lyun/index.php?logout">注销</a></li>
        </ul>
        
    </div>
    <!-- 顶部结束 -->
    <!-- 中部开始 -->
     <!-- 左侧菜单开始 -->
    <div class="left-nav">
      <div id="side-nav">
        <ul id="nav">
                <a href="javascript:;">
                    <cite>数据信息</cite>
                </a>
			</br>
            <li>
                <a href="javascript:;">
                    <i class="iconfont">&#xe70c;</i>
                    <cite>实时监控</cite>
                    <i class="iconfont nav_right">&#xe697;</i>
                </a>
                <ul class="sub-menu">
                    <li>
                        <a _href="online_list.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>在线检测</cite>
                        </a>
                    </li >
					<li>
                        <a _href="user_log.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>操作记录</cite>
                        </a>
                    </li >
                </ul>
            </li>
			</br>
                <a href="javascript:;">
                    <cite>用户信息</cite>
                </a>
			</br>
            <li>
                <a href="javascript:;">
                    <i class="iconfont">&#xe6b8;</i>
                    <cite>账号管理</cite>
                    <i class="iconfont nav_right">&#xe697;</i>
                </a>
                <ul class="sub-menu">
                    <li>
                        <a _href="add_user.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>添加账号</cite>
                            
                        </a>
                    </li >
                    <li>
                        <a _href="padd_user.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>批量添加账号</cite>
                            
                        </a>
                    </li>
					<li>
                        <a _href="user_list.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>账号列表</cite>
                            
                        </a>
                    </li>
					<li>
                        <a _href="user_area.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>用户分布情况</cite>
                            
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="iconfont">&#xe723;</i>
                    <cite>卡密管理</cite>
                    <i class="iconfont nav_right">&#xe697;</i>
                </a>
                <ul class="sub-menu">
                    <li>
                        <a _href="kms_list.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>卡密列表</cite>
                        </a>
                    </li >
					<li>
                        <a _href="daili_kms.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>代理充值卡密</cite>
                        </a>
                    </li >
					<li>
                        <a _href="suo_kms.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>搜索卡密</cite>
                        </a>
                    </li >
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="iconfont">&#xe6f6;</i>
                    <cite>套餐管理</cite>
                    <i class="iconfont nav_right">&#xe697;</i>
                </a>
                <ul class="sub-menu">
                    <li>
                        <a _href="add_taocan.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>添加新套餐</cite>
                        </a>
                    </li >
					<li>
                        <a _href="taocan_list.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>套餐列表</cite>
                        </a>
                    </li >
					<li>
                        <a _href="buy_list.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>交易记录列表</cite>
                        </a>
                    </li >
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="iconfont">&#xe723;</i>
                    <cite>负载集群管理</cite>
                    <i class="iconfont nav_right">&#xe697;</i>
                </a>
                <ul class="sub-menu">
                    <li>
                        <a _href="add_note.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>添加新节点</cite>
                        </a>
                    </li >
					<li>
                        <a _href="note_list.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>节点列表</cite>
                        </a>
                    </li >
					<li>
                        <a _href="set_zhshu.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>修改线路证书</cite>
                        </a>
                    </li >
                </ul>
            </li>
			</br>
                <a href="javascript:;">
                    <cite>代理信息</cite>
                </a>
			</br>
            <li>
                <a href="javascript:;">
                    <i class="iconfont">&#xe726;</i>
                    <cite>代理管理</cite>
                    <i class="iconfont nav_right">&#xe697;</i>
                </a>
                <ul class="sub-menu">
                    <li>
                        <a _href="add_daili.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>添加新代理</cite>
                        </a>
                    </li >
                    <li>
                        <a _href="daili_list.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>代理用户列表</cite>
                        </a>
                    </li >
                    <li>
                        <a _href="deu_daili.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>清空代理数据</cite>
                        </a>
                    </li >
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="iconfont">&#xe6ce;</i>
                    <cite>云端管理</cite>
                    <i class="iconfont nav_right">&#xe697;</i>
                </a>
                <ul class="sub-menu">
                    <li>
                        <a _href="add_ggao.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>发布新公告</cite>
                        </a>
                    </li >
                    <li>
                        <a _href="ggao_list.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>公告列表</cite>
                        </a>
                    </li>
                    <li>
                        <a _href="app_qq.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>软件客服</cite>
                        </a>
                    </li>
                    <li>
                        <a _href="shengji.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>启动图与更新</cite>
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="iconfont">&#xe6ce;</i>
                    <cite>线路管理</cite>
                    <i class="iconfont nav_right">&#xe697;</i>
                </a>
                <ul class="sub-menu">
                    <li>
                        <a _href="add_line.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>添加新线路</cite>
                        </a>
                    </li >
                    <li>
                        <a _href="line_list.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>平台线路列表</cite>
                        </a>
                    </li>
                    <li>
                        <a _href="fank_list.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>用户反馈列表</cite>
                        </a>
                    </li>
                    <li>
                        <a _href="line_check.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>代理线路审核</cite>
                        </a>
                    </li>
					<li>
                        <a _href="Lyun_line.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>官方推送列表</cite>
                        </a>
                    </li>
                </ul>
            </li>
			</br>
                <a href="javascript:;">
                    <cite>服务信息</cite>
                </a>
			</br>
            <li>
                <a href="javascript:;">
                    <i class="iconfont">&#xe732;</i>
                    <cite>高级管理</cite>
                    <i class="iconfont nav_right">&#xe697;</i>
                </a>
                <ul class="sub-menu">
                    <li>
                        <a _href="daili_config.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>平台信息</cite>
                        </a>
                    </li >
                    <li>
                        <a _href="user_Lyun.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>管理员信息</cite>
                        </a>
                    </li>
                    <li>
                        <a _href="webxsu.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>系统服务设置</cite>
                        </a>
                    </li>
                    <li>
                        <a _href="pass_set.php">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite>修改密码</cite>
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="../Lyun/index.php?logout">
                    <i class="iconfont">&#xe69a;</i>
                    <cite>退出登录</cite>
                    <i class="iconfont nav_right">&#xe697;</i>
                </a>
            </li>
            <li>
                <a href="javascript:;">
                    <i class="iconfont">&#xe6ae;</i>
                    <cite>系统版本信息</cite>
                    <i class="iconfont nav_right">&#xe697;</i>
                </a>
                <ul class="sub-menu">
                <a href="javascript:;">
                    <cite>PHP 版本：'.PHP_VERSION.'</cite>
                </a>
                <a href="javascript:;">
                    <cite>MySQL 版本：5.5.52</cite>
                </a>
                <a href="javascript:;">
                    <cite>WEB 版本：Lyun-3.0</cite>
                </a>
                </ul>
            </li>
        </ul>
      </div>
    </div>
    <!-- <div class="x-slide_left"></div> -->
    <!-- 左侧菜单结束 -->
    <!-- 右侧主体开始 -->
    <div class="page-content">
        <div class="layui-tab tab" lay-filter="xbs_tab" lay-allowclose="false">
          <ul class="layui-tab-title">
            <li class="home"><i class="layui-icon">&#xe68e;</i>平台首页</li>
          </ul>
          <div class="layui-tab-content">
            <div class="layui-tab-item layui-show">
                <iframe src="Lyun_admin.php" frameborder="0" scrolling="yes" class="x-iframe"></iframe>
            </div>
          </div>
        </div>
    </div>
    <div class="page-content-bg"></div>
    <!-- 右侧主体结束 -->
    <!-- 中部结束 -->
    <!-- 底部开始 -->
    <div class="footer">
        <div class="copyright">Copyright ©2017 凌云 v3.0 All Rights Reserved 框架基于<a href="http://x.xuebingsi.com/">x-admin</a></div>  
    </div>
</body>
</html>';
}else{exit("<script language='javascript'>window.location.href='../Lyun/index.php';</script>");}
?>