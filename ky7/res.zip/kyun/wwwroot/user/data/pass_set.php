<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：修改用户账号密码
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

$db = db('openvpn');
$row = $db->where(array('iuser'=>$_GET['user'],'pass'=>$_GET['pass']))->find();
if($row){
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title> - 修改密码</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
                      <div class="col-sm-12">
			<div class="ibox-mulu">
          <h3> &nbsp;&nbsp; <i class="fa fa-user-md fa-lg"></i> 高级管理 > 修改密码</h3>
            </div>
			   <br>	
<?php
if($_POST['setpass']=="ok"){
// 双MD5加密
$oldpass = daddslashes($_POST['oldpass']);
$pass = daddslashes($_POST['newpass']);
if($db->where(array('iuser'=>$row['iuser'],'pass'=>$oldpass))->find()){	
   if($db->where(array('iuser'=>$row['iuser']))->update(array('pass'=>$pass))){			 
        echo Skip('修改密码',success);
   }else{
        echo Skip('修改密码',error);
   }
}else{
   echo Skip('旧密码不正确，修改',error);
}
exit;
}
?>          <div class="ibox">
                   <div class="ibox-content">	
                    <div class="ibox-content">
                        <form action="./pass_set.php" method="get" class="form-horizontal m-t">
						 <input type="hidden" name="setpass" value="ok" />
						    <div class="form-group has-error"> 
                                <label class="col-sm-3 control-label">管理员旧密码：</label>
                                <div class="col-sm-8">
                                    <input name="oldpass" placeholder="请输入旧密码" class="form-control" type="text">
                                 </div>
                            </div>
							 <div class="hr-line-dashed"></div>
							 
							 <div class="form-group has-success">
                                <label class="col-sm-3 control-label">管理员新密码：</label>
                                <div class="col-sm-8">
                                    <input name="newpass" placeholder="请输入新密码" class="form-control" type="text">
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-8 col-sm-offset-3">
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                                  </div>
                            </div>
                        </form>					
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</body>

</html>
<?php
}else{ 
    exit("<script>window.location.href='../Kyun/index.php';</script>");
}
?>