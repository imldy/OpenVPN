<?php
    $mod = 'blank';
    include ('../api.inc.php');
    $title = 'APP环境配置修改';
    include './head.php';
    if ($islogin2 == 1) {
    } else exit ("<script language='javascript'>window.location.href='./login.php';</script>");
?>

<?php
    $id = daddslashes($_GET['id']);
    if (!$id || !$row = $DB->get_row("select * from `lyj_link` where id='$id' limit 1")) {
        exit ('环境配置不存在');
    }
    if ($_POST['type'] == 'update') {
        echo '<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">修改环境配置结果</h3></div>
<div class="panel-body">';
        $url = daddslashes($_POST['url']);
        $description = daddslashes($_POST['description']);
        if ($DB->query("update `lyj_link` set `url`='$url',`description`='$description' where id='$id'")) {
            echo '修改成功！';
        } else {
            echo '修改失败！'.$DB->error();
        }
        echo '<hr/><a href="./setting.php">返回环境配置列表</a></div></div>';
        exit;
    }
?>
<section id="content">
<section class="vbox">
<section class="scrollable padder">
<ul class="breadcrumb no-border no-radius b-b b-light pull-in">
<section class="panel panel-default">
              <header class="panel-heading font-bold"> 配置:<?=$row['name']
?>  </header>
              <div class="panel-body">

          <form action="./recsetting.php?id=<?=$id
?>" method="post" class="form-horizontal" role="form">
          <input type="hidden" name="type" value="update" />
          	<div class="input-group">
              <span class="input-group-addon">url:</span>
			  <input type="text" name="url" value="<?=$row['url']
?>" class="form-control">
            </div><br/>
          	<div class="input-group">
              <span class="input-group-addon">链接简介:</span>
			  <input type="text" name="description" value="<?=$row['description']
?><?php
    echo '" class="form-control">
            </div><br/>
			
            <div class="form-group">
              <div class="col-sm-12"><input type="submit" name="submit" value="修改" class="btn btn-primary form-control"/></div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  ';
    include './nav.php';
?>