<?php

include('head.php');
include('nav.php');
$m = new Map();
if($_GET['act'] == 'update'){
$info = file_put_contents('/home/ht_host',$_POST['content']);
tip_success('修改成功',$_SERVER['HTTP_REFERER']);
}else{
$action = '?act=update';
$info = file_get_contents('/home/ht_host');
;echo '<div class="box">
<div class="main">
<span class="label label-default">自定义DNS</span>
<div style="clear:both;height:10px;"></div>
<div class="alert alert-danger">示例:127.0.0.1 www.baidu.com 则用户访问百度会被屏蔽！<br>请等页面加载完毕再操作，保存后点立即生效！<br>如果快捷命令报错请进入ssh输入 vpn restart 命令重启vpn服务</div>
		<form class="form-horizontal" role="form" method="POST" action="';echo $action;echo '">
			<textarea class="form-control" rows="20" name="content">';echo $info ;echo '</textarea>
			<br>
			<button type="submit" class="btn btn-info btn-block">保存</button>
			<input type="button" class="btn btn-success btn-block" onclick="cmds(\'service dnsmasq restart\')" value="立即生效（保存后再执行）">
	
	</form> 
	</div>
</div>
<script>
function cmds(line){
	if(confirm("立即生效自定义DNS拦截列表？")){
		$.post(\'fas_service.php\',{
			  "cmd":line  
		},function(data){
			if(data.status == "success"){
				alert("执行完毕");
				 location.reload();
			}else{
				alert(data.msg);
					}
		},"JSON");
	}
	
}
</script>
';
}
include('haosky.php');
?>