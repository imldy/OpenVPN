<?php
$mod='blank';
include("../api.inc.php");
$title='配置用户帐号';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body">

    <?php include 'set.php';?>
    
    <div class="page-container">

        <?php include 'nav.php';?>
        
        <div class="main-content">
                    
            <?php include 'info.php';?>
            
          <div class="page-title">
          <div class="title-env">
            <h1 class="title"><?php echo $title ?></h1>
            <p class="description">此处按需要配置帐号密码</p>
          </div>
            <div class="breadcrumb-env">
            
               <ol class="breadcrumb bc-1">
                 <li>
                  <a href="index.php"><i class="fa-home"></i>首页</a>
                </li>
                <li class="active">
                      <strong><?php echo $title ?></strong>
                  </li>
              </ol>
                  
             </div>
           </div>
<?php
$user = daddslashes($_GET['user']);
?>

            <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">进行账号 <?=$user?> 的配置</h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">

<?php
if(!$user || !$row = $DB->get_row("select * from `openvpn` where iuser='$user' limit 1")){ exit("账号不存在!");}

if ($row['tian']>0) {
  echo "<style>#enddate{display: none;}</style>";
}else{
  echo "<style>#tian{display: none;}</style>";
}

if($_POST['type']=="update"){
echo '<div class="alert ';
$notes = daddslashes($_POST['notes']);
$fwqid = daddslashes($_POST['fwqid']);
$pass = daddslashes($_POST['pass']);
$maxll = daddslashes($_POST['maxll'])*1024*1024;
$state = daddslashes($_POST['state']);
$endtime = strtotime($_POST['enddate']);
$dlid = daddslashes($_POST['dlid']);
$tian = daddslashes($_POST['tian']);
$by = daddslashes($_POST['by']);

  if($DB->query("update `openvpn` set `pass`='$pass',`maxll`='$maxll',`i`='$state',`endtime`='$endtime',`dlid`='$dlid',`fwqid`='$fwqid',`notes`='$notes',`by`='$by' where iuser='$user'")){
    echo 'alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  修改成功！';
  }else{
    echo 'alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  修改失败！'.$DB->error();
  }
echo '</div>';
echo "<style>#qset{display: none;}</style>";
//exit;
}

$fwqlist=$DB->query("SELECT * FROM auth_fwq");
$dllist=$DB->query("SELECT * FROM auth_daili");
?>
      

                <form id="qset" action="./qset.php?user=<?=$user?>" method="post" role="form" class="form-horizontal">
                <input type="hidden" name="type" value="update" />

                  <div class="form-group">
                    <label class="col-sm-2 control-label">帐号密码</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="field-1" placeholder="请输入密码" name="pass" value="<?=$row['pass']?>">
                    </div>
                  </div>  

                  <div class="form-group">
                    <label class="col-sm-2 control-label">是否开通</label>
                    <div class="col-sm-9">
                <?php 
                if($row['i']==1){
                  echo '
                        <label class="radio-inline">
                          <input type="radio" name="state" checked="" value="1">
                          开通
                        </label>
                        <label class="radio-inline">
                          <input type="radio" name="state" value="0">
                          禁用
                        </label>
                  ';
                }else{
                  echo '
                        <label class="radio-inline">
                          <input type="radio" name="state" value="1">
                          开通
                        </label>
                        <label class="radio-inline">
                          <input type="radio" name="state" checked="" value="0">
                          禁用
                        </label>
                  ';}
                ?>
                    </div>
                  </div>  

                  <div class="form-group">
                    <label class="col-sm-2 control-label">是否包月</label>
                    <div class="col-sm-9">
                <?php 
                if($row['by']==1){
                  echo '
                        <label class="radio-inline">
                          <input type="radio" name="by" checked="" value="1">
                          开通
                        </label>
                        <label class="radio-inline">
                          <input type="radio" name="by" value="0">
                          禁用
                        </label>
                  ';
                }else{
                  echo '
                        <label class="radio-inline">
                          <input type="radio" name="by" value="1">
                          开通
                        </label>
                        <label class="radio-inline">
                          <input type="radio" name="by" checked="" value="0">
                          禁用
                        </label>
                  ';}
                ?><p class="text-info"><br>* 如果设置为包月，该会员将无法通过卡密充值，仅为人工设置</p>
                    </div>

                  </div>  

                  <div class="form-group">
                    <label class="col-sm-2 control-label">开通流量</label>
                    <div class="col-sm-9">
                      <div class="input-group">
                        <input type="text" class="form-control" name="maxll" value="<?=round($row['maxll']/1024/1024)?>">
                        <span class="input-group-addon">MB</span> 
                      </div>
                    </div>
                  </div>

                  <div class="form-group" id="tian">
                    <label class="col-sm-2 control-label">激活天数</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="field-1" value="<?=$row['tian']?>" placeholder="请输入使用天数" name="tian" data-validate="required">
                    </div>
                  </div>

                  <div class="form-group" id="enddate">
                    <label class="col-sm-2 control-label">到期日期</label>
                    
                    <div class="col-sm-9">
                      <div class="input-group">
                        <input type="text" class="form-control datepicker" data-format="yyyy/mm/dd " name="enddate" value="<?=date('Y/m/d',$row['endtime']);?>">
                        
                        <div class="input-group-addon">
                          <a href="#"><i class="linecons-calendar"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>

              <!-- <div class="input-group">
              <span class="input-group-addon">使用天数</span>
              <input type="text" name="tian" value="" class="form-control"  autocomplete="off" required>
              </div><br/> -->

                  <div class="form-group">

                    <label class="col-sm-2 control-label">选择代理</label>
                    <div class="col-sm-9">
                      <select class="form-control" name="dlid">
                      <?php while($d = $DB->fetch($dllist)): ?>
                        <option value="<?php echo $d['id']; ?>"  <?php if($d['id'] == $row['dlid'])echo "selected=\"selected\"";?>>用户名：<?php echo $d['user']; ?>；姓名：<?php echo $d['name']; ?></option>
                      <?php endwhile; ?>
                      </select>
                    </div>
                      
                  </div>

                  <div class="form-group">

                    <label class="col-sm-2 control-label">选择服务器</label>
                    <div class="col-sm-9">
                      <select class="form-control" name="fwqid">
                      <?php while($v = $DB->fetch($fwqlist)): ?>
                        <option value="<?php echo $v['id']; ?>"><?php echo $v['name']; ?></option>
                      <?php endwhile; ?>
                      </select>
                    </div>
                      
                  </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label">账户备注</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="field-1" placeholder="请输入备注" name="notes" value="<?=$row['notes']?>">
                    </div>
                  </div>  

                  <div class="form-group">
                    <label class="col-sm-2 control-label"></label>
                    <div class="col-sm-9">
                      <button type="submit" type="button" class="btn btn-info btn-block">修改</button>
                    </div>
                  </div>
                  
                </form>

                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
        </div>
        
        </div>
        
    </div>

  <!-- Bottom Scripts -->
  <script src="../assets/js/bootstrap.min.js"></script>
  <script src="../assets/js/TweenMax.min.js"></script>
  <script src="../assets/js/resizeable.js"></script>
  <script src="../assets/js/joinable.js"></script>
  <script src="../assets/js/xenon-api.js"></script>
  <script src="../assets/js/xenon-toggles.js"></script>


  <!-- Imported scripts on this page -->
  <script src="../assets/js/datepicker/bootstrap-datepicker.js"></script>

  <!-- JavaScripts initializations and stuff -->
  <script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 