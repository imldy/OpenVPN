<style  type="text/css">
.auto{
	background:#fff;
	padding-left:10px;
	height:40px;
	line-height:40px;
	border-top:1px solid #ccc;
}

.box01_list{
	list-style:none;
	margin:0px;
	padding:0px;
}
.sx{
	background:#328cc9;
	color:#fff;
	border:none;
	height:40px;
	margin:0px;
	float:right;
}
.breadcrumb{
	margin:0px;
}
.tip{
	color:#999;font-size:14px;
	padding:5px 0px;
}.select_note{
	padding:10px;
	background:#fff;
}
} 
</style>
<?php
$note=$_GET['note'];
$bfl=$_GET['fhl'];
$username=$_GET['username'];
$password=$_GET['password'];
if(trim($_GET["s"]) == ""){ 
if($_GET["location"] != "true"){ 
 $vo = db(openvpn)->where(array('iuser'=>$username))->find();	
 $region = $vo["area"];
 $isp = '中国'.$vo["isp"]; 
 }else{ 
      $ip = getvip(); 
           $is_location = true; 
			  $api_uri = "http://ip.taobao.com/service/getIpInfo.php?ip={$ip}";
			  $json = file_get_contents($api_uri); 
			  $arr = json_decode($json,true); 
			  if($arr["code"] != "0"){ 
				$ispno = true; 
				} 
				$isp = '中国'.$arr["data"]["isp"]; 
				$region = $arr["data"]["region"];
				   }}else{ 
					$region = $_GET["s"]; 
					$isp = $_GET["i"]; } 
					$find = str_replace("省","",$region); 
					$find = str_replace("市","",$find); 
					$find = str_replace("壮族自治区","",$find); 
					$find = str_replace("维吾尔自治区","",$find);
					$find = str_replace("回族自治区","",$find); 
					$find = str_replace("自治区","",$find);
					$line_grop = db('line_grop')->where(array("show"=>1))->order('id ASC')->select(); 
	                $line_grop = db('line_grop')->where(array("show"=>1))->order('`order` ASC,id ASC')->select();
					$dqfz = db(Ly_fz)->where(array('id'=>$note))->find();	
            if($region == '广西壮族自治区'){
			$region = '广西';
			}elseif($region == '宁夏回族自治区'){
			$region = '宁夏';	
			}elseif($region == '新疆维吾尔自治区'){
			$region = '新疆'; 
			}elseif($region == '西藏自治区'){
			$region = '西藏';
			}elseif($region == '内蒙古自治区'){
			$region = '内蒙古';}	
        if($bfl < 40){
		$yanse='#006633';	
		}elseif($bfl >= 40 && $bfl < 80){
		$yanse='#0000FF';	
		}else{
		$yanse='#FF0000';                }			
		?>
<form action="api.php?" method="GET">		
<div style="margin:10px 10px;">
<div class="alert alert-info">
<input name="act" value="line2" type="hidden"/>
<input name="username" value="<?=$username;?>" type="hidden"/>
<input name="password" value="<?=$password;?>" type="hidden"/>
<input name="note" value="<?=$note?>" type="hidden"/>
<input name="fhl" value="<?=$bfl?>" type="hidden"/>
# 当前节点为<i><?php echo $dqfz['name'];?> &nbsp;负荷率：<font color="<?php echo $yanse;?>"><?php echo $bfl;?></i></font><br><br>
# 当前系统自动定位为<select name="s">
<?php if($region != ""){?>
<option value="<?php echo $region;?>"><?php echo $region;?></option>
<?php }?>
<option>不限地区</option> 
<option>北京市</option> 
<option>天津市</option> 
<option>上海市</option> 
<option>重庆市</option>
<option>河北省</option>
<option>山西省</option>
<option>山东省</option>
<option>辽宁省</option> 
<option>吉林省</option> 
<option>黑龙江省</option> 
<option>江苏省</option> 
<option>浙江省</option> 
<option>安徽省</option> 
<option>福建省</option> 
<option>江西省</option>  
<option>河南省</option> 
<option>湖北省</option> 
<option>湖南省</option> 
<option>广东省</option> 
<option>海南省</option> 
<option>四川省</option> 
<option>贵州省</option> 
<option>云南省</option> 
<option>陕西省</option> 
<option>甘肃省</option> 
<option>宁夏</option> 
<option>广西</option> 
<option>新疆</option> 
<option>西藏</option>
<option>内蒙古</option> 
<option>青海省</option> 
<option>台湾省</option>
<option>香港</option>
<option>澳门</option>
</select>
<select name="i">
		<?php
		$i = 1;
		$p = "";
		
		$select_id = $line_grop[0]['id'];
		foreach($line_grop as $vo){
			if(!$ispno){
				if($vo["name"] == $isp){
					$p = 'selected';
					$select_id = $vo["id"];
				}
				echo '<option value="'.$vo["name"].'" '.$p.'>'.$vo["name"].'</option>';
			}else{
				if($i == 1){
					$p = 'selected';
					$select_id = $vo["id"];
				}
				echo '<option value="'.$vo["name"].'" '.$p.'>'.$vo["name"].'</option>';
			}
			$i++;
			$p = "";
		}		?>
</select></br><br>
# 如果系统自动定位不准确？
<input type="submit" class="btn btn-info btn-sm" style="float:right;height:25px;border-radius:5px;" value="筛选"/>
<a type="button" class="btn btn-success btn-sm" style="float:right;height:25px;border-radius:5px;" href="api.php?act=line2&fhl=<?php echo $bfl;?>&note=<?php echo $note;?>&username=<?php echo $username;?>&password=<?php echo $password;?>&location=true">新定位</a>						
</div></div>
</form>
    <div id="slider" class="swipe">
	
      <ul class="box01_list">
      
				<li class="li_list" style="<?php echo $ss?>">
				<!---->
					<div class="main">
					<ul class="list-group">
					<?php if($is_location){?>
					<center>
							<div class="tip">--=自动定位：<?php echo $find == "" ? "不限地区" : $region?><?php echo $isp  == "" ? "中国移动" : $isp?>=--</div>
						</center>
					<?php  };
					$show = false;
						if(trim($region) == "" || $region == "不限地区"){
							$line = db('line')->where(array('show'=>'1','group'=>$select_id))->order('id DESC')->select();
						}else{
							$show = true;
							if(str_length(urldecode($region)) > 8){
								die("参数过长 len:".str_length(urldecode($region)));
							}
							$line = db('line')->where("`show`=1 AND `group`=:select_id AND (label LIKE '%".$find."%' OR name LIKE '%".$find."%')",array(":select_id"=>$select_id))->order('id DESC')->select();

							$line2 = db('line')->where("`show`=1 AND `group`=:select_id AND (label LIKE '%全国%' OR label LIKE '%通用%' OR label LIKE '%不限地区%' OR `name` LIKE '%全国%' OR `name` LIKE '%通用%' OR `name` LIKE '%不限地区%')",array(":select_id"=>$select_id))->order('id DESC')->select();
						}
						
						if($line){
							foreach($line as $vos){
								$num = db("openvpn")->where(array('line_id'=>$vos['id']))->getnums();
								?>
							<li class="list-group-item"><h4><?php echo $vos['name']?>
							<h5><i><?php echo $vos['label']?></i></h4>	
                            <img src="mode/pay/time.jpg" height="13" width="13"/>&nbsp;<?php echo $vos['type'];?>
							&nbsp;&nbsp;<img src="../assets/img/user.png" height="13" width="11"/>&nbsp;有<?php echo $num?>人安装
							<button class="btn btn-warning btn-sm" style="float:right;height:25px;border-radius:5px;" data-toggle="modal" data-target="#user_fk" onclick="Userfank('<?php echo $vos['name'];?>',<?php echo $vos['id']?>)">反馈</button>
							<button class="btn btn-info btn-sm" style="float:right;height:25px;border-radius:5px;" onclick="addLine('<?php echo $vos['id']?>')">安装</button>&nbsp;&nbsp;
							</li>
							<?php 
							}
						}else{
						?>
						<center>
							<div style="color:#ccc;font-size:12px;">没有找到该地区线路哦</div>
						</center>
						<?php
						}
						if($show){
						?>
						<center>
							<div class="tip">--=为您推荐全国线路=--</div>
						</center>
						<?php foreach($line2 as $vos){
							$num = db("openvpn")->where(array('line_id'=>$vos['id']))->getnums();?>
						     <li class="list-group-item"><h4><?php echo $vos['name']?>
							<h5><i><?php echo $vos['label']?></i></h4>	
                            <img src="mode/pay/time.jpg" height="13" width="13"/>&nbsp;&nbsp;<?php echo $vos['type']?>
							&nbsp;&nbsp;<img src="../assets/img/user.png" height="13" width="11"/>&nbsp;有<?php echo $num?>人安装
							<button class="btn btn-warning btn-sm" style="float:right;height:25px;border-radius:5px;" data-toggle="modal" data-target="#user_fk" onclick="Userfank('<?php echo $vos['name'];?>',<?php echo $vos['id']?>)">反馈</button>
							<button class="btn btn-info btn-sm" style="float:right;height:25px;border-radius:5px;" onclick="addLine('<?php echo $vos['id']?>')">安装</button>&nbsp;&nbsp;
							</li><?php }
						} ?>
					</ul>
					<div style="clear:both"></div>
				</div>
			</li>		
		<!---->
      </ul>
</div>
	<center>
		<div style="color:#ccc;font-size:12px;">我们一直在努力创新 只为给你带来更完美</div>
	</center>
<!-- 模态框（Modal） -->
<div class="modal fade" id="user_fk" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
					&times;
				</button>
				<h4 class="modal-title">
			  线路反馈 <small id="myModalLabel"></small>
			</h4>
			</div>
			<div class="modal-body">
			  <label for="name">当前线路网速</label><br>
			        <select class="form-control m-b" id="wang">
					    <option value="3">非常快</option>
					        <option value="1">有限速</option>
                                 <option value="2">不限速</option>
                             </select>	
							<br>
				          <div class="form-group">
                          <label for="name">您所在的地区</label><br>
                          <input type="text" class="form-control" id="diqu"/>
                       </div>
					</div>
			       <div class="modal-footer">
				<button type="button" class="btn btn-default" style="border-radius:5px;" data-dismiss="modal">
				   Close
				</button>
				<button onclick="Fank()" class="btn btn-info" style="border-radius:5px;">
					保持内容
				</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal -->
</div>
<!-- 模态框（Modal）end --> 
<script type="text/javascript">
var line_id = 0;
$(function(){
	$(".gitem").click(function(){
			var n = $(".gitem").index(this);
			$(".gitem a").removeClass("active").eq(n).addClass("active");
			$(".li_list").hide().eq(n).show();
		});
	});
	
	var name_tmp = "";
	function addLine(id){
		
		$.post(
			'getLine.php',
			{
				'id':id,
				'username':'<?php echo $_GET["username"] ?>',
				'note':'<?php echo $_GET["note"] ?>',
				'password':'<?php echo $_GET["password"] ?>'
			},function(data){
				if(data.status == 'success'){
					//window.myObj.writeFile('test.ovpn','<?php echo base64_encode(file_get_contents('1.ovpn'))?>','download');
					name_tmp = data.name;
					window.myObj.writeFile(data.name+'.ovpn',data.content,'download'); 
				}else{
					alert(data.msg);
				}
			},"JSON");
		  
	}
	function cli_sendData(status,type,msg){
		if(type == 'file_w'){
			if(status == 'success'){
				window.myObj.installPro('download/'+name_tmp+'.ovpn');
			}else{
				$('.tip').html("写入文件失败");
			}
		}
	}
	
function Fank(){
  if($("#diqu").val() == ""){
	  alert("请填写你所在的地区哦");
   }else{
	  $.post(
			'api.php?act=fank',
			{
				'user':'<?php echo $username?>',
				'wang': $("#wang").val(),
				'id':line_id,
			    'diqu':$("#diqu").val()
			},function(data){
				if(data.status == 'success'){
				  $('#user_fk').modal('hide');
				    alert("反馈成功啦");
				}else if(data.status == "old"){
					$('#user_fk').modal('hide');
				    alert("同一账号30分钟只能反馈一次哦");
			    }else{
					alert(data.msg);
				}
			},"JSON");
    }
}
function Userfank(name,id){
    $("#myModalLabel").html(name);
    line_id = id;
}
	</script>
