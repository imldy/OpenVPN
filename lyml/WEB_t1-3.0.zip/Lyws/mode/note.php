<?php
$u = $_GET['username'];
$p = $_GET['password'];
   echo '<div style="margin:10px 10px;">
   <div class="alert alert-info"># 请根据你所在地区和节点负荷来选择节点
   <br># 节点离你越近和负荷越小网速就会越快哦！
   </div></div><div class="main">';
      $note_list = db('Ly_fz')->where(array())->order('`order` ASC')->select();
	foreach($note_list as $vo){	
	    $ip = gethostbyname(''.$vo['ipport'].'');
		$onlinenum = db("openvpn")->where(array('last_ip'=>$ip,'online'=>'1'))->getnums();
		$dqfz = db(Ly_fz)->where(array('id'=>$vo['id']))->find();
		$bfl = $onlinenum/$dqfz['maximum']*100;   //默认200人在线为100%，请根据自己的服务器宽带调整
		if($bfl == 0){
			$fhl = '空闲';
		}else{
			$fhl = ''.$bfl.'%';
		}	
		if($bfl < 60){
		$yanse='#006633';	
		}elseif($bfl >= 60 && $bfl < 80){
		$yanse='#0000FF';	
		}else{
		$yanse='#FF0000';}		
		echo '<ul class="list-group"><li class="list-group-item"><h4>'.$vo['name'].'<h5>'.$vo['type'].' &nbsp;<i>负荷率：<font color="'.$yanse.'">'.$fhl.'</i></font>
			<a type="button" class="btn btn-info btn-sm" style="float:right;width:20%;height:25px;border-radius:5px;" href="api.php?act=line2&username='.$u.'&password='.$p.'&note='.$vo[id].'&fhl='.$fhl.'">选择</a></h4></li></ul>';
		 }
  ?>
  </div>
  <center>
		<div style="color:#ccc;font-size:12px;">我们一直在努力创新 只为给你带来更完美</div>
	</center>