<?php
require("../../Kyws/system.php");
header("Content-Type: application/force-download");
if (!isset($_POST['cid']) || !isset($_POST['axid'])) {
	echo '缺少必要的参数';
	die;
}
$u = @$_GET['user'];
$p = @$_GET['pass'];
$region = $_POST['region'];
$isps = $_POST['isps'];
$res=db(_openvpn_)->where(array(_iuser_=>$u,_ipass_=>$p))->find();
if(!$res){
	echo "you need to login";
	exit;
}
$cid = (int)$_POST['cid'];
$aid = (int)$_POST['bxid'];
if(isset($_POST['axid']) && $_POST['axid'] != 'ABC'){
		$aid = $_POST['axid'];
}
$result = db("line")->where(array("group"=>$cid,"id"=>$aid))->find();
if(!$result) {
	echo '记录集为空';
	die;
}
$ip = getvip(); 
$agent = getAgent();
db(_openvpn_)->where(array(_iuser_=>$u))->update(array('area'=>$region,'isp'=>$isps,'client'=>$agent,'line_id'=>$aid));
$zs=db("ky_zs")->where(array())->find();
$fwq=db("ky_fz")->where(array("id"=>$_POST['note']))->find();
$fileName = $result['name'].'.ovpn';
$name = iconv('UTF-8','GBK',$fileName);
$content = $result['content'];
$content = preg_replace("/\[ip\]/is",$fwq["ipport"],$content);
$content = preg_replace("/\[C证书\]/is",html_decode($zs["ca"]),$content);
$content = preg_replace("/\[T证书\]/is",html_decode($zs["tls"]),$content);
header("Content-Disposition: attachment; filename=\"" . $name . "\"");
//转义数据库特殊符号
echo htmlspecialchars_decode($content,ENT_QUOTES);
mysql_close($con);
