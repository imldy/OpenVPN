<?php
$mod='blank';
include("../api.inc.php");

$userid=$_SESSION['userid'];

$u = daddslashes($_GET['user']);

$p = daddslashes($_GET['pass']);



if($u==""){
$res = $DB->get_row("SELECT * FROM openvpn WHERE id='$userid' limit 1");
$qdres = $DB->get_row("SELECT * FROM auth_qd WHERE iuser='{$res['iuser']}' limit 1");
}else{
$res=$DB->get_row("SELECT * FROM `openvpn` where `iuser`='$u' && `pass`='$p' limit 1");
}


if(!$res){
//	header('location: login.php');
		exit("<script language='javascript'>window.location.href='./login.php';</script>");
}


$title='用户中心';
include './head.php';

?>



<section id="content"> 
 <div class="container"> <div class="m-b-lg m-t-lg"> 


<div class="col-lg-6">
<div class="widget">


          <div class="panel-title">资料修改</div>
<div class="widget-content block full">
<div class="ibox-content">
<form action="index" role="form" class="form-horizontal" method="post">
<div class="form-group">
<label class="col-lg-3 control-label">ID:</label>
<div class="col-lg-8">
<input type="text" class="form-control" value="<?php echo $_SESSION['dlid'];?>" disabled="disabled">
</div>
</div>
<div class="form-group">
<label class="col-lg-3 control-label">用户名:</label>
<div class="col-lg-8">
<input type="text" class="form-control" value="<?php echo $row['user'];;?>" disabled="disabled">
</div>
</div>
<div class="form-group">
<label class="col-lg-3 control-label">绑定QQ：</label>
<div class="col-lg-8">
<?php 
if(!$row['qq']){	
echo "<input type='text' class='form-control' name='newqq' value=''>";
}else{
echo "<input type='text' class='form-control' disabled='disabled' maxlength='12' name='qq' value='".$row['qq']."'>";
}
?>




<span class="help-block m-b-none">所有信息都与此QQ进行绑定，填写后可显示对应头像以及用来找回密码，加入Vip售后群时将以此QQ号进行验证</span>
</div>
</div>

<div class="form-group">
<label class="col-lg-3 control-label">旧密码:</label>
<div class="col-lg-8">
<input type="text" class="form-control" name="pass" placeholder="">
</div>
</div>
<div class="form-group">
<label class="col-lg-3 control-label">新密码:</label>
<div class="col-lg-8">
<input type="text" class="form-control" name="newpass" placeholder="不修改请留空">
</div>
</div>
<div class="form-group">
<div class="col-lg-offset-3 col-lg-8">
<button class="btn btn-sm btn-primary pull-right m-t-n-xs" type="submit">保存修改</button>
</div>
</div>
</form>
</div>
</div>
</div>
</div>

