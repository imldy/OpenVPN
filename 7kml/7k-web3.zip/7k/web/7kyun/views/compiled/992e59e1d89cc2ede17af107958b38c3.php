﻿﻿<!DOCTYPE HTML>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <meta name="viewport"
          content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no"/>
    <meta name="MobileOptimized" content="320"/>
    <meta name="author" content="<?php echo $author; ?>"/>
    <meta name="robots" content="none"/>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/mui.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/jquery.js"></script>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/default.js"></script>
    <title><?php echo $title; ?></title>
    <link type="image/x-icon" rel="icon" href="<?php echo $base_url; ?>/favicon.ico"/>
    <link type="image/x-icon" rel="shortcut icon" href="<?php echo $base_url; ?>/favicon.ico"/>
    <link href="<?php echo $base_url; ?>/views/assets/css/mui.min.css" rel="stylesheet"/>
    <link href="<?php echo $base_url; ?>/views/assets/css/default.css" rel="stylesheet"/>
    <style type="text/css">
        html, body {
            height: 100%;
            overflow: hidden;
            background: #FFFFFF;
        }

        .mui-content {
            padding: 10px;
            background: #FFFFFF;
        }

        .mui-table-view:after {
            height: 0;
        }

        .mui-table-view-cell:after {
            left: 1px;
        }

        .mui-input-group .mui-input-row::after {
            left: 0;
        }

        .mui-input-group::before,
        .mui-input-group::after {
            height: 0;
        }

        .mui-btn {
            padding: 5px;
        }
    </style>
</head>

<body>
<noscript class="error">
    很遗憾，由于你的浏览器不支持或禁用了JavaScript，导致无法获得正常体验。
</noscript><script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/jquery.uploadfile.js"></script>
<script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/jquery.form.js"></script>
<header class="mui-bar mui-bar-nav">
    <a class="mui-action-back mui-icon mui-icon-left-nav mui-pull-left" href="javascript:history.back();"></a>

    <h1 class="mui-title"><?php echo $title; ?></h1>
</header>
<div class="mui-content">
    <form class="mui-input-group">
        <h5>类型：</h5>

        <div class="mui-input-row">
            <select name="category" id="category" class="mui-left">
                <?php foreach ($categories as $category) { ?>
                <option value="<?php echo $category['id']; ?>">
                    <?php echo $category['name']; ?>
                </option>
                <?php } ?>
            </select>
        </div>
        <h5>名称：(支持<a href="<?php echo $base_url; ?>/smhoud.php?c=Ubb" target="_blank">UBB</a>)</h5>

        <div class="mui-input-row">
            <input type="text" id="link_name" name="link_name" maxlength="50" placeholder="50字以内"
                   class="mui-input mui-input-clear"/>
        </div>
        <h5>地址：</h5>

        <div class="mui-input-row">
            <input type="text" id="link_url" name="link_url" value="http://" class="mui-input mui-input-clear"/>
        </div>
        <h5>图标：</h5>

        <div>
            <span id="upload" class="mui-btn-link"></span>

            <div class="center"><img id="link_icon" src="." width="60" alt="[图]"/></div>
        </div>
        <h5>排序：</h5>

        <div class="mui-input-row">
            <input type="number" id="link_sortby" name="link_sortby" value="0" class="mui-input mui-input-clear"/>
        </div>
    </form>
    <div class="mui-content-padded">
        <button class="mui-btn mui-btn-block mui-btn-primary" onclick="linkAdd()">添加</button>
    </div>
    <div class="loader hide"></div>
</div>
<script type="text/javascript">
    jQuery("#upload").uploadFile({
        url: '<?php echo $base_url; ?>/api.php?c=Upload&dir=image',
        returnType: 'json',
        fileName: 'file',
        multiple: false,
        dragDrop: false,
        autoSubmit: true,
        showCancel: false,
        allowDuplicates: false,
        maxFileSize: 50000, //约50K
        showFileCounter: false,
        allowedTypes: 'jpg,png',
        acceptFiles: '.jpg,.png',
        uploadButtonClass: "txt",
        uploadStr: "点击上传图片",
        extErrorStr: "不允许上传，只允许：",
        duplicateErrorStr: "不允许上传，文件已存在",
        sizeErrorStr: "不允许上传，只允许最大尺寸：",
        uploadErrorStr: "上传出错了",
        onSuccess: function (files, response, xhr, pd) {
            if (response.code == 1) {
                jQuery("#link_icon").attr("src", response.msg);
            } else {
                alert(response.msg);
            }
        },
        onError: function (files, status, message, pd) {
            alert(message);
        }
    });

    function linkAdd() {
        var category = jQuery.trim(jQuery("#category").val());
        var name = jQuery.trim(jQuery("#link_name").val());
        var url = jQuery.trim(jQuery("#link_url").val());
        var icon = jQuery("#link_icon").attr("src");
        var sortby = jQuery.trim(jQuery("#link_sortby").val());
        if (name == "") {
            alert("名称不能为空！");
            //noinspection JSValidateTypes
            return false;
        } else if (url == "") {
            alert("链接不能为空！");
            //noinspection JSValidateTypes
            return false;
        } else if (url == "http://") {
            alert("链接还没有填写！");
            //noinspection JSValidateTypes
            return false;
        } else if (icon == "") {
            alert("图标不能为空！");
            //noinspection JSValidateTypes
            return false;
        } else if (!jQuery.isNumeric(sortby)) {
            alert("排序只能为数字！");
            //noinspection JSValidateTypes
            return false;
        }
        jQuery(".loader").show();
        name = encodeURIComponent(name);
        url = encodeURIComponent(url);
        icon = encodeURIComponent(icon);
        jQuery.post("<?php echo $base_url; ?>/smhoud.php?c=LinkManage&a=add", {
            token: '<?php echo $token; ?>',
            category: category,
            name: name,
            url: url,
            icon: icon,
            sortby: sortby
        }, function (result) {
            jQuery(".loader").hide();
            if (confirm(result + "\n需要继续添加吗？")) {
                window.location = "<?php echo $base_url; ?>/smhoud.php?c=LinkManage&a=add&token=<?php echo $token; ?>";
            } else {
                window.location = "<?php echo $base_url; ?>/smhoud.php?c=LinkManage&token=<?php echo $token; ?>";
            }
        }, "text");
        //noinspection JSValidateTypes
        return false; //阻止表单提交
    }
</script><div style="width:100%;background:#FFFFFF;display:block;border-top:1px dotted #CCCCCC;position:fixed;bottom:0;">
    <div class="center">
        <?php echo isset($copyright) ? $copyright : ''; ?>
    </div>
</div>
</body>

</html>
<!-- Created By Template Engineer At 2016/07/27,22:40 -->
