<?php
/**
 * 搜索授权
**/
$mod='blank';
include("../api.inc.php");
$title='搜索卡密';
$dlid=$_SESSION['dlid'];
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head2.php';?>
<body class="page-body">
    
    <?php include 'nav.php';?>

    <div class="page-container"><!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->
            
        <div class="main-content">
                    
            
            <h3 id="layout-toggles">
                代理中心
                <br />
            </h3>
            
            <br />

            <div class="row">
                
                <div class="col-sm-12">
                    
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            请输入信息
                        </div>
                        
                        <div class="panel-body">
                            
                            <div class="row">
                                <div class="col-sm-12">
                                    
                              <form action="./kmlist.php" method="get" class="form-inline validate" role="form">
                                <div class="form-group">
                                  <select name="type" class="form-control">
                                    <option value="1">卡密</option>
                                    <option value="2">账号</option>
                                  </select>
                                </div>
                                <div class="form-group">
                                  <input type="text" name="kw" value="" class="form-control"  data-validate="required"/>
                                </div>
                                <input type="submit" value="查询" class="btn btn btn-secondary btn-single"/>
                              </form>
                                    
                                </div>
                            </div>
                            
                        </div>
                        
                    </div>
                </div>

            </div>

             <?php include("../copy2.php");?>
             
        </div>
        
    </div>
    
    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>

    <script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>

    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 