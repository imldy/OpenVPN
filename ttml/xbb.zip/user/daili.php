<?php
$mod='blank';
include("../api.inc.php");

$userid=$_SESSION['userid'];

$u = daddslashes($_GET['user']);

$p = daddslashes($_GET['pass']);



if($u==""){
$res = $DB->get_row("SELECT * FROM openvpn WHERE id='$userid' limit 1");
$qdres = $DB->get_row("SELECT * FROM auth_qd WHERE iuser='{$res['iuser']}' limit 1");
}else{
$res=$DB->get_row("SELECT * FROM `openvpn` where `iuser`='$u' && `pass`='$p' limit 1");
}


if(!$res){
//	header('location: login.php');
		exit("<script language='javascript'>window.location.href='./login.php';</script>");
}

if($res['dlif']=0){exit("<script language='javascript'>alert('代理已开通，请勿重复开通！');history.go(-1);</script>");}




if($_GET['id']){
	$id = daddslashes($_GET['id']);
	$row=$DB->get_row("SELECT * FROM `auth_dltc` where `id`='$id' limit 1");
	if(!$row){
		exit("<script language='javascript'>alert('此代理套餐不存在');history.go(-1);</script>");
	}else{
		

		$rmb = $row['rmb'];
		$xrmb = $row['rmb']-10;
		$vip = $row['vip'];
		$numrows=$DB->count("SELECT count(*) from `auth_daili` WHERE 1") + 1;

		$srmb=$res['userrmb']-$rmb;
		
		if($srmb>=0){
	
		}else{
			exit("<script language='javascript'>alert('生成失败，余额不足，请联系管理员充值！');history.go(-1);</script>");
		}
		$sql=$DB->query("update `openvpn` set `userrmb`='$srmb' where `id`='{$res['id']}';");
		if($sql){
		$DB->query("insert `auth_daili`(`id`,`user`,`pass`,`rmb`,`vip`,`kmlist`,`active`,`regdate`,`qq`) values('$numrows','{$res['iuser']}','{$res['pass']}','{$xrmb}','{$vip}',null,1,'$date','{$res['qq']}');");
		wlog('账号','用户'.$u.'开通代理'.$km.'续费账号['.$date.']');
		exit("<script language='javascript'>alert('开通代理成功！');history.go(-1);</script>");
		}else{
			exit("<script language='javascript'>alert('扣款失败，请联系管理员！');history.go(-1);</script>");
		}
		

		


		//$duetime = ($res['endtime'] < time() ? time() : $res['endtime']) + $myrow['value']*24*60*60;
		//$addll = ($res['endtime'] < time() ? $myrow['values'] : $res['endtime']) + $myrow['values'];
		//$sql="update `openvpn` set `maxll`=`maxll` + '0',`endtime`='{$duetime}' where `iuser`='{$res['iuser']}' && `pass`='{$p}'";
		

		
	//if($DB->query("update `openvpn` set `pass`='$pass',`maxll`='$maxll',`i`='$state',`endtime`='$endtime' where iuser='$user'"))
}
}


if($_POST['km']){
	$km = daddslashes($_POST['km']);
	$myrow=$DB->get_row("select * from auth_rmb where kind=1 and km='$km' limit 1");
	if(!$myrow){
		exit("<script language='javascript'>alert('此激活码不存在');history.go(-1);</script>");
	}elseif($myrow['isuse']==1){
		exit("<script language='javascript'>alert('此激活码已被使用');history.go(-1);</script>");
	}else{
		$rmb = $myrow['money'];
        $sql="update `openvpn` set `userrmb`=`userrmb` + '{$rmb}' where `iuser`='{$res['iuser']}' && `pass`='{$res['pass']}'";
			if($DB->query($sql)){
				$DB->query("update `auth_rmb` set `isuse` ='1',`user` ='{$res['iuser']}',`usetime` ='$date' where `id`='{$myrow['id']}'");
				wlog('账号激活','用户'.$u.'使用激活码'.$km.'续费账号['.$date.']');
				exit("<script language='javascript'>alert('续费成功！');history.go(-1);</script>");
			}else{
				exit("<script language='javascript'>alert('续费失败！');history.go(-1);</script>");
			}
		
		
		//$duetime = ($res['endtime'] < time() ? time() : $res['endtime']) + $myrow['value']*24*60*60;
		//$addll = ($res['endtime'] < time() ? $myrow['values'] : $res['endtime']) + $myrow['values'];
		//$sql="update `openvpn` set `maxll`=`maxll` + '0',`endtime`='{$duetime}' where `iuser`='{$res['iuser']}' && `pass`='{$p}'";
		
	}
	//if($DB->query("update `openvpn` set `pass`='$pass',`maxll`='$maxll',`i`='$state',`endtime`='$endtime' where iuser='$user'"))
}

$title='用户中心';
include './head.php';

$config = $DB->get_row("SELECT * FROM auth_config");
$gonggao=$config['ggs'];//公告获取
if(!empty($_GET['kw'])) {
	$sql=" `title`='{$_GET['kw']}'";
	$numrows=$DB->count("SELECT count(*) from `auth_dltc` WHERE{$sql}");
	$con='包含 '.$_GET['kw'].' 的共有 <b>'.$numrows.'</b> 个路线';
}else{
	$numrows=$DB->count("SELECT count(*) from `auth_dltc` WHERE 1");
	$sql=" 1";
	$con='平台总路线: <b>'.$numrows.'</b>&nbsp&nbsp&nbsp&nbsp';
}
?>

<section id="content"> 
 <div class="container"> <div class="m-b-lg m-t-lg"> 

 
 
 
 <?php
$pagesize=30;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
//$zt = array('0'=>'<font color=green>正常</font>','1'=>'<font color=red>密码错误</font>','2'=>'<font color=red>冻结</font>','3'=>'<font color=red>开启设备锁</font>');
$rs=$DB->query("SELECT * FROM `auth_dltc` WHERE{$sql} order by id desc limit $offset,$pagesize");
while($row = $DB->fetch($rs))

{ 

$con=$DB->get_row("SELECT * FROM auth_config WHERE 1");

if($res['vip']==0){
		$isactive=$con['dl0']."元/天 + ".$con['dls0']."元/GB";
}elseif($res['vip']==1){
	$isactive=$con['dl1']."元/天 + ".$con['dls1']."元/GB";
}elseif($res['vip']==2){
	$isactive=$con['dl2']."元/天 + ".$con['dls2']."元/GB";
}elseif($res['vip']==3){
	$isactive=$con['dl3']."元/天 + ".$con['dls3']."元/GB";
}elseif($res['vip']==4){
	$isactive=$con['dl4']."元/天 + ".$con['dls4']."元/GB";
}elseif($res['vip']==5){
	$isactive=$con['dl5']."元/天 + ".$con['dls5']."元/GB";
}

?>
 
<div class="col-lg-4">
                        <div class="panel b-a">
                            <div class="panel-heading text-center bg-info no-border">
                              <h4 class="text-u-c m-b-none"><?=$row['name']?></h4>
                              <h2 class="m-t-none">
                                <sup class="pos-rlt" style="top:-22px">$</sup>
                                <span class="text-2x text-lt"><?=$row['rmb']?></span>
                                <span class="text-xs">/ 元 (永久权限)</span>
                              </h2>
                            </div>
                            <ul class="list-group">
                                <li class="list-group-item">
                                    <i class="icon-check text-success m-r-xs"></i> 独立代理后台
                                </li>
                                <li class="list-group-item">
                                    <i class="icon-check text-success m-r-xs"></i> 流量拿货<?php echo $isactive;?>
                                </li>
                                <li class="list-group-item">
                                    <i class="icon-check text-success m-r-xs"></i> 生成流量充值卡密
                                </li>
                                <li class="list-group-item">
                                    <i class="icon-close text-danger m-r-xs"></i> <span class="text-l-t">生成用户购买卡密</span>
                                </li>
                                <li class="list-group-item">
                                    <i class="icon-close text-danger m-r-xs"></i> <span class="text-l-t">在线用户充值流量</span>
                                </li>
                                <li class="list-group-item">
                                    <i class="icon-close text-danger m-r-xs"></i> <span class="text-l-t">生成用户充值卡密</span>
                                </li>
                                <li class="list-group-item">
                                    <i class="icon-close text-danger m-r-xs"></i> <span class="text-l-t">后台直接创建VPN帐号</span>
                                </li>
                                <li class="list-group-item">
                                    <i class="icon-close text-danger m-r-xs"></i> <span class="text-l-t">包月无限流量充值卡密</span>
                                </li>
                            </ul>
                            <div class="panel-footer text-center">
                                <a href="daili.php?id=<?=$row['id']?>" class="btn btn-info font-bold m">我要开通</a>
                            </div>
                        </div>
                    </div>
<?php }
?>
  </center>