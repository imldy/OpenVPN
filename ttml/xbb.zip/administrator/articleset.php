<?php
    $mod = 'blank';
    include ('../api.inc.php');
    $title = '账号列表';
    include './head.php';
    if ($islogin2 == 1) {
    } else exit ("<script language='javascript'>window.location.href='./login.php';</script>");
?>

<?php
    $id = daddslashes($_GET['id']);
    if (!$id || !$row = $DB->get_row("select * from `lyj_article` where id='$id' limit 1")) {
        exit ('线路不存在');
    }
    if ($_POST['type'] == 'update') {
        echo '<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">修改线路结果</h3></div>
<div class="panel-body">';
        $title = daddslashes($_POST['title']);
        $content = daddslashes($_POST['content']);
        $id = daddslashes($_POST['id']);
        if ($DB->query("update `lyj_article` set `title`='$title',`content`='$content' where id='$id'")) {
            echo '修改成功！';
        } else {
            echo '修改失败！'.$DB->error();
        }
        echo '<hr/><a href="./article.php">>>返回线路列表</a></div></div>';
        exit;
    }
?>

<section id="content">
<section class="vbox">
<section class="scrollable padder">
<ul class="breadcrumb no-border no-radius b-b b-light pull-in">
<section class="panel panel-default">
              <header class="panel-heading font-bold"> 路线:<?=$row['title']
?> 配置 </header>
              <div class="panel-body">

          <form action="./articleset.php?id=<?=$id
?>" method="post" class="form-horizontal" role="form">
          <input type="hidden" name="type" value="update" />
          	<div class="input-group">
              <span class="input-group-addon">路线id</span>
			  <input type="text" name="id" value="<?=$row['id']
?>" class="form-control">
            </div><br/>
          	<div class="input-group">
              <span class="input-group-addon">路线名称</span>
			  <input type="text" name="title" value="<?=$row['title']
?>" class="form-control">
            </div><br/>
            <div class="form-group">
            	<input type="hidden" name="content" value="config"/>
              <label class="col-sm-2 control-label">路线OPEN</label><br>
			<div class="col-sm-10"><textarea class="form-control" name="content" rows="5" cols="50" required><?=$row['content']
?><?php
    echo '</textarea></div>
            </div><br/>
			
            <div class="form-group">
              <div class="col-sm-12"><input type="submit" name="submit" value="修改" class="btn btn-primary form-control"/></div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
';
    include './nav.php';
?>