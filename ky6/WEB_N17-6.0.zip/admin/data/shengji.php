<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
$res=$DB->get_row("SELECT * FROM kyun");
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>云端管理 - 启动图与更新</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>云端管理 >><small>启动图与更新</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
<?php
if($_POST["versionCode"]){	
echo '<div class="panel-heading w h">
<h3 class="panel-title">修改软件信息结果</h3></div>
<div class="panel-body box">';
$versionCode=$_POST["versionCode"];
$content=$_POST["content"];
$url=$_POST["url"];
$splash=$_POST["splash"];
$splashurl=$_POST["splashurl"];
$sql="update `kyun` set `versionCode`='{$versionCode}',`url`='{$url}',`content`='{$content}',`splash`='{$splash}',`splashurl`='{$splashurl}'";
if ($DB->query($sql)){ 
echo '<div class="box">恭喜亲，成功修改软件相关信息</div>';}
else{echo'<div class="box">噢，修改软件信息失败,请稍后重新尝试.</div>';}
echo '<hr/><a href="./shengji.php" class="btn btn-success">返回修改更新</a></div>';
exit;}
?>
                        <form action="./shengji.php" method="post" class="form-horizontal m-t">
							 <div class="form-group has-error">
								 <label class="col-sm-2 control-label">启动图</label>
								   <div class="col-sm-2">
                                    <select class="form-control m-b" name="splash">
									<?php
									if($res['splash'] == 'yes'){
									   echo '<option value="yes">启用</option>
									         <option value="no">关闭</option>';
									}else{
									   echo '<option value="no">关闭</option>
									        <option value="yes">启用</option>';
									}                                  ?>
                                    </select>
                                </div>
								<label class="col-sm-2 control-label">启动图地址</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" value="<?php echo $res['splashurl'];?>" name="splashurl" required="required"/>
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
						  <div class="form-group has-warning">
                                <label class="col-sm-2 control-label">版本号</label>
                                <div class="col-sm-2">
                                    <input type="text" class="form-control" value="<?php echo $res['versionCode'];?>" name="versionCode" required="required"/>
                                </div>
								<label class="col-sm-2 control-label">软件下载地址</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" value="<?php echo $res['url'];?>" name="url" required="required"/>
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
						    <div class="form-group has-success"> 
                                <label class="col-sm-2 control-label">更新提示内容</label>
                                 <div class="col-sm-9">
                                   <textarea class="form-control" rows="6" name="content"><?php echo $res['content'];?></textarea>
                                 </div>
								</div>
							  <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-4 col-sm-offset-2"> 
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                                </div>
                            </div>
                        </form>					
                    </div>
                </div>
            </div>
        </div>

    </div>

</body>

</html>
