<?php
$mod='blank';
include("../api.inc.php");
if($active != 2)exit("Error");
$title='添加服务器';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<!-- Body -->
<body>
        <?php include 'nav.php';?>
		      <section>
         <!-- Page content-->
         <div class="content-wrapper">
            <h3><?php echo $title ?>
               <small>可在此增加多个服务器在此平台维护</small>
            </h3>





                   

                      <?php
                      if($_POST['name']){
                      echo '<div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert">
                      <span aria-hidden="true">×</span>
                      <span class="sr-only">Close</span>
                    </button>';
                      $name = daddslashes($_POST['name']);
                      $ipport = daddslashes($_POST['ipport']);

                      if(!$DB->get_row("select * from `auth_fwq` where `name`='$name' limit 1")){
                        $sql="insert into `auth_fwq` (`name`,`ipport`) values ('{$name}','{$ipport}')";
                        if($DB->query($sql))
                          echo "成功添加一个服务器";
                        else
                          echo "添加失败：".$DB->error();
                      }else{
                        echo "<script>alert('该服务器已存在！');history.go(-1);</script>";
                      }
                      echo '</div>';
                      //exit;
                      }
                      ?>

                                         <div class="row">
               <div class="col-md-12">
                      
					  		                       <div class="panel panel-default">

                        <div class="panel-body">
                    <div class="panel-body">
              <form action="./addfwq.php" method="post" role="form" class="form-horizontal validate">
                
                <div class="form-group">
                  <div class="col-sm-12">
                    <input type="text" class="form-control" id="field-1" placeholder="服务器名称" name="name" data-validate="required">
                  </div>
                </div>

                <div class="form-group">
                  <div class="col-sm-12">
                    <input type="text" class="form-control" id="field-1" placeholder="ip地址:端口" name="ipport" data-validate="required">
                  </div>
                </div>

                <button type="submit" type="button" class="btn btn-info">添加</button>
                
              </form>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
