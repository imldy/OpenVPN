﻿<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：用户下载线路配置文件
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

$db =db("openvpn");	
$row = $db->where(array('iuser'=>$_GET['user'],'pass'=>$_GET['pass']))->find();
if($row){
$res = $db->where(array('iuser'=>$row['iuser']))->find();
if($res['i']<>'1'){
	exit("<script>alert('账号未激活或流量不足！');history.go(-1);</script>");
}
$lineid = $_POST['bxid'];
$ip = $_POST['ip'];
$isp = $_POST['isp'];
$agent = getAgent();
if(isset($_POST['axid']) && $_POST['axid'] != 'ABC'){
		$lineid = $_POST['axid'];
}
$res = db("line")->where(array('id'=>$lineid))->find();
if(!$res){
   exit("<script>alert('亲，平台没有此线路！');history.go(-1);</script>");
}
$db->where(array('iuser'=>$u))->update(array('area'=>$region,'isp'=>$isp,'client'=>$agent,'line_id'=>$lineid));
$zs = db('ky_zs')->where(array())->find();
$fwq = db('ky_fz')->where(array(id=>$_POST['note']))->find();
$fileName = $res['name'].'.ovpn';
$name = iconv('UTF-8','GBK',$fileName);
$content = preg_replace("/\[ip\]/is",$fwq["ipport"],$res['content']);
$content = preg_replace("/\[C证书\]/is",$zs["ca"],$content);
$content = preg_replace("/\[T证书\]/is",$zs["tls"],$content);
Header( "Content-type:  application/octet-stream "); 
Header( "Accept-Ranges:  bytes "); 
Header( "Accept-Length: " .filesize($name));
header("Content-Disposition: attachment; filename=\"" . $name . "\"");
echo html_decode($content);  
}else{
   exit("<script>window.location.href='../index.php';</script>");
}
?>