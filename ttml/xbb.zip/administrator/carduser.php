<?php
    $mod = 'blank';
    include ('../api.inc.php');
    $title = '用户直充';
    include './head.php';
    if ($islogin2 == 1) {
    } else exit ("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<?php
    echo '
<div class="row wrapper wrapper-content">
    <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
';
    $my = isset($_GET['my']) ? $_GET['my'] : null;
    if ($my == 'add') {
        $user = daddslashes($_POST['user']);
        $value = strval($_POST['value']);
        $endtime = strval($_POST['endtime']);
        if (!$user) {
            exit ("<script language='javascript'>alert('充值失败，用户不能为空！');history.go(-1);</script>");
        }
        if ($endtime <= 0) {
            exit ("<script language='javascript'>alert('充值失败，生成天数必须大于0！');history.go(-1);</script>");
        }
        if ($value <= 0) {
            exit ("<script language='javascript'>alert('充值失败，流量必须大于0GB！');history.go(-1);</script>");
        }
        $money = $endtime*$dljg+$value*$dljgs;
        $rmb = $row['rmb']-$money;
        $cxuser = $DB->get_row("SELECT * FROM `openvpn` WHERE `iuser` LIKE '$user'");
        if (!$cxuser) {
            exit ("<script language='javascript'>alert('用户不存在，请重新审核！');history.go(-1);</script>");
        }
        $addll = $value*1024*1024*1024;
        $duetime = ($cxuser['endtime']<time() ? time() : $cxuser['endtime']) +$endtime*24*60*60;
        if ($cxuser['endtime']<time()) {
            $sql = "update `openvpn` set `isent`='0',`irecv`='0',`maxll`='{$addll
        }
        ',`endtime`='{$duetime
    }
    ',`i`='1' where `id`='{$cxuser['id']
    }
    ' ";
    if ($DB->query($sql)) {
        wlog('管理直冲', '用户'.$user.'流量'.$value.'日期'.$endtime);
        exit ("<script language='javascript'>alert('开通成功！');history.go(-1);</script>");
    } else {
        exit ("<script language='javascript'>alert('开通失败！');history.go(-1);</script>");
    }
    } else {
        $sql = "update `openvpn` set `maxll`=`maxll` + '{$addll
    }
    ',`endtime`='{$duetime
    }
    ',`i`='1' where `id`='{$cxuser['id']
    }
    ' ";
    if ($DB->query($sql)) {
        wlog('管理直冲', '用户'.$user.'流量'.$value);
        exit ("<script language='javascript'>alert('续费成功！');history.go(-1);</script>");
    } else {
        exit ("<script language='javascript'>alert('续费失败！');history.go(-1);</script>");
    }
    }
    } elseif ($my == 'del') {
        echo '<div class="panel panel-success">
<div class="panel-heading w h"><h3 class="panel-title">删除账号</h3></div>
<div class="panel-body box">';
        $id = $_GET['id'];
        $pd = $DB->get_row("SELECT * FROM openvpn WHERE id='$id' limit 1");
    } else {
        echo '
<form class="form-horizontal" action="carduser.php?my=add" method="post" id="add_goods" autocomplete="off">
<section class="panel panel-default">
              <header class="panel-heading font-bold"> 直充流量 </header>
              <div class="panel-body">
            <div class="input-group">
              <span class="input-group-addon">用户帐号</span>
			  <input type="text" name="user" value="" class="form-control" required="">
            </div><br>
            <div class="input-group">
              <span class="input-group-addon">流量数量(/G)</span>
			  <input type="text" name="value" value="" class="form-control" required="">
            </div><br>
            <div class="input-group">
              <span class="input-group-addon">有效天数(/天)</span>
			  <input type="text" name="endtime" value="" class="form-control" required="">
            </div><br>
            <input type="submit" value="充值" class="btn btn-primary form-control">
          </form>
        </div>
</section>';
    }
?>

      </div>
    </div>
  </div>
    </center>