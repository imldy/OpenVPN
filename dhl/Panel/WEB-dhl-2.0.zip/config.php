<?php
//数据库信息
$host = "localhost" ;
$port = "3306" ;
$user = "root" ;
$pwd = "MySQLPass" ;
$dbname = "ov" ;

//管理员账号
$adminuser='admin';
$adminpass='SuperPass';

//支付接口信息
$alipayid = '';          //此处请填写金沙江支付平台申请的id
$alipaykey = '';         //此处请填写金沙江支付平台申请的key
$alipayurl = '';         //此处请填写主域名/IP地址 例如 http://www.baidu.com
?>