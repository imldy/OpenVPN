<?php
$mod='blank';
include("../api.inc.php");
$title='当前在线用户';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
if(isset($_GET['id'])){
    $id = $_GET['id'];
    $rs = $DB->get_row("SELECT * FROM `auth_fwq` WHERE `id`='$id' limit 1");
    if(!$rs){
        echo "此服务器不存在";
    }else{
        $file = 'http://'.$rs['ipport'].'/res/openvpn-status.txt';
        $file1 = 'http://'.$rs['ipport'].'/udp/openvpn-status2.txt';
    }
}else{
    $file = '../res/openvpn-status.txt';
    $file1 = '../udp/openvpn-status2.txt';
}

?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<!-- Body -->
<body>
        <?php include 'nav.php';?>
		      <section>
         <!-- Page content-->
         <div class="content-wrapper">
            <h3><?php echo $title ?>
               <small>平台在线用户使用详细，刷新速度为你搭建时设置的时段</small>
            </h3>
            <div class="row">
               <div class="col-md-12">
                      <form action="qqlist.php" method="get" role="form" class="form-inline">
					  		                       <div class="panel panel-default">
                        <div class="panel-heading">
                           <div class="panel-title">当前TCP <?php //echo $DB->
                                            //在线人数接口
                                            $str=file_get_contents('../res/openvpn-status.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
                                            echo $onlinenum = (int)((substr_count($str,date('Y'))-1)/2);
                                            ?> 人在线 ： 当前UDP <?php //echo $DB->
                                            //在线人数接口
                                            $str=file_get_contents('../udp/openvpn-status2.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
                                            echo $onlinenum = (int)((substr_count($str,date('Y'))-1)/2);
                                            ?> 人在线</div>
                        </div>
                        <div class="panel-body">

                      
                                  <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                                      <thead>
                                          <tr>
                                                <th>ID</th>
                                                <th data-priority="1">用户名</th>
                                                <th data-priority="3">上传</th>
                                                <th data-priority="6">下载</th>
                                          </tr>
                                      </thead>
                                      <tbody>
									  <br>
                                            <?php
                                            $str=file_get_contents($file);
                                            $num=(substr_count($str,date('Y'))-1)/2;
                                            $fp=fopen($file,"r");
                                            fgets($fp);
                                            fgets($fp);
                                            fgets($fp);
                                            for($i=0;$i<$num;$i++){
                                            $j=$i+1;
                                            echo "<tr>";
                                                $line=fgets($fp);
                                                $arr=explode(",",$line);
                                                $recv=round($arr[2]/1024)/1000;
                                                $sent=round($arr[3]/1024)/1000;
                                                echo "<th>".$j."</th>";
                                            echo "<td>TCP模式：".$arr[0]."</td>";
                                            echo "<td>".$recv."MB</td>";
                                            echo "<td>".$sent."MB</td>";
                                            echo "</tr>";
                                            }
                                            ?>

									  <br>
                                            <?php
                                            $str=file_get_contents($file1);
                                            $num=(substr_count($str,date('Y'))-1)/2;
                                            $fp=fopen($file1,"r");
                                            fgets($fp);
                                            fgets($fp);
                                            fgets($fp);
                                            for($i=0;$i<$num;$i++){
                                            $j=$i+1;
                                            echo "<tr>";
                                                $line=fgets($fp);
                                                $arr=explode(",",$line);
                                                $recv=round($arr[2]/1024)/1000;
                                                $sent=round($arr[3]/1024)/1000;
                                                echo "<th>".$j."</th>";
                                            echo "<td>UDP模式：".$arr[0]."</td>";
                                            echo "<td>".$recv."MB</td>";
                                            echo "<td>".$sent."MB</td>";
                                            echo "</tr>";
                                            }
                                            ?>
                                      </tbody>
                                  </table>
                      
                      </div>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
