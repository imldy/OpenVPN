<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：修改平台套餐配置信息
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

if($is_login == 'ok'){
$db = db("ky_tc");
$row = $db->where(array("id"=>$_GET['id']))->find();
if(!$row){
     exit("<script>alert('亲，平台找不到此套餐！');history.go(-1);</script>");
}
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>套餐管理 - 修改套餐</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
               <div class="col-sm-12">
			<div class="ibox-mulu">
      <h3> &nbsp;&nbsp; <i class="fa fa-shopping-cart fa-lg"></i> 套餐管理 > 修改套餐</h3>
              </div>
			  <br>
<?php
if($_POST['name']){
$name = daddslashes($_POST['name']);
$tian = daddslashes($_POST['tian']);
$G = daddslashes($_POST['G']);
$money = daddslashes($_POST['money']);
$i = daddslashes($_POST['jifei']);
if($db->where(array("id"=>$_GET['id']))->update(array('name'=>$name,'G'=>$G,'tian'=>$tian,'money'=>$money,'i'=>$i))){
     echo Skip('修改套餐【'.$name.'】',success);
  }else{
    echo Skip('修改套餐【'.$name.'】',error);
 }
exit;
}?>	
                 <div class="ibox">
                  <div class="ibox-content">
                        <form action="./taocan_set.php?id=<?=$row['id']?>" class="form-horizontal m-t" method="post">
						    <div class="form-group has-error"> 
                                <label class="col-sm-3 control-label">套餐名称</label>
                                <div class="col-sm-8">
                                    <input id="firstname" name="name" value="<?php echo $row['name']?>" class="form-control" type="text">
                                 </div>
                            </div>
							 <div class="hr-line-dashed"></div>
							 
							 <div class="form-group has-success">
                                <label class="col-sm-3 control-label">使用天数</label>
                                <div class="col-sm-8">
                                    <input id="firstname" name="tian" value="<?php echo $row['tian']?>"class="form-control" type="text">
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
							 
							  <div class="form-group has-warning">
                                 <label class="col-sm-3 control-label">计费方式</label>
								   <div class="col-sm-8 control-label">
                                    <select class="form-control m-b" name="jifei">
									<?php
									if($row['i']=='1'){
									    echo '<option value="1">按时间计费</option>
									         <option value="2">按流量计费</option>';
									      }else{
										echo '<option value="2">按流量计费</option>
											 <option value="1">按时间计费</option>';	  
										  } ?>
                                    </select>
                                </div>
							 </div>
							 <div class="hr-line-dashed"></div>
							 <div class="form-group has-success">
                                <label class="col-sm-3 control-label">流量(单位/G)</label>
                                <div class="col-sm-8">
                                    <input id="firstname" name="G" value="<?php echo $row['G']?>" class="form-control" type="text">
                                </div>
							  </div>
							 <div class="hr-line-dashed"></div>
							 
							 <div class="form-group has-error">
                                <label class="col-sm-3 control-label">售价(单位/元)</label>
                                <div class="col-sm-8">
                                    <input id="firstname" name="money" value="<?php echo $row['money']?>" class="form-control" type="text">
                                </div>
							  </div>
							 <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-8 col-sm-offset-3">
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
</body>

</html>
<?php
}else{ 
    exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
}
?>