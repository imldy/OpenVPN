#!/bin/sh
user=$username
rp=$password
spd="123456"
NOW=`date +%s`
mysql -hlocalhost -uroot -p$spd -e "use ov;SELECT pass FROM openvpn WHERE iuser='$user' && fwqid='0';">>log.txt
mysql -hlocalhost -uroot -p$spd -e "use ov;SELECT irecv FROM openvpn WHERE iuser='$user' && fwqid='0';">>log.txt
mysql -hlocalhost -uroot -p$spd -e "use ov;SELECT isent FROM openvpn WHERE iuser='$user' && fwqid='0';">>log.txt
mysql -hlocalhost -uroot -p$spd -e "use ov;SELECT maxll FROM openvpn WHERE iuser='$user' && fwqid='0';">>log.txt
mysql -hlocalhost -uroot -p$spd -e "use ov;SELECT i FROM openvpn WHERE iuser='$user' && fwqid='0';">>log.txt
mysql -hlocalhost -uroot -p$spd -e "use ov;SELECT endtime FROM openvpn WHERE iuser='$user' && fwqid='0';">>log.txt
pass=$(sed -n 2p log.txt)
recv=$(sed -n 4p log.txt)
sent=$(sed -n 6p log.txt)
all=$(sed -n 8p log.txt)
i=$(sed -n 10p log.txt)
endtime=$(sed -n 12p log.txt)
rm -rf log.txt
if [ "$rp" == "$pass" ] && [ "$i" == "1" ] && [ "$[$recv+$sent]" -lt "$all" ] && [ "$endtime" -gt "$NOW" ];
then
echo $(date +%Y年%m月%d日%k时%M分) "用户登录成功" "账号:"${username} "密码:"${password}>>/home/wwwroot/login.log
exit 0
else
echo $(date +%Y年%m月%d日%k时%M分) "用户登录失败" "账号:"${username} "密码:"${password}>>/home/wwwroot/login.log
exit 1
fi