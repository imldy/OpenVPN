<?php
/*数据库配置*/
$host = "localhost"; //MYSQL主机
$port = 3306; //MYSQL主机
$user = "root"; //MYSQL用户
$pwd ="Dmgsql"; //MYSQL密码
$dbname = "ov"; //数据库名
$adminuser="Dmguser";//管理员用户名
$adminpass="Dmgpass";//管理员密码
//***提示：五期更新后，密码统一更换MD5格式，如果还不是MD5格式，自行转换去http://tool.chinaz.com/Tools/MD5.aspx转换（32位小写，尽量复杂）***
//***复杂格式：大小写英文+数字+特殊符号；例如：Amc8899!@!@***
?>