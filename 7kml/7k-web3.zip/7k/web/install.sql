-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2016-10-16 16:19:20
-- 服务器版本： 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ov`
--

-- --------------------------------------------------------

--
-- 表的结构 `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- 表的结构 `alipay`
--

CREATE TABLE IF NOT EXISTS `alipay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `partner` text NOT NULL,
  `alikey` text NOT NULL,
  `url` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `alipay`
--

INSERT INTO `alipay` (`id`, `partner`, `alikey`, `url`) VALUES
(1, '', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `auth_config`
--

CREATE TABLE IF NOT EXISTS `auth_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gg` text NOT NULL,
  `ggs` text,
  `dl1` float DEFAULT NULL COMMENT 'vip1',
  `dl2` float DEFAULT NULL COMMENT 'vip2',
  `dl3` float DEFAULT NULL COMMENT 'vip3',
  `dl4` float DEFAULT NULL COMMENT 'vip4',
  `dl5` float DEFAULT NULL COMMENT 'vip5',
  `dl0` float DEFAULT NULL COMMENT 'vip0',
  `dls1` float NOT NULL,
  `dls2` float NOT NULL,
  `dls3` float NOT NULL,
  `dls4` float NOT NULL,
  `dls5` float NOT NULL,
  `member_reg` int(2) NOT NULL DEFAULT '0',
  `dls0` float NOT NULL,
  `regok` int(11) DEFAULT NULL,
  `activeok` int(11) DEFAULT NULL,
  `ok` int(11) DEFAULT NULL,
  `shopUrl` text NOT NULL,
  `shopCode` text NOT NULL,
  `daili_cash` float NOT NULL,
  `reg_cash` float NOT NULL,
  `user_cash` float NOT NULL,
  `qian` float NOT NULL,
  `user_endtime` int(11) NOT NULL,
  `url` varchar(200) NOT NULL,
  `prefix` varchar(200) NOT NULL,
  `rmb` varchar(200) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `auth_config`
--

INSERT INTO `auth_config` (`id`, `gg`, `ggs`, `dl1`, `dl2`, `dl3`, `dl4`, `dl5`, `dl0`, `dls1`, `dls2`, `dls3`, `dls4`, `dls5`, `member_reg`, `dls0`, `regok`, `activeok`, `ok`, `shopUrl`, `shopCode`, `daili_cash`, `reg_cash`, `user_cash`, `qian`, `user_endtime`, `url`, `prefix`, `rmb`) VALUES
(1, '欢迎使用7k流控', '欢迎使用7k流控', 0, 0, 0, 0, 0, 0, 1.5, 1.2, 0.9, 0.6, 0.3, 0, 3, 0, 0, 2, 'http://www.917ka.com/', '<div id="pdBuy"  class="PDB2C_moban_warp"><img src="http://code.jiasale.com/pdbs/images/init_wait.gif"></div> <script type="text/javascript" id="pdB2C_js"></script> <script type="text/javascript" id="pdB2C_shell_js" src="http://code.jiasale.com/shoptemplet/3c07dc175a1242d7b4770de7650044db/t30834.js"></script>', 10, 104858000, 209715000, 10485800, 1, '', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `auth_daili`
--

CREATE TABLE IF NOT EXISTS `auth_daili` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `tj_rmb` decimal(11,2) NOT NULL,
  `tj_user` varchar(255) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `rmb` decimal(11,2) NOT NULL DEFAULT '0.00',
  `vip` int(11) DEFAULT NULL,
  `kmlist` int(11) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  `regdate` datetime DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `qq` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `buy` text NOT NULL,
  `buy2` text NOT NULL,
  `income` decimal(11,2) NOT NULL DEFAULT '0.00',
  `adtext` text NOT NULL,
  `adimg` text NOT NULL,
  `url` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `auth_daili`
--

INSERT INTO `auth_daili` (`id`, `tj_rmb`, `tj_user`, `user`, `pass`, `rmb`, `vip`, `kmlist`, `active`, `regdate`, `name`, `qq`, `tel`, `buy`, `buy2`, `income`, `adtext`, `adimg`) VALUES
(0, '0.00', '', '7k', '7k', '0.00', 0, NULL, 1, '2016-10-13 23:56:22', '管理员', '123456', '13800138000', '', '', '0.00', 'gdfgfd', '');

-- --------------------------------------------------------

--
-- 表的结构 `auth_fwq`
--

CREATE TABLE IF NOT EXISTS `auth_fwq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `ipport` varchar(64) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `auth_fwq`
--

INSERT INTO `auth_fwq` (`id`, `name`, `ipport`, `time`) VALUES
(0, '本地服务器', '127.0.0.1:808', '2016-10-03 16:12:09');

-- --------------------------------------------------------

--
-- 表的结构 `auth_kms`
--

CREATE TABLE IF NOT EXISTS `auth_kms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kind` tinyint(1) NOT NULL DEFAULT '1',
  `daili` int(11) NOT NULL DEFAULT '0',
  `km` varchar(64) DEFAULT NULL,
  `value` int(11) NOT NULL DEFAULT '0',
  `values` decimal(11,2) DEFAULT NULL,
  `money` decimal(11,2) DEFAULT '0.00',
  `isuse` tinyint(1) DEFAULT '0',
  `user` varchar(50) DEFAULT NULL,
  `usetime` datetime DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `kmtype_id` float NOT NULL,
  `url` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `km` (`km`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `auth_kms`
--

INSERT INTO `auth_kms` (`id`, `kind`, `daili`, `km`, `value`, `values`, `money`, `isuse`, `user`, `usetime`, `addtime`, `kmtype_id`) VALUES
(1, 1, 0, '741733226271405308', 31, '10.00', '0.00', 1, '1', '2016-10-14 01:53:45', '2016-10-14 01:53:22', 11),
(2, 1, 0, '188844611320235625', 31, '3.00', '0.00', 0, NULL, NULL, '2016-10-14 01:51:55', 8),
(3, 1, 0, '227156520106300499', 31, '3.00', '0.00', 1, '1', '2016-10-14 01:52:12', '2016-10-14 01:51:55', 8);

-- --------------------------------------------------------

--
-- 表的结构 `auth_kmtype`
--

CREATE TABLE IF NOT EXISTS `auth_kmtype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `days` float NOT NULL,
  `maxll` float NOT NULL,
  `dlid` float NOT NULL,
  `km_rmb` decimal(11,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `auth_log`
--

CREATE TABLE IF NOT EXISTS `auth_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) NOT NULL,
  `msg` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `auth_openvpn`
--

CREATE TABLE IF NOT EXISTS `auth_openvpn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iuser` varchar(16) NOT NULL,
  `isent` bigint(128) DEFAULT '0',
  `irecv` bigint(128) DEFAULT '0',
  `maxll` bigint(128) NOT NULL,
  `pass` varchar(18) NOT NULL,
  `i` int(1) NOT NULL,
  `starttime` varchar(30) DEFAULT NULL,
  `endtime` int(11) DEFAULT '0',
  `dlid` int(11) DEFAULT NULL,
  `fwqid` int(11) DEFAULT '1',
  `notes` varchar(255) DEFAULT NULL,
  `tian` float NOT NULL COMMENT '7k激活使用',
  `qian_date` date NOT NULL,
  `qian_num` float NOT NULL,
  `tj_user` text CHARACTER SET utf8 NOT NULL,
  `tj_ok` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `iuser` (`iuser`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `banner`
--

CREATE TABLE IF NOT EXISTS `banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img1` text CHARACTER SET utf8 NOT NULL,
  `tit1` text CHARACTER SET utf8 NOT NULL,
  `info1` text CHARACTER SET utf8 NOT NULL,
  `img2` text CHARACTER SET utf8 NOT NULL,
  `tit2` text CHARACTER SET utf8 NOT NULL,
  `info2` text CHARACTER SET utf8 NOT NULL,
  `img3` text CHARACTER SET utf8 NOT NULL,
  `tit3` text CHARACTER SET utf8 NOT NULL,
  `info3` text CHARACTER SET utf8 NOT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `banner`
--

INSERT INTO `banner` (`id`, `img1`, `tit1`, `info1`, `img2`, `tit2`, `info2`, `img3`, `tit3`, `info3`) VALUES
(1, 'http://i.niupic.com/images/2016/09/22/s2rWJE.jpg', '超实惠流量冲浪新时代', '抵制高价流量，让你使用专用的流量服务，从而价格远远低于运营商，安全快捷！', 'http://i.niupic.com/images/2016/09/22/QC3qln.jpg', '支持IOS6-IOS9系统', '一次安装永久支持续费，VPN连接100M服务器转接', 'http://i.niupic.com/images/2016/09/22/JHtWio.jpg', '安卓系统完美支持', '操作人性化，流量软件上手很简单，使用仅需简单操作几步');

-- --------------------------------------------------------

--
-- 表的结构 `kmtype`
--

CREATE TABLE IF NOT EXISTS `kmtype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `days` float NOT NULL,
  `maxll` float NOT NULL,
  `dlid` float NOT NULL,
  `km_rmb` decimal(11,2) NOT NULL DEFAULT '0.00',
  `url` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- 转存表中的数据 `kmtype`
--

INSERT INTO `kmtype` (`id`, `name`, `days`, `maxll`, `dlid`, `km_rmb`,`url`) VALUES
(6, '1G', 31, 1048580, 4, '0.60',''),
(8, '包月3G流量', 31, 3145730, 0, '9.00',''),
(9, '包月5G流量', 31, 5242880, 0, '15.00',''),
(11, '包月10G流量', 31, 10485800, 0, '25.00',''),
(12, '包月无限流量', 31, 1048570000000, 0, '30.00',''),
(14, '123', 31, 2097150, 2, '60.00',''),
(15, '456', 31, 3145730, 2, '30.00',''),
(16, '789', 31, 4194300, 2, '40.00','');

-- --------------------------------------------------------

--
-- 表的结构 `lyj_article`
--

CREATE TABLE IF NOT EXISTS `lyj_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '无题',
  `content` text NOT NULL,
  `visit_count` int(10) unsigned NOT NULL DEFAULT '0',
  `timeline` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='文章表' AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `lyj_article`
--

INSERT INTO `lyj_article` (`id`, `category_id`, `title`, `content`, `visit_count`, `timeline`) VALUES
(2, 1, '移动', '1', 0, 1471086665);

-- --------------------------------------------------------

--
-- 表的结构 `lyj_category`
--

CREATE TABLE IF NOT EXISTS `lyj_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '默认栏目',
  `description` varchar(255) NOT NULL DEFAULT '栏目简介',
  `sortby` int(5) NOT NULL DEFAULT '0',
  `hidden` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='栏目表' AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `lyj_category`
--

INSERT INTO `lyj_category` (`id`, `name`, `description`, `sortby`, `hidden`) VALUES
(1, '移动', '', 1, 0),
(2, '联通', '', 2, 0),
(3, '电信', '', 3, 0);

-- --------------------------------------------------------

--
-- 表的结构 `lyj_link`
--

CREATE TABLE IF NOT EXISTS `lyj_link` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `name` varchar(200) NOT NULL DEFAULT '链接名称',
  `description` varchar(255) NOT NULL DEFAULT '链接简介',
  `url` varchar(255) NOT NULL DEFAULT 'http://',
  `icon` varchar(255) NOT NULL DEFAULT 'http://',
  `sortby` int(5) NOT NULL DEFAULT '0',
  `hidden` int(2) NOT NULL DEFAULT '0',
  `timeline` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='友链表' AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `lyj_link`
--

INSERT INTO `lyj_link` (`id`, `category_id`, `name`, `description`, `url`, `icon`, `sortby`, `hidden`, `timeline`) VALUES
(1, 1, '流控地址', '链接简介', 'http://自己的ip:端口/', '.', 1, 0, 0),
(2, 1, '卡密地址', '链接简介', 'http://ip:port', '.', 0, 0, 1471028321),
(3, 1, '官方商城', '链接简介', 'http://ip:port/', '.', 2, 0, 1471029048),
(4, 1, '使用说明', '链接简介', 'http://ip:port/shuoming.html', '.', 3, 0, 1471029100),
(5, 1, '背景图片', '链接简介', 'http://图片', '.', 4, 0, 1471029221);

-- --------------------------------------------------------

--
-- 表的结构 `lyj_setting`
--

CREATE TABLE IF NOT EXISTS `lyj_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `skey` varchar(100) NOT NULL DEFAULT '要设置的键',
  `sval` varchar(1024) NOT NULL DEFAULT '要设置的值',
  PRIMARY KEY (`id`),
  UNIQUE KEY `skey` (`skey`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='设置表' AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `lyj_setting`
--

INSERT INTO `lyj_setting` (`id`, `skey`, `sval`) VALUES
(1, 'contact', 'qq'),
(2, 'seo_title', 'qqkey'),
(3, 'seo_keywords', '图片地址'),
(4, 'seo_description', '公告信息'),
(5, 'copyright', '流控地址');

-- --------------------------------------------------------

--
-- 表的结构 `lyj_token`
--

CREATE TABLE IF NOT EXISTS `lyj_token` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `token` varchar(32) NOT NULL,
  `expire_timeline` int(10) NOT NULL,
  `update_timeline` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='登录令牌表' AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `lyj_token`
--

INSERT INTO `lyj_token` (`id`, `user_id`, `token`, `expire_timeline`, `update_timeline`) VALUES
(1, 1, 'f826ef30ddc531f51c107a8c18d8ff8a', 1473619585, 1471027585),
(2, 2, '1549492819', 1473619585, 1471027585);

-- --------------------------------------------------------

--
-- 表的结构 `lyj_user`
--

CREATE TABLE IF NOT EXISTS `lyj_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account` varchar(15) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `nick` varchar(15) NOT NULL,
  `face` varchar(255) DEFAULT NULL,
  `sex` int(2) DEFAULT '0',
  `device_id` varchar(20) NOT NULL,
  `is_forbidden` int(10) NOT NULL DEFAULT '0',
  `is_app` int(2) DEFAULT '0',
  `timeline` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`account`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='用户表' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `lyj_user`
--

INSERT INTO `lyj_user` (`id`, `account`, `password`, `nick`, `face`, `sex`, `device_id`, `is_forbidden`, `is_app`, `timeline`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '7kml.com', '', 1, '123456', 0, 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `open`
--

CREATE TABLE IF NOT EXISTS `open` (
  `id` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mo` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `openvpn`
--

CREATE TABLE IF NOT EXISTS `openvpn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iuser` varchar(16) NOT NULL,
  `isent` bigint(128) DEFAULT '0',
  `irecv` bigint(128) DEFAULT '0',
  `maxll` bigint(128) NOT NULL,
  `pass` varchar(18) NOT NULL,
  `i` int(1) NOT NULL,
  `starttime` varchar(30) DEFAULT NULL,
  `endtime` int(11) DEFAULT '0',
  `dlid` int(11) DEFAULT NULL,
  `fwqid` int(11) DEFAULT '1',
  `notes` varchar(255) DEFAULT NULL,
  `tian` float NOT NULL COMMENT '7k激活使用',
  `qian_date` date NOT NULL,
  `qian_num` float NOT NULL,
  `tj_user` text CHARACTER SET utf8 NOT NULL,
  `tj_ok` float NOT NULL,
  `url` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `iuser` (`iuser`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `openvpn`
--

INSERT INTO `openvpn` (`id`, `iuser`, `isent`, `irecv`, `maxll`, `pass`, `i`, `starttime`, `endtime`, `dlid`, `fwqid`, `notes`, `tian`, `qian_date`, `qian_num`, `tj_user`, `tj_ok`,`url`) VALUES
(1, '1', 12368, 400686, 10737418240, '1', 1, '1476202885', 1479059625, 0, 0, '', 0, '0000-00-00', 0, '', 0,'服务器IP');

-- --------------------------------------------------------

--
-- 表的结构 `website`
--

CREATE TABLE IF NOT EXISTS `website` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logo` text CHARACTER SET utf8 NOT NULL,
  `title` text CHARACTER SET utf8 NOT NULL,
  `app1` text CHARACTER SET utf8 NOT NULL,
  `app2` text CHARACTER SET utf8 NOT NULL,
  `qq` text CHARACTER SET utf8 NOT NULL,
  `tel` text CHARACTER SET utf8 NOT NULL,
  `ipinfo` text CHARACTER SET utf8 NOT NULL,
  `appleid1` text CHARACTER SET utf8 NOT NULL,
  `appleps1` text CHARACTER SET utf8 NOT NULL,
  `appleid2` text CHARACTER SET utf8 NOT NULL,
  `appleps2` text CHARACTER SET utf8 NOT NULL,
  `appleid3` text CHARACTER SET utf8 NOT NULL,
  `appleps3` text CHARACTER SET utf8 NOT NULL,
  `and_img1` text CHARACTER SET utf8 NOT NULL,
  `and_img2` text CHARACTER SET utf8 NOT NULL,
  `and_img3` text CHARACTER SET utf8 NOT NULL,
  `and_img4` text CHARACTER SET utf8 NOT NULL,
  `jia1` text CHARACTER SET utf8 NOT NULL,
  `jia2` text CHARACTER SET utf8 NOT NULL,
  `jia3` text CHARACTER SET utf8 NOT NULL,
  `jia4` text CHARACTER SET utf8 NOT NULL,
  `seo` text CHARACTER SET utf8 NOT NULL,
  `peie` varchar(200) DEFAULT '0.3',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `website`
--

INSERT INTO `website` (`id`, `logo`, `title`, `app1`, `app2`, `qq`, `tel`, `ipinfo`, `appleid1`, `appleps1`, `appleid2`, `appleps2`, `appleid3`, `appleps3`, `and_img1`, `and_img2`, `and_img3`, `and_img4`, `jia1`, `jia2`, `jia3`, `jia4`, `seo`, `peie`) VALUES
(1, 'http://i.niupic.com/images/2016/08/05/ZEsqL4.png', '7k™丨全新一代流控管理系统', 'http://pre.im/ZtcW', 'http://fir.im/', '123456', '13800138001', '121.41.*.* 浙江省杭州市 阿里巴巴', 'www@1gyy.com', 'Abc201314', 'ww@1gyy.com', 'Abc201314', 'w@1gyy.com', 'Abc201314', 'http://i.niupic.com/images/2016/08/15/YkoMbx.jpg', 'http://i.niupic.com/images/2016/08/15/BYwMZQ.jpg', 'http://i.niupic.com/images/2016/08/15/Egl15P.jpg', 'http://i.niupic.com/images/2016/08/15/rpb5BX.jpg', '0', '5', '50', '200', '<!-- JiaThis Button BEGIN -->\r\n<script type="text/javascript" src="http://v3.jiathis.com/code/jiathis_r.js?move=0" charset="utf-8"></script>\r\n<!-- JiaThis Button END -->', '0.3');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
