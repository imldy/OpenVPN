<?php
$mod='blank';
include("../api.inc.php");
$title='实时监控';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<!-- Body -->
<body>
        <?php include 'nav.php';?>
		      <section>
         <!-- Page content-->
         <div class="content-wrapper">
            <h3><?php echo $title ?>
               <small>此为平台实时监控日志</small>
            </h3>

            <div class="row">
               <div class="col-md-12">

					  		                       <div class="panel panel-default">
                        <div class="panel-heading">

                        <div class="panel-body">

                    <?php
                    $myfile = fopen("../jiankong.log", "r") or die("Unable to open file!");
                    echo fread($myfile,filesize("../jiankong.log"));
                    fclose($myfile);
                    ?>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>

   
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
