<?php
/**
 * 添加模式
**/
$mod='blank';
include("../api.inc.php");
if($active != 2)exit("Error");
$title='添加模式';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<!-- Body -->
<body>
        <?php include 'nav.php';?>
		      <section>
         <!-- Page content-->
         <div class="content-wrapper">
            <h3><?php echo $title ?>
               <small>此处可以添加自带云端①免流线路</small>
            </h3>
 
<?php
if($_POST['name']){
echo '<div class="alert '; 
$name = $_REQUEST['name']; 
$mo = $_REQUEST['mo'];   
$id=strtoupper(substr(md5($uin.time()),0,8).'-'.uniqid()); 
$sql="insert into `open` (`id`,`name`,`mo`) values ('{$id}','{$name}','{$mo}')"; 
if($DB->query($sql))
echo 'alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>功添加一个模式</div>
                <a href="javascript:history.go(-1)" class="btn btn-secondary btn-icon btn-icon-standalone">
                  <i class="fa-edit"></i>
                  <span>继续添加</span>
                </a>
                <a href="openlist.php" class="btn btn-info btn-icon btn-icon-standalone">
                  <i class="fa-list-ol"></i>
                  <span>查看列表</span>
                </a>
                <style>#open{display: none;}</style>'; 
else
                echo 'alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  添加失败</div>
                <a href="javascript:history.go(-1)" class="btn btn-secondary btn-icon btn-icon-standalone">
                  <i class="fa-edit"></i>
                  <span>继续添加</span>
                </a>
                <a href="openlist.php" class="btn btn-info btn-icon btn-icon-standalone">
                  <i class="fa-list-ol"></i>
                  <span>查看列表</span>
                </a>
                <style>#open{display: none;}</style>'; 
//exit;  
}
?>

            <div class="row">
               <div class="col-md-12">

					  		                       <div class="panel panel-default">

                        <div class="panel-body"> 
                    <form id="open" action="./open.php" method="post" class="form-horizontal validate" role="form">
                      <div class="form-group">
                        <label class="col-sm-2 control-label">线路名称：</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" id="field-1" placeholder="输入模式名称" name="name" data-validate="required">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="col-sm-2 control-label">模式内容：</label>
                        <div class="col-sm-9">
                           <textarea class="form-control" cols="5" id="field-5" name="mo" rows="6" data-validate="required"></textarea>
                        </div>
                      </div>  

                      <div class="form-group">
                        <label class="col-sm-2 control-label"></label>
                        <div class="col-sm-9">
                          <button type="submit" type="button" class="btn btn-info btn-block">添加</button>
                        </div>
                      </div>
                    </form>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
