<?php
/**
 * 凌云免流管理中心
 * by 天木兮 2018年10月15日
 */
include("../../Data/api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='../Lyun/index.php';</script>");
$user = daddslashes($_GET['user']);
$sqlA = "select * from `openvpn` where iuser='$user' limit 1";
if(!$user || !$row = $DB->get_row($sqlA)){
exit("<script language='javascript'>alert('亲，平台找不到此用户！');window.location.href='./online_list.php';</script>");
}else{
$pass = daddslashes($_POST['pass']);
$maxll = daddslashes($_POST['maxll'])*1024*1024;
$max = $maxll*1024;
$state = daddslashes($_POST['state']);
$endtime = strtotime($_POST['enddate']);
$tian = daddslashes($_POST['tian']);
$endtime = time()+3600*24*daddslashes($_POST['tian']);}
if($row["i"] == "1" ){
	$zhtai='1';
	$zhtai2="开通";
	$zhtai3='2';
	$zhtai4="未激活";
	$zhtai5='0';
	$zhtai6="禁用";
	}elseif($row['i'] == "2"){
	$zhtai='2';
	$zhtai2='未激活';
	$zhtai3='1';
	$zhtai4="开通";
	$zhtai5='0';
	$zhtai6="禁用";
	}
	elseif($row['i'] == "0"){
	$zhtai='0';
	$zhtai2='禁用';
	$zhtai3='2';
	$zhtai4="未激活";
	$zhtai5='1';
	$zhtai6="开通";
	}
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>账号管理 - 修改账号</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico">
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="../../assets/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>账号管理 >><small>修改账号<?=$user?></small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="form_basic.html#">
                              </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
<?php
if($_POST['type']=="update"){
echo '
<div class="panel-heading w h"><h3 class="panel-title">账号修改结果</h3></div>
<div class="panel-body box">';
$sql="update `openvpn` set `pass`='$pass',`isent`='0',`irecv`='0',`maxll`='$max',`i`='$state',`endtime`='$endtime',`tian`=$tian where iuser='$user'";
if($DB->query($sql)){
echo '<div class="box">恭喜亲成功修改账号 '.$user.'</div>';
}else{
echo '<div class="box">奥，修改用户账号失败,请稍后重新尝试.</div>';
}
echo '<hr/><a href="./user_list.php" class="btn btn-success">返回账号列表</a></div></div>';}
else{
echo'
                    <form action="./uesr_set.php?user='.$user.'" method="post" class="form-horizontal">
						  <input type="hidden" name="type" value="update" />
                          <div class="form-group has-success">
                                <label class="col-sm-2 control-label">密码</label>

                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="'.$row['pass'].'" name="pass">
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="form-group has-warning">
                                <label class="col-sm-2 control-label">账号状态</label>

                                <div class="col-sm-10">
                                 <select class="form-control m-b" name="state">
                                     <option value="'.$zhtai.'">'.$zhtai2.'</option>
									 <option value="'.$zhtai3.'">'.$zhtai4.'</option>
									 <option value="'.$zhtai5.'">'.$zhtai6.'</option>
                                    </select>
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
                             <div class="form-group has-success">
                                <label class="col-sm-2 control-label">使用天数</label>

                                <div class="col-sm-10">
                                    <input type="text" value="'.$row['tian'].'" class="form-control" name="tian">
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
							 <div class="form-group has-error">
                                <label class="col-sm-2 control-label">总流量(单位/G)</label>

                                <div class="col-sm-10">
                                    <input type="text" value="'.round($row['maxll']/1024/1024).'" class="form-control" name="maxll">
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-4 col-sm-offset-2">
                                    <button class="btn btn-primary" type="submit">保存内容</button>
								</form>';
}								
?>								
								</div>
                         </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
