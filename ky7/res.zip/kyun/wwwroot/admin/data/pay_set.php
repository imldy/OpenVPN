<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：平台支付接口信息配置
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

if($is_login == 'ok'){
$user = admin_copy('pay_user');
$json = curl_get("http://kypay.top/WebApi.php?user=".$user);	
$result = json_decode($json,true); 
$Money = $result['Money'];	
$TiXian = $result['TiXian'];
$TodayPay = $result['TodayMoney'];	
$TodayMoney = $result['TodayMoney'];
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>套餐管理 - 支付接口设置</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../../assets/img/favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
<style type="text/css">
.box {
    background-color: #fff;
	width:100%;
    height:80px;
	border-radius:6px;
	margin:0px 0px 20px 0px;
}

.circle{
    width:60px;
    height:60px;
    background-color: #84C1FF;
    border-radius:50px;
	color: #fff;
	position: absolute;
    margin:10px 0px 0px 15px;

}

.acc {
   margin:18px 0px 0px 17px;
}

h1 {
   position: absolute;
   margin:12px 0px 0px 45%;
   font-size: 32px;
   font-family:"新宋体";
}
span {
   font-size: 17px;
   font-family:"微软雅黑";
}
p {
   position: absolute;
   margin:48px 0px 0px 46%;
   font-size: 12px;
   font-family:"新宋体";
}
</style>
</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-sm-12">
			<div class="ibox-mulu">
      <h3> &nbsp;&nbsp; <i class="fa fa-shopping-cart fa-lg"></i> 套餐管理 > 支付接口信息</h3>
              </div>
			  <br>
<?php
if($_POST['key']){
$user = daddslashes($_POST['user']);
$key = daddslashes($_POST['key']);
$url = daddslashes($_POST['url']);
if(db('ky_cfg')->where(array())->update(array('pay_user'=>$user,'pay_key'=>$key,'pay_url'=>$url))){
   echo Skip('修改接口',success);
}else{
   echo Skip('修改接口',error);
}
exit;
}
?>
<div class="row">
<div class="col-sm-3">
<div class="box">
  <div class="circle">
  <div class="acc">
  <i class="fa fa-recycle fa-2x"></i>
</div>
</div>
<h1><?=$Money?><span> 元</span></h1>
<p>账户余额</p>
</div>
</div>
<div class="col-sm-3">
<div class="box">
  <div class="circle">
  <div class="acc">
  <i class="fa fa-shopping-cart fa-2x"></i>
</div>
</div>
<h1><?=$TodayMoney?><span> 元</span></h1>
<p>今日收入</p>
</div>
</div>
<div class="col-sm-3">
<div class="box">
  <div class="circle">
  <div class="acc">
  <i class="fa fa-handshake-o fa-2x"></i>
</div>
</div>
<h1><?=$TodayPay?><span> 笔</span></h1>
<p>今日成交</p>
</div>
</div>
<div class="col-sm-3">
<div class="box">
  <div class="circle">
  <div class="acc">
  <i class="fa fa-suitcase fa-2x"></i>
</div>
</div>
<h1><?=$TiXian?><span> 次</span></h1>
<p>提现次数</p>
</div>
</div>	
</div>
         <div class="ibox">
                  <div class="ibox-content">
                        <form action="./pay_set.php" class="form-horizontal m-t" method="post">
						    <div class="form-group has-error"> 
                                <label class="col-sm-3 control-label">快支付账号：</label>
                                <div class="col-sm-7">
                                    <input id="firstname" name="user" value="<?php echo $user;?>" class="form-control" type="text">
                                 </div>
								</div>
								
							 <div class="hr-line-dashed"></div>
							 <div class="form-group has-success">
                                <label class="col-sm-3 control-label">快支付KEY：</label>
                                <div class="col-sm-7">
                                    <input id="firstname" name="key" value="<?php echo admin_copy('pay_key')?>" class="form-control" type="text">
                                </div>
							  </div>
							  
							 <div class="hr-line-dashed"></div>
							 <div class="form-group has-warning">
                                <label class="col-sm-3 control-label">支付返回URL：</label>
                                <div class="col-sm-7">
                                    <input id="firstname" name="url" value="<?php echo admin_copy('pay_url')?>" class="form-control" type="text">
                                </div>
							  </div>
							  
							 <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-8 col-sm-offset-3">
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                                </div>
                            </div>
                        </form>
				</div>
			 </div>
            </div>
        </div>
    </div>
</body>

</html>
<?php
}else{ 
    exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
}
?>