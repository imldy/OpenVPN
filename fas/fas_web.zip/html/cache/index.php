<?php
echo '<!DOCTYPE html>
<html lang="cn" class="bg-dark">
<head>
<meta charset="utf-8" />
<title>��ӭ������ϵͳ��Ŀ¼</title>

<section id="content" class="m-t-lg wrapper-md animated fadeInUp">




<br>
<br>
<a class="navbar-brand block" href="http://wpa.qq.com/msgrd?v=3&uin=963963860&site=qq&menu=yes/">ϵͳ�ۺ�����ϵQQ963963860</a>
<br>
<br>
<br>

<a class="navbar-brand block" href="https://jq.qq.com/?_wv=1027&k=1bSzPwg7">����Ⱥ</a>
<br>
<br>
<br>
<br>
<a class="navbar-brand block" href="https://yyrh.me/">�����绨</a>';
?>