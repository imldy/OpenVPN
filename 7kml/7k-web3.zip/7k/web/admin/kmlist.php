<?php
/**
 * 商品列表
**/
$mod='blank';
include("../api.inc.php");
$title='商品列表';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<!-- Body -->
<body>
        <?php include 'nav.php';?>
		      <section>
         <!-- Page content-->
         <div class="content-wrapper">
            <h3><?php echo $title ?>
               <small>当前卡密列表</small>
            </h3> 


<?php
function getkm($len = 18)
{
	$str = "1234567890";
	$strlen = strlen($str);
	$randstr = "";
	for ($i = 0; $i < $len; $i++) {
		$randstr .= $str[mt_rand(0, $strlen - 1)];
	}
	return $randstr;
}
$kind=1;
$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='add'){
$kind=1;
$num=intval($_POST['num']);
$value=intval($_POST['value']);
$values=intval($_POST['values']);
$kmtype_id=intval($_POST['kmtype_id']);
if($site_id!=1){
	$rs=$DB->get_row("SELECT * FROM website where id='1'");
	$rs2=$DB->get_row("SELECT * FROM auth_config where id='$site_id'");
	$rmb=$num*($values*$rs['peie']);
}
if($rs2['rmb']<$rmb){
	echo '余额不足';
}else{
	$DB->query("update `auth_config` set rmb=rmb-$rmb where id='$site_id'");
echo '<div class="list-group list-group-minimal">
                                        <li class="list-group-item list-group-item-success">成功生成以下商品</li>';
for ($i = 0; $i < $num; $i++) {
	$km=getkm(18);
	$sql=$DB->query("insert into `auth_kms` (`kind`,`km`,`value`,`values`,`money`,`addtime`,`kmtype_id`) values ('".$kind."','".$km."','".$value."','".$values."','0.00','".$date."','".$kmtype_id."')");
	if($sql) {
		echo "<li class='list-group-item'>$km</li>";
	}
}

echo '<a href="./kmlist.php" class="list-group-item active"><i class="fa fa-mail-reply"></i> 返回商品列表</a>';	
}
}

elseif($my=='del'){
echo '<div class="page-body"><div class="alert';
$id=$_GET['id'];
$sql=$DB->query("DELETE FROM auth_kms WHERE id='$id'");
if($sql){echo ' alert-success">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除成功！';}
else{echo ' alert-danger">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除失败！';}
echo '</div>';
}

elseif($my=='qk'){//清空商品
echo '<div class="alert alert-warning">
                                        <button type="button" class="close" data-dismiss="alert">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span></button>
您确认要清空所有商品吗？清空后无法恢复！</div><a href="./kmlist.php?my=qk2" class="btn btn-red">确定清空</a><a href="javascript:history.back();" class="btn btn-white">返回</a></div></div>';
}
elseif($my=='qk2'){//清空商品结果
echo '<div class="page-body"><div class="alert';
if($DB->query("DELETE FROM auth_kms WHERE kind='$kind'")==true){
echo ' alert-success">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>清空成功！';
}else{
echo' alert-danger">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>清空失败！';
}
echo '</div>';
}
else
{

$form= '<form action="kmlist.php?my=add" method="POST" class="form-inline validate">
<a href="kmlist.php?my=qk" class="btn btn-danger" onclick="return confirm(\'你确实要清空吗？\');">清空</a>
<div class="form-group pull-right">
  <div class="form-group">
    <input type="text" class="form-control" name="num" placeholder="商品数量" data-validate="required,number,min[1]">
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="value" placeholder="使用天数" data-validate="required,number,min[1]">
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="values" placeholder="流量（GB）" data-validate="required,number,min[1]">
  </div>
  <button type="submit" class="btn btn-secondary btn-single">生成</button>
</div>
</form>';

if(isset($_GET['kw'])) {
	if($_GET['type']==1) {
		$sql=" `km`='{$_GET['kw']}' and kind=1";
		$numrows=$DB->count("SELECT count(*) from auth_kms WHERE{$sql}");
		$con='包含 '.$_GET['kw'].' 的共有 '.$numrows.' 个商品';
	}elseif($_GET['type']==2) {
		$sql=" `user`='{$_GET['kw']}' and kind=1";
		$numrows=$DB->count("SELECT count(*) from auth_kms WHERE{$sql}");
		$con='包含 '.$_GET['kw'].' 的共有 '.$numrows.' 个商品';
	}
}else{
	$numrows=$DB->count("SELECT count(*) from auth_kms WHERE kind=1");
	$sql=" kind=1";
	$con='平台共有 '.$numrows.' 个商品';
}
?>
                                         <div class="row">
               <div class="col-md-12">
                      
					  		                       <div class="panel panel-default">
                        <div class="panel-heading">
                           <div class="panel-title"><?php echo $con; ?></div>
                        </div>
                        <div class="panel-body">
                    <div class="panel-body">


                      <!--?php echo $form; ?-->

                      <div class="table-responsive">
                      
                                  <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                                      <thead>
	                                    <tr>
	                                        <th>序号</th>
	                                        <th data-priority="1">卡密</th>
	                                        <th data-priority="3">商品信息</th>
	                                        <th data-priority="6">状态</th>
	                                        <th data-priority="6">代理ID</th>
                                          <th data-priority="6">套餐ID</th>
	                                        <th data-priority="6">添加时间</th>
	                                        <th data-priority="6">使用时间</th>
	                                        <th data-priority="6">操作</th>
	                                    </tr>
                                      </thead>
                                      <tbody>
										<?php
										$pagesize=30;
										$pages=intval($numrows/$pagesize);
										if ($numrows%$pagesize)
										{
										 $pages++;
										 }
										if (isset($_GET['page'])){
										$page=intval($_GET['page']);
										}
										else{
										$page=1;
										}
										$offset=$pagesize*($page - 1);
										if($site_id==1){
										$rs=$DB->query("SELECT * FROM auth_kms WHERE{$sql} order by id desc limit $offset,$pagesize");
										}else{
										$url = $_SERVER['HTTP_HOST'];//获取当前url	
										$rs=$DB->query("SELECT * FROM auth_kms WHERE url='$url' and 1=1 order by id desc limit $offset,$pagesize");	
										}
										while($res = $DB->fetch($rs))
										{
										if($res['isuse']==1) {
											$isuse='<span class="badge badge-info">使用者:'.$res['user'].'</span>';
										} elseif($res['isuse']==0) {
											$isuse='<span class="badge btn-green">未使用</span>';
										}
                                                      if($res['isuse']==1) {
                                                          $del='<button class="btn btn-xs btn-gray disabled">已经使用</button>';
                                                      } elseif($res['isuse']==0) {
                                                          $del='<a href="./kmlist.php?my=del&id='.$res['id'].'" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要删除此卡密吗？\');">删除</a>';
                                                      }
										echo '<tr><th><span class="co-name">'.$res['id'].'</span></th><td>'.$res['km'].'</td><td>'.$res['value'].'天/'.$res['values'].'GB/￥'.$res['money'].'</td><td>'.$isuse.'</td><td>'.($res['daili']?$res['daili']:'管理员').'</td><td>'.$res['kmtype_id'].'</td><td>'.$res['addtime'].'</td><td>'.$res['usetime'].'</td><td>'.$del.'</td></tr>';
										}
										?>
                                      </tbody>
                                  </table>
                      
                      </div>
                      <br>
						<?php
						echo'<ul class="pagination pagination-sm">';
						$first=1;
						$prev=$page-1;
						$next=$page+1;
						$last=$pages;
						if ($page>1)
						{
						echo '<li><a href="kmlist.php?page='.$first.$link.'">首页</a></li>';
						echo '<li><a href="kmlist.php?page='.$prev.$link.'">&laquo;</a></li>';
						} else {
						echo '<li class="disabled"><a>首页</a></li>';
						echo '<li class="disabled"><a>&laquo;</a></li>';
						}
						for ($i=1;$i<$page;$i++)
						echo '<li><a href="kmlist.php?page='.$i.$link.'">'.$i .'</a></li>';
						echo '<li class="disabled"><a>'.$page.'</a></li>';
						for ($i=$page+1;$i<=$pages;$i++)
						echo '<li><a href="kmlist.php?page='.$i.$link.'">'.$i .'</a></li>';
						echo '';
						if ($page<$pages)
						{
						echo '<li><a href="kmlist.php?page='.$next.$link.'">&raquo;</a></li>';
						echo '<li><a href="kmlist.php?page='.$last.$link.'">尾页</a></li>';
						} else {
						echo '<li class="disabled"><a>&raquo;</a></li>';
						echo '<li class="disabled"><a>尾页</a></li>';
						}
						echo'</ul>';
						#分页
						}
						?>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
