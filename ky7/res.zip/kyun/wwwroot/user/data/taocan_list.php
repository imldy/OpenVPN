<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：显示平台所有套餐信息
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

$db = db('openvpn');
$row = $db->where(array('iuser'=>$_GET['user'],'pass'=>$_GET['pass']))->find();
if($row){
$db = db("ky_tc");
$db2 = db("ky_dl");
$rw = $db2->where(array('id'=>$dlid))->find();
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>套餐管理 - 套餐列表</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    <script src="../../assets/js/jquery.min.js"></script>
	<script src="../../assets/js/bootstrap.min.js"></script>
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
<div class="wrapper wrapper-content animated fadeInUp">
   <div class="row">
         <div class="col-sm-12">
			<div class="ibox-mulu">
      <h3> &nbsp;&nbsp; <i class="fa fa-shopping-cart fa-lg"></i> 套餐管理 > 套餐列表</h3>
              </div>
			  <br>
<?php
$taocan_list = $db->where(array('dlid'=>'0'))->order('id desc')->select();
echo '<div class="row">';
foreach($taocan_list as $res){
if($res["i"] == "1" ){
   $i='<span class="label label-primary">按时间计费</span>';
}else{
   $i='<span class="label label-success">按流量计费</span>';
}	
echo '<form action="../../Pay/PayApi.php?user='.$row['iuser'].'&dlid=0" method="post">
       <div class="col-sm-3">
         <div class="ibox">
          <div class="ibox-content">
		  <center>
		  <input name="shop_name" value="'.$res['name'].'" type="hidden"/>
	     <h2>'.$res['name'].'</h2>
		 <h3>套餐时间：'.$res['tian'].' 天</h3>
		 <h3>套餐流量：'.$res['G'].' G</h3>
		 <h3>出售金额：'.$res['money'].' 元</h3>
		 <h3>计费方式：'.$i.'</h3>
		<button type="submit" class="btn btn-default" name="shop_pay" value="alipay"><img src="../../Kyws/images/alipay.ico""/> 支付宝</button>
	   <button type="submit" class="btn btn-default" name="shop_pay" value="qqpay"><img src="../../Kyws/images/qqpay.ico""/> QQ钱包</button>
	   <button type="submit" class="btn btn-default" name="shop_pay" value="wxpay"><img src="../../Kyws/images/wxpay.ico""/>微信支付</button>
	 </center></div></div></div></form>';
}
echo '</div>';
?>

    </div>
	  </div>
		 </div>
              </div>
		 </div>
    </body>
</html>
<?php
}else{
   exit("<script>window.location.href='../Kyun/index.php';</script>");
}                 
?>