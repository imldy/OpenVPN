#! /bin/bash
DB='openvpn'
DBADMIN='root'
DBPASSWD='roottoor'
host='localhost'
port='3306'
mysql -h$host -P$port -u$DBADMIN -p$DBPASSWD -e "UPDATE log SET end_time=now(),bytes_received='$bytes_received',bytes_sent='$bytes_sent',total_used=(select sum(bytes_sent)+sum(bytes_received)),status=0 WHERE trusted_ip='$trusted_ip' AND trusted_port=$trusted_port AND remote_ip='$ifconfig_pool_remote_ip' AND username='$common_name' AND status=1;" $DB
mysql -h$host -P$port -u$DBADMIN -p$DBPASSWD -e "update stat set total_used=(select sum(total_used) from log where log.username='$common_name') WHERE stat.username='$common_name';" $DB
mysql -h$host -P$port -u$DBADMIN -p$DBPASSWD -e "UPDATE user SET used_quota=(select total_used from stat where stat.username='$common_name'),left_quota=quota_bytes-used_quota WHERE username='$common_name';" $DB
mysql -h$host -P$port -u$DBADMIN -p$DBPASSWD -e "UPDATE user SET use_cycle=(TO_DAYS(NOW()) - TO_DAYS(creation)) WHERE username='$common_name';" $DB
mysql -h$host -P$port -u$DBADMIN -p$DBPASSWD -e "UPDATE user SET surplus_cycle=(quota_cycle - use_cycle) WHERE username='$common_name';" $DB
mysql -h$host -P$port -u$DBADMIN -p$DBPASSWD -e "UPDATE user SET enabled=0 WHERE username='$common_name';" $DB
mysql -h$host -P$port -u$DBADMIN -p$DBPASSWD -e "UPDATE user SET quota_bytes=0 WHERE (quota_cycle - use_cycle) <= 0 AND username='$common_name';" $DB
mysql -h$host -P$port -u$DBADMIN -p$DBPASSWD -e "UPDATE user SET used_quota=0 WHERE (quota_cycle - use_cycle) <= 0 AND username='$common_name';" $DB
mysql -h$host -P$port -u$DBADMIN -p$DBPASSWD -e "UPDATE user SET active=0 WHERE (quota_cycle - use_cycle) <= 0 AND username='$common_name';" $DB
mysql -h$host -P$port -u$DBADMIN -p$DBPASSWD -e "UPDATE user SET active=0 WHERE left_quota <= 1048576 AND username='$common_name';" $DB
