<?php

$mod='blank';
include("../api.inc.php");

$userid=$_SESSION['userid'];

$u = daddslashes($_GET['user']);

$p = daddslashes($_GET['pass']);



if($u==""){
$res = $DB->get_row("SELECT * FROM openvpn WHERE id='$userid' limit 1");
$qdres = $DB->get_row("SELECT * FROM auth_qd WHERE iuser='{$res['iuser']}' limit 1");
}else{
$res=$DB->get_row("SELECT * FROM `openvpn` where `iuser`='$u' && `pass`='$p' limit 1");
}


if(!$res){
//	header('location: login.php');
		exit("<script language='javascript'>window.location.href='./login.php';</script>");
}
if($_POST['km']){
	$km = daddslashes($_POST['km']);
	$myrow=$DB->get_row("select * from auth_kms where kind=1 and km='$km' limit 1");
	if(!$myrow){
		exit("<script language='javascript'>alert('此激活码不存在');history.go(-1);</script>");
	}elseif($myrow['isuse']==1){
		exit("<script language='javascript'>alert('此激活码已被使用');history.go(-1);</script>");
	}else{
if($res['maxll']/1024/1024/1024>9999){
		exit("<script language='javascript'>alert('包月无限流量用户，无法充值！');history.go(-1);</script>");
}

		$duetime = ($res['endtime'] < time() ? time() : $res['endtime']) + $myrow['value']*24*60*60;
		$addll = $myrow['values']*1024*1024*1024;
		if($res['endtime'] < time()){//已到期
			$sql="update `openvpn` set `isent`='0',`irecv`='0',`maxll`='{$addll}',`endtime`='{$duetime}',`dlid`='{$myrow['daili']}',`i`='1' where `iuser`='{$res['iuser']}' && `pass`='{$res['pass']}'";
			if($DB->query($sql)){
				$DB->query("update `auth_kms` set `isuse` ='1',`user` ='$u',`usetime` ='$date' where `id`='{$myrow['id']}'");
				wlog('账号激活','用户'.$res['iuser'].'使用激活码'.$km.'开通账号['.$date.']');
				exit("<script language='javascript'>alert('开通成功！');history.go(-1);</script>");
			}else{
				exit("<script language='javascript'>alert('开通失败！');history.go(-1);</script>");
			}
		}else{
			$sql="update `openvpn` set `maxll`=`maxll` + '{$addll}',`endtime`='{$duetime}',`dlid`='{$myrow['daili']}',`i`='1' where `iuser`='{$res['iuser']}' && `pass`='{$res['pass']}'";
			if($DB->query($sql)){
				$DB->query("update `auth_kms` set `isuse` ='1',`user` ='$u',`usetime` ='$date' where `id`='{$myrow['id']}'");
				wlog('账号激活','用户'.$res['iuser'].'使用激活码'.$km.'续费账号['.$date.']');
				exit("<script language='javascript'>alert('续费成功！');history.go(-1);</script>");
			}else{
				exit("<script language='javascript'>alert('续费失败！');history.go(-1);</script>");
			}
		}
		//$duetime = ($res['endtime'] < time() ? time() : $res['endtime']) + $myrow['value']*24*60*60;
		//$addll = ($res['endtime'] < time() ? $myrow['values'] : $res['endtime']) + $myrow['values'];
		//$sql="update `openvpn` set `maxll`=`maxll` + '0',`endtime`='{$duetime}' where `iuser`='{$u}' && `pass`='{$p}'";
		
	}
	//if($DB->query("update `openvpn` set `pass`='$pass',`maxll`='$maxll',`i`='$state',`endtime`='$endtime' where iuser='$user'"))
}elseif($_POST['newpass']){
$newpass = daddslashes($_POST['newpass']);
$usedpass = daddslashes($_POST['usedpass']);
	if($usedpass==$res['pass']){
	if($DB->query("update `openvpn` set `pass` ='$newpass' where `iuser`='{$res['iuser']}' && `pass`='{$res['pass']}' limit 1")){
		exit("<script language='javascript'>alert('密码修改成功！');history.go(-1);</script>");
	}else{
		exit("<script language='javascript'>alert('密码修改失败！');history.go(-1);</script>");
	}
	}else{
		exit("<script language='javascript'>alert('旧密码不正确！');history.go(-1);</script>");
}
}


elseif($_POST['qd']){
    if($qdsql=='0'){}else exit("<script language='javascript'>alert('签到暂时未开放！');history.go(-1);</script>");
	$qd = $DB->get_row("SELECT * FROM `auth_qd` WHERE `iuser`='{$res['iuser']}' limit 1");
	$s = mt_rand(20,100);
	if($s>150){
	exit("<script language='javascript'>alert('数据非法！');history.go(-1);</script>");
	}

	if(!$qd){
if($DB->query("insert `auth_qd`(`id`, `iuser`, `pass`, `Lasttime`, `frequency`) VALUES ('{$res['id']}', '{$res['iuser']}', '{$res['pass']}','" . date("Y/m/d") ."',  '{$s}'")){
$addll = $s*1024*1024;
$sql="update `openvpn` set `isent`='0',`irecv`='0',`maxll`=`maxll` +'{$addll}',`i`='1' where `iuser`='{$res['iuser']}' && `pass`='{$res['pass']}'";
if($DB->query($sql)){
wlog('账号签到','用户'.$res['iuser'].'赠送$s M流量['.$date.']');
exit("<script language='javascript'>alert('签到成功，赠送$s M流量！');history.go(-1);</script>");
	}else{
	exit("<script language='javascript'>alert('签到失败，赠送$s M流量！');history.go(-1);</script>");
	}
	}else{
	exit("<script language='javascript'>alert('签到失败！');history.go(-1);</script>");}
	}elseif($qd['Lasttime'] ==  date("Y/m/d")){
	exit("<script language='javascript'>alert('今天已签到');history.go(-1);</script>");
	}elseif($qd['Lasttime'] < time()){
    $date = date("Y/m/d");
if($DB->query("UPDATE `ov`.`auth_qd` SET `Lasttime` = '{$date}', `frequency` = `frequency` + {$s} WHERE `auth_qd`.`id` = {$res['id']}")){			
				$addll = $s*1024*1024;
				$sql="update `openvpn` set `isent`='0',`irecv`='0',`maxll`=`maxll` +'{$addll}',`i`='1' where `iuser`='{$res['iuser']}' && `pass`='{$res['pass']}'";
			if($DB->query($sql)){
				wlog('账号签到','用户'.$res['iuser'].'赠送$s M流量['.$date.']');
			exit("<script language='javascript'>alert('签到成功，赠送$s M流量！');history.go(-1);</script>");
			}else{
				exit("<script language='javascript'>alert('签到失败，无法赠送$s M流量！');history.go(-1);</script>");
			}
	
	}else{
	exit("<script language='javascript'>alert('签到失败！');history.go(-1);</script>");}
}
}elseif($_POST['syll']){

if($res['syll']==1){
	
exit("<script language='javascript'>alert('领取失败！您已经领取过试用流量，无法再次领取哦！');history.go(-1);</script>");

}elseif($res['syll']==0){
$addll = 100*1024*1024;
$duetime = '1'*24*60*60;//流量到期日
  
$sql="update `openvpn` set `isent`='0',`irecv`='0',`maxll`='{$addll}',`endtime`=`endtime` + '{$duetime}',`i`='1' where `iuser`='{$res['iuser']}' && `pass`='{$res['pass']}'";
if($DB->query($sql)){
$DB->query("update `openvpn` set `isent`='0',`irecv`='0',`syll`='1',`i`='1' where `iuser`='{$res['iuser']}' && `pass`='{$res['pass']}'");
wlog('100M流量','用户'.$res['iuser'].'领取成功100M流量['.$date.']');
exit("<script language='javascript'>alert('领取成功！恭喜您，成功领取到了100M测试流量！');history.go(-1);</script>");
}else{
exit("<script language='javascript'>alert('领取失败！');history.go(-1);</script>");
}

}


}
;

if(round(($res['maxll']-$res['isent']-$res['irecv'])/1024/1024) > 1000000){

$ysll = '包月无限';
}else{
$ysll = round(($res['maxll']-$res['isent']-$res['irecv'])/1024/1024).'M';
}
 
 
 


$title='用户中心';


$config = $DB->get_row("SELECT * FROM auth_config");
$gonggao=$config['ggs'];//公告获取
include './head.php';

?>




<section id="content"> 
 <div class="container"> <div class="m-b-lg m-t-lg"> 






<div class="col-lg-4">
                        <div class="panel b-a">
                            <div class="panel-heading bg-info dk no-border wrapper-lg"></div>
                            <div class="text-center m-b clearfix">
                                    <img alt="image" class="img-circle" src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $res['qq'];?>&amp;spec=100">
                                <div class="h4 font-thin m-t-sm"><?php echo $res['iuser'];?></div>
                                <span class="text-muted text-xs block">会员用户 UID:<?php echo $res['id'];?></span>
                            </div>
                            <div class="padder-v b-t b-light bg-light lter row text-center no-gutter">
                                <div class="col-xs-4">
                                    <div>上传流量</div>
                                    <div class="inline m-t-sm"><span class="step"><?php echo round($res['isent']/1024/1024);?></span>M</div>
                                </div>
                                <div class="col-xs-4">
                                    <div>下载流量</div>
                                    <div class="inline m-t-sm"><span class="step"><?php echo round($res['irecv']/1024/1024);?></span>M</div>
                                </div>
                                <div class="col-xs-4">
                                    <div>剩余流量</div>
                                    <div class="inline m-t-sm"><span class="step"><?php echo $ysll;?></span></div>
                                </div>
                            </div>
                            <div class="hbox text-center b-t b-light">          
                                <div class="col padder-v text-muted b-r b-light">
                                    <div class="h4"><?php echo date('Y年m月d日',$res['endtime']);?></div><span>流量到期</span>
                                </div>
                                <div class="col padder-v text-muted">
                                    <div class="h4"><?php echo $res['userrmb'];?>元</div><span>账户余额</span>
                                </div>
                            </div>
                                
                            <div class="btn-group btn-group-justified">
                                <a href="./shop.php" class="btn btn-primary">充值流量</a>
                                <a href="./addmoney.php" class="btn btn-info">充值金额</a>
                                <a href="./Invitation.php" class="btn btn-success">邀请好友</a>
                            </div>
                                
                        </div>
 </div>

<div class="col-lg-8">
		<form action="" method="POST" class="form-inline">
    <div class="panel panel-default">
       <div class="panel-heading" style="padding-bottom:8px;">

		<input type="submit" name="qd" class="btn btn-xs btn-success m-t-xs" name="submit" value="签到">
		
          <div class="panel-title">积分排行榜</div>
       </div>
       <div data-height="180" data-scrollable="" class="list-group">
          <li class="list-group-item bb">
		  
		  </form>
		  
		  
<?php
$pagesize=30;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
$rs=$DB->query("SELECT * FROM `auth_qd` ORDER BY `auth_qd`.`frequency` DESC");
//$rs=$DB->query("SELECT * FROM auth_kms WHERE{$sql} order by id desc limit $offset,$pagesize");
while($res = $DB->fetch($rs))
{
if($res['isuse']==1) {
	$isuse='<font color="red">已使用</font><br/>使用者:'.$res['user'];
} elseif($res['isuse']==0) {
	$isuse='<font color="green">未使用</font>';
}
echo '

<li class="list-group-item bb"><span class="badge bg-inverse-light">'.$res['frequency'].'</span><span class="label label-info">2</span>　用户名：'.$res['iuser'].'</li>


';
}
?>
		  

		  
		  <li class="list-group-item bb"><span class="badge bg-inverse-light"><?php echo $qdres['frequency'];?></span><span class="label label-info">#</span>　用户名：我的积分</li>   
       </div>
    </div>
    
 </div>

</div>					

<div class="col-lg-12">
                        <div class="panel panel-default" draggable="true">
                            <div class="panel-heading">试用流量领取</div>
                            <div class="list-group-item">1免费100M试用流量领取，每人限领一次。<a href="../app"><kbd>免流测试教程</kbd></a></div>
                            <div class="list-group-item">2、已经购买过流量的用户请勿领取，会覆盖掉你购买的流量。</div>
                            <div class="list-group-item">
                                <span class="glyphicon glyphicon-th" aria-hidden="true"> 全站总共领取人数:<font color="green" size="3"><?php $s=$DB->count("SELECT count(*) from `openvpn` WHERE 1") + 968; echo $s;?></font>人</span>
                            </div>
                            <div class="list-group-item">
							<form action="" method="POST" class="form-inline">
								<input type="submit" name="syll" class="btn btn-success btn-block" name="submit" value="点此领取试用流量">
							</form>
                            </div>
                        </div>
                    </div>
		

    </body>
</html>

