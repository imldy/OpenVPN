<?php
$mod='blank';
include("../api.inc.php");

$userid=$_SESSION['userid'];

$u = daddslashes($_GET['user']);

$p = daddslashes($_GET['pass']);



if($u==""){
$res = $DB->get_row("SELECT * FROM openvpn WHERE id='$userid' limit 1");
$qdres = $DB->get_row("SELECT * FROM auth_qd WHERE iuser='{$res['iuser']}' limit 1");
}else{
$res=$DB->get_row("SELECT * FROM `openvpn` where `iuser`='$u' && `pass`='$p' limit 1");
}


if(!$res){
//	header('location: login.php');
		exit("<script language='javascript'>window.location.href='./login.php';</script>");
}

$title='用户中心';
include './head.php';

$config = $DB->get_row("SELECT * FROM auth_config");
$gonggao=$config['ggs'];//公告获取
?>

<section id="content"> 
 <div class="container"> 
 <div class="m-b-lg m-t-lg"> 


<div class="wrapper">



<div class="col-lg-6">
                        <div class="panel panel-info">
                            <div class="panel-heading text-center">
                                <h4 class="font-bold no-margins" style="margin:5px;">邀请好友</h4>
                            </div>
                            <div class="panel-body">
                                <div class="tooltip-demo text-center">
                                    <div id="qrcode" title="http://qq.jisuyun.cc/download/jisuyun.apk"><canvas width="200" height="200" style="display: none;"></canvas><img src="http://qr.liantu.com/api.php?text=http://www.bh-yl.top:8888/user/reg.php?id=<?php echo $res['id'];?>" height="200" width="200" style="display: initial;"></div>
                                    <h5>您的好友<?php echo $res['iuser'];?>派出200M流量红包,快来接受我的邀请吧!http://www.bh-yl.top:8888/user/reg.php?id=<?php echo $res['id'];?></h5>
                                    <h3>每邀请一位好友赠送500M流量。</h3>
                                    <h4><div class="jiathis_style_32x32">
<a class="jiathis_button_qzone"></a>
<a class="jiathis_button_tsina"></a>
<a class="jiathis_button_tqq"></a>
<a class="jiathis_button_weixin"></a>
<a class="jiathis_button_renren"></a>
<a href="http://www.jiathis.com/share" class="jiathis jiathis_txt jiathis_separator jtico jtico_jiathis" target="_blank"></a>
<a class="jiathis_counter_style"></a>
</div></h4>
									<!-- JiaThis Button BEGIN -->

                                </div>
                            </div>
                        </div>
                    </div>



			</div>
			</div>
			</section>
			
			
			

<script type="text/javascript" >
var jiathis_config={
	url:"http://www.bh-yl.top:8888/user/reg.php?id=<?php echo $res['id'];?>",
	summary:"您的好友<?php echo $res['iuser'];?>派出200M流量红包,快来接受我的邀请吧!",
	title:"您的好友<?php echo $res['iuser'];?>派出200M流量红包,快来接受我的邀请吧! ##",
	shortUrl:false,
	hideMore:false
}
</script>
<script type="text/javascript" src="http://v3.jiathis.com/code/jia.js" charset="utf-8"></script>
<!-- JiaThis Button END -->
