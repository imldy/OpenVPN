<?php
require_once ("head.php");

?>
<section id="content">
<section class="vbox">
<section class="scrollable padder">
<ul class="breadcrumb no-border no-radius b-b b-light pull-in">
	<li><a href="#"><i class="fa fa-home"></i> <?php echo $title ?></a></li>
</ul>
<section class="panel panel-default">
              <header class="panel-heading font-bold"> 全局设置 </header>
              <div class="panel-body">
				<form action="?" class="form-horizontal" method="post">
				<input type="hidden" name="do" value="web">
                  <div class="form-group">
                    <label class="col-sm-2 control-label">网站名称</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control rounded" name="name" value="<?=$conf['name']?>">
                    </div>
                  </div>
                  <div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label">站长QQ</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="kfqq" value="<?=$conf['qq']?>">
                      <span class="help-block m-b-none">网站客服QQ.</span> </div>
                  </div>
                  <div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label" for="input-id-1">网站域名</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="domain" value="<?=$conf['domain']?>">
                    </div>
                  </div>
				  <div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label">网站公告</label>
                    <div class="col-sm-10">
					  <textarea class="form-control" name="gonggao"><?=$conf['gonggao']?></textarea>
                    </div>
                  </div>
                  <div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label">监控密匙</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="key" value="<?=$conf['cronrand']?>">
                    </div>
                  </div>
                  <div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label">是否开放注册</label>
                    <div class="col-sm-10">
										<p>
											<label class="radio-inline">
												<input type="radio" name="ifreg" value="1" <?php if($conf['ifreg']==1) echo 'checked=""';?>>开放
											</label>
											<label class="radio-inline">
												<input type="radio" name="ifreg" value="0" <?php if($conf['ifreg']==0) echo 'checked=""';?>>关闭
											</label>
										</p>
									</div>
                  </div>
				  <div class="line line-dashed line-lg pull-in"></div>
				  <div class="form-group">
                    <label class="col-sm-2 control-label">网站维护</label>
                    <div class="col-sm-10">
										<p>
											<label class="radio-inline">
												<input type="radio" name="ifweb" value="1" <?php if($conf['ifweb']==1) echo 'checked=""';?>>开启
											</label>
											<label class="radio-inline">
												<input type="radio" name="ifweb" value="0" <?php if($conf['ifweb']==0) echo 'checked=""';?>>关闭
											</label>
										</p>
									</div>
                  </div>
				  <div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label">维护提示</label>
                    <div class="col-sm-10">
					  <textarea class="form-control" name="webcon"><?=$conf['webcon']?></textarea>
                    </div>
                  </div>
                  <div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
                    <div class="col-sm-4 col-sm-offset-2">
                      <button type="submit" class="btn btn-primary">保存设置</button>
                    </div>
                  </div>
                </form>
              </div>
            </section>
</section>
</section>

<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a></section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
<div class="wrapper">
	Notification
</div>
</aside>
<!-- end -->
<?php
require_once ("foot.php");
?>
<?php 