<?php

include('head.php');
include('nav.php');
$m = new Map();
if($_GET['act'] == 'update'){
$info = file_put_contents(R.'/jiemian.txt',$_POST['content']);
tip_success('修改成功',$_SERVER['HTTP_REFERER']);
}else{
$action = '?act=update';
$info = file_get_contents(R.'/jiemian.txt');
;echo '<div class="box">
<div class="main">
<span class="label label-default">界面滚动公告</span>
<div style="clear:both;height:10px;"></div>
<div class="alert alert-danger">App连接界面滚动公告</div>
		<form class="form-horizontal" role="form" method="POST" action="';echo $action;echo '">
			
			<textarea class="form-control" rows="10" name="content">';echo $info ;echo '</textarea>
			<br>
			<button type="submit" class="btn btn-info btn-block">提交数据</button>
			
	
	</form> 
	</div>
</div>

';
}
include('haosky.php');
?>