<?php
@eval("//Encode by  phpjiami.com,Free user."); ?><?php
//购买说明
$info_buy = '激活码购买地址：<a target="_blank" href="http://917ka.com/">http://917ka.com/</a>';

//联系QQ
$info_qq = '123456';

//第二次续费另外赠送天数
$twice_free = 0; 