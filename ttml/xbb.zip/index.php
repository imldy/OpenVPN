<link rel="shortcut icon" href="../static/index/images/favicon.ico">
<?php
header("location: ./user/login.php"); 
//include("user/login.php");
?>