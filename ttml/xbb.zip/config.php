<?php
//数据库信息
$host = "localhost" ;
$port = "3306" ;
$user = "root" ;
$pwd = "MySQLPass" ;
$dbname = "ov" ;

$conf_rate="0.05";//推荐人返现折扣率，如：0为不返现，1为全额返现，返点5%填0.05，返点10%填0.1，正常情况下，取值范围（0~1），请须知
?>