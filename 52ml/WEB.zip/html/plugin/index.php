<?php
@eval("//Encode by  phpjiami.com,Free user."); ?><?php
//�����̳� QQ:261753427
if (!defined('IN_IA')) {
    exit('Access Denied');
}
global $_W, $_GPC; 