<?php
/**
 * 管理中心
**/

$title='管理中心';

?>
<!DOCTYPE html>
<html lang="en" class="app"><head>
        <meta charset="utf-8" />
        <title>管理员后台</title>
        <meta name="description" content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav"
        />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"
        />
        <link rel="stylesheet" href="/static/index/css/app.v2.css" type="text/css"
        />
        
	
<?php
$url = $_SERVER['PHP_SELF'];
if ($url == '/admin/index.php') {
    echo '
<script src="/static/qqlogin/jquery-2.2.0.min.js"></script>
<script src="/static/qqlogin/qqlogin.js"></script>
<script src="/static/qqlogin/login.js"></script>';
}
?>
<!--[if lt IE 9]>
<script src="/static/index/js/ie/html5shiv.js" cache="false"></script>
<script src="/static/index/js/ie/respond.min.js" cache="false"></script>
<script src="/static/index/js/ie/excanvas.js" cache="false"></script>
<![endif]-->
</head>
<body>
<section class="vbox">
<header class="bg-dark dk header navbar navbar-fixed-top-xs">
<div class="navbar-header aside-md">
	<a class="btn btn-link visible-xs" data-toggle="class:nav-off-screen" data-target="#nav"><i class="fa fa-bars"></i></a><a class="navbar-brand" ><img src="/static/index/images/logo.png" class="m-r-sm">大灰狼</a><a class="btn btn-link visible-xs" data-toggle="dropdown" data-target=".nav-user"><i class="fa fa-cog"></i></a>
</div>
<ul class="nav navbar-nav navbar-right hidden-xs nav-user">
	<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="thumb-sm avatar pull-left"><img src="./sjimg/4.jpg"></span> 管理员<b class="caret"></b></a>
	<ul class="dropdown-menu animated fadeInRight">
		<span class="arrow top"></span>
		<li><a href="./passwd.php">修改密码</a></li>
		<li><a href="./login.php?logout">注销</a></li>
	</ul>
	</li>
</ul>
</header>
<section>
<section class="hbox stretch">
<aside class="bg-light lter b-r aside-md hidden-print" id="nav">
<section class="vbox">
<section class="w-f scrollable">
<div class="slim-scroll" data-height="auto" data-disable-fade-out="true" data-distance="0" data-size="5px" data-color="#333333">
	<!-- nav -->
	<nav class="nav-primary hidden-xs">
	<ul class="nav">
		<li class="active"><a href="index.php" class="active"><i class="fa fa-dashboard icon"><b class="bg-danger"></b></i><span>平台首页</span></a></li>
		<li><a href="#layout"><i class="fa fa-cog" ><b class="bg-warning"></b></i><span class="pull-right"><i class="fa fa-angle-down text"></i><i class="fa fa-angle-up text-active"></i></span><span>服务管理
</span></a>
		<ul class="nav lt">
            <li><a href="./fwqlist.php"><i class="fa fa-angle-right"></i><span>服务器列表</span></a></li>
            <li><a href="./addfwq.php"><i class="fa fa-angle-right"></i><span>添加服务器</span></a></li>
			<li><a href="./log.php"><i class="fa fa-angle-right"></i><span>操作记录</span></a></li>
			
		</ul>
		</li>
		<li><a href="#uikit"><i class="fa fa-flask icon"><b class="bg-success"></b></i><span class="pull-right"><i class="fa fa-angle-down text"></i><i class="fa fa-angle-up text-active"></i></span><span>账号管理</span></a>
		<ul class="nav lt">
			<li><a href="./addqq.php"><b class="badge bg-info pull-right"></b><i class="fa fa-angle-right"></i><span>添加账号</span></a></li>
            <li><a href="./qqlist.php"><b class="badge bg-info pull-right"><?php echo $DB->
                                            count("select count(uid) as count from " . DBQZ . "_user where 1=1") ?></b><i class="fa fa-angle-right"></i><span>账号列表</span></a></li>
			<li><a href="./pladd.php"><b class="badge bg-info pull-right"></b><i class="fa fa-angle-right"></i><span>批量添加账号</span></a></li>
			<li><a href="./daochu.php"><b class="badge bg-info pull-right"></b><i class="fa fa-angle-right"></i><span>导出账号</span></a></li>
		</ul>
		</li>
		
		<li>
		<a href="#kalist"><i class="fa fa-file-text icon"><b class="bg-primary"></b></i><span class="pull-right"><i class="fa fa-angle-down text"></i><i class="fa fa-angle-up text-active"></i></span><span>卡密管理</span></a>
		<ul class="nav lt">
			<li><a href="./kmlist.php"><i class="fa fa-angle-right"></i><span>卡密列表</span></a></li>
			<li><a href="./search.php"><i class="fa fa-angle-right"></i><span>搜索卡密</span></a></li>
			
		</ul>
		</li>
	
<li>
		<a href="#layout"><i class="fa fa-coffee icon"><b class="bg-success"></b></i><span class="pull-right"><i class="fa fa-angle-down text"></i><i class="fa fa-angle-up text-active"></i></span><span>代理管理</span></a>
		<ul class="nav lt">
			<li><a href="./daili.php"><i class="fa fa-angle-right"></i><span>代理用户管理</span></a></li>
			<li><a href="./dlkm.php"><i class="fa fa-angle-right"></i><span>代理卡密管理</span></a></li>
			<li><a href="./dlconfig.php"><i class="fa fa-angle-right"></i><span>代理功能设置</span></a></li>
		</ul>
		</li>
		
		<li>
		<a href="#ovpn"><i class="fa fa-android icon"><b class="bg-primary"></b></i><span class="pull-right"><i class="fa fa-angle-down text"></i><i class="fa fa-angle-up text-active"></i></span><span>安卓线路</span></a>
		<ul class="nav lt">
			<li><a href="./app.php"><i class="fa fa-angle-right"></i><span>APP设置</span></a></li>
			<li><a href="./addovpn.php"><i class="fa fa-angle-right"></i><span>添加线路</span></a></li>
			<li><a href="./ovpnlist.php"><i class="fa fa-angle-right"></i><span>线路列表</span></a></li>

		</ul>
		</li>
		
        <li><a href="../phpmyadmin"><i class="fa fa-android icon"><b class="bg-info"></b></i><span>数据库管理</span></a></li>
		<li><a href="./login.php?logout"><i class="fa fa-power-off icon"><b class="bg-info"></b></i><span>注销登录</span></a></li>
	</ul>
	</nav>
	<!-- / nav -->
</div>
</section>
<footer class="footer lt hidden-xs b-t b-light">
            <a href="#nav" data-toggle="class:nav-xs" class="pull-right btn btn-sm btn-default btn-icon"> <i class="fa fa-angle-left text"></i> <i class="fa fa-angle-right text-active"></i> </a>
</footer>
</section>
</aside>
<!-- /.aside -->
<?php 