<?php

/**

 * 添加线路

**/

$mod='blank';

include("../api.inc.php");

$title='添加线路';

if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

$bind_domain = explode(":",$_SERVER["HTTP_HOST"]);

?>

<!DOCTYPE html>

<html lang="en">

<?php include '../head.php';?>

<body class="page-body">



    <?php include 'set.php';?>

    

    <div class="page-container">



        <?php include 'nav.php';?>

        

        <div class="main-content">

                    

            <?php include 'info.php';?>

            

          <div class="page-title">

          <div class="title-env">

            <h1 class="title"><?php echo $title ?></h1>

            <p class="description">此处可以添加免流线路</p>

          </div>

            <div class="breadcrumb-env">

            

               <ol class="breadcrumb bc-1">

                 <li>

                  <a href="index.php"><i class="fa-home"></i>首页</a>

                </li>

                <li class="active">

                      <strong><?php echo $title ?></strong>

                  </li>

              </ol>

                  

             </div>

           </div>



            <div class="row">

                <div class="col-sm-12">



<?php

$open=isset($_POST['open'])?$_POST['open']:null;



if($open=='open1'){

echo '<div class="alert '; 

$name = $_REQUEST['name']; 

$proxy = $_REQUEST['proxy'];

$ca = $_REQUEST['ca']; 

$key = $_REQUEST['key']; 

$mo ='# 云免流控™配置 www.xiaoyangren.net
client
dev tun
proto tcp
resolv-retry infinite
nobind
persist-key
persist-tun
setenv IV_GUI_VER "de.blinkt.openvpn 0.6.17"
push route 114.114.114.144 114.114.115.115
machine-readable-output
connect-retry-max 5
connect-retry 5
resolv-retry 60
key-direction 1
auth-user-pass
ns-cert-type server
comp-lzo
verb 3
########免流代码########
'.$proxy.'
########免流代码########

## 证书
<ca>
'.$ca.'</ca>
<tls-auth>
'.$key.'</tls-auth>
';
$type = $_REQUEST['type']; 
$group = $_REQUEST['group'];
$show = $_REQUEST['show'];
$label = $_REQUEST['label'];
$time=time(); 
//$id=strtoupper(substr(md5($uin.time()),0,8).'-'.uniqid()); 
//$sql="insert into `open` (`id`,`name`,`mo`,`type`) values ('{$id}','{$name}','{$mo}','{$type}')"; 
$sql="insert `line`(`id`,`name`,`content`,`type`,`group`,`show`,`label`,`time`) values(null,'$name','$mo','$type','$group','$show','$label','$time')";
//$llws = $_REQUEST['llws'];   
$DB->query("insert `line`(`id`,`name`,`content`,`type`,`group`,`show`,`label`,`time`) values(null,'$name','$mo','$type','$group','$show','$label','$time');");
//if($DB->query($sql))
if($sql)
echo 'alert-success">

                    <button type="button" class="close">

                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>

                      <span class="sr-only">Close</span>

                    </button>成功添加一个线路</div>

                <a href="open.php" class="btn btn-secondary btn-icon btn-icon-standalone">

                  <i class="fa-edit"></i>

                  <span>继续添加</span>

                </a>

                <a href="openlist.php" class="btn btn-info btn-icon btn-icon-standalone">

                  <i class="fa-list-ol"></i>

                  <span>查看列表</span>

                </a>

                <style>#addline{display: none;}</style>'; 

else

                echo 'alert-danger">

                    <button type="button" class="close">

                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>

                      <span class="sr-only">Close</span>

                    </button>

                  添加失败</div>

                <a href="open.php" class="btn btn-secondary btn-icon btn-icon-standalone">

                  <i class="fa-edit"></i>

                  <span>继续添加</span>

                </a>

                <a href="openlist.php" class="btn btn-info btn-icon btn-icon-standalone">

                  <i class="fa-list-ol"></i>

                  <span>查看列表</span>

                </a>

                <style>#addline{display: none;}</style>'; 

//exit;  

}



if($open=='open2'){

echo '<div class="alert '; 

$name = $_REQUEST['name']; 

$mo = $_REQUEST['mo'];   
$type = $_REQUEST['type']; 
$group = $_REQUEST['group'];
$show = $_REQUEST['show'];
$label = $_REQUEST['label'];
$time=time(); 
//$id=strtoupper(substr(md5($uin.time()),0,8).'-'.uniqid()); 
//$sql="insert into `open` (`id`,`name`,`mo`,`type`) values ('{$id}','{$name}','{$mo}','{$type}')";
$DB->query("insert `line`(`id`,`name`,`content`,`type`,`group`,`show`,`label`,`time`) values(null,'$name','$mo','$type','$group','$show','$label','$time');"); 
$sql="insert `line`(`id`,`name`,`content`,`type`,`group`,`show`,`label`,`time`) values(null,'$name','$mo','$type','$group','$show','$label','$time')";
if($sql)
echo 'alert-success">

                    <button type="button" class="close">

                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>

                      <span class="sr-only">Close</span>

                    </button>成功添加一个线路</div>

                <a href="open.php" class="btn btn-secondary btn-icon btn-icon-standalone">

                  <i class="fa-edit"></i>

                  <span>继续添加</span>

                </a>

                <a href="openlist.php" class="btn btn-info btn-icon btn-icon-standalone">

                  <i class="fa-list-ol"></i>

                  <span>查看列表</span>

                </a>

                <style>#addline{display: none;}</style>'; 

else

                echo 'alert-danger">

                    <button type="button" class="close">

                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>

                      <span class="sr-only">Close</span>

                    </button>

                  添加失败</div>

                <a href="open.php" class="btn btn-secondary btn-icon btn-icon-standalone">

                  <i class="fa-edit"></i>

                  <span>继续添加</span>

                </a>

                <a href="openlist.php" class="btn btn-info btn-icon btn-icon-standalone">

                  <i class="fa-list-ol"></i>

                  <span>查看列表</span>

                </a>

                <style>#addline{display: none;}</style>'; 

//exit;  

}



?>



                <div id="addline">

                      <ul class="nav nav-tabs">

                        <li class="active">

                          <a href="#profile" data-toggle="tab">

                            <span class="visible-xs">高级模式</span>

                            <span class="hidden-xs">高级模式</span>

                          </a>

                        </li>

                        <li class="">

                          <a href="#by" data-toggle="tab">

                            <span class="visible-xs">简约模式</span>

                            <span class="hidden-xs">简约模式</span>

                          </a>

                        </li>

                      </ul>

                      <div class="tab-content">

                        <div class="tab-pane active" id="profile">

                          <form id="newopen" action="./open.php" method="post" class="form-horizontal validate" role="form">

                            <input type="text" class="hide" name="open" value="open1">

                            <div class="form-group">

                              <label class="col-sm-2 control-label">线路名称：</label>

                              <div class="col-sm-9">

                                <input type="text" class="form-control" id="proxy_title" placeholder="输入线路名称" name="name" data-validate="required">

                              </div>

                            </div>




                            <div class="form-group">
                              <label class="col-sm-2 control-label">线路类型：</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="proxy_title" placeholder="线路类型" name="type" data-validate="required">
                              </div>
                            </div>
							<div class="form-group">
                              <label class="col-sm-2 control-label">显示标签：</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="proxy_title" placeholder="显示标签" name="label" data-validate="required">
                              </div>
                            </div>
                       


                        <div class="form-group">
                          <label class="col-sm-2 control-label">线路种类：</label>
                          <div class="col-sm-9">
                            <label class="radio-inline">
                              <input type="radio" name="group" checked="" value="1">
                              移动

                            </label>

                            <label class="radio-inline">
                              <input type="radio" name="group" value="2">
                              联通

                            </label>

                            <label class="radio-inline">
                              <input type="radio" name="group" value="3">
                              电信

                            </label>

                            <label class="radio-inline">
                              <input type="radio" name="group" value="4">
                              其它

                            </label>

                          </div>

                        </div>

                        <div class="form-group">
                        	
                          
                          <div class="col-sm-9">
                         </div>	
                       	 </div>
                        
                           			 <div class="form-group">
                 		 <label class="col-sm-2 control-label">免流模式：</label>
                              <div class="col-sm-6">

                                 <textarea class="form-control jq_watermark" cols="5" id="proxy" name="proxy" rows="11" data-validate="required" placeholder='remote wap.gd.10086.cn 80<br/>http-proxy 【您的IP】 【免流端口】

<br/>http-proxy-option EXT1 xyrml 127.0.0.1:【VPN端口】

<br/>http-proxy-option EXT1 "X-Online-Host: wap.gd.10086.cn "

<br/>http-proxy-option EXT1 "Host: wap.gd.10086.cn "'></textarea>

                              <p class="text-info" style="line-height: 31px;">* 以上是基础示例，【】为特殊提示可删除，默认验证头为xyrml，默认VPN端口为443</p>

                              </div>

                              <?php 

                              $url = "http://www.xiaoyangren.net/proxy/"; 

                              $contents = file_get_contents($url); 

                              echo $contents; 

                              ?>

                            </div>  

                            <div class="form-group">

                              <label class="col-sm-2 control-label">您的证书：</label>

                              <div class="col-sm-9">

                                 <textarea class="form-control" cols="5" id="field-5" name="ca" rows="6" data-validate="required"><?php

                                      $myfile = fopen("../ca.crt", "r") or die("没有找到ca.crt");

                                      echo fread($myfile,filesize("../ca.crt"));

                                      fclose($myfile);

                                      ?></textarea>

                              </div>

                            </div>  



                            <div class="form-group">

                              <label class="col-sm-2 control-label">您的Key：</label>

                              <div class="col-sm-9">

                                 <textarea class="form-control" cols="5" id="field-5" name="key" rows="6" data-validate="required"><?php

                                      $myfile = fopen("../ta.key", "r") or die("没有找到ta.key");

                                      echo fread($myfile,filesize("../ta.key"));

                                      fclose($myfile);

                                      ?></textarea>

                              </div>
                            </div>  
                            
                            <div class="form-group">
                                <div class="col-sm-offset-2 col-sm-10">
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" checked="" name="show" value="1">是否启用
                                        </label>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group">

                              <label class="col-sm-2 control-label"></label>

                              <div class="col-sm-9">

                                <button type="submit" type="button" class="btn btn-info btn-block">添加</button>

                              </div>

                            </div>

                          </form>

                        </div>

                        <div class="tab-pane" id="by">

                          <form id="open" action="./open.php" method="post" class="form-horizontal validate" role="form">

                            <input type="text" class="hide" name="open" value="open2">

                            <div class="form-group">

                              <label class="col-sm-2 control-label">线路名称：</label>

                              <div class="col-sm-9">

                                <input type="text" class="form-control" id="field-1" placeholder="输入线路名称" name="name" data-validate="required">

                              </div>

                            </div>
                            <div class="form-group">
                              <label class="col-sm-2 control-label">线路类型：</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="proxy_title" placeholder="线路类型" name="type" data-validate="required">
                              </div>
                            </div>
                            
							<div class="form-group">
                              <label class="col-sm-2 control-label">显示标签：</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="proxy_title" placeholder="显示标签" name="label" data-validate="required">
                              </div>
                            </div>
                            
                        <div class="form-group">
                          <label class="col-sm-2 control-label">线路种类：</label>
                          <div class="col-sm-9">
                            <label class="radio-inline">
                              <input type="radio" name="group" checked="" value="1">
                              移动

                            </label>

                            <label class="radio-inline">
                              <input type="radio" name="group" value="2">
                              联通

                            </label>

                            <label class="radio-inline">
                              <input type="radio" name="group" value="3">
                              电信

                            </label>

                            <label class="radio-inline">
                              <input type="radio" name="group" value="4">
                              其它

                            </label>

                          </div>

                        </div>

                        

                        <div class="form-group">
                          
                          <div class="col-sm-9">
                          </div>

                        </div>



                            <div class="form-group">

                              <label class="col-sm-2 control-label">线路内容：</label>

                              <div class="col-sm-9">

                                 <textarea class="form-control" cols="5" id="field-5" name="mo" rows="25" data-validate="required"></textarea>
                              </div>
                            </div>  

                            <div class="form-group">
                                <div class="col-sm-offset-2 col-sm-10">
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" checked="" name="show" value="1">是否启用
                                        </label>
                                    </div>
                                </div>
                            </div>
							
                            <div class="form-group">

                              <label class="col-sm-2 control-label"></label>

                              <div class="col-sm-9">

                                <button type="submit" type="button" class="btn btn-info btn-block">添加</button>

                              </div>

                            </div>

                          </form>

                        </div>

                      </div>

                </div>

                    

                </div>



            </div>

   

            <!-- Main Footer -->

            <?php include("../copy.php");?>

        </div>

        

        </div>

        

    </div>



    <!-- Bottom Scripts -->

    <script src="../assets/js/bootstrap.min.js"></script>

    <script src="../assets/js/TweenMax.min.js"></script>

    <script src="../assets/js/resizeable.js"></script>

    <script src="../assets/js/joinable.js"></script>

    <script src="../assets/js/xenon-api.js"></script>

    <script src="../assets/js/xenon-toggles.js"></script>

    <script src="../assets/js/moment.min.js"></script>





    <!-- Imported scripts on this page -->

  <script src="../assets/js/datepicker/bootstrap-datepicker.js"></script>

  <link rel="stylesheet" href="../assets/js/multiselect/css/multi-select.css">

  <script src="../assets/js/multiselect/js/jquery.multi-select.js"></script>

    <script src="../assets/js/jquery.watermark.min.js"></script>



    <!-- JavaScripts initializations and stuff -->

    <script src="../assets/js/xenon-custom.js"></script>



</body>

</html><?php 