<?php
$mod='blank';
include("../api.inc.php");
$title='批量添加账号';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<!-- Body -->
<body>

        <?php include 'nav.php';?>
      <section>
         <!-- Page content-->
         <div class="content-wrapper">
            <h3><?php echo $title ?>
               <small>可以一次生成所需要的格式的帐号密码.</small>
            </h3>

<?php
if($_POST['num']){
$notes = daddslashes($_POST['notes']);
$num = daddslashes($_POST['num']);
//$prefix = daddslashes($_POST['prefix']);
$strlen = daddslashes($_POST['strlen']);  //账号长度
//$suffix = daddslashes($_POST['suffix']);
$fwqid = daddslashes($_POST['fwqid']);
$passwd = daddslashes($_POST['passwd']);  //密码长度
$maxll = daddslashes($_POST['maxll'])*1024*1024;
$state = daddslashes($_POST['state']);
$tian = daddslashes($_POST['tian']);
$tian = $_POST['tian'];
//$endtime = time()+3600*24*daddslashes($_POST['tian']);

for($x=0; $x<$num; $x++){

$user = random($strlen,1); //生成的账号
$pass = random($passwd,1); //生成的密码
$url = $_SERVER['HTTP_HOST'];//获取当前url	
if(!$DB->get_row("select * from `openvpn` where `iuser`='$user' limit 1")){
	$id=strtoupper(substr(md5($uin.time()),0,8).'-'.uniqid());
	$sql="insert into `openvpn` (`iuser`,`pass`,`isent`,`irecv`,`maxll`,`i`,`starttime`,`endtime`,`fwqid`,`notes`,`tian`,`url`) values ('{$user}','{$pass}',0,0,'{$maxll}','{$state}','".time()."','{$endtime}','{$fwqid}','{$notes}','{$tian}','{$url}')";
	if($DB->query($sql))
		echo "<b>账号：{$user} &nbsp;&nbsp; 密码：{$pass} &nbsp;&nbsp; 备注：{$notes}</b><br />";
	else
		echo "添加失败：".$DB->error()."<br />";
}else{
	echo "该账号已存在！<br />";
}


}




echo '<hr/><a href="./pladd.php">>>返回继续添加</a><br><a href="./qqlist.php">>>返回账号列表</a></div></div>';
}
                    $fwqlist=$DB->query("SELECT * FROM auth_fwq");
                    ?>
      
            <div class="row">
               <div class="col-md-12">
          <form action="./pladd.php" method="post" class="form-horizontal" role="form">
		                       <div class="panel panel-default">
                        <div class="panel-heading">
                           <div class="panel-title">批量添加账号</div>
                        </div>
                        <div class="panel-body">
		                    <fieldset>
                              <div class="form-group">
                                 <label class="col-sm-2 control-label">账号个数</label>
                                 <div class="col-sm-6">
                                    <input type="text" name="num" class="form-control">
                                 </div>
                                 <div class="col-sm-4"><code>请输入您需要生成的账号数量</code>
                                 </div>
                              </div>
                           </fieldset>
                           <fieldset>
                              <div class="form-group">
                                 <label class="col-sm-2 control-label">用户名长度</label>
                                 <div class="col-sm-6">
                                    <input type="text" name="strlen" class="form-control">
                                 </div>
                                 <div class="col-sm-4"><code>请输入您需要生成的账号长度</code>
                                 </div>
                              </div>
                           </fieldset>

                            <fieldset>
                              <div class="form-group">
                                 <label class="col-sm-2 control-label">密码长度</label>
                                 <div class="col-sm-6">
                                    <input type="text" name="passwd" class="form-control">
                                 </div>
                                 <div class="col-sm-4"><code>请输入您需要生成的密码长度</code>
                                 </div>
                              </div>
                           </fieldset>

						    <fieldset>
                              <div class="form-group">
                                 <label class="col-sm-2 control-label">账号状态</label>
								 <div class="col-sm-6">
                                 <select name="state" class="form-control">
              	                 <option value="1">开通</option>
				                 <option value="2">未激活</option>
				                 <option value="0">禁用</option>
                                 </select>
								 </div>
                                 <div class="col-sm-4"><code>请选择账号状态</code>
                                 </div>
                              </div>
                           </fieldset>
						   
                           <fieldset>
                              <div class="form-group">
                                 <label class="col-sm-2 control-label">总流量(M)</label>
                                 <div class="col-sm-6">
                                    <input type="text" name="maxll" class="form-control">
                                 </div>
                                 <div class="col-sm-4"><code>请输入您需要生成的账号流量</code>
                                 </div>
                              </div>
                           </fieldset>

                           <fieldset>
                              <div class="form-group">
                                 <label class="col-sm-2 control-label">有效天数</label>
                                 <div class="col-sm-6">
                                    <input type="text" name="tian" class="form-control">
                                 </div>
                                 <div class="col-sm-4"><code>请输入您需要生成账号的有效天数</code>
                                 </div>
                              </div>
                           </fieldset>						   

                           <fieldset>
                              <div class="form-group">
                                 <label class="col-sm-2 control-label">选择服务器</label>
                                 <div class="col-sm-6">
                                    <select name="fwqid" class="form-control">
				<?php while($v = $DB->fetch($fwqlist)): ?>
				  <option value="<?php echo $v['id']; ?>"><?php echo $v['name']; ?></option>
				<?php endwhile; ?>
				</select>
            </div>
                                 <div class="col-sm-4"><code>请输入您需要生成的服务器</code>
                                 </div>
                              </div>
                           </fieldset>						   					   

                           <fieldset>
                              <div class="form-group">
                                 <label class="col-sm-2 control-label">备注</label>
                                 <div class="col-sm-6">
                                    <input type="text" name="notes" class="form-control">
                                 </div>
                                 <div class="col-sm-4"><code>请输入您需要生成账号的备注</code>
                                 </div>
                              </div>
                           </fieldset>	
             <div class="panel-footer text-center">						   
            <input type="submit" value="添加" class="btn btn-info btn-block"/>
			                        </div>
                     </div>
          </form>
        </div>
      </div>
    </div>
  </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>