<?php
include("../api.inc.php");
$dlid=$_SESSION['dlid'];
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
if($dllx=='0'){}else exit("<script language='javascript'>alert('路线暂时未开放下载！');history.go(-1);</script>");

$id = daddslashes($_GET['id']);
if(!$id || !$row = $DB->get_row("select * from `lyj_article` where id='$id' limit 1")){ exit("线路不存在");}

$filename = $row['title'].'.ovpn';
header("Content-Type: application/octet-stream");   
header('Content-Disposition: attachment; filename="' . $filename . '"');
//header('Content-Disposition: attachment; filename*="' .  $filename . '"'); 
echo $row['content'];
exit;
?>


