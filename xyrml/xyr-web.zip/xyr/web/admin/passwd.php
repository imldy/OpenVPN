<?php
$mod='blank';
include("../api.inc.php");
$title='修改密码';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body">

    <?php include 'set.php';?>
    
    <div class="page-container">

        <?php include 'nav.php';?>
        
        <div class="main-content">
                    
            <?php include 'info.php';?>
            
          <div class="page-title">
          <div class="title-env">
            <h1 class="title"><?php echo $title ?></h1>
            <p class="description">管理员在这里可以修改后台账号和密码</p>
          </div>
            <div class="breadcrumb-env">
            
               <ol class="breadcrumb bc-1">
                 <li>
                  <a href="index.php"><i class="fa-home"></i>首页</a>
                </li>
                <li class="active">
                      <strong><?php echo $title ?></strong>
                  </li>
              </ol>
                  
             </div>
           </div>

            <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">修改管理员账号和密码</h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">
<?phpif(isset($_POST['newname'])&&isset($_POST['newpasswd'])) {$newname=$_POST['newname'];$newpasswd=$_POST['newpasswd'];if($newname==""||$newpasswd=="") {exit("<script language='javascript'>alert('用户名和密码不能为空！');history.go(-1);</script>");}else {	$newpasswd=md5($newpasswd);		$sql = "update `app_admin` set `username` = '".$newname."', `password` = '".$newpasswd."'";    $result = $DB->query($sql);		if($result){        exit("<script language='javascript'>alert('密码修改成功！');history.go(-1);</script>");    }else{		exit("<script language='javascript'>alert('密码修改失败！');history.go(-1);</script>");    }	   }}
?>

              <form id="myform" action="./passwd.php" method="post" role="form" class="form-horizontal validate">     
                <div class="form-group">						
                  <label class="col-sm-2 control-label">新账号</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="field-1" name="newname" data-validate="required">
                  </div>
                </div>				
                <div class="form-group">
                  <label class="col-sm-2 control-label">新密码</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="field-1" name="newpasswd" data-validate="required">
                  </div>
                </div>


                <div class="form-group">
                  <label class="col-sm-2 control-label"></label>
                  <div class="col-sm-6">
                    <button type="submit" type="button" class="btn btn-info">修改</button>
                  </div>
                </div>
                
              </form> 
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
        </div>
        
        </div>
        
    </div>

    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>


    <!-- Imported scripts on this page -->
    <script src="../assets/js/xenon-widgets.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/globalize.min.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/dx.chartjs.js"></script>
    <script src="../assets/js/toastr/toastr.min.js"></script>

    <script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>

    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 