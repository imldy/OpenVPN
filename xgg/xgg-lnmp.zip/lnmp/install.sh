#!/bin/bash
mkdir -p /home/wwwroot/default
mkdir -p /home/wwwlog/

./include/install_nginx.sh

./include/init.sh
 
./include/install_mysql.sh

./include/install_php.sh


systemctl restart mariadb
systemctl restart nginx.service
systemctl restart php-fpm.service
systemctl restart crond.service