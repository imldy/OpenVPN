<?php
if($_GET['dlapp']){
   $row = db("ky_dl")->where(array('id'=>$_GET['dlapp']))->find();
   if($row){
	   $qq = $row['qq']; 
	   $html = $row['html']; 
	   $name = $row['name']; 
   }else{
	   $qq = admin_copy('qq');
       $html = admin_copy('html');
       $name = admin_copy('name');
   }
}else{
   $qq = admin_copy('qq');
   $html = admin_copy('html');
   $name = admin_copy('name');
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="/Core/fun/prettify.css"/>
<div class="main">
	<div class="panel panel-default">
   <div class="panel-body">
    <?php echo $html ;
	  echo '<br><br><a href="mqqwpa://im/chat?chat_type=wpa&uin='.$qq.'&version=1&src_type=web&web_src=oicqzone.com" style="margin-top:10px;"><img src="images/qq.png" style="width:20px;float:left;">&nbsp;'.$name.'</a><br><br>';
?>
   </div>
</div>
</div>

