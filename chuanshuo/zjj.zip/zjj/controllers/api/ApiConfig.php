<?php

/**
 * Created by PhpStorm.
 * Author: 李玉江[QQ:1032694760]
 * Date: 2015-12-24 14:06
 */
class ApiConfig
{

    /**
    * 是否需要access_token
    */
    const NEED_ACCESS_TOKEN = false;

}
?>