<?php
/**
 * 凌云免流管理中心
 * by 天木兮 2018年10月15日
 */
include("../../Data/api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='../Lyun/index.php';</script>");
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>代理管理 - 清空数据</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> <link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="../../assets/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>代理管理 >><small>清空数据</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="form_basic.html#">
                              </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">         
<?php
if($_POST['type']=="user") {//清空代理账号
$dlid=$_POST['id'];
echo '<div class="panel-heading w h"><h3 class="panel-title">清空代理账号结果</h3></div>
<div class="panel-body box">';
$sql=$DB->query("DELETE FROM openvpn WHERE dlid='{$dlid}'");
if($sql){
echo '<div class="box">恭喜亲成功清空该代理所有账号.</div>';
}else{
echo'<div class="box">奥，清空该代理账号失败，请重新尝试.</div>';}
echo '<hr/><a href="./deu_daili.php" class="btn btn-success">返回继续删除</a></div></div>';
}elseif($_POST['type']=="kms") {//清空代理卡密
$dlid=$_POST['id'];
echo '<div class="panel-heading w h"><h3 class="panel-title">清空代理卡密结果</h3></div>
<div class="panel-body box">';
$sql=$DB->query("DELETE FROM auth_kms WHERE daili='{$dlid}'");
if($sql){
echo '<div class="box">恭喜亲成功清空该代理所有卡密.</div>';
}else{
echo'<div class="box">奥，清空该代理卡密失败，请重新尝试.</div>';}
echo '<hr/><a href="./deu_daili.php" class="btn btn-success">返回继续删除</a></div></div>';
}else{
                echo '<form action="./deu_daili.php" method="post" class="form-horizontal">
						    <div class="form-group has-error">
                                <label class="col-sm-3 control-label">删除内容</label>
                             <div class="col-sm-8">
                         <select class="form-control m-b" name="type">';
                   echo '<option value="kms">代理子卡密</option>
			             <option value="user">代理子账号</option>';
                  echo ' </select>
                              </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                          <div class="form-group has-success">
                                <label class="col-sm-3 control-label">代理账号</label>

                                <div class="col-sm-8">
                         <select class="form-control m-b" name="id">';
                     $rs=$DB->query("SELECT * FROM auth_daili");						 
                 while($res = $DB->fetch($rs))							
              echo '<option value="'.$res['id'].'">'.$res['user'].'</option>';
              echo '          </select>
                                </div>
                            </div>
                          <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-8 col-sm-offset-3">
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                                </div>
                            </div>
                        </form>';
}								
?>								
								</div>
                         </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 自定义js -->
    <script src="../../assets/js/content.js?v=1.0.0"></script>

    <!-- iCheck -->
    <script src="../../assets/js/plugins/iCheck/icheck.min.js"></script>

</body>

</html>
