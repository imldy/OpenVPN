-- MySQL dump 10.13  Distrib 5.5.51, for Linux (x86_64)
--
-- Host: localhost    Database: lenged
-- ------------------------------------------------------
-- Server version	5.5.51

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lyj_article`
--

DROP TABLE IF EXISTS `lyj_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lyj_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '无题',
  `content` text NOT NULL,
  `visit_count` int(10) unsigned NOT NULL DEFAULT '0',
  `timeline` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='文章表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lyj_article`
--

LOCK TABLES `lyj_article` WRITE;
/*!40000 ALTER TABLE `lyj_article` DISABLE KEYS */;
INSERT INTO `lyj_article` VALUES (1,1,'联通线路','添加线路内容',0,0);
/*!40000 ALTER TABLE `lyj_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lyj_category`
--

DROP TABLE IF EXISTS `lyj_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lyj_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '默认栏目',
  `description` varchar(255) NOT NULL DEFAULT '栏目简介',
  `sortby` int(5) NOT NULL DEFAULT '0',
  `hidden` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='栏目表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lyj_category`
--

LOCK TABLES `lyj_category` WRITE;
/*!40000 ALTER TABLE `lyj_category` DISABLE KEYS */;
INSERT INTO `lyj_category` VALUES (1,'移动','',1,0),(2,'联通','',2,0),(3,'电信','',3,0);
/*!40000 ALTER TABLE `lyj_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lyj_link`
--

DROP TABLE IF EXISTS `lyj_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lyj_link` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `name` varchar(200) NOT NULL DEFAULT '链接名称',
  `description` varchar(255) NOT NULL DEFAULT '链接简介',
  `url` varchar(255) NOT NULL DEFAULT 'http://',
  `icon` varchar(255) NOT NULL DEFAULT 'http://',
  `sortby` int(5) NOT NULL DEFAULT '0',
  `hidden` int(2) NOT NULL DEFAULT '0',
  `timeline` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='友链表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lyj_link`
--

LOCK TABLES `lyj_link` WRITE;
/*!40000 ALTER TABLE `lyj_link` DISABLE KEYS */;
INSERT INTO `lyj_link` VALUES (2,1,'卡密地址','链接简介','http://baidu.com','.',0,0,1470804616),(3,1,'卡密购买','链接简介','http://www.lenged.cn','.',1,0,1470804640),(4,1,'流控地址','链接简介','http://ip:2468/','.',2,0,1470804683),(5,1,'官方商城','链接简介','http://lenged.cn','.',3,0,1470804714),(6,1,'使用说明','链接简介','http://dd','.',4,0,1470804734),(7,1,'背景图片','链接简介','http://1','.',5,0,1470804751);
/*!40000 ALTER TABLE `lyj_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lyj_setting`
--

DROP TABLE IF EXISTS `lyj_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lyj_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `skey` varchar(100) NOT NULL DEFAULT '要设置的键',
  `sval` varchar(1024) NOT NULL DEFAULT '要设置的值',
  PRIMARY KEY (`id`),
  UNIQUE KEY `skey` (`skey`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='设置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lyj_setting`
--

LOCK TABLES `lyj_setting` WRITE;
/*!40000 ALTER TABLE `lyj_setting` DISABLE KEYS */;
INSERT INTO `lyj_setting` VALUES (1,'contact','1789665003'),(2,'seo_title','key授权+QQ1281259317'),(3,'seo_keywords','http://d.5857.com/htfss_140227/004.jpg'),(4,'seo_description','移动用户今天请更新线路'),(5,'copyright','http://d.5857.com/htfss_140227/004.jpg');
/*!40000 ALTER TABLE `lyj_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lyj_token`
--

DROP TABLE IF EXISTS `lyj_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lyj_token` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `token` varchar(32) NOT NULL,
  `expire_timeline` int(10) NOT NULL,
  `update_timeline` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='ç™»å½•ä»¤ç‰Œè¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lyj_token`
--

LOCK TABLES `lyj_token` WRITE;
/*!40000 ALTER TABLE `lyj_token` DISABLE KEYS */;
INSERT INTO `lyj_token` VALUES (1,1,'9fda638ea1677b070005c07a98b4bd39',1472321068,1469729068),(2,2,'1ade3b90bde227ec3242fa4c65369ad9',1789665003,1789665003);
/*!40000 ALTER TABLE `lyj_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lyj_user`
--

DROP TABLE IF EXISTS `lyj_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lyj_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account` varchar(15) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `nick` varchar(15) NOT NULL,
  `face` varchar(255) DEFAULT NULL,
  `sex` int(2) DEFAULT '0',
  `device_id` varchar(20) NOT NULL,
  `is_forbidden` int(10) NOT NULL DEFAULT '0',
  `is_app` int(2) DEFAULT '0',
  `timeline` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`account`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lyj_user`
--

LOCK TABLES `lyj_user` WRITE;
/*!40000 ALTER TABLE `lyj_user` DISABLE KEYS */;
INSERT INTO `lyj_user` VALUES (1,'admin','e10adc3949ba59abbe56e057f20f883e','传说科技','',1,'1789665003',0,0,0),(2,'zjj','369189fb6b1d00e690a15496240d09d8','传说科技','',1,'1789665003',0,0,0);
/*!40000 ALTER TABLE `lyj_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-08-10 13:21:24
