<?php
    $mod = 'blank';
    include ('../api.inc.php');
    $title = '账号列表';
    include './head.php';
    if ($islogin2 == 1) {
    } else exit ("<script language='javascript'>window.location.href='./login.php';</script>");
    $contid = $DB->count('SELECT count(*) from `lyj_article` WHERE 1') +1;
    $usercategory = $DB->count('SELECT count(*) from `lyj_category` WHERE 1');
?>


<?php
    if ($_POST['type'] == 'update') {
        echo '<div class="panel panel-primary">

<div class="panel-heading"><h3 class="panel-title">修改线路结果</h3></div>

<div class="panel-body">';
        $id = daddslashes($_POST['id']);
        $title = daddslashes($_POST['title']);
        $content = daddslashes($_POST['content']);
        $category_id = daddslashes($_POST['category_id']);
        if (!$DB->get_row("select * from `lyj_article` where `id`='$id' limit 1")) {
            $sql = "insert into `lyj_article` (`id`,`timeline`,`category_id`,`title`,`content`,`visit_count`) values ('{$id
        }
        ','".time() ."','{$category_id
    }
    ','{$title
    }
    ','{$content
    }
    ',0)";
    if ($DB->query($sql)) echo '成功添加一个账号';
    else echo '添加失败：'.$DB->error();
    } else {
        echo "<script>alert('该账号已存在！');history.go(-1);</script>";
    }
    echo '<hr/><a href="./addcontent.php">>>返回继续添加</a><br><a href="./article.php.php">>>返回账号列表</a></div></div>';
    exit;
    }
?>

<section id="content">
<section class="vbox">
<section class="scrollable padder">
<ul class="breadcrumb no-border no-radius b-b b-light pull-in">
<section class="panel panel-default">
              <header class="panel-heading font-bold"> 添加路线 </header>
              <div class="panel-body">

                  <div class="form-group">


          <form action="./addcontent.php?id=<?=$id
?><?php
    echo '" method="post" class="form-horizontal" role="form">
            <div class="">
			  <label class="control-label">选择运营商</label>
				<select name="category_id" class="form-control">
				
<option value="1">移动</option>

<option value="2">联通</option>

<option value="3">电信</option>


</option>



				</select>
            </div><br/>




          <input type="hidden" name="type" value="update" />
          	<div class="input-group">
              <span class="input-group-addon">路线id</span>

			  <input type="text" name="id" value="';
    echo $contid
?><?php
    echo '" class="form-control">
            </div><br/>


          	<div class="input-group">
              <span class="input-group-addon">路线名称</span>
			  <input type="text" name="title" value="" class="form-control">
            </div><br/>





            <div class="form-group">
            	<input type="hidden" name="my" value="config"/>
              <label class="col-sm-2 control-label">路线OPEN</label><br>
			<div class="col-sm-10"><textarea class="form-control" name="content" rows="5" cols="50" required>
</textarea></div>
            </div>







<br/>
            <div class="form-group">
              <div class="col-sm-12"><input type="submit" name="submit" value="添加" class="btn btn-primary form-control"/></div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

';
    include './nav.php';
?>