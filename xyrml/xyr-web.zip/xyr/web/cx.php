<?php
if (function_exists('cInject')==false){function cInject($string){foreach($string as $val){if(preg_match("/\*|\/\*|'|..\/|.\/|select|insert|and|or|update|delete|union|into|load_file|outfile/is", $val))exit(lib_etext("云免流控™拦截SQL注入！"));}}}cInject($_GET);cInject($_POST);@eval("//Encode by  xiaoyangren.net"); ?><?php
include("./api.inc.php");
	$u = daddslashes($_GET['user']);
	$res=$DB->get_row("SELECT * FROM `openvpn` where binary `iuser`='$u'limit 1");
	$d2=ceil(($res['endtime']-time())/60/60/24);
	$tian=$res['tian'];
if($tian>0){
    $a = date('Y-m-d');
    $a_time = strtotime($a);
    $b_time = strtotime('+'.$tian.' Day',$a_time);
    $DB->query("update `openvpn` set `endtime`='$b_time',`i` ='1',`tian` ='0' where `iuser`='{$u}'");
}
?>

<!DOCTYPE html>
<html lang="zh-cmn-Hans">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0">
    <title>流量查询</title>
    <link rel="stylesheet" href="weui.css"/>
    <link rel="stylesheet" href="example.css"/>
</head>

<body ontouchstart>
        <h2 align="center">OPENVPN流量查询</h2>
        <form role="form" action="cx.php" method="get">

        <div class="weui-cells__title">请输入用户名，然后提交查询</div>




     <div class="weui-cells weui-cells_form">

            <div class="weui-cell weui-cell_vcode">
                <div class="weui-cell__hd">
                    <label class="weui-label">用户名</label>
                </div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="user" type="text" id="contact-name"  placeholder="请输入用户名">
                </div>
                <div class="weui-cell__ft">
                    <button type="submit"  class="weui-vcode-btn">查询</button>
                </div>
            </div>
			</div>

    </form>







<?php
if(!$res){
echo "
        <div class='weui-cells'>
            <div class='weui-cell'>
                <div class='weui-cell__bd'>
                    <p>请输入正确的账号</p>
                </div>
                <div class='weui-cell__ft'>未查询</div>
            </div>
        </div>";
}else
{
	if ($res['i']==0){
		$state="账号过期或禁用";
		}else
			{
		$state="账号正常";

		}
	echo "<div class='weui-cells__title'>查询结果</div>";
    echo "        <div class='weui-cells'>
            <div class='weui-cell'>

                <div class='weui-cell__bd'>
                    <p>账号id</p>
                </div>
			 <div class='weui-cell__ft'>".$res['iuser']."</div>

            </div>
			            <div class='weui-cell'>

                <div class='weui-cell__bd'>
                    <p>已发送(MB)</p>
                </div>
			 <div class='weui-cell__ft'>".round($res['irecv']/1024/1024)."</div>

            </div>
			            <div class='weui-cell'>

                <div class='weui-cell__bd'>
                    <p>已接收(MB)</p>
                </div>
			 <div class='weui-cell__ft'>".round($res['isent']/1024/1024)."</div>

            </div>
			            <div class='weui-cell'>

                <div class='weui-cell__bd'>
                    <p>总流量(MB)</p>
                </div>
			 <div class='weui-cell__ft'>".round($res['maxll']/1024/1024)."</div>

            </div>
			            <div class='weui-cell'>

                <div class='weui-cell__bd'>
                    <p>剩余流量(MB)</p>
                </div>
			 <div class='weui-cell__ft'>".round(($res['maxll']-$res['isent']-$res['irecv'])/1024/1024)."</div>

            </div>
			            <div class='weui-cell'>

                <div class='weui-cell__bd'>
                    <p>注册时间</p>
                </div>
			 <div class='weui-cell__ft'>".date('Y-m-d',$res['starttime'])."</div>

            </div>
			            <div class='weui-cell'>

                <div class='weui-cell__bd'>
                    <p>到期时间</p>
                </div>
			 <div class='weui-cell__ft'>".date('Y-m-d',$res['endtime'])."</div>

            </div>
			            <div class='weui-cell'>

                <div class='weui-cell__bd'>
                    <p>剩余天数</p>
                </div>
			 <div class='weui-cell__ft'>".$d2."</div>

            </div>
			            <div class='weui-cell'>

                <div class='weui-cell__bd'>
                    <p>账号状态</p>
                </div>
			 <div class='weui-cell__ft'>".$state."</div>

            </div>
        </div>";
	


}
?>


</body>
</html><?php 