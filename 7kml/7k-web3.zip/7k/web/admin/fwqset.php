<?php
$mod='blank';
include("../api.inc.php");
if($active != 2)exit("Error");
$title='配置服务器';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<!-- Body -->
<body>
        <?php include 'nav.php';?>
		      <section>
         <!-- Page content-->
         <div class="content-wrapper">
            <h3><?php echo $title ?>
               <small>修改配置您的服务器信息</small>
            </h3>



<?php
$row = $DB->get_row("select * from `auth_fwq` where id='$id' limit 1");
if($_POST['type']=="update"){
echo '<div class="alert ';
$fwqid = daddslashes($_POST['fwqid']);
$name = daddslashes($_POST['name']);
$ipport = daddslashes($_POST['ipport']);
  if($DB->query("update `auth_fwq` set `id`='$fwqid',`name`='$name',`ipport`='$ipport' where id='$id'")){
    echo 'alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  修改成功！';
  }else{
    echo 'alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  修改失败！'.$DB->error();
  }
echo '</div>';
echo "<style>#fwqset{display: none;}</style>";
//exit;
}
?>
 			<?php
$id = daddslashes($_GET['id']);
?>
            <div class="row">
               <div class="col-md-12">

					  		                       <div class="panel panel-default">
                        <div class="panel-heading">
						
                           <div class="panel-title">进行服务器编号为 “<?=$id?>” 的配置</div>
                        </div>
                        <div class="panel-body">     
 <div class="panel-body">  
                <form id="fwqset" action="./fwqset.php?id=<?=$id?>" method="post" role="form" class="form-horizontal">
                <input type="hidden" name="type" value="update" />

                  <div class="form-group has-feedback">
				  <label class="text-muted">服务器ID</label>
                     <input id="field-1" name="fwqid" type="text" placeholder="请输入服务器ID" autocomplete="off" required class="form-control" value="<?=$row['id']?>">

                  </div>

                  <div class="form-group has-feedback">
				  <label class="text-muted">服务器名称</label>
                     <input name="name" type="text" placeholder="服务器名称" autocomplete="off" required class="form-control" value="<?=$row['name']?>">

                  </div>
				  
                  <div class="form-group has-feedback">
				  <label class="text-muted">服务器地址</label>
                     <input name="ipport" type="text" placeholder="服务器地址" autocomplete="off" required class="form-control" value="<?=$row['ipport']?>">
                     
                  </div>



                  <div class="form-group">
                    <label class="col-sm-12"></label>
                    <div class="col-sm-9">
                      <button type="submit" type="button" class="btn btn-info btn-block">修改</button>
                    </div>
                  </div>
                  
                </form>

                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>