<?php
    $mod = 'blank';
    include ('../api.inc.php');
    $title = '平台设置';
    include './head.php';
    $rs = $DB->get_row('SELECT * FROM auth_config');
    $yunname = $rs['yunname'];
    $ak = $rs['ak'];
    $dl00 = $rs['dl0'];
    $dl01 = $rs['dl1'];
    $dl02 = $rs['dl2'];
    $dl03 = $rs['dl3'];
    $dl04 = $rs['dl4'];
    $dl05 = $rs['dl5'];
    $dls00 = $rs['dls0'];
    $dls01 = $rs['dls1'];
    $dls02 = $rs['dls2'];
    $dls03 = $rs['dls3'];
    $dls04 = $rs['dls4'];
    $dls05 = $rs['dls5'];
    $qd = $rs['qd'];
    $gg = $rs['gongg'];
    $dllx = $rs['dllx'];
    $ggs = $rs['gonggs'];
    $dldiy = $rs['dldiy'];
    $dltc = $rs['dltc'];
    if ($islogin2 == 1) {
    } else exit ("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<?php
    echo '
<section id="content">
<section class="vbox">
<section class="scrollable padder">
';
    $my = $_POST['my'];
    if ($my == 'config') {
        echo '<div class="panel panel-primary">
<div class="panel-heading w h"><h3 class="panel-title">代理页面设置</h3></div>
<div class="panel-body box">';
        $yunname = $_POST['yunname'];
        $ak = $_POST['ak'];
        $dl00 = $_POST['dl0'];
        $dl01 = $_POST['dl1'];
        $dl02 = $_POST['dl2'];
        $dl03 = $_POST['dl3'];
        $dl04 = $_POST['dl4'];
        $dl05 = $_POST['dl5'];
        $dls00 = $_POST['dls0'];
        $dls01 = $_POST['dls1'];
        $dls02 = $_POST['dls2'];
        $dls03 = $_POST['dls3'];
        $dls04 = $_POST['dls4'];
        $dls05 = $_POST['dls5'];
        $qd = $_POST['qd'];
        $gg = daddslashes($_POST['gongg']);
        $dllx = daddslashes($_POST['dllx']);
        $ggs = daddslashes($_POST['gonggs']);
        $dldiy = $_POST['dldiy'];
        $dltc = $_POST['dltc'];
        $sql = $DB->query("update `auth_config` set  `yunname`='$yunname',`gg`='$gg',`ggs`='$ggs',`activeok`='$ak',`dl1`='$dl01',`dl2`='$dl02',`dl3`='$dl03',`dl4`='$dl04',`dl5`='$dl05',`dl0`='$dl00',`dls1`='$dls01',`dls2`='$dls02',`dls3`='$dls03',`dls4`='$dls04',`dls5`='$dls05',`dls0`='$dls00',`dllx`='$dllx',`qd`='$qd',`dldiy`='$dldiy',`dltc`='$dltc' where 1");
        if ($sql) {
            echo '保存成功！';
        } else {
            echo '保存失败！';
        }
        echo '<hr/><a href="./dlconfig.php">>>返回平台页面设置</a></div></div>';
        exit;
    }
?>
<?php
    echo '

        <div class="panel-body">
		
	
          <form action="./dlconfig.php" method="post" class="form-horizontal" role="form">


            <div class="form-group">
            	<input type="hidden" name="my" value="config"/>
              <label class="col-sm-2 control-label">云免名称</label><br>
			<div class="col-sm-10"><textarea class="form-control" name="yunname" rows="5" cols="10" required>';
    echo $yunname;
?><?php
    echo '</textarea></div>
            </div>

            <div class="form-group">
            	<input type="hidden" name="my" value="config"/>
              <label class="col-sm-2 control-label">代理公告</label><br>
			<div class="col-sm-10"><textarea class="form-control" name="gongg" rows="5" cols="50" required>';
    echo $gongg;
?><?php
    echo '</textarea></div>
            </div>
            <div class="form-group">
            	<input type="hidden" name="my" value="config"/>
              <label class="col-sm-2 control-label">用户公告</label><br>
			<div class="col-sm-10"><textarea class="form-control" name="gonggs" rows="5" cols="50" required>';
    echo $gonggs;
?><?php
    echo '</textarea></div>
            </div>
            <div class="form-group">
              <label class="col-sm-2 control-label">普通用户注册</label><br>
                <div class="col-sm-10"><select name="member_reg" class="form-control">
                ';
    if ($member_reg == 1) {
        echo '<option value="0">开放注册</option><option value="1" selected="selected">关闭开放注册</option>';
    } else {
        echo '<option value="0" selected="selected">开放注册</option><option value="1" >关闭开放注册</option>';
    }
?>
<?php
    echo '              </select></div>
            </div>
			
			<div class="form-group">
            <label class="col-sm-2 control-label">注册默认开通</label><br>
                 <div class="col-sm-10"><select name="ak" class="form-control">
                  ';
    if ($activeok == 1) {
        echo ' <option value="0">默认开通账号</option><option value="1" selected="selected">默认关闭账号</option>';
    } else {
        echo ' <option value="0" selected="selected" >默认开通账号</option><option value="1" >默认关闭账号</option>';
    }
?>
<?php
    echo '              </select></div>
			 </div>

			 
			<div class="form-group">
            <label class="col-sm-2 control-label">代理下载路线</label><br>
                 <div class="col-sm-10"><select name="dllx" class="form-control">
                  ';
    if ($dllx == 1) {
        echo ' <option value="0">开启</option><option value="1" selected="selected">关闭</option>';
    } else {
        echo ' <option value="0" selected="selected" >开启</option><option value="1" >关闭</option>';
    }
?>
<?php
    echo '              </select></div>
			 </div>
			 
			<div class="form-group">
            <label class="col-sm-2 control-label">签到设置</label><br>
                 <div class="col-sm-10"><select name="qd" class="form-control">
                  ';
    if ($qdsql == 1) {
        echo ' <option value="0">开启</option><option value="1" selected="selected">关闭</option>';
    } else {
        echo ' <option value="0" selected="selected" >开启</option><option value="1" >关闭</option>';
    }
?>
<?php
    echo '              </select></div>
			 </div>
			 
			<div class="form-group">
            <label class="col-sm-2 control-label">代理自定义拿货</label><br>
                 <div class="col-sm-10"><select name="dldiy" class="form-control">
                  ';
    if ($dldiy == 1) {
        echo ' <option value="0">开启</option><option value="1" selected="selected">关闭</option>';
    } else {
        echo ' <option value="0" selected="selected" >开启</option><option value="1" >关闭</option>';
    }
?>
<?php
    echo '              </select></div>
			 </div>
			 
			<div class="form-group">
            <label class="col-sm-2 control-label">代理套餐拿货</label><br>
                 <div class="col-sm-10"><select name="dltc" class="form-control">
                  ';
    if ($dltc == 1) {
        echo ' <option value="0">开启</option><option value="1" selected="selected">关闭</option>';
    } else {
        echo ' <option value="0" selected="selected" >开启</option><option value="1" >关闭</option>';
    }
?>
<?php
    echo '              </select></div>
			 </div>
			 
			 <div class="form-group">
             <label class="col-sm-2 control-label">普通代理价格</label>
             	<div class="col-sm-2">时间(元/天):</div>
				<div class="col-sm-3"><input type="text" class="form-control" name="dl0" value="';
    echo $dl0;
?><?php
    echo '"/></div>
             	<div class="col-sm-2">流量(元/GB):</div>
				<div class="col-sm-3"><input type="text" class="form-control" name="dls0" value="';
    echo $dls0;
?><?php
    echo '"/></div>
			 </div>
			 <div class="form-group">
             <label class="col-sm-2 control-label">铜牌代理价格</label>
             	<div class="col-sm-2">时间(元/天):</div>
				<div class="col-sm-3"><input type="text" class="form-control" name="dl1" value="';
    echo $dl1;
?><?php
    echo '"/></div>
             	<div class="col-sm-2">流量(元/GB):</div>
				<div class="col-sm-3"><input type="text" class="form-control" name="dls1" value="';
    echo $dls1;
?><?php
    echo '"/></div>
			 </div>
			 <div class="form-group">
             <label class="col-sm-2 control-label">银牌代理价格</label>
             	<div class="col-sm-2">时间(元/天):</div>
				<div class="col-sm-3"><input type="text" class="form-control" name="dl2" value="';
    echo $dl2;
?><?php
    echo '"/></div>
             	<div class="col-sm-2">流量(元/GB):</div>
				<div class="col-sm-3"><input type="text" class="form-control" name="dls2" value="';
    echo $dls2;
?><?php
    echo '"/></div>
			 </div>
			 <div class="form-group">
             <label class="col-sm-2 control-label">金牌代理价格</label>
             	<div class="col-sm-2">时间(元/天):</div>
				<div class="col-sm-3"><input type="text" class="form-control" name="dl3" value="';
    echo $dl3;
?><?php
    echo '"/></div>
             	<div class="col-sm-2">流量(元/GB):</div>
				<div class="col-sm-3"><input type="text" class="form-control" name="dls3" value="';
    echo $dls3;
?><?php
    echo '"/></div>
			 </div>
			 <div class="form-group">
             <label class="col-sm-2 control-label">钻石代理价格</label>
             	<div class="col-sm-2">时间(元/天):</div>
				<div class="col-sm-3"><input type="text" class="form-control" name="dl4" value="';
    echo $dl4;
?><?php
    echo '"/></div>
             	<div class="col-sm-2">流量(元/GB):</div>
				<div class="col-sm-3"><input type="text" class="form-control" name="dls4" value="';
    echo $dls4;
?><?php
    echo '"/></div>
			 </div>
			 <div class="form-group">
             <label class="col-sm-2 control-label">至尊代理价格</label>
             	<div class="col-sm-2">时间(元/天):</div>
				<div class="col-sm-3"><input type="text" class="form-control" name="dl5" value="';
    echo $dl5;
?><?php
    echo '"/></div>
             	<div class="col-sm-2">流量(元/GB):</div>
				<div class="col-sm-3"><input type="text" class="form-control" name="dls5" value="';
    echo $dls5;
?><?php
    echo '"/></div>
			 </div>
            <input type="submit" value="保存" class="btn btn-primary form-control"/>
          </form>
           <div class="table-responsive">
        <table class="table table-striped">
</table>
        </div>
		<div class="panel-footer">
          <span class="glyphicon glyphicon-info-sign"></span> 管理员在这里可以管理代理页面的公告和代理拿货价格。
        </div>
      </div>
    </div>
  </div>
   
                  
              </div>
            </section>
</section>
</section>

<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a></section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
<div class="wrapper">
	Notification
</div>
</aside>
<!-- end -->
';
    include './nav.php';
?>