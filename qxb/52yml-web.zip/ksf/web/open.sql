-- phpMyAdmin SQL Dump
-- version 4.6.2
-- https://www.phpmyadmin.net/
--
-- Host: 10.249.50.199:5627
-- Generation Time: 2016-07-30 15:17:53
-- 服务器版本： 5.5.24-CDB-2.0.0-log
-- PHP Version: 5.6.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ov`
--

-- --------------------------------------------------------

--
-- 表的结构 `open`
--

CREATE TABLE `open` (
  `id` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mo` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `open`
--

INSERT INTO `open` (`id`, `name`, `mo`) VALUES
('41DDC0CA-579BBAB983D28', 'ceshi', '未输入配置信息!');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
