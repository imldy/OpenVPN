<?php
/**
 * 凌云免流管理中心
 * by 天木兮 2018年10月15日
 */
include("../../Data/api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='../Lyun/index.php';</script>");
// 北京市用户情况
$bjnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='北京市' && `isp`='移动'");
$bjnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='北京市' && `isp`='联通'");
$bjnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='北京市' && `isp`='电信'");
$bjnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='北京市'");
// 天津市用户情况
$tjnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='天津市' && `isp`='移动'");
$tjnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='天津市' && `isp`='联通'");
$tjnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='天津市' && `isp`='电信'");
$tjnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='天津市'");
//上海市用户情况
$shnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='上海市' && `isp`='移动'");
$shnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='上海市' && `isp`='联通'");
$shnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='上海市' && `isp`='电信'");
$shnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='上海市'");
//重庆市用户情况
$cqnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='重庆市' && `isp`='移动'");
$cqnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='重庆市' && `isp`='联通'");
$cqnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='重庆市' && `isp`='电信'");
$cqnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='重庆市'");
//湖南省用户情况
$hnnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='湖南省' && `isp`='移动'");
$hnnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='湖南省' && `isp`='联通'");
$hnnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='湖南省' && `isp`='电信'");
$hnnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='湖南省'");
//湖北省用户情况
$hbnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='湖北省' && `isp`='移动'");
$hbnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='湖北省' && `isp`='联通'");
$hbnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='湖北省' && `isp`='电信'");
$hbnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='湖北省'");
//广东省用户情况
$gdnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='广东省' && `isp`='移动'");
$gdnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='广东省' && `isp`='联通'");
$gdnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='广东省' && `isp`='电信'");
$gdnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='广东省'");
//广西壮族自治区用户情况
$gxnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='广西壮族自治区' && `isp`='移动'");
$gxnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='广西壮族自治区' && `isp`='联通'");
$gxnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='广西壮族自治区' && `isp`='电信'");
$gxnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='广西壮族自治区'");
//四川省用户情况
$scnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='四川省' && `isp`='移动'");
$scnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='四川省' && `isp`='联通'");
$scnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='四川省' && `isp`='电信'");
$scnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='四川省'");
//贵州省用户情况
$gznumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='贵州省' && `isp`='移动'");
$gznumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='贵州省' && `isp`='联通'");
$gznumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='贵州省' && `isp`='电信'");
$gznum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='贵州省'");
//河南省用户情况
$henumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='河南省' && `isp`='移动'");
$henumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='河南省' && `isp`='联通'");
$henumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='河南省' && `isp`='电信'");
$henum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='河南省'");
//河北省用户情况
$hanumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='河北省' && `isp`='移动'");
$hanumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='河北省' && `isp`='联通'");
$hanumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='河北省' && `isp`='电信'");
$hanum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='河北省'");
//山东省用户情况
$sdnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='山东省' && `isp`='移动'");
$sdnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='山东省' && `isp`='联通'");
$sdnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='山东省' && `isp`='电信'");
$sdnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='山东省'");
//山西省用户情况
$sxnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='山西省' && `isp`='移动'");
$sxnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='山西省' && `isp`='联通'");
$sxnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='山西省' && `isp`='电信'");
$sxnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='山西省'");
//江西省用户情况
$jxnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='江西省' && `isp`='移动'");
$jxnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='江西省' && `isp`='联通'");
$jxnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='江西省' && `isp`='电信'");
$jxnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='江西省'");
//江苏省用户情况
$jsnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='江苏省' && `isp`='移动'");
$jsnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='江苏省' && `isp`='联通'");
$jsnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='江苏省' && `isp`='电信'");
$jsnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='江苏省'");
//安徽省用户情况
$ahnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='安徽省' && `isp`='移动'");
$ahnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='安徽省' && `isp`='联通'");
$ahnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='安徽省' && `isp`='电信'");
$ahnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='安徽省'");
//浙江省用户情况
$zjnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='浙江省' && `isp`='移动'");
$zjnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='浙江省' && `isp`='联通'");
$zjnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='浙江省' && `isp`='电信'");
$zjnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='浙江省'");
//福建省用户情况
$fjnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='福建省' && `isp`='移动'");
$fjnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='福建省' && `isp`='联通'");
$fjnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='福建省' && `isp`='电信'");
$fjnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='福建省'");
//海南省用户情况
$hinumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='海南省' && `isp`='移动'");
$hinumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='海南省' && `isp`='联通'");
$hinumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='海南省' && `isp`='电信'");
$hinum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='海南省'");
//云南省用户情况
$ynnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='云南省' && `isp`='移动'");
$ynnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='云南省' && `isp`='联通'");
$ynnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='云南省' && `isp`='电信'");
$ynnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='云南省'");
//辽宁省用户情况
$lnnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='辽宁省' && `isp`='移动'");
$lnnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='辽宁省' && `isp`='联通'");
$lnnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='辽宁省' && `isp`='电信'");
$lnnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='辽宁省'");
//吉林省用户情况
$jlnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='吉林省' && `isp`='移动'");
$jlnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='吉林省' && `isp`='联通'");
$jlnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='吉林省' && `isp`='电信'");
$jlnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='吉林省'");
//黑龙江省用户情况
$hlnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='黑龙江省' && `isp`='移动'");
$hlnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='黑龙江省' && `isp`='联通'");
$hlnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='黑龙江省' && `isp`='电信'");
$hlnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='黑龙江省'");
//陕西省用户情况
$snnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='陕西省' && `isp`='移动'");
$snnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='陕西省' && `isp`='联通'");
$snnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='陕西省' && `isp`='电信'");
$snnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='陕西省'");
//甘肃省用户情况
$gsnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='甘肃省' && `isp`='移动'");
$gsnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='甘肃省' && `isp`='联通'");
$gsnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='甘肃省' && `isp`='电信'");
$gsnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='甘肃省'");
//青海省用户情况
$qhnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='青海省' && `isp`='移动'");
$qhnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='青海省' && `isp`='联通'");
$qhnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='青海省' && `isp`='电信'");
$qhnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='青海省'");
//台湾省用户情况
$twnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='台湾省' && `isp`='移动'");
$twnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='台湾省' && `isp`='联通'");
$twnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='台湾省' && `isp`='电信'");
$twnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='台湾省'");
//宁夏回族自治区用户情况
$nxnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='宁夏回族自治区' && `isp`='移动'");
$nxnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='宁夏回族自治区' && `isp`='联通'");
$nxnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='宁夏回族自治区' && `isp`='电信'");
$nxnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='宁夏回族自治区'");
//新疆维吾尔族自治区用户情况
$xjnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='新疆维吾尔自治区' && `isp`='移动'");
$xjnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='新疆维吾尔自治区' && `isp`='联通'");
$xjnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='新疆维吾尔自治区' && `isp`='电信'");
$xjnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='新疆维吾尔自治区'");
//西藏藏族自治区用户情况
$xznumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='西藏自治区' && `isp`='移动'");
$xznumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='西藏自治区' && `isp`='联通'");
$xznumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='西藏自治区' && `isp`='电信'");
$xznum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='西藏自治区'");
//内蒙古自治区用户情况
$nmnumyd = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='内蒙古自治区' && `isp`='移动'");
$nmnumlt = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='内蒙古自治区' && `isp`='联通'");
$nmnumdx = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='内蒙古自治区' && `isp`='电信'");
$nmnum = $DB->count("SELECT count(*) from `openvpn` WHERE `area`='内蒙古自治区'");
//$max = array(
//		$bjnum,$tjnum,$shnum,$cqnum,$gsnum,$ahnum,$hnnum,
//		$hbnum,$gdnum,$gxnum,$sdnum,$snnum,$hinum,$henum,
//		$hanum,$jxnum,$jsnum,$twnum,$zjnum,$fjnum,$gznum,
//		$scnum,$ynnum,$nxnum,$hlnum,$jlnum,$lnnum,$qhnum,
//		$sxnum,$nmnum,$xjnum,$xznum
//  );
//$pos = max($max);  
$maxnum = $DB->count("SELECT count(*) from `openvpn`");
$qtnum = $maxnum-$bjnum-$tjnum-$shnum-$cqnum-$gsnum-$ahnum-$hnnum-$hbnum-$gdnum-$gxnum-$sdnum-$snnum-$hinum-$henum-$hanum-$jxnum-$jsnum-$twnum-$zjnum-$fjnum-$gznum-$scnum-$ynnum-$nxnum-$hlnum-$jlnum-$lnnum-$qhnum-$sxnum-$nmnum-$xjnum-$xznum;
?>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="renderer" content="webkit">

    <title>高级管理 - 用户分布情况</title>

    <meta name="keywords" content="凌云免流，凌云流控，凌云流量，LY免流，LY流控">
    <meta name="description" content="凌云免流，凌云流控，凌云流量，LY免流，LY流控">
    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
</head>	
<body class="gray-bg">
    <div class="wrapper wrapper-content">
        <div class="row">
            <div class="col-sm-12">
                 <div class="ibox">
                    <div class="ibox-content">
                        <h3><i class="fa fa-users"></i> 平台用户分布情况</h3>
                  <div class="row">
                   <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">北京市</font> 用户情况
					  <br>总人数： <?php echo $bjnum;?> 人
					  <br>中国移动： <?php echo $bjnumyd;?> 人
					<br>中国联通： <?php echo $bjnumlt;?> 人
					  <br> 中国电信： <?php echo $bjnumdx;?> 人
				    	</center>
					</div>
				</div>
		     </div>	
			  <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">天津市</font> 用户情况
					  <br>总人数： <?php echo $tjnum;?> 人
			           <br>中国移动： <?php echo $tjnumyd;?> 人
					<br>中国联通： <?php echo $tjnumlt;?> 人
					  <br> 中国电信： <?php echo $tjnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>	
			<div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">上海市</font> 用户情况
					  <br>总人数： <?php echo $shnum;?> 人
			           <br>中国移动： <?php echo $shnumyd;?> 人
					<br>中国联通： <?php echo $shnumlt;?> 人
					  <br> 中国电信： <?php echo $shnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>	
			<div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">重庆市</font> 用户情况
					  <br>总人数： <?php echo $cqnum;?> 人
			           <br>中国移动： <?php echo $cqnumyd;?> 人
					<br>中国联通： <?php echo $cqnumlt;?> 人
					  <br> 中国电信： <?php echo $cqnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
			<div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">湖南省</font> 用户情况
					  <br>总人数： <?php echo $hnnum;?> 人
			           <br>中国移动： <?php echo $hnnumyd;?> 人
					<br>中国联通： <?php echo $hnnumlt;?> 人
					  <br> 中国电信： <?php echo $hnnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>	
			<div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">湖北省</font> 用户情况
					  <br>总人数： <?php echo $hbnum;?> 人
			           <br>中国移动： <?php echo $hbnumyd;?> 人
					<br>中国联通： <?php echo $hbnumlt;?> 人
					  <br> 中国电信： <?php echo $hbnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
			<div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">广东省</font> 用户情况
					  <br>总人数： <?php echo $gdnum;?> 人
			           <br>中国移动： <?php echo $gdnumyd;?> 人
					<br>中国联通： <?php echo $gdnumlt;?> 人
					  <br> 中国电信： <?php echo $gdnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
			<div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">广西自治区</font> 用户情况
					  <br>总人数： <?php echo $gxnum;?> 人
			           <br>中国移动： <?php echo $gxnumyd;?> 人
					<br>中国联通： <?php echo $gxnumlt;?> 人
					  <br> 中国电信： <?php echo $gxnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
			<div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">四川省</font> 用户情况
					  <br>总人数： <?php echo $scnum;?> 人
			           <br>中国移动： <?php echo $scnumyd;?> 人 
					<br>中国联通： <?php echo $scnumlt;?> 人
					  <br> 中国电信： <?php echo $scnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
           <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">贵州省</font> 用户情况
					  <br>总人数： <?php echo $gznum;?> 人
			           <br>中国移动： <?php echo $gznumyd;?> 人
					<br>中国联通： <?php echo $gznumlt;?> 人
					  <br> 中国电信： <?php echo $gznumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
           <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">河南省</font> 用户情况
					  <br>总人数： <?php echo $henum;?> 人
			           <br>中国移动： <?php echo $henumyd;?> 人
					<br>中国联通： <?php echo $henumlt;?> 人
					  <br> 中国电信： <?php echo $henumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
           <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">河北省</font> 用户情况
					  <br>总人数： <?php echo $hanum;?> 人
			           <br>中国移动： <?php echo $hanumyd;?> 人
					<br>中国联通： <?php echo $hanumlt;?> 人
					  <br> 中国电信： <?php echo $hanumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>	
           <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">山东省</font> 用户情况
					  <br>总人数： <?php echo $sdnum;?> 人
			           <br>中国移动： <?php echo $sdnumyd;?> 人
					<br>中国联通： <?php echo $sdnumlt;?> 人
					  <br> 中国电信： <?php echo $sdnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>	
           <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">山西省</font> 用户情况
					  <br>总人数： <?php echo $sxnum;?> 人
			           <br>中国移动： <?php echo $sxnumyd;?> 人
					<br>中国联通： <?php echo $sxnumlt;?> 人
					  <br> 中国电信： <?php echo $sxnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
              <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">江西省</font> 用户情况
					  <br>总人数： <?php echo $jxnum;?> 人
			           <br>中国移动： <?php echo $jxnumyd;?> 人
					<br>中国联通： <?php echo $jxnumlt;?> 人
					  <br> 中国电信： <?php echo $jxnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
              <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">江苏省</font> 用户情况
					  <br>总人数： <?php echo $jsnum;?> 人
			           <br>中国移动： <?php echo $jsnumyd;?> 人
					<br>中国联通： <?php echo $jsnumlt;?> 人
					  <br> 中国电信： <?php echo $jsnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
              <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">安徽省</font> 用户情况
					  <br>总人数： <?php echo $ahnum;?> 人
			           <br>中国移动： <?php echo $ahnumyd;?> 人
					<br>中国联通： <?php echo $ahnumlt;?> 人
					  <br> 中国电信： <?php echo $ahnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
              <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">浙江省</font> 用户情况
					  <br>总人数： <?php echo $zjnum;?> 人
			           <br>中国移动： <?php echo $zjnumyd;?> 人
					<br>中国联通： <?php echo $zjnumlt;?> 人
					  <br> 中国电信： <?php echo $zjnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
              <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">福建省</font> 用户情况
					  <br>总人数： <?php echo $fjnum;?> 人
			           <br>中国移动： <?php echo $fjnumyd;?> 人
					<br>中国联通： <?php echo $fjnumlt;?> 人
					  <br> 中国电信： <?php echo $fjnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
              <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">海南省</font> 用户情况
					  <br>总人数： <?php echo $hinum;?> 人
			           <br>中国移动： <?php echo $hinumyd;?> 人
					<br>中国联通： <?php echo $hinumlt;?> 人
					  <br> 中国电信： <?php echo $hinumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
              <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">云南省</font> 用户情况
					  <br>总人数： <?php echo $ynnum;?> 人
			           <br>中国移动： <?php echo $ynnumyd;?> 人
					<br>中国联通： <?php echo $ynnumlt;?> 人
					  <br> 中国电信： <?php echo $ynnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
              <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">辽宁省</font> 用户情况
					  <br>总人数： <?php echo $lnnum;?> 人
			           <br>中国移动： <?php echo $lnnumyd;?> 人
					<br>中国联通： <?php echo $lnnumlt;?> 人
					  <br> 中国电信： <?php echo $lnnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
              <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">吉林省</font> 用户情况
					  <br>总人数： <?php echo $jlnum;?> 人
			           <br>中国移动： <?php echo $jlnumyd;?> 人
					<br>中国联通： <?php echo $jlnumlt;?> 人
					  <br> 中国电信： <?php echo $jlnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
              <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">黑龙江省</font> 用户情况
					  <br>总人数： <?php echo $hlnum;?> 人
			           <br>中国移动： <?php echo $hlnumyd;?> 人
					<br>中国联通： <?php echo $hlnumlt;?> 人
					  <br> 中国电信： <?php echo $hlnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
              <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">陕西省</font> 用户情况
					  <br>总人数： <?php echo $snnum;?> 人
			           <br>中国移动： <?php echo $snnumyd;?> 人
					<br>中国联通： <?php echo $snnumlt;?> 人
					  <br> 中国电信： <?php echo $snnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
              <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">甘肃省</font> 用户情况
					  <br>总人数： <?php echo $gsnum;?> 人
			           <br>中国移动： <?php echo $gsnumyd;?> 人
					<br>中国联通： <?php echo $gsnumlt;?> 人
					  <br> 中国电信： <?php echo $gsnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
              <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">青海省</font> 用户情况
					  <br>总人数： <?php echo $qhnum;?> 人
			           <br>中国移动： <?php echo $qhnumyd;?> 人
					<br>中国联通： <?php echo $qhnumlt;?> 人
					  <br> 中国电信： <?php echo $qhnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
			<div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">台湾省</font> 用户情况
					  <br>总人数： <?php echo $twnum;?> 人
			           <br>中国移动： <?php echo $twnumyd;?> 人
					<br>中国联通： <?php echo $twnumlt;?> 人
					  <br> 中国电信： <?php echo $twnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>	
              <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">内蒙古自治区</font> 用户情况
					  <br>总人数： <?php echo $nmnum;?> 人
			           <br>中国移动： <?php echo $nmnumyd;?> 人
					<br>中国联通： <?php echo $nmnumlt;?> 人
					  <br> 中国电信： <?php echo $nmnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
              <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">宁夏自治区</font> 用户情况
					  <br>总人数： <?php echo $nxnum;?> 人
			           <br>中国移动： <?php echo $nxnumyd;?> 人
					<br>中国联通： <?php echo $nxnumlt;?> 人
					  <br> 中国电信： <?php echo $nxnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
              <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">新疆自治区</font> 用户情况
					  <br>总人数： <?php echo $xjnum;?> 人
			           <br>中国移动： <?php echo $xjnumyd;?> 人
					<br>中国联通： <?php echo $xjnumlt;?> 人
					  <br> 中国电信： <?php echo $xjnumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
              <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">西藏自治区</font> 用户情况
					  <br>总人数： <?php echo $xznum;?> 人
			           <br>中国移动： <?php echo $xznumyd;?> 人
					<br>中国联通： <?php echo $xznumlt;?> 人
					  <br> 中国电信： <?php echo $xznumdx;?> 人
				    	</center>
					</div>
				</div>
		    </div>
              <div class="col-sm-2">
                     <div class="ibox">
                      <div class="ibox-content">
			           <center>
			            <font size="3" color="#3399FF">其他地区</font> 用户情况
					  <br>总人数： <?php echo $qtnum;?> 人
				    	</center>
					</div>
				</div>
		    </div>																																																																																																																																																	
		</div>
		<p>PS：其他地区人数代表该用户的从未登陆使用过或是国外用户</p>
		  </div>
                </div>
            </div>
		</div> 			
      </div>
 </body>
</html>