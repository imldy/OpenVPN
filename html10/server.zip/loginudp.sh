#!/bin/sh
user=$username
rp=$password
DB='7788'
DBADMIN='root'
DBPASSWD='roottoor'
host='localhost'
port='3306'
now=`date +%Y-%m-%d\ %k:%M:%S`
[[ $user =~ "delect" ]] || [[ $user =~ "drop" ]] || [[ $user =~ "select" ]] || [[ $user =~ "update" ]] || [[ $user =~ "insert" ]] || [[ $user =~ ";" ]] && exit 1
[[ $rp =~ "delect" ]] || [[ $rp =~ "drop" ]] || [[ $rp =~ "select" ]] || [[ $rp =~ "update" ]] || [[ $rp =~ "insert" ]] || [[ $rp =~ ";" ]] && exit 1
mysql -h$host -P$port -u$DBADMIN -p$DBPASSWD -e "use ${DB};SELECT password FROM user WHERE username='$user';">>/etc/openvpn/log.txt
mysql -h$host -P$port -u$DBADMIN -p$DBPASSWD -e "use ${DB};SELECT active FROM user WHERE username='$user';">>/etc/openvpn/log.txt
mysql -h$host -P$port -u$DBADMIN -p$DBPASSWD -e "use ${DB};update user set creation='${now}',firstlogin='1' WHERE firstlogin='0' AND username='$user';"
pass=$(sed -n 2p /etc/openvpn/log.txt)
i=$(sed -n 4p /etc/openvpn/log.txt)
rm -rf /etc/openvpn/log.txt
if [ “$rp” == “$pass” ] && [ “$i” == “1” ];
then
echo $(date +%Y年%m月%d日%k时%M分) “用户登录成功” “账号:”${username} “密码:”${password}>>/etc/openvpn/login.log
exit 0
else
echo $(date +%Y年%m月%d日%k时%M分) “用户登录失败” “账号:”${username} “密码:”${password}>>/etc/openvpn/login.log
exit 1
fi