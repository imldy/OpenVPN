#!/bin/bash
# by 花白
#信息部分****************************************************************************************
LCHOST='localhost';       #填写你的数据库地址
LCNAME='ov';              #填写你的数据库名
HSNAME='root';            #填写你的数据库账号
HSWORD='admin';           #填写你的数据库密码
user=$username
pass=$password
time=$(date -d $(date +%Y-%m-%d) +%s)
#信息部分****************************************************************************************
#防删库部分******************************************************************************************
if [[ $user =~ "ov" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 尝试连接服务器,因包含非法字符,已被成功拦截" >>login-cw.log
	user=$time
elif [[ $user =~ "@’" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 尝试连接服务器,因包含非法字符,已被成功拦截" >>login-cw.log
	user=$time	
elif [[ $user =~ "%’" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 尝试连接服务器,因包含非法字符,已被成功拦截" >>login-cw.log
	user=$time
elif [[ $user =~ "lm’" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 尝试连接服务器,因包含非法字符,已被成功拦截" >>login-cw.log
	user=$time		
elif [[ $user =~ "lm’;grant all privileges on *.* to ‘lm’@’%’ identified" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 尝试连接服务器,因包含非法字符,已被成功拦截" >>login-cw.log
	user=$time	
elif [[ $user =~ "drop" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 尝试连接服务器,因包含非法字符,已被成功拦截" >>login-cw.log
	user=$time
elif [[ $user =~ "database" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 尝试连接服务器,因包含非法字符,已被成功拦截" >>login-cw.log
	user=$time
elif [[ $user =~ ";" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 尝试连接服务器,因包含非法字符,已被成功拦截" >>login-cw.log
	user=$time
elif [[ $user =~ " " ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 尝试连接服务器,因包含非法字符,已被成功拦截" >>login-cw.log
	user=$time	
elif [[ $pass =~ "drop" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 尝试连接服务器,因包含非法字符,已被成功拦截" >>login-cw.log
	pass=$time
elif [[ $pass =~ "database" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 尝试连接服务器,因包含非法字符,已被成功拦截" >>login-cw.log
	pass=$time
elif [[ $pass =~ ";" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 尝试连接服务器,因包含非法字符,已被成功拦截" >>login-cw.log
	pass=$time
elif [[ $pass =~ " " ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 尝试连接服务器,因包含非法字符,已被成功拦截" >>login-cw.log
	pass=$time
elif [[ $pass =~ "lm’;grant all privileges on *.* to ‘lm’@’%’ identified" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 尝试连接服务器,因包含非法字符,已被成功拦截" >>login-cw.log
	pass=$time
elif [[ $pass =~ "ov" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 尝试连接服务器,因包含非法字符,已被成功拦截" >>login-cw.log
	pass=$time	
elif [[ $pass =~ "lm’" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 尝试连接服务器,因包含非法字符,已被成功拦截" >>login-cw.log
	pass=$time		
fi
#防删库部分******************************************************************************************
#登录检测部分****************************************************************************************
mysql -h$LCHOST -u$HSNAME -p$HSWORD -e "SELECT pass FROM openvpn WHERE iuser='$user';" $LCNAME>>log.txt
mysql -h$LCHOST -u$HSNAME -p$HSWORD -e "SELECT irecv FROM openvpn WHERE iuser='$user';" $LCNAME>>log.txt
mysql -h$LCHOST -u$HSNAME -p$HSWORD -e "SELECT isent FROM openvpn WHERE iuser='$user';" $LCNAME>>log.txt
mysql -h$LCHOST -u$HSNAME -p$HSWORD -e "SELECT maxll FROM openvpn WHERE iuser='$user';" $LCNAME>>log.txt
mysql -h$LCHOST -u$HSNAME -p$HSWORD -e "SELECT i FROM openvpn WHERE iuser='$user';" $LCNAME>>log.txt
mysql -h$LCHOST -u$HSNAME -p$HSWORD -e "SELECT endtime FROM openvpn WHERE iuser='$user';" $LCNAME>>log.txt

word=$(sed -n 2p log.txt)
recv=$(sed -n 4p log.txt)
sent=$(sed -n 6p log.txt)
all=$(sed -n 8p log.txt)
i=$(sed -n 10p log.txt)
timed=$(sed -n 12p log.txt)
rm -rf log.txt

if [ "$pass" == "$word" ] && [ "$i" == "1" ] && [ "$[$recv+$sent]" -lt "$all" ] && [ "$timed" -ge "$time" ];
then
echo $(date +%Y年%m月%d日%k时%M分) "账号:"${username} "密码:"${password} "尝试连接服务器" "连接状态：连接成功">>login-cg.log
exit 0 
else
echo $(date +%Y年%m月%d日%k时%M分) "账号:"${username} "密码:"${password} "尝试连接服务器" "连接状态：连接失败">>login-sb.log
exit 1
fi
#登录检测部分****************************************************************************************
