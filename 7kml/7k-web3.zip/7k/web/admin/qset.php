<?php
$mod='blank';
include("../api.inc.php");
$title='配置用户帐号';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
   <link rel="stylesheet" href="../assets/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css">
<!-- Body -->
<body>
        <?php include 'nav.php';?>
		      <section>
         <!-- Page content-->
         <div class="content-wrapper">
            <h3><?php echo $title ?>
               <small>当前平台所有账户列表.</small>
            </h3>
        
<?php
$user = daddslashes($_GET['user']);
?>
 
            <div class="row">
               <div class="col-md-12">
			   			<div class="panel panel-default">
                        <div class="panel-heading">
                           <div class="panel-title">进行账号 <?=$user?> 的配置</div>
                        </div>
                        <div class="panel-body">



<?php
if(!$user || !$row = $DB->get_row("select * from `openvpn` where iuser='$user' limit 1")){ exit("账号不存在!");}
if($_POST['type']=="update"){
echo '<div class="alert ';
$notes = daddslashes($_POST['notes']);
$fwqid = daddslashes($_POST['fwqid']);
$pass = daddslashes($_POST['pass']);
$maxll = daddslashes($_POST['maxll'])*1024*1024;
$state = daddslashes($_POST['state']);
$endtime = strtotime($_POST['enddate']);
  if($DB->query("update `openvpn` set `pass`='$pass',`maxll`='$maxll',`i`='$state',`endtime`='$endtime',`fwqid`='$fwqid',`notes`='$notes' where iuser='$user'")){
    echo 'alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  修改成功！';
  }else{
    echo 'alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  修改失败！'.$DB->error();
  }
echo '</div>';
echo "<style>#qset{display: none;}</style>";
//exit;
}

$fwqlist=$DB->query("SELECT * FROM auth_fwq");
?>
      

                <form id="qset" action="./qset.php?user=<?=$user?>" method="post" role="form" class="form-horizontal">
                <input type="hidden" name="type" value="update" />

                  <div class="form-group">
                    <label class="col-sm-2 control-label">帐号密码</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="field-1" placeholder="请输入密码" name="pass" value="<?=$row['pass']?>">
                    </div>
                  </div>  

                  <div class="form-group">
                    <label class="col-sm-2 control-label">是否开通</label>
                    <div class="col-sm-9">
                      <select name="state" class="form-control">
                        <option value="0">禁用</option>
                        <option value="1" <?=$row['i']?"selected":''?>>开通</option>
                      </select>
                    </div>
                  </div>  

                  <div class="form-group">
                    <label class="col-sm-2 control-label">开通流量</label>
                    <div class="col-sm-9">
                      <div class="input-group">
                        <input type="text" class="form-control" name="maxll" value="<?=round($row['maxll']/1024/1024)?>">
                        <span class="input-group-addon">MB</span> 
                      </div>
                    </div>
                  </div>

				  
                  <div class="form-group">
                    <label class="col-sm-2 control-label">到期日期</label>
                    
                    <div class="col-sm-9">
                      <div  id="datetimepicker1" class="input-group">
                        <input type="text"  id="datetimepicker1" class="form-control datepicker" name="enddate" value="<?=date('Y/m/d',$row['endtime']);?>">
                        
                        <div class="input-group-addon">
                          <a href="#"><i class="fa fa-calendar"></i></a>
                        </div>
                      </div>
                    </div>
                  </div>

              <!-- <div class="input-group">
              <span class="input-group-addon">使用天数</span>
              <input type="text" name="tian" value="" class="form-control"  autocomplete="off" required>
              </div><br/> -->

                  <div class="form-group">

                    <label class="col-sm-2 control-label">选择服务器</label>
                    <div class="col-sm-9">
                      <select class="form-control" name="fwqid">
                      <?php while($v = $DB->fetch($fwqlist)): ?>
                        <option value="<?php echo $v['id']; ?>"><?php echo $v['name']; ?></option>
                      <?php endwhile; ?>
                      </select>
                    </div>
                      
                  </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label">账户备注</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="field-1" placeholder="请输入备注" name="notes" value="<?=$row['notes']?>">
                    </div>
                  </div>  

                  <div class="form-group">
                    <label class="col-sm-2 control-label"></label>
                    <div class="col-sm-9">
                      <button type="submit" type="button" class="btn btn-info btn-block">修改</button>
                    </div>
                  </div>
                  
                </form>

                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
   <!-- DATETIMEPICKER-->
   <script type="text/javascript" src="../assets/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>
            <?php include("../copy.php");?>