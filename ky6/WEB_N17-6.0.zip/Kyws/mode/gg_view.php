<?php
$db = db('ky_gg');
	$vo = $db->where(array('id'=>$_GET['id']))->order('id DESC')->find();
	$num = db("ky_yd")->where(array('readid'=>$_GET['id']))->getnums();
	if($vo){
		 echo '<div style="margin:10px 10px;"><div class="alert alert-info"><h4>'.$vo['name'].'</h4>'.$vo['content'].'<br><br>
		 <img src="mode/pay/time.jpg" height="12" width="12">&nbsp;'.date("Y/m/d H:i",$vo['time']).'</img>
		 <div style="float:right;width:23%;height:25px;"><h5>'.$num.'人已阅读</h5></div>
		 </div></div>'; 
	}else{
		echo '消息已经删除或者不存在！';
	}
//添加记录
$ydu = db("ky_yd")->where(array('readid'=>$_GET['id'],'username'=>$_GET['username']))->find();
if(!$ydu){
$yd=db("ky_yd")->insert(array('username'=>$_GET['username'],'readid'=>$_GET['id']));
}
