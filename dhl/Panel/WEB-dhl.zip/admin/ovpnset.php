﻿<?php
$mod='blank';
include("../api.inc.php");
$title='账号列表';
include './head.php';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
include './nav.php';
?>


    <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<?php
$user = daddslashes($_GET['ovpn']);
if(!$user || !$row = $DB->get_row("select * from `lyj_article` where id='$user' limit 1")){ exit("配置不存在!");}
if($_POST['type']=="update"){
echo '<div class="panel panel-default">
<div class="panel-heading"><h3 class="panel-title">修改配置结果</h3></div>
<div class="panel-body">';
$title = daddslashes($_POST['title']);
$category_id = daddslashes($_POST['category_id']);
$content = daddslashes($_POST['content']);
	if($DB->query("update `lyj_article` set `title`='$title',`category_id`='$category_id',`content`='$content', `timeline`=NOW() where id='$user'")){
		echo '修改成功！';
	}else{
		echo '修改失败！'.$DB->error();
	}
echo '<hr/><a href="./ovpnlist.php">>>返回配置列表</a></div></div>';
exit;
}
?>

              <header class="panel-heading font-bold">修改线路模式 </header>
              <div class="panel-body">
          <form action="./ovpnset.php?ovpn=<?=$user?>" method="post" class="form-horizontal" role="form">
		            <input type="hidden" name="type" value="update" />
              <div class="form-group"><label>&nbsp;&nbsp;线路名称：</label> <input type="text" value="<?=$row['title']?>" class="form-control" name="title" required="" aria-required="true"></div>
              <div class="form-group"><label>&nbsp;&nbsp;线路分类：</label> <input type="text" value="<?=$row['category_id']?>" class="form-control" name="category_id" required="" aria-required="true"></div>
              <div class="form-group"><label>&nbsp;&nbsp;模式内容：</label>
              <textarea  type="text"  class="form-control"  name="content"  required="" aria-required="true" rows="15" ><?=$row['content']?></textarea>
             </div>
            <br/>
            <input type="submit" value="修改" class="btn btn-primary form-control"/>
          </form>
        </div>
      </div>

  <script src="../datepicker/WdatePicker.js"></script><?php 
