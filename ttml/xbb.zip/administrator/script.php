<?php
    $mod = 'blank';
    include ('../api.inc.php');
    $title = '实时监控';
    if ($islogin2 == 1) {
    } else exit ("<script language='javascript'>window.location.href='./login.php';</script>");
?>



<?php
    require_once ('head.php');
?>
<?php
    echo '<section id="content">
<section class="vbox">
<section class="scrollable padder">
<ul class="breadcrumb no-border no-radius b-b b-light pull-in">
<section class="panel panel-default">
              <header class="panel-heading font-bold"> 实时监控日志 </header>
              <div class="panel-body">
				    
';
    $myfile = fopen('../res/script.log', 'r') || die ('Unable to open file!');
    echo fread($myfile, filesize('../res/script.log'));
    fclose($myfile);
?>
<?php
    echo '					
    </div>
  </div>
                  
                    
                  
              </div>
            </section>
</section>
</section>

<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a></section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
<div class="wrapper">
	Notification
</div>
</aside>
<!-- end -->
';
    include './nav.php';
?>