DROP TABLE IF EXISTS `auth_daili`;
CREATE TABLE IF NOT EXISTS `auth_daili` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `tj_rmb` decimal(11,2) NOT NULL,
  `tj_user` varchar(255) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `rmb` decimal(11,2) NOT NULL DEFAULT '0.00',
  `vip` int(11) DEFAULT NULL,
  `kmlist` int(11) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  `regdate` datetime DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `qq` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `buy` text NOT NULL,
  `buy2` text NOT NULL,
  `income` decimal(11,2) NOT NULL DEFAULT '0.00',
  `adtext` text NOT NULL,
  `adimg` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

DROP TABLE IF EXISTS `auth_kms`;
CREATE TABLE IF NOT EXISTS `auth_kms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kind` tinyint(1) NOT NULL DEFAULT '1',
  `daili` int(11) NOT NULL DEFAULT '0',
  `km` varchar(64) DEFAULT NULL,
  `value` int(11) NOT NULL DEFAULT '0',
  `values` decimal(11,2) DEFAULT NULL,
  `money` decimal(11,2) DEFAULT '0.00',
  `isuse` tinyint(1) DEFAULT '0',
  `user` varchar(50) DEFAULT NULL,
  `usetime` datetime DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `kmtype_id` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `km` (`km`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

DROP TABLE IF EXISTS `auth_log`;
CREATE TABLE IF NOT EXISTS `auth_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) NOT NULL,
  `msg` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

DROP TABLE IF EXISTS `auth_kmtype`;
CREATE TABLE IF NOT EXISTS `auth_kmtype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `days` float NOT NULL,
  `maxll` float NOT NULL,
  `dlid` float NOT NULL,
  `km_rmb` decimal(11,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

DROP TABLE IF EXISTS `auth_openvpn`;
CREATE TABLE IF NOT EXISTS `auth_openvpn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iuser` varchar(16) NOT NULL,
  `isent` bigint(128) DEFAULT '0',
  `irecv` bigint(128) DEFAULT '0',
  `maxll` bigint(128) NOT NULL,
  `pass` varchar(18) NOT NULL,
  `i` int(1) NOT NULL,
  `starttime` varchar(30) DEFAULT NULL,
  `endtime` int(11) DEFAULT '0',
  `dlid` int(11) DEFAULT NULL,
  `fwqid` int(11) DEFAULT '1',
  `notes` varchar(255) DEFAULT NULL,
  `tian` float NOT NULL COMMENT '7k激活使用',
  `qian_date` date NOT NULL,
  `qian_num` float NOT NULL,
  `tj_user` text CHARACTER SET utf8 NOT NULL,
  `tj_ok` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `iuser` (`iuser`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=1 ;

INSERT INTO `admin` (`username`, `password`) VALUES('admin', 'admin');
INSERT INTO `alipay` (`partner`, `alikey`, `url`) VALUES('', '', '');
INSERT INTO `banner` (`img1`, `tit1`, `info1`, `img2`, `tit2`, `info2`, `img3`, `tit3`, `info3`) VALUES
('http://i.niupic.com/images/2016/09/22/s2rWJE.jpg', '超实惠流量冲浪新时代', '抵制高价流量，让你使用专用的流量服务，从而价格远远低于运营商，安全快捷！', 'http://i.niupic.com/images/2016/09/22/QC3qln.jpg', '支持IOS6-IOS9系统', '一次安装永久支持续费，VPN连接100M服务器转接', 'http://i.niupic.com/images/2016/09/22/JHtWio.jpg', '安卓系统完美支持', '操作人性化，流量软件上手很简单，使用仅需简单操作几步');
INSERT INTO `website` (`logo`, `title`, `app1`, `app2`, `qq`, `tel`, `ipinfo`, `appleid1`, `appleps1`, `appleid2`, `appleps2`, `appleid3`, `appleps3`, `and_img1`, `and_img2`, `and_img3`, `and_img4`, `jia1`, `jia2`, `jia3`, `jia4`, `seo`, `peie`) VALUES
('http://i.niupic.com/images/2016/08/05/ZEsqL4.png', '7k™丨全新一代流控管理系统', 'https://www.pgyer.com/', 'http://fir.im/', '123456', '13800138001', '121.41.*.* 浙江省杭州市 阿里巴巴', 'cuod061@icloud.com', 'Dd112211', '1335538902@qq.com', 'Aa20162016', 'hah4073@icloud.com', 'Dd112211', 'http://i.niupic.com/images/2016/08/15/YkoMbx.jpg', 'http://i.niupic.com/images/2016/08/15/BYwMZQ.jpg', 'http://i.niupic.com/images/2016/08/15/Egl15P.jpg', 'http://i.niupic.com/images/2016/08/15/rpb5BX.jpg', '0', '5', '50', '200', '<!-- JiaThis Button BEGIN -->\r\n<script type="text/javascript" src="http://v3.jiathis.com/code/jiathis_r.js?move=0" charset="utf-8"></script>\r\n<!-- JiaThis Button END -->' , '0');