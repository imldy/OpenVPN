<?php
    $mod = 'blank';
    include ('../api.inc.php');
    $title = '运营商管理';
    include './head.php';
    if ($islogin2 == 1) {
    } else exit ("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<?php
    echo '<section id="content">
<section class="vbox">
<section class="scrollable padder">
<ul class="breadcrumb no-border no-radius b-b b-light pull-in">
<section class="panel panel-default">
              <header class="panel-heading font-bold"> 运营商列表 </header>
              <div class="panel-body">
				
';
    $my = isset($_GET['my']) ? $_GET['my'] : null;
    if ($my == 'addyys') {
        $yys = $_POST['yys'];
        $id = $_POST['id'];
        echo '<div class="panel panel-primary">
<div class="panel-heading w h"><h3 class="panel-title">添加运营商</h3></div>
<div class="panel-body box">';
        if (!$DB->get_row("select * from `lyj_category` where `name`='$name' limit 1")) {
            $sql = "insert into `lyj_category` (`id`,`name`,`sortby`) values ('{$id
        }
        ','{$yys
    }
    ','{$id
    }
    ')";
    if ($DB->query($sql)) echo '成功添加一个运营商';
    else echo '添加失败：'.$DB->error();
    } else {
        echo "<script>alert('该运营商已存在！');history.go(-1);</script>";
    }
    echo '<hr/><a href="./addroute.php">>>返回运营商列表</a></div></div>';
    }
    if ($my == 'del') {
        echo '<div class="panel panel-primary">
<div class="panel-heading w h"><h3 class="panel-title">删除运营商</h3></div>
<div class="panel-body box">';
        $id = $_GET['id'];
        $sql = $DB->query("DELETE FROM `lyj_category` WHERE id='$id'");
        if ($sql) {
            echo '删除成功！';
        } else {
            echo '删除失败！';
        }
        echo '<hr/><a href="./addroute.php">>>返回运营商列表</a></div></div>';
    } else {
        if (!empty($_GET['kw'])) {
            $sql = " `name`='{$_GET['kw']
        }
        '";
        $numrows = $DB->count("SELECT count(*) from `lyj_category` WHERE{$sql
    }
    ");
    } else {
        $numrows = $DB->count('SELECT count(*) from `lyj_category` WHERE 1');
        $sql = ' 1';
    }
?>
<?php
    echo '          <form action="./addroute.php?my=addyys" method="post" class="form-inline" role="form">
            <div class="form-group">
              <label>添加运营商</label>
              <input type="text" name="yys" value="运营商名称" class="form-control" required/>
              <input type="text" name="id" value="运营商ID" class="form-control" required/>
            </div>
            <input type="submit" value="添加" class="btn btn-primary form-control"/>
          </form>

<div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">


      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th>ID</th><th>运营商</th><th>管理</th></th></thead>
          <tbody>
';
    $pagesize = 30;
    $pages = intval($numrows/$pagesize);
    if ($numrows%$pagesize) {
        $pages++;
    }
    if (isset($_GET['page'])) {
        $page = intval($_GET['page']);
    } else {
        $page = 1;
    }
    $offset = $pagesize*($page-1);
    $rs = $DB->query("SELECT * FROM `lyj_category` WHERE{$sql
    }
     order by id desc limit $offset,$pagesize");
    while ($res = $DB->fetch($rs)) {
        $str = file_get_contents('http://'.$res['ipport'].'/res/openvpn-status.txt', !1, stream_context_create(array('http'=>array('method'=>'GET', 'timeout'=>1))));
        $onlinenum = (substr_count($str, date('Y')) -1) /2;
        if ($onlinenum<0) $onlinetext = '<span style="color:red;">超时</span>';
    else $onlinetext = '<a href="online.php?id='.$res['id'].'">'.(int)$onlinenum.'</a>';
?>
<tr>
<td><?=$res['id']
?></td>
<td><?=$res['name']
?></td>
<td><a href="./addroute.php?my=del&id=<?=$res['id']
?><?php
    echo "\" class=\"btn btn-xs btn-danger\" onclick=\"if(!confirm('你确实要删除此记录吗？')){return false;}\">删除</a></td>
</tr>

";
    }
?>
<?php
    echo '          </tbody>
        </table>
      </div>
';
    echo '<ul class="pagination">';
    $first = 1;
    $prev = $page-1;
    $next = $page+1;
    $last = $pages;
    if ($page>1) {
        echo '<li><a href="fwqlist.php?page='.$first.$link.'">首页</a></li>';
        echo '<li><a href="fwqlist.php?page='.$prev.$link.'">&laquo;</a></li>';
    } else {
        echo '<li class="disabled"><a>首页</a></li>';
        echo '<li class="disabled"><a>&laquo;</a></li>';
    }
    for ($i = 1;$i<$page;$i++) echo '<li><a href="fwqlist.php?page='.$i.$link.'">'.$i.'</a></li>';
    echo '<li class="disabled"><a>'.$page.'</a></li>';
    for ($i = $page+1;$i <= $pages;$i++) echo '<li><a href="fwqlist.php?page='.$i.$link.'">'.$i.'</a></li>';
    echo '';
    if ($page<$pages) {
        echo '<li><a href="fwqlist.php?page='.$next.$link.'">&raquo;</a></li>';
        echo '<li><a href="fwqlist.php?page='.$last.$link.'">尾页</a></li>';
    } else {
        echo '<li class="disabled"><a>&raquo;</a></li>';
        echo '<li class="disabled"><a>尾页</a></li>';
    }
    echo '</ul>';
    }
?>
<?php
    echo '    </div>
  </div>
                  <div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
                    
                  
              </div>
            </section>
</section>
</section>

<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a></section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
<div class="wrapper">
	Notification
</div>
</aside>
<!-- end -->
';
    include './nav.php';
?>
<?php