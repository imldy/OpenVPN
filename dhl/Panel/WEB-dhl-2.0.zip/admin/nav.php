<?php
 ?>  <nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">导航按钮</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="./">管理中心</a>
      </div><!-- /.navbar-header -->
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
		
          <li>
            <a href="./"><span class="glyphicon glyphicon-home"></span> 首页</a>
          </li>	
		  
		  <li>
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-tasks"></span> 平台管理<b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="../phpmyadmin">数据库管理</a></li>
			  <li><a href="./notcie.php">公告管理</a></li>
			  <li><a href="./log.php">操作记录</a></li>
			  <li><a href="./fwqlist.php">服务器列表</a></li>
			  <li><a href="./addfwq.php">添加服务器</a></li>
            </ul>
          </li>
		  
		  <li>
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span> 账号管理<b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="./qqlist.php">账号列表</a></li>
			  <li><a href="./addqq.php">添加账号</a></li>
			  <li><a href="./pladd.php">批量添加</a></li>
			  <li><a href="./search.php">搜索帐号</a></li>
            </ul>
          </li>
		  
		  <li>
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-usd"></span> 支付管理<b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="./price.php">价格列表</a></li>
			  <li><a href="./addprice.php">添加价格</a></li>
			  <li><a href="./paylog.php">支付记录</a></li>
            </ul>
          </li>
		  
		  <li>
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-paperclip"></span> APP管理<b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="./app.php">APP设置</a></li>
			  <li><a href="./addovpn.php">添加线路</a></li>
			  <li><a href="./ovpnlist.php">线路列表</a></li>
            </ul>
          </li>
		  
		  <li><a href="./login.php?logout"><span class="glyphicon glyphicon-log-out"></span> 退出登陆</a></li>
        </ul>
      </div><!-- /.navbar-collapse -->
    </div><!-- /.container -->
  </nav><!-- /.navbar -->
  <div class="container" style="padding-top:70px;"><?php 