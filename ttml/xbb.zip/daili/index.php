<?php
$mod='blank';
include("../api.inc.php");
$title='代理中心';
include './head.php';
$dlid=$_SESSION['dlid'];
$row = $DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$rs=$DB->get_row("SELECT * FROM auth_config WHERE 1");
$vip=$row['vip'];
$rmb=$row['rmb'];
if($vip==1){
	$dljg=$rs['dl1'];
	$dljgs=$rs['dls1'];
	$v="<font color='#FFB200'>铜牌代理</font>";
}elseif($vip==2){
	$dljg=$rs['dl2'];
	$dljgs=$rs['dls2'];
	$v="<font color='#80FE80'>银牌代理</font>";
}elseif($vip==3){
	$dljg=$rs['dl3'];
	$dljgs=$rs['dls3'];
	$v="<font color='#FEE680'>金牌代理</font>";
}elseif($vip==0){
	$dljg=$rs['dl0'];
	$dljgs=$rs['dls0'];
	$v="<font color='#B26B00'>普通代理</font>";
	//exit("<script language='javascript'>window.location.href='./login.php';</script>");
}elseif($vip==4){
	$dljg=$rs['dl4'];
	$dljgs=$rs['dls4'];
		$v="<font color='#2D006B'>钻石代理</font>";
}elseif($vip==5){
	$dljg=$rs['dl5'];
	$dljgs=$rs['dls5'];
	$v="<font color='red'>至</font><font color='green'>尊</font><font color='#2D006B'>代</font><font color='#E60066'>理</font>";
}
//$v="<font color='red'>VIP$vip</font>";

if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

if($_POST['pass']){
$pass = daddslashes($_POST['pass']);
$newpass = daddslashes($_POST['newpass']);
	if($pass==$res['pass']){
	if($DB->query("update `auth_daili` set `pass` ='$newpass' where `id`='$dlid' and `pass`='$pass' limit 1")){
		exit("<script language='javascript'>alert('密码修改成功！');history.go(-1);</script>");
		
	}else{
		exit("<script language='javascript'>alert('密码修改失败！');history.go(-1);</script>");
	}
	}else{
		exit("<script language='javascript'>alert('旧密码不正确！');history.go(-1);</script>");
}
}
if($_POST['qq']){
$qq = daddslashes($_POST['qq']);
	if($DB->query("update `auth_daili` SET `qq` = '$qq' WHERE `auth_daili`.`id` = $dlid;")){
		exit("<script language='javascript'>alert('QQ绑定成功！');history.go(-1);</script>");
	}else{
		exit("<script language='javascript'>alert('QQ绑定失败！');history.go(-1);</script>");
	}
}

include './nav.php';
?>

<div class="row">
<div class="col-sm-6 col-lg-3">
<a href="javascript:void(0)" class="widget">
<div class="widget-content widget-content-mini text-right clearfix">
<div class="widget-icon pull-left themed-background">
<i class="fa fa-users text-light-op"></i>
</div>
<h2 class="widget-heading h3">
<strong><span><?php echo $_SESSION['dlid'];?></span></strong>
</h2>
<span class="text-muted">代理ID</span>
</div>
</a>
</div>
<div class="col-sm-6 col-lg-3">
<a href="javascript:void(0)" class="widget">
<div class="widget-content widget-content-mini text-right clearfix">
<div class="widget-icon pull-left themed-background-success">
<i class="fa fa-qq text-light-op"></i>
</div>
<h2 class="widget-heading h3 text-success">
<strong><span><?php echo $v;?></span></strong>
</h2>
<span class="text-muted">代理VIP等级</span>
</div>
</a>
</div>
<div class="col-sm-6 col-lg-3">
<a href="javascript:void(0)" class="widget">
<div class="widget-content widget-content-mini text-right clearfix">
<div class="widget-icon pull-left themed-background-warning">
<i class="fa fa-thumbs-up text-light-op"></i>
</div>
<h2 class="widget-heading h3 text-warning">
<strong><?php echo $dljg."元/天 + ".$dljgs."元/GB";?><span></span></strong>
</h2>
<span class="text-muted">代理拿货价格</span>
</div>
</a>
</div>
<div class="col-sm-6 col-lg-3">
<a href="javascript:void(0)" class="widget">
<div class="widget-content widget-content-mini text-right clearfix">
<div class="widget-icon pull-left themed-background-danger">
<i class="fa fa-rebel text-light-op"></i>
</div>
<h2 class="widget-heading h3 text-danger">
<strong><?php echo $rmb."元";?><span></span></strong>
</h2>
<span class="text-muted">账户余额</span>
</div>
</a>
</div>



<div class="col-sm-12 col-md-12 col-lg-6">
			<div class="row">
				<div class="col-md-12">
					<div class="panel">
						<div class="row">
							<div class="col-xs-4">
								<div class="panel-body text-center">
									<a href="./builduser.php" class="btn btn-primary"><em class="fa fa-user"></em><span>提取账号</span></a>
								</div>
							</div>
							<div class="col-xs-4">
								<div class="panel-body text-center">
									<a href="./kmlist.php" class="btn btn-danger"><em class="fa fa-hand-o-right"></em><span>提取卡密</span></a>
								</div>
							</div>
							<div class="col-xs-4">
								<div class="panel-body text-center">
									<a href="./addmoney.php" class="btn btn-success"><em class="fa fa-smile-o"></em><span>用户充值</span></a>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-4">
								<div class="panel-body text-center">
									<a href="../app/dailiapp.apk" class="btn btn-success"><em class="fa fa-thumbs-o-up"></em><span>下载代理</span></a>
								</div>
							</div>
							<div class="col-xs-4">
								<div class="panel-body text-center">
									<a href="../app/app.apk" class="btn btn-warning"><em class="fa fa-star-o"></em><span>下客户端</span></a>
								</div>
							</div>
							<div class="col-xs-4">
								<div class="panel-body text-center">
									<a hrefhttp://shang.qq.com/wpa/qunwpa?idkey=9ef10c84b3bbf95c92110ff487c1861efaca4d4b912b0bc9dd6f420db06a4f74" class="btn btn-primary"><em class="fa fa-hand-o-right"></em><span>加入官方</span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
				
				
<div class="col-sm-5">
<div class="widget">
<div class="widget-content themed-background text-light-op">
<i class="fa fa-fw fa-pencil"></i> <strong>最新公告</strong>
</div>
<div class="panel-body widget">
<p><?php echo $gongg;?></p>
</div>
</div>
</div>
				
				
			</div>
		</div>

<div class="col-lg-6">
<div class="widget">
<div class="widget-content themed-background text-light-op">
<i class="fa fa-fw fa-pencil"></i> <strong>资料修改</strong>
</div>
<div class="widget-content block full">
<div class="ibox-content">
<form action="" role="form" class="form-horizontal" method="post">
<div class="form-group">
<label class="col-lg-3 control-label">ID:</label>
<div class="col-lg-8">
<input type="text" class="form-control" value="<?php echo $_SESSION['dlid'];?>" disabled="disabled">
</div>
</div>
<div class="form-group">
<label class="col-lg-3 control-label">用户名:</label>
<div class="col-lg-8">
<input type="text" class="form-control" value="<?php echo $row['user'];;?>" disabled="disabled">
</div>
</div>
<div class="form-group">
<label class="col-lg-3 control-label">绑定QQ：</label>
<div class="col-lg-8">
<?php 
if(!$row['qq']){	
echo "<input type='text' class='form-control' name='qq' value='' >";
}else{
echo "<input type='text' class='form-control' disabled='disabled' maxlength='12' name='qq' value='".$row['qq']."'>";
}
?>
<span class="help-block m-b-none">所有信息都与此QQ进行绑定，填写后可显示对应头像以及用来找回密码，加入Vip售后群时将以此QQ号进行验证</span>
</div>
</div>

<div class="form-group">
<label class="col-lg-3 control-label">旧密码:</label>
<div class="col-lg-8">
<input type="text" class="form-control" name="pass" placeholder="">
</div>
</div>
<div class="form-group">
<label class="col-lg-3 control-label">新密码:</label>
<div class="col-lg-8">
<input type="text" class="form-control" name="newpass" placeholder="不修改请留空">
</div>
</div>
<div class="form-group">
<div class="col-lg-offset-3 col-lg-8">
<button class="btn btn-sm btn-primary pull-right m-t-n-xs" type="submit">保存修改</button>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
		
		
	</div>			
	</div>

	
	
 
 

</body>
 
</html>