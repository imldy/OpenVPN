#!/bin/sh
user=$username
rp=$password
mysql -hlocalhost -uroot -p123456 -e "use ov;SELECT pass FROM openvpn WHERE iuser='$user';">>log.txt
mysql -hlocalhost -uroot -p123456 -e "use ov;SELECT irecv FROM openvpn WHERE iuser='$user';">>log.txt
mysql -hlocalhost -uroot -p123456 -e "use ov;SELECT isent FROM openvpn WHERE iuser='$user';">>log.txt
mysql -hlocalhost -uroot -p123456 -e "use ov;SELECT maxll FROM openvpn WHERE iuser='$user';">>log.txt
mysql -hlocalhost -uroot -p123456 -e "use ov;SELECT i FROM openvpn WHERE iuser='$user';">>log.txt
mysql -hlocalhost -uroot -p123456 -e "use ov;SELECT endtime FROM openvpn WHERE iuser='$user';">>log.txt
pass=$(sed -n 2p log.txt)
recv=$(sed -n 4p log.txt)
sent=$(sed -n 6p log.txt)
all=$(sed -n 8p log.txt)
i=$(sed -n 10p log.txt)
e=$(sed -n 12p log.txt)
rm -rf log.txt
time=$(date +%s)
#if [ "$rp" == "$pass" ] && [ "$i" == "1" ] && [ "$[$recv+$sent]" -lt "$all" ] && [ "$time" -lt "$e" ];
if [ "$rp" == "$pass" ] && [ "$i" == "1" ] && [ "$[$recv+$sent]" -lt "$all" ] && [ "$time" -lt "$e" ];
then
echo $(date +%Y��%m��%d��%kʱ%M��) "�û���¼�ɹ�" "�˺�:"${username} "����:"${password}>>/home/wwwroot/default/restxt/login.i3log

mysql -hlocalhost -uroot -p123456 -e "use ov;UPDATE openvpn SET tian = '1' WHERE iuser='$user';"

exit 0
else
echo $(date +%Y��%m��%d��%kʱ%M��) "�û���¼ʧ��" "�˺�:"${username} "����:"${password}>>/home/wwwroot/default/restxt/login.i3log
exit 1
fi