<?php
$mod='blank';
include("../api.inc.php");

$u = $_REQUEST['user'];
$p = $_REQUEST['pass'];
$user=$DB->get_row("SELECT * FROM `openvpn` where `iuser`='$u' && `pass`='$p' limit 1");
if(!$user){
echo 0;
}
if($user['maxll']-$user['isent']-$user['irecv']>0 && $user['endtime']>time() && $user['i']==1){
echo 1;
}else{
echo 2;
	}