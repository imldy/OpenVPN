﻿﻿<!DOCTYPE HTML>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <meta name="viewport"
          content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no"/>
    <meta name="MobileOptimized" content="320"/>
    <meta name="author" content="<?php echo $author; ?>"/>
    <meta name="robots" content="none"/>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/mui.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/jquery.js"></script>
    <script type="text/javascript" src="<?php echo $base_url; ?>/views/assets/js/default.js"></script>
    <title><?php echo $title; ?></title>
    <link type="image/x-icon" rel="icon" href="<?php echo $base_url; ?>/favicon.ico"/>
    <link type="image/x-icon" rel="shortcut icon" href="<?php echo $base_url; ?>/favicon.ico"/>
    <link href="<?php echo $base_url; ?>/views/assets/css/mui.min.css" rel="stylesheet"/>
    <link href="<?php echo $base_url; ?>/views/assets/css/default.css" rel="stylesheet"/>
    <style type="text/css">
        html, body {
            height: 100%;
            overflow: hidden;
            background: #FFFFFF;
        }

        .mui-content {
            padding: 10px;
            background: #FFFFFF;
        }

        .mui-table-view:after {
            height: 0;
        }

        .mui-table-view-cell:after {
            left: 1px;
        }

        .mui-input-group .mui-input-row::after {
            left: 0;
        }

        .mui-input-group::before,
        .mui-input-group::after {
            height: 0;
        }

        .mui-btn {
            padding: 5px;
        }
    </style>
</head>

<body>
<noscript class="error">
    很遗憾，由于你的浏览器不支持或禁用了JavaScript，导致无法获得正常体验。
</noscript><header class="mui-bar mui-bar-nav">
    <a class="mui-action-back mui-icon mui-icon-left-nav mui-pull-left" href="javascript:history.back();"></a>

    <h1 class="mui-title"><?php echo $title; ?></h1>
</header>
<div class="mui-content">
    <form method="post" action="./admin.php?c=install" class="mui-input-group">
        <h5>类型：</h5>

        <div class="mui-input-row">
            <input name="db_type" type="radio" value="mysql"/>MySQL
            <input name="db_type" type="radio" value="mysqli" checked="checked"/>MySQLi
        </div>
        <h5>主机：</h5>

        <div class="mui-input-row">
            <input type="text" name="db_host" value="localhost" class="mui-input mui-input-clear"/>
        </div>
        <h5>端口：</h5>

        <div class="mui-input-row">
            <input type="text" name="db_port" value="3306" class="mui-input mui-input-clear"/>
        </div>
        <h5>用户：</h5>

        <div class="mui-input-row">
            <input type="text" name="db_user" value="root" class="mui-input mui-input-clear"/>
        </div>
        <h5>密码：</h5>

        <div class="mui-input-row">
            <input type="password" name="db_pass" value="" class="mui-input mui-input-clear"/>
        </div>
        <h5>库名：</h5>

        <div class="mui-input-row">
            <input type="text" name="db_name" value="" class="mui-input mui-input-clear"/>
        </div>
        <div class="center" style="margin-top: 10px;">
            <input type="submit" style="color: #FF0000;background: #0000BB;" value="安装"/>
        </div>
    </form>
</div><div style="width:100%;background:#FFFFFF;display:block;border-top:1px dotted #CCCCCC;position:fixed;bottom:0;">
    <div class="center">
        <?php echo isset($copyright) ? $copyright : ''; ?>
    </div>
</div>
</body>

</html>
<!-- Created By Template Engineer At 2016/08/08,13:41 -->
