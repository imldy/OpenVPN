﻿<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="renderer" content="webkit">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?=$title?></title>
		<link rel="shortcut icon" href="favicon.ico">
		<link href="./css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
		<link href="./css/font-awesome.min.css?v=4.4.0" rel="stylesheet">
		<link href="./css/animate.min.css" rel="stylesheet">
		<link href="./css/style.min.css?v=4.1.0" rel="stylesheet">
	</head>