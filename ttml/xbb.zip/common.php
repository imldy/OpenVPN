<?php
/**
 * Created by PhpStorm.
 * User: 李金旺
 * Date: 2016/9/27
 * Time: 0:43
 */

if(is_file($_SERVER['DOCUMENT_ROOT'].'/safe/360webscan.php')){
    require_once($_SERVER['DOCUMENT_ROOT'].'/safe/360webscan.php');
}