﻿<head>
<!-- CSS JS文件加载 -->
  <link rel="stylesheet" href="./css/bootstrap.css" type="text/css">
  <link rel="stylesheet" href="./css/toob.css" type="text/css">
     <!-- CSS JS文件结束 -->
		</script>
</head>


 <?php
$line_app_key = ""; $line_app_code = ""; function getvip() { if (getenv("HTTP_CLIENT_IP")) $ip = getenv("HTTP_CLIENT_IP"); else if(getenv("HTTP_X_FORWARDED_FOR")) $ip = getenv("HTTP_X_FORWARDED_FOR"); else if(getenv("REMOTE_ADDR")) $ip = getenv("REMOTE_ADDR"); else $ip = "Unknow"; return $ip; } $app_key = ""; $domain = ""; $regionno = false; if(trim($_GET["s"]) == ""){ if($_SESSION["is_tmp_location"] && $_GET["location"] != "true"){ $region = $_SESSION["region"]; $isp = $_SESSION["isp"]; }else{ $ip = getvip(); $is_location = true; $api_uri = "http://ip.taobao.com/service/getIpInfo.php?ip=$ip"; $json = file_get_contents($api_uri); $arr = json_decode($json,true); if($arr["code"] != "0"){ $ispno = true; } $isp = '中国'.$arr["data"]["isp"]; $region = $arr["data"]["region"]; $ip = getvip(); } }else{ $region = $_GET["s"]; $isp = $_GET["i"]; $_SESSION["region"] = $region; $_SESSION["isp"] = $isp; $_SESSION["is_tmp_location"] = true; } $find = str_replace("省","",$region); $find = str_replace("市","",$find); $find = str_replace("壮族自治区","",$find); $find = str_replace("维吾尔自治区","",$find); $find = str_replace("回族自治区","",$find); $find = str_replace("自治区","",$find); $line_grop = db('line_grop')->where(array("show"=>1))->order('id ASC')->select(); ?>


<!--
<option>北京市</option>
<option>天津市</option>
<option>上海市</option>
<option>重庆市</option>
<option>河北省</option>
<option>山西省</option>
<option>辽宁省</option>
<option>吉林省</option>
<option>黑龙江省</option>
<option>江苏省</option>
<option>浙江省</option>
<option>安徽省</option>
<option>福建省</option>
<option>江西省</option>
<option>山东省</option>
<option>河南省</option>
<option>湖北省</option>
<option>湖南省</option>
<option>广东省</option>
<option>海南省</option>
<option>四川省</option>
<option>贵州省</option>
<option>云南省</option>
<option>陕西省</option>
<option>甘肃省</option>
<option>青海省</option>
<option>台湾省</option>
<option>香港</option>
<option>澳门</option>
-->
<form action="?" method="GET">
<input name="act" value="line" type="hidden">
<input name="app_key" value="<?php echo $_GET["app_key"] ?>" type="hidden">
<input name="username" value="<?php echo $_GET["username"] ?>" type="hidden">
<input name="password" value="<?php echo $_GET["password"] ?>" type="hidden">
 <b>
 &nbsp; &nbsp;<font color="#FF0000">运营商</font> &nbsp;<select name="i">
		<?php
		$i = 1;
		$p = "";
		
		$select_id = $line_grop[0]['id'];
		foreach($line_grop as $vo){
			if(!$ispno){
				if($vo["name"] == $isp){
					$p = 'selected';
					$select_id = $vo["id"];
				}
				echo '<option value="'.$vo["name"].'" '.$p.'>'.$vo["name"].'</option>';
			}else{
				if($i == 1){
					$p = 'selected';
					$select_id = $vo["id"];
				}
				echo '<option value="'.$vo["name"].'" '.$p.'>'.$vo["name"].'</option>';
			}
			$i++;
			$p = "";
		}
		?>
	</select>
    &nbsp;&nbsp<font color="#AEB404">当前搜索地区：</font>
    <span class="label label-warning"><?php echo $region;?></span>
	   </b>
	  <br>
      <b class="pull-left" style="margin-top:8px;">
      &nbsp;&nbsp;&nbsp;<input style=" width:170px; height:30px;" name="s" value="<?php echo $region;?>" placeholder="（支持模糊和城市搜索）"type="text"   /></b>
<b class="pull-right" style="margin-right:12px;margin-top:7px"><input class="btn btn-sm btn-info btn-effect-ripple" type="submit" value="搜索线路" id="go" alt="搜索" title="Search" />
<?php if($LINE != "no_abs"){?>
	  <a target="_blank" style="margin-top:1px;" class="btn btn-sm btn-info btn-effect-ripple" href="http://zyzyml.cn/1.html"> <b>地区线路 </b></a>
	  
	<?php } ?>
	</b>
	<br>
	<br>
	 
</div>
</form>

    <div id="slider" class="swipe">
	
      <ul class="box01_list">
      
				<li class="li_list" style="<?php echo $ss?>">
				<!---->
					<div class="main">
					<ul class="list-group">
					<?php if($is_location){?>
					<center>
							<div class="tip">--=自动定位：<?php echo $find == "" ? "不限地区" : $region?><?php echo $isp  == "" ? "中国移动" : $isp?>=--</div>
						</center>
					<?php  };
					$show = false;
						if(trim($region) == "" || $region == "不限地区"){
							$line = db('line')->where(array('show'=>'1','group'=>$select_id))->order('id DESC')->select();
						}else{
							$show = true;
							if(str_length(urldecode($region)) > 8){
								die("参数过长 len:".str_length(urldecode($region)));
							}
							$line = db('line')->where("`show`=1 AND `group`=:select_id AND (label LIKE '%".$find."%' OR name LIKE '%".$find."%')",array(":select_id"=>$select_id))->order('id DESC')->select();

							$line2 = db('line')->where("`show`=1 AND `group`=:select_id AND (label LIKE '%全国%' OR label LIKE '%通用%' OR label LIKE '%不限地区%' OR `name` LIKE '%全国%' OR `name` LIKE '%通用%' OR `name` LIKE '%不限地区%')",array(":select_id"=>$select_id))->order('id DESC')->select();
						}
						
						if($line){
							foreach($line as $vos){
								?>
                                <div class="col-lg-8 col-md-12 col-lg-offset-2">
                            <div class="panel panel-info" draggable="true">
                                <div class="panel-heading font-bold"><?php echo $vos['name']?><b class="badge bg-info pull-right"><?php echo $vos['type']?></b></div>
                                <div class="panel-body">
                                
                                        
										
                                            <b class="pull-right"><button onclick="addLine('<?php echo $vos['id']?>')" class="btn btn-sm btn-info btn-effect-ripple">安装</button></b>
                                            <span class="ng-binding ng-scope">时间：<span class="label label-info"><?php echo $vos['type']?></span></span>
                                                                                   
                                   <br>
								  <br>
                                      
                                            <b class="pull-right"><button type="button" class="btn btn-default btn-sm" data-toggle="modal" data-target="#myModal" onclick="feedback('<?php echo $vos['name']?>',<?php echo $vos['id']?>)">反馈</button></b>
                                            <span class="ng-binding ng-scope">地区：<?php echo $vos['label']?></span>
                                             <br>&nbsp;                  
							  </div>
                                  </div>
                      </div>
                        
					  <?php 
							}
						}else{
						?>
                      <br>
						<center>
							<div style="color:#ccc;font-size:12px;"><u>暂无地区线路</u></div>
						</center></br>
						<?php
						}
						if($show){
						?>
						<center>
							<div class="tip">--=为您推荐全国线路=--</div>
						</center>
						<?php foreach($line2 as $vos){?>
                      <div class="col-lg-8 col-md-12 col-lg-offset-2">
                            <div class="panel panel-info" draggable="true">
                                <div class="panel-heading font-bold"><?php echo $vos['name']?><b class="badge bg-info pull-right"><?php echo $vos['type']?></b></div>
                                <div class="panel-body">
                                            <b class="pull-right"><button onclick="addLine('<?php echo $vos['id']?>')" class="btn btn-sm btn-info btn-effect-ripple">安装</button></b>
                                            <span class="ng-binding ng-scope">时间：<span class="label label-primary"><?php echo date("Y-m-d", $vos['time']) ;;?></span></span>
                                                                                   
                                   <br>
								  <br>
                                      
                                            <b class="pull-right"><button type="button" class="btn btn-default btn-sm" data-toggle="modal" data-target="#myModal" onclick="feedback('<?php echo $vos['name']?>',<?php echo $vos['id']?>)">反馈</button></b>
                                            <span class="ng-binding ng-scope">地区：<?php echo $vos['label']?></span>
                                             <br>&nbsp;                  
											  </div>
                                                                    </div>
                      </div>
                        
					  <?php 
							}
						}else{
						?>
                      <br>
						<center>
							<div style="color:#ccc;font-size:12px;"><u>暂无地区线路</u></div>
						</center></br>
						<?php
						}
						if($show){
						?>
						<center>
							<div class="tip">--=为您推荐全国线路=--</div>
						</center>
						<?php foreach($line2 as $vos){?>
                      <div class="col-lg-8 col-md-12 col-lg-offset-2">
                            <div class="panel panel-info" draggable="true">
                                <div class="panel-heading font-bold"><?php echo $vos['name']?><b class="badge bg-info pull-right"><?php echo $vos['type']?></b></div>
                                <div class="panel-body">
                                            <b class="pull-right"><button onclick="addLine('<?php echo $vos['id']?>')" class="btn btn-sm btn-info btn-effect-ripple">安装</button></b>
                                            <span class="ng-binding ng-scope">时间：<span class="label label-primary"><?php echo date("Y-m-d", $vos['time']) ;;?></span></span>
                                                                                   
                                   <br>
								  <br>
                                      
                                            <b class="pull-right"><button type="button" class="btn btn-default btn-sm" data-toggle="modal" data-target="#myModal" onclick="feedback('<?php echo $vos['name']?>',<?php echo $vos['id']?>)">反馈</button></b>
                                            <span class="ng-binding ng-scope">地区：<?php echo $vos['label']?></span>
                                             <br>&nbsp;                  
											  </div>
                                                                    </div>
                            
                        </div>
					
					</li></center>
						<?php } } ?>
					</ul>
					<div style="clear:both"></div>
				</div>
			</li>
		<!---->
      </ul>
</div>

<script type="text/javascript">
$(function(){
	$(".gitem").click(function(){
		var n = $(".gitem").index(this);
		$(".gitem a").removeClass("active").eq(n).addClass("active");
		$(".li_list").hide().eq(n).show();
	});
});

</script>

<script>
	var name_tmp = "";
	function addLine(id){
		$.post(
			'getLine.php',
			{
				'id':id,
				'key':'<?php echo $_GET["app_key"] ?>',
				'username':'<?php echo $_GET["username"] ?>',
				'password':'<?php echo $_GET["password"] ?>'
			},function(data){
				if(data.status == 'success'){
					//window.myObj.writeFile('test.ovpn','<?php echo base64_encode(file_get_contents('1.ovpn'))?>','download');
					name_tmp = data.name;
					window.myObj.writeFile(data.name+'.ovpn',data.content,'download');
				}else{
					alert(data.msg);
				}
			},"JSON");

	}
	function cli_sendData(status,type,msg){
		if(type == 'file_w'){
			if(status == 'success'){
				window.myObj.installPro('download/'+name_tmp+'.ovpn');
			}else{
				$('.tip').html("写入文件失败");
			}
		}
	}
	</script>
<center>

<span class="label label-info">欢迎使用</span>&nbsp;&nbsp;<span class="label label-danger">ZY流控</span><br> <br>
<span class="label label-warning">中国移动</span> <span class="label label-success">中国联通</span> <span class="label label-primary">中国电信</span></center>
</div>
	</center>

<?php ?>