<?php
function checkIfActive($string) {
	$array=explode(',',$string);
	$php_self=substr($_SERVER['PHP_SELF'],strrpos($_SERVER['PHP_SELF'],'/')+1);
	$php_self=str_replace('.php','',$php_self);
	if (in_array($php_self,$array)){
		return 'active';
	}else
		return null;
}
?>
<nav class="navbar navbar-inverse" role="navigation">
    <div class="container-fluid">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse"
                data-target="#example-navbar-collapse">
            <span class="sr-only">切换导航</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="#">流量卫士</a>
    </div>
    <div class="collapse navbar-collapse" id="example-navbar-collapse">
        <ul class="nav navbar-nav">
            <li class="<?php echo checkIfActive("admin");  ?>"><a href="admin.php">环境检查</a></li>
            <li class="<?php echo checkIfActive("add_gg");  ?>"><a href="add_gg.php">发布公告</a></li>
            <li class="<?php echo checkIfActive("list_gg");  ?>"><a href="list_gg.php">公告列表</a></li>
            <li class="<?php echo checkIfActive("list_line");  ?>"><a href="list_line.php">线路列表</a></li>
            <li class="<?php echo checkIfActive("add_line");  ?>"><a href="add_line.php">添加线路</a></li>
            <li class="<?php echo checkIfActive("qq_admin");  ?>"><a href="qq_admin.php">高级设置</a></li>
            <li class="<?php echo checkIfActive("qq_admin_daili");  ?>"><a href="qq_admin_daili.php">代理QQ设置</a></li>
            <li class="<?php echo checkIfActive("user");  ?>"><a href="user.php">管理员设置</a></li>
            <li class="<?php echo checkIfActive("count");  ?>"><a href="count.php">使用统计</a></li>
            
        </ul>
    </div>
    </div>
</nav>
