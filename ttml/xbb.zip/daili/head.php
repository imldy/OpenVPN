<!DOCTYPE html>
<!--[if IE 9]>
<html class="no-js lt-ie10"> <![endif]-->
<!--[if gt IE 9]><!-->
<html class="no-js"> <!--<![endif]-->
<head>
 
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>代理中心 - <?php echo $yunname;?>代理中心 - 专业虚拟流量产品交易平台</title>
<meta name="applicable-device" content="pc,mobile">
<meta name="renderer" content="webkit">
<meta http-equiv="Cache-Control" content="no-transform"/>
<meta http-equiv="Cache-Control" content="no-siteapp"/>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">
 
 
<link rel="stylesheet" href="/static/user_style/css/bootstrap.min.css">
 
<link rel="stylesheet" href="/static/user_style/css/plugins.css">
 
<link rel="stylesheet" href="/static/user_style/css/main.css">
 
 
<link rel="stylesheet" href="/static/user_style/css/themes.css">
 
<link rel="stylesheet" type="text/css" href="/static/sweetalert/sweetalert.css"/>
 
<script src="/static/user_style/js/vendor/modernizr-2.8.3.min.js"></script>
<script src="https://www.qqmiaozan.com/static/user_style/js/vendor/jquery-2.2.0.min.js"></script>
<script src="https://www.qqmiaozan.com/static/user_style/js/vendor/bootstrap.min.js"></script>
<script src="https://www.qqmiaozan.com/static/user_style/js/plugins.js"></script>
<script src="https://www.qqmiaozan.com/static/user_style/js/app.js"></script>
<script src="https://www.qqmiaozan.com/static/sweetalert/sweetalert.min.js"></script>

<script src="https://www.qqmiaozan.com/static/app/js_sdk.js"></script>
<script src="https://www.qqmiaozan.com/static/user_style/js/jquery.cookie.min.js"></script>

<script src="https://www.qqmiaozan.com/static/user_style/js/pages/uiWidgets.js"></script>

</head>
<body>
 
<div id="page-wrapper" class="page-loading-off">
 
<div class="preloader">
<div class="inner">
 
<div class="preloader-spinner themed-background hidden-lt-ie10"></div>
 
<h3 class="text-primary visible-lt-ie10"><strong>Loading..</strong></h3>
</div>
</div>