<?php
/**code by ?? 
*???? http://lailailai.me
*/
function customError($errno, $errstr, $errfile, $errline)  
{  
  echo "<b>Error number:</b> [$errno],error on line $errline in $errfile<br />" ;  
  die();  
}  
set_error_handler("customError",E_ERROR);  
$getfilter="'|(and|or)\\b.+?(>|<|=|in|like)|\\/\\*.+?\\*\\/|<\\s*script\\b|\\bEXEC\\b|UNION.+?Select|Update.+?SET|Insert\\s+INTO.+?VALUES|(Select|Delete).+?FROM|(Create|Alter|Drop|TRUNCATE)\\s+(TABLE|DATABASE)" ;  
$postfilter="\\b(and|or)\\b.{1,6}?(=|>|<|\\bin\\b|\\blike\\b)|\\/\\*.+?\\*\\/|<\\s*script\\b|\\bEXEC\\b|UNION.+?Select|Update.+?SET|Insert\\s+INTO.+?VALUES|(Select|Delete).+?FROM|(Create|Alter|Drop|TRUNCATE)\\s+(TABLE|DATABASE)" ;  
$cookiefilter="\\b(and|or)\\b.{1,6}?(=|>|<|\\bin\\b|\\blike\\b)|\\/\\*.+?\\*\\/|<\\s*script\\b|\\bEXEC\\b|UNION.+?Select|Update.+?SET|Insert\\s+INTO.+?VALUES|(Select|Delete).+?FROM|(Create|Alter|Drop|TRUNCATE)\\s+(TABLE|DATABASE)" ;  
function StopAttack($StrFiltKey,$StrFiltValue,$ArrFiltReq){  
if(is_array($StrFiltValue)){  
  $StrFiltValue=implode($StrFiltValue);  
}  
if (preg_match("/".$ArrFiltReq."/is",$StrFiltValue)==1){
    print "Please do not submit illegal parameters!!!" ;
    exit();}    
}
//$ArrPGC=array_merge($_GET,$_POST,$_COOKIE);  
foreach($_GET as $key=>$value){  
  StopAttack($key,$value,$getfilter);  
}  
foreach($_POST as $key=>$value){  
  StopAttack($key,$value,$postfilter);  
}
foreach($_COOKIE as $key=>$value){  
  StopAttack($key,$value,$cookiefilter);  
}
?>