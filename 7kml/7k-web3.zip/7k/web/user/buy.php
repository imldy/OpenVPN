<?php
$mod='blank';
include("../api.inc.php");

$u = daddslashes($_GET['user']);
$p = daddslashes($_GET['pass']);
$res=$DB->get_row("SELECT * FROM `openvpn` where `iuser`='$u' && `pass`='$p' limit 1");
if(!$res){
//	header('location: login.php');
		exit("<script language='javascript'>alert('未正确登录，或用户名或密码不正确！');window.location.href='/user/login.php';</script>");
}

/*获取代理信息*/
$daili_info = $DB->get_row("SELECT * FROM openvpn where `iuser`='{$u}'");
$daili_info_id=$daili_info['dlid'];
if($daili_info_id){
	
}else{
	$daili_info_id=0;
}
//echo "<script language='javascript'>alert('获取代理信息：".$daili_info_id."');</script>";

if($daili_info_id){
	$config_dl = $DB->get_row("SELECT * FROM auth_daili WHERE id='$daili_info_id' limit 1");
	$config_name=$config_dl['name'];//代理姓名
	$config_qq=$config_dl['qq'];
	$config_tel=$config_dl['tel'];
	$config_buy=$config_dl['buy'];//购买链接
	$config_buy2=$config_dl['buy2'];//购买代码
	//echo "<script language='javascript'>alert('获取代理信息：".$config_name."');</script>";
}else{
	$rs=$DB->get_row("SELECT * FROM website where id='$site_id'");
	$config_name=$rs['title'];
	$config_qq=$rs['qq'];
	$config_tel=$rs['tel'];

	$rs2=$DB->get_row("SELECT * FROM auth_config where id='$site_id'");
	$config_buy=$rs2['shopUrl'];
	$config_buy2=$rs2['shopCode'];
}


?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<!-- Body -->
<body>
        <?php include 'nav.php';?>
		      <section>
         <!-- Page content-->
         <div class="content-wrapper">
            <h3><?php echo $title ?>
               <small>请选择合适的套餐</small>
            </h3>

                                         <div class="row">
               <div class="col-md-12">
                      
					  		                       <div class="panel panel-default">
                        <div class="panel-heading">
                           <div class="panel-title"><?php echo $con; ?></div>
                        </div>
                        <div class="panel-body">
					            <div class="container container-md">
								               <div class="row">
               <!-- START PLAN TABLE-->

		                                        <?php

		                                        $rs=$DB->query("SELECT * FROM `kmtype` WHERE `dlid` = '$daili_info_id'");
		                                        //$rs=$DB->query("SELECT * FROM `kmtype`");//读取全部套餐

		                                        while($res = $DB->fetch($rs))
		                                        { ?>


                  <div class="col-md-4">
                     <div class="panel b">
                        <div class="panel-body text-center bb">
							<div class="text-bold"><?=$res['name']?></div>

                        </div>
                        <div class="panel-body">
                                                    <p>
                              <em class="fa fa-check fa-fw text-green mr"></em>
                              <span><?=$res['days']?>天使用时间</span>
                           </p>
                           <p>
                              <em class="fa fa-check fa-fw text-green mr"></em>
                              <span><?=round(($res['maxll'])/1024/1024)?> GB流量</span>
                           </p>
                           <p>
                              <em class="fa fa-check fa-fw text-green mr"></em>
                              <span><?=$res['km_rmb']?> 元</span>
                           </p></div>

		                                        <div class="form-group">

		                                                     <a href="pay.php?id=<?php echo $res['id']?>&user=<?php echo $u?>&pass=<?php echo $p?>" type="submit" class="btn btn-white btn-single btn-block">立即购买</a>
															  </div>
                           <div class="panel-body text-center">
                        </div>
                     </div>
                  </div>              

		                                        <?php }
						/*if($res){
							
						}else{
							echo '<div class="col-sm-12"><div class="alert alert-white">
						                                        <button type="button" class="close">
						                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
											<span class="sr-only">Close</span>
										</button>
										暂无设置套餐！
									</div></div>';
						}*/
		                                        ?>


		                    </div>

                    </div>
                  
                  </div></div>
                    


			<!-- Main Footer -->
			<?php include("../copy.php");?>
