<?php
/**
 * 搜索授权
**/
$mod='blank';
include("../api.inc.php");
$title='套餐管理';
$dlid=$_SESSION['dlid'];
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<!-- Body -->
<body>
        <?php include 'nav.php';?>
		      <section>
         <!-- Page content-->
         <div class="content-wrapper">
            <h3><?php echo $title ?>
               <small>当前平台所有账户列表.</small>
            </h3>
                    
<?php
if($_POST['name']){
echo '';
$name = daddslashes($_POST['name']);
$days = daddslashes($_POST['days']);
$maxll = daddslashes($_POST['maxll'])*1024*1024;
$km_rmb = daddslashes($_POST['km_rmb']);
if(!$DB->get_row("select * from `kmtype` where `name`='$name' limit 1")){
  $sql="insert into `kmtype` (`name`,`days`,`maxll`,`km_rmb`,`dlid`) values ('{$name}','{$days}','{$maxll}','{$km_rmb}','{$dlid}')";
  if($DB->query($sql))
    echo '<div class="alert alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  成功添加一个套餐</div>
                <a href="javascript:history.go(-1)" class="btn btn-secondary btn-icon btn-icon-standalone">
                  <i class="fa fa-edit"></i>
                  <span>继续添加</span>
                </a>
                <a href="kmtype.php" class="btn btn-info btn-icon btn-icon-standalone">
                  <i class="fa fa-list-ol"></i>
                  <span>查看列表</span>
                </a>
                  <style>#addtype{display: none;}</style><br>';
  else
    echo '<div class="alert alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>添加失败：'.$DB->error().'</div>
                <a href="javascript:history.go(-1)" class="btn btn-secondary btn-icon btn-icon-standalone">
                  <i class="fa fa-edit"></i>
                  <span>继续添加</span>
                </a>
                <a href="kmtype.php" class="btn btn-info btn-icon btn-icon-standalone">
                  <i class="fa fa-list-ol"></i>
                  <span>查看列表</span>
                </a>
                <style>#addtype{display: none;}</style><br>';
}else{
  echo "<script>alert('该套餐已存在！');history.go(-1);</script>";
}
echo '';
//exit;
}

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='del'){
echo '<div class="alert';
$id=$_GET['id'];
$sql=$DB->query("DELETE FROM `kmtype` WHERE id='$id'");
if($sql){echo ' alert-success">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除成功！';}
else{echo ' alert-danger">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除失败！';}
echo '</div><style>#addtype{display: none;}</style>';
}

//echo "<script>alert('".$dlid."');</script>";
  $numrows=$DB->count("SELECT count(*) from `kmtype` WHERE `dlid`='$dlid'");
  $sql=" 1";
  $con='平台共有 '.$numrows.' 个套餐';

?>
            <div class="row">
               <div class="col-md-12">
 
					  		                       <div class="panel panel-default">
                        <div class="panel-heading">
                           <div class="panel-title"><?php echo $con; ?></div>
                        </div>
                        <div class="panel-body">


                            <form action="kmtype.php?my=add" method="POST" class="form-inline validate" style="overflow: hidden;">
                              <div class="form-group">
                              <div class="form-group">
                                <input type="text" class="form-control" name="name" placeholder="套餐名称" data-validate="required">
                              </div>
                              <div class="form-group">
                                <input type="text" class="form-control" name="days" placeholder="使用天数" data-validate="required,number,min[1]">
                              </div>
                              <div class="form-group">
                                <input type="text" class="form-control" name="maxll" placeholder="流量（GB）" data-validate="required,number,min[1]">
                              </div>
                              <div class="form-group">
                                <input type="text" class="form-control" name="km_rmb" placeholder="售价" data-validate="required,number,min[1]">
                              </div>
							   <div class="form-group">
                              <button type="submit" class="btn btn-secondary btn-single">添加套餐</button>
                            </div>
                            </form>
          
							<hr /></div></div>

					            <div class="container container-md">
               <!-- START PLAN TABLE-->
               <div class="row">
                                                <?php

                                                $rs=$DB->query("SELECT * FROM `kmtype` WHERE `dlid` = '$dlid'");
                                                while($res = $DB->fetch($rs))
                                                { ?>

                 <div class="col-md-4">
                     <div class="panel b">
                        <div class="panel-body text-center bb">
							<div class="text-bold"><?=$res['name']?></div>
                              <span class="text-xs"><a	class="signup bg-palegreen" href="kmtype.php?my=del&id=<?=$res['id']?>" onclick="if(!confirm('你确实要删除此套餐吗？')){return false;}" "></small></sup>
								删除此套餐</a>	</span>
                           </h3>
                        </div>
                        <div class="panel-body">
                                                    <p>
                              <em class="fa fa-check fa-fw text-green mr"></em>
                              <span><?=$res['days']?>天使用时间</span>
                           </p>
                           <p>
                              <em class="fa fa-check fa-fw text-green mr"></em>
                              <span><?=round(($res['maxll'])/1024/1024)?> GB流量</span>
                           </p>
                           <p>
                              <em class="fa fa-check fa-fw text-green mr"></em>
                              <span><?=$res['km_rmb']?> 元</span>
                           </p>
                            </div>						   
                                                  <form action="kmlist.php?my=add" method="POST" class="form-inline validate">
                                                  <input type="text" class="hide" name="kmtype_id" value="<?=$res['id']?>" data-validate="required,number,min[1]">
                                                  <input type="text" class="hide" name="value" value="<?=$res['days']?>" data-validate="required,number,min[1]">
                                                  <input type="text" class="hide" name="values" value="<?=round(($res['maxll'])/1024/1024)?>" data-validate="required,number,min[1]">
                                                 <div class="form-group">
                                                    <input type="text" class="form-control" name="num" placeholder="开多少张卡？" data-validate="required,number,min[1]">
                                                  </div>
                                                 <div class="form-group">
                                                     <button type="submit" class="btn btn-white btn-single btn-block">生成</button>
                                                  </div>
                                              </form>
                           <div class="panel-body text-center">
                        </div>
                     </div>
                  </div>             


                                                <?php }
                                                ?>


                            </div>
                            
                        </div></div>
                            
                        </div>
                        


             <?php include("../copy.php");?>
             
