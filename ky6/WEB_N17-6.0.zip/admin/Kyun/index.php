<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
$row = $DB->get_row("SELECT * FROM kyun"); 	
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no"/>
    <meta name="author" content="Coderthemes">
    <meta name="keywords" content="快云免流，快云流控，快云流量，NB免流，NB流控">
    <meta name="description" content="快云免流，快云流控，快云流量，NB免流，NB流控">
    <link rel="shortcut icon" href="../img/favicon.ico">

    <title>管理员登录 - <?php echo $row['logo'];?></title>

    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/core.css" rel="stylesheet" type="text/css">
    <link href="css/components.css" rel="stylesheet" type="text/css">
    <link href="css/pages.css" rel="stylesheet" type="text/css">
    <link href="css/responsive.css" rel="stylesheet" type="text/css">

</head>
<body> 


<div class="wrapper-page">
    <div class="panel panel-color panel-primary panel-pages">
        <div class="panel-heading bg-img">
            <div class="bg-overlay"></div>
            <h3 class="text-center m-t-10 text-white"><strong><?php echo $row['logo'];?>管理后台 - 登录</strong> </h3>
        </div>

        <div class="panel-body">
            <form class="form-horizontal m-t-20" action="../index.php" method="post">

                <div class="form-group">
                    <div class="col-xs-12">
                        <input class="form-control input-lg" type="text" required="" name="user" placeholder="请输入管理员账号">
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-xs-12">
                        <input class="form-control input-lg" type="password" required="" name="pass" placeholder="请输入管理员密码">
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-xs-12">
                        <input class="form-control input-lg" type="password" required="" name="twopass" placeholder="请输入本地二级密码">
                    </div>
                </div>

                <div class="form-group text-center m-t-40">
                    <div class="col-xs-12">
                        <button class="btn btn-primary form-control" type="submit">立 即 登 录</button>
                    </div>
                </div>
            </form>
        </div>

    </div>
</div>
</body>
</html>