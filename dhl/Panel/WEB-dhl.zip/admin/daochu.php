<?php
$mod='blank';
include("../api.inc.php");

if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

$date=date("Y-m-d");
$data='';
$rs=$DB->query("SELECT * FROM `openvpn` WHERE 1");
while($row = $DB->fetch($rs))
{
	$data.=$row['iuser'].'----'.$row['pass'].'----'.$row['notes']."\r\n";
}

$file_name='openvpn_'.$date.'_'.time().'.txt';
$file_size=strlen($data);
header("Content-Description: File Transfer");
header("Content-Type:application/force-download");
header("Content-Length: {$file_size}");
header("Content-Disposition:attachment; filename={$file_name}");
echo $data;
?><?php 