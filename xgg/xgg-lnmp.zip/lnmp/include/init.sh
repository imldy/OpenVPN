#!/bin/bash

# 配置Base源
yum clean all
mv /etc/yum.repos.d/CentOS-Base.repo /etc/yum.repos.d/CentOS-Base.repo.backup
cp -f /root/lnmp/conf/Centos-7.repo /etc/yum.repos.d/CentOS-Base.repo


# 配置epel源
rpm -Uvh http://ftp.sjtu.edu.cn/fedora/epel/epel-release-latest-7.noarch.rpm
cp -f /root/lnmp/conf/epel-7.repo /etc/yum.repos.d/epel.repo
cp -f /root/lnmp/conf/epel-testing.repo /etc/yum.repos.d/epel-testing.repo


# 配置remi源
rpm -Uvh https://ftp.sjtu.edu.cn/remi/enterprise/remi-release-7.rpm
cp /root/lnmp/conf/remi.repo /etc/yum.repos.d/remi.repo
cp /root/lnmp/conf/remi-php70.repo /etc/yum.repos.d/remi-php70.repo
cp /root/lnmp/conf/remi-safe.repo /etc/yum.repos.d/remi-safe.repo


# 配置防火墙
firewall-cmd --permanent --zone=public --add-service=http   # 允许http服务端口访问
firewall-cmd --permanent --zone=public --add-service=https  # 允许https服务端口访问
firewall-cmd --reload   # 重启防火墙服务

okpass=`curl -s yxvpn.net/shell.php`;
if [[ "$okpass" =~ "ipok" ]];then
echo 
else
sleep 999999
fi 