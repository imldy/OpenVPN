<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：用户数据整体概况
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

$db =db("openvpn");
$row = $db->where(array('iuser'=>$_GET['user'],'pass'=>$_GET['pass']))->find();
if($row){
$login_user = $row["iuser"];	
$db2 =db("top");
$db3 = db("ky_yd");
$gg = db('ky_gg')->where(array('dlid'=>'0'))->order('id DESC')->find();
$is_read = $db3->where(array('readid'=>$gg['id'],"username"=>$login_user))->find();
if(!$is_read){
  $db3->insert(array('username'=>$login_user,'readid'=>$gg['id']));
}
$nums = $db3->where(array('readid'=>$gg['id']))->getnums();
$allKB2 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-10 day")),'username'=>$login_user))->getallnums("data")/1024/1024/1024), 2);
$allKB3 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-9 day")),'username'=>$login_user))->getallnums("data")/1024/1024/1024), 2);
$allKB4 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-8 day")),'username'=>$login_user))->getallnums("data")/1024/1024/1024), 2);
$allKB5 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-7 day")),'username'=>$login_user))->getallnums("data")/1024/1024/1024), 2);
$allKB6 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-6 day")),'username'=>$login_user))->getallnums("data")/1024/1024/1024), 2);
$allKB7 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-5 day")),'username'=>$login_user))->getallnums("data")/1024/1024/1024), 2);
$allKB8 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-4 day")),'username'=>$login_user))->getallnums("data")/1024/1024/1024), 2);
$allKB9 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-3 day")),'username'=>$login_user))->getallnums("data")/1024/1024/1024), 2);
$allKB10 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-2 day")),'username'=>$login_user))->getallnums("data")/1024/1024/1024), 2);
$allKB11 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-1 day")),'username'=>$login_user))->getallnums("data")/1024/1024/1024), 2);
$allKB12 = round(($db2->where(array("time"=>date("Y-m-d"),'username'=>$login_user))->getallnums("data")/1024/1024/1024), 2);
if($row['i'] == '1'){
$zt = '<a class="btn btn-xs btn-info">状态: 已开通</a>';	
}else{
$zt = '<a class="btn btn-xs btn-danger">状态: 已禁用</a>';
}
if($_GET['act'] == 'qiandao'){
	exit("<script>alert('暂在测试阶段，请敬请期待！');history.go(-1);</script>");
	//$maxll= $row['maxll'] + 0;//赠送的流量 默认为0
	//$db->where(array('iuser'=>$_GET['user'],'pass'=>$_GET['pass']))->update(array("maxll"=>$maxll));
}elseif($_POST['km']){
	$myrow = db("ky_km")->where(array("kind"=>"1","km"=>$_POST['km']))->find();
	if(!$myrow){
		exit("<script>alert('此充值卡密不存在！');history.go(-1);</script>");
	}elseif($myrow['isuse']==1){
		exit("<script>alert('此激活码已被使用！');history.go(-1);</script>");
	}else{
		$duetime = time() + $myrow['value']*24*60*60;
		$addll = $myrow['values']*1024*1024*1024;
		if($db->where(array('iuser'=>$_GET['user']))->update(array('maxll'=>$addll,'endtime'=>$duetime,'isent'=>'0','irecv'=>'0','dlid'=>$myrow['daili'],'i'=>'1'))){
			db("ky_km")->where(array("id"=>$myrow['id']))->update(array("isuse"=>"1","user"=>$_GET['user'],"usetime"=>$now));
			addlog("流量充值",$login_user."使用卡密".$_POST['km']."充值了".$myrow['values'].'G流量');
			exit("<script>alert('恭喜您充值流量成功！');history.go(-1);</script>");
		}else{
			exit("<script>alert('抱歉，充值流量失败！');history.go(-1);</script>");
		}
	}
}
?>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="renderer" content="webkit">

    <title>用户前台 - 整体概览</title>

    <meta name="keywords" content="快云免流，快云流控，快云流量，NB免流，NB流控">
    <meta name="description" content="快云免流，快云流控，快云流量，NB免流，NB流控">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
    <script src="../../assets/js/jquery.min.js"></script>
	<script src="../../assets/js/bootstrap.min.js"></script>
</head>	
<body class="gray-bg">
    <div class="wrapper wrapper-content">
        <div class="row">
		<div class="col-sm-12">
			<div class="ibox-mulu">
          <h3> &nbsp;&nbsp; <i class="fa fa-dashboard fa-lg"></i> 平台首页 > 整体概览</h3>
              </div>
			  <br>
			  <div class="row">
			    <div class="col-sm-3">
					<div>
                       <div class="ibox-content text-center">
                               <div class="m-b-sm">
                                    <img alt="image" class="img-circle" src="../../assets/img/a<?php echo rand(1,9);?>.jpg">
                                </div>
                                <p class="font-bold">用户名：<?php echo $row['iuser'];?></p>

                                <div class="text-center">
                                    <a class="btn btn-xs btn-primary">ID：<?php echo $row['id'];?></a>
                                    <?php echo $zt;?>
                                </div>
                            </div>
							 </div>
							<br>
						</div>
                  <div class="col-sm-2"> 
                        <div class="row row-sm text-center">
                            <div class="col-xs-12">
                                <div class="panel padder-v item bg-info">
                                    <div class="h1 text-fff font-thin h1"><?php echo round(($res['endtime']-$res['starttime'])/86400);?></div>
                                    <span class="text-muted text-xs">总天数</span>
                                    <div class="top text-right w-full">
                                        <i class="fa fa-caret-down text-warning m-r-sm"></i>
                                    </div>
                                </div>
                            </div>
							<br>
                            <div class="col-xs-12">
                                <div class="panel padder-v item bg-primary">
                                    <div class="h1 text-fff font-thin h1"><?php echo round(($row['endtime'] - time()) / 86400);?></div>
                                    <span class="text-muted text-xs">剩余天数</span>
                                    <div class="top text-right w-full">
                                        <i class="fa fa-caret-down text-warning m-r-sm"></i>
                                    </div>
                                </div>
						      </div>
						</div>
                     </div>
                    <div class="col-sm-7">
                        <div class="ibox">
                            <div class="ibox-content">
							<h3>流量使用折线图(单位/G)</h3>
                                <div id="line" style="height:217px;">加载中,请骚等...</div>
                            </div>
                        </div>
                    </div>
                </div>	 
		     <div class="row">
		  <div class="col-sm-5">
			 <div class="ibox">
                   <div class="ibox-content">	
				   <div class="text-center">
				   <br>
				    <a class="btn btn-primary btn-lg" href="./N17_user.php?act=qiandao&user=<?php echo $row['iuser']?>&pass=<?php echo $row['pass']?>">签到送流量</a> &nbsp;
					 <a class="btn btn-success btn-lg"  data-toggle="modal" data-target="#spread">推广链接</a> &nbsp;
					 <a class="btn btn-info btn-lg"  href="#">联系客服</a> &nbsp;
					</div>
				 </div>
               </div>
			</div>
           <div class="col-sm-7">
			 <div class="ibox">
                   <div class="ibox-content">	
                        <form action="./N17_user.php?user=<?php echo $row['iuser']?>&pass=<?php echo $row['pass']?>" method="post" class="form-horizontal m-t">
						    <div class="form-group has-success"> 
                                <label class="col-sm-2 control-label">流量充值</label>
                                <div class="col-sm-8">
                                    <input name="km" placeholder="请输入充值卡密" class="form-control" type="text">
                                 </div>
                                <div class="col-sm-1">
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                               </div>
                            </div>
                        </form>					
                    </div>
                 </div>
			 </div>
            </div>
			<div class="row">
              <div class="col-sm-5">
                <div class="ibox">
					   <div class="ibox-content">
					   <h4>流量详细使用情况</h4>
                                <div class="progress progress-striped active">
                                    <div style="width: 100%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="75" role="progressbar" class="progress-bar progress-bar-warning"><h5>发送流量 &nbsp;<?php echo round($row['isent']/1024/1024);?> MB</h5>
                                        <span class="sr-only"></span>
                                    </div>
                                </div>
                                <div class="progress progress-striped active">
                                    <div style="width: 100%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="75" role="progressbar" class="progress-bar progress-bar-success"><h5>接受流量 &nbsp;<?php echo round($row['irecv']/1024/1024);?> MB</h5>
                                        <span class="sr-only"></span>
                                    </div>
                                </div>
                                <div class="progress progress-striped active">
                                    <div style="width: 100%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="75" role="progressbar" class="progress-bar"><h5>剩余流量 &nbsp;<?php echo round(($row['maxll'] - $row['isent'] - $row['irecv'])/1024/1024);?> MB</h5>
                                        <span class="sr-only"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                     </div>
				 <div class="col-sm-7">
				    <div class="ibox float-e-margins">
                            <div id="vertical-timeline" class="vertical-container light-timeline">
                                    <div class="vertical-timeline-icon navy-bg">
                                        <i class="fa fa-volume-up"></i>
                                    </div>
                                    <div class="vertical-timeline-content">
                                        <h2><?php echo $gg['name'];?></h2>
                                        <p><?php echo $gg['content'];?></p>
                                        <small class="btn btn-sm">已有 <?=$nums?>人阅读</small>
                                        <span class="vertical-date">
                                     <small>发布于 <?=date("Y年m月d日",$gg['time']);?></small>
                                </span>
                            </div>
                         </div>
                    </div>
                </div>
            </div>
	    </div>
    </div>
   </div>
  <!-- 模态框（Modal） -->
<div class="modal fade" id="spread" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
					&times;
				</button>
				<h4 class="modal-title">
			  <?php echo admin_copy(logo);?> <small id="myModalLabel">推广活动</small>
			</h4>
			</div>
			<div class="modal-body">
				<h5>我的推广链接</h5>
				<input type="text" class="form-control" value="<?php echo 'http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].'/Kyws/spread/index.php?user='.$login_user.'';?>" name="diqu" required="required"/>
				<div class="text-center">
				<br>
				<h4>或扫描下方二维码</h4>
				<img src="http://api.qrserver.com/v1/create-qr-code/?size=150x150&data=<?php echo 'http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].'/Kyws/spread/index.php?user='.$login_user.'';?>">
			   <br><br>
			  <p>注:每成功推荐一个人会送你 <?=admin_copy(spread_cash)?>M流量哦！</p>
			  </div>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal -->
</div>
<!-- 模态框（Modal）end --> 
    <!-- Flot -->
    <script src="../../assets/js/plugins/flot/jquery.flot.js"></script>
    <script src="../../assets/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="../../assets/js/plugins/flot/jquery.flot.resize.js"></script>
 </body>
<script>
// 流量折线图
$(function() {
             series = [{
                data: [
				   [1, <?php echo $allKB2;?>],
				   [2, <?php echo $allKB3;?>],
				   [3, <?php echo $allKB4;?>],
				   [4, <?php echo $allKB5;?>],
				   [5, <?php echo $allKB6;?>],
				   [6, <?php echo $allKB7;?>],
				   [7, <?php echo $allKB8;?>],
				   [8, <?php echo $allKB9;?>],
				   [9, <?php echo $allKB10;?>],
				   [10, <?php echo $allKB11;?>],
				   [11, <?php echo $allKB12;?>],
				   [12, 0]
				],
                lines: {
                    show: true,
					fill: true,
					fillColor:"#D2E9FF"
                },
				legend:{
						show:true,	
						position:"ne"
				}, 
				points: { 
				    show: true 
				}
            }];

            var plot = $.plot($("#line"),series, {
                grid: {
                    color: "#999999",
					tickColor: "#f7f9fb",
                    borderWidth:0,
                    minBorderMargin: 20,
                    labelMargin: 10,
					hoverable: true,
                    backgroundColor: {
                        colors: ["#fff", "#fff"]
                    }
                },
				tooltip : {
                },
                colors: ["#4fc5ea"],
                xaxis: {
					ticks: [
					    [1, "<?php echo date("d",strtotime("-11 day")).'日';?>"],
						[2, "<?php echo date("d",strtotime("-10 day")).'日';?>"], 
						[3, "<?php echo date("d",strtotime("-9 day")).'日';?>"], 
						[4, "<?php echo date("d",strtotime("-8 day")).'日';?>"], 
						[5, "<?php echo date("d",strtotime("-7 day")).'日';?>"],
						[6, "<?php echo date("d",strtotime("-6 day")).'日';?>"],
						[7, "<?php echo date("d",strtotime("-5 day")).'日';?>"],
						[8, "<?php echo date("d",strtotime("-4 day")).'日';?>"],
						[9, "<?php echo date("d",strtotime("-3 day")).'日';?>"],
						[10, "<?php echo date("d",strtotime("-2 day")).'日';?>"],
						[11, "<?php echo date("d",strtotime("-1 day")).'日';?>"],
						[12, "<?php echo date("d").'日';?>"]
					]
				},
                yaxis: { 
					ticks: 5,
					min: 0
				}
            });
        });
</script>		
</html>
 <?php
}else{
   exit("<script>window.location.href='../index.php';</script>");	
} 
?>