      <footer>
         <span>&copy; 2016 - <?php
  $rs=$DB->get_row("SELECT * FROM website");
  $webtitle=$rs['title'];
   echo $webtitle
    ?></span>
      </footer>
   </div>
   <script src="../assets/modernizr/modernizr.custom.js"></script>
   <script src="../assets/matchMedia/matchMedia.js"></script>
   <script src="../assets/jquery/dist/jquery.js"></script>
   <script src="../assets/bootstrap/dist/js/bootstrap.js"></script>
   <script src="../assets/jQuery-Storage-API/jquery.storageapi.js"></script>
   <script src="../assets/jquery.easing/js/jquery.easing.js"></script>
   <script src="../assets/animo.js/animo.js"></script>
   <script src="../assets/slimScroll/jquery.slimscroll.min.js"></script>
   <script src="../assets/screenfull/dist/screenfull.js"></script>
   <script src="../assets/jquery-localize-i18n/dist/jquery.localize.js"></script>
   <script src="js/demo/demo-rtl.js"></script>
   <script src="../assets/sparkline/index.js"></script>
   <script src="../assets/Flot/jquery.flot.js"></script>
   <script src="../assets/flot.tooltip/js/jquery.flot.tooltip.min.js"></script>
   <script src="../assets/Flot/jquery.flot.resize.js"></script>
   <script src="../assets/Flot/jquery.flot.pie.js"></script>
   <script src="../assets/Flot/jquery.flot.time.js"></script>
   <script src="../assets/Flot/jquery.flot.categories.js"></script>
   <script src="../assets/flot-spline/js/jquery.flot.spline.min.js"></script>
   <script src="../assets/jquery-classyloader/js/jquery.classyloader.min.js"></script>
   <script src="../assets/moment/min/moment-with-locales.min.js"></script>
   <script src="../assets/skycons/skycons.js"></script>
   <script src="../assets/js/demo/demo-flot.js"></script>
   <script src="../assets/ika.jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
   <script src="../assets/ika.jvectormap/jquery-jvectormap-world-mill-en.js"></script>
   <script src="../assets/ika.jvectormap/jquery-jvectormap-us-mill-en.js"></script>
   <script src="../assets/js/demo/demo-vector-map.js"></script>
   <script src="../assets/js/app.js"></script>
</body>

</html>