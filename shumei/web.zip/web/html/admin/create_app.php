﻿<?php
include('head.php');
include('nav.php');
?>
<script>
window.location.href='https://www.berryphone.club/app/';
</script>
<?php include("footer.php");?>