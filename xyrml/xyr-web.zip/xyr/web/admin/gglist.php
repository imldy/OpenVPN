<?php
$mod = 'blank';
include ("../api.inc.php");
$title = '公告列表';
if ($islogin2 == 1) {
} else
	exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php
	include '../head.php';
?>
<body class="page-body">

    <?php
	include 'set.php';
?>
    
    <div class="page-container">

        <?php
        include 'nav.php';
        ?>
<?php

$my=isset($_GET['my'])?$_GET['my']:null;



 	
?>
        <div class="main-content">
                    
            <?php
						include 'info.php';
					?>

          <div class="page-title" style="margin-bottom: 15px;">
          	
          <div class="title-env">
            <h1 class="title"><?php echo $title ?></h1>
            <p class="description">此处可以查看流量卫士公告列表</p>
          </div>
            <div class="breadcrumb-env">
            
               <ol class="breadcrumb bc-1">
                 <li>
                  <a href="index.php"><i class="fa-home"></i>首页</a>
                </li>
                <li class="active">
                      <strong><?php echo $title ?></strong>
                  </li>
              </ol>
                  
             </div>
           </div>

           			<div class="alert alert-info">
                    	<button type="button" class="close" data-dismiss="alert">
                      		<span aria-hidden="true">×</span>
                      		<span class="sr-only">Close</span>
                    	</button>
                    <strong>提示：</strong> 公告只会在用户登录时、连接时和切换账号时才会显示！
                  </div>
                  
            <div class="row">

            
            <div class="col-sm-12">
<?php           
            if($my=='del'){
echo '<div class="alert';
$id=$_GET['id'];
$sql=$DB->query("DELETE FROM `app_gg` WHERE id='$id'");
if($sql){echo ' alert-success">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除成功！<style>#gglist{display: none;}</style> ';}
else{echo ' alert-danger">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除失败！';}
echo '</div>';
}
?>
            <div id="gglist">
            	<div class="panel panel-default">
            		
            <div class="panel-heading">

                      <h3 class="panel-title">公告列表</h3>
                      
                      <div class="panel-options">
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>                      
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>

                    </div>
                    
                    
                    	<div class="panel-body">
                    		
			<ul class="list-group">
				
	 
    			<?php 
					//SELECT * FROM `app_gg` WHERE 1
					//$db = db('app_gg');
					//$list = SELECT * FROM `app_gg` WHERE 1 ORDER BY id DESC;
					
					//$sql="SELECT * FROM `app_gg` WHERE 1";					
					
					//$list = $sql;
					$list=$DB->query("SELECT * FROM `app_gg` WHERE 1 ORDER BY id DESC");				
				foreach($list as $vo){
				echo '<li class="list-group-item line-id-'.$vo['id'].'">
        		<span class="badge badge-success">'.date('Y/m/d H:i:s',$vo['time']).'</span>
        		公告标题: '.$vo['name'].'<br>
				<button type="button" class="btn btn-xs btn-turquoise" onclick="window.location.href=\'ggset.php?id='.$vo['id'].'\'" style="margin-top: 10px;">编辑</button>&nbsp;';
				echo '<button type="button"  class="btn btn-danger btn-xs" onclick="window.location.href=\'gglist.php?my=del&id='.$vo['id'].'\'"  style="margin-top: 10px;" >删除</button>
   			 	</li>';
		}
	?>
    			
			</ul>

						</div>
                    
                    
                    
                    
                    
              </div>      
			</div>
			</div>
            </div>
   
            <!-- Main Footer -->
            <?php
				include ("../copy.php");
			?>
        </div>
        
        </div>
        
    </div>

    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>


    <!-- Imported scripts on this page -->
    <script src="../assets/js/xenon-widgets.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/globalize.min.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/dx.chartjs.js"></script>
    <script src="../assets/js/toastr/toastr.min.js"></script>


    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html>
<script><?php 