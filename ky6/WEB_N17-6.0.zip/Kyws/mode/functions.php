<?php
include("../../Data/api.inc.php");
$row = $DB->get_row("SELECT * FROM kyun"); 	
function sendMail($to,$title,$content,$logo){

    //引入PHPMailer的核心文件 使用require_once包含避免出现PHPMailer类重复定义的警告
    require_once("class.phpmailer.php"); 
    require_once("class.smtp.php");
	
    //实例化PHPMailer核心类
    $mail = new PHPMailer();

    //使用smtp鉴权方式发送邮件
    $mail->isSMTP();

    //smtp需要鉴权 这个必须是true
    $mail->SMTPAuth=true;

    //链接qq域名邮箱的服务器地址
    $mail->Host = 'smtp.qq.com';

    //设置使用ssl加密方式登录鉴权
    $mail->SMTPSecure = 'ssl';

    //设置ssl连接smtp服务器的远程服务器端口号，以前的默认是25，可选465或587
    $mail->Port = 465;

    //设置发件人的主机域 可有可无 默认为localhost 内容任意，建议使用你的域名
    $mail->Hostname = 'http://lsuyi.cn';

    //设置发送的邮件的编码 可选GB2312 我喜欢utf-8 据说utf8在某些客户端收信下会乱码
    $mail->CharSet = 'UTF-8';

    //设置发件人姓名（昵称） 任意内容，显示在收件人邮件的发件人邮箱地址前的发件人姓名
    $mail->FromName = $logo;

    //作者邮箱登陆账号，已经配置好啦，你可以使用作者的，也可以自己配置哦
    $mail->Username ='fyuewl@qq.com';

    //邮箱登陆授权码，嫌麻烦默认作者的就好哦
    $mail->Password = 'wyirfjuujgnfbhfb';

    //设置发件人邮箱地址 这里填入上述提到的“发件人邮箱”
    $mail->From = 'fyuewl@qq.com';

    //邮件正文是否为html编码 注意此处是一个方法 不再是属性 true或false
    $mail->isHTML(true); 

    //设置收件人邮箱地址 该方法有两个参数 第一个参数为收件人邮箱地址 第二参数为给该地址设置的昵称
    $mail->addAddress($to,$logo);

    //添加该邮件的主题
    $mail->Subject = $title;

    //添加邮件正文 上方将isHTML设置成了true，则可以是完整的html字符串
    $mail->Body = $content;

    if($mail->Send()){  
    
            die(json_encode(array('status'=>'success'))); 
        }   
}
$h=date('G');
if ($h<11){
$s = '早上好';	
}elseif ($h<13){
$s = '中午好';
}elseif ($h<17){
$s = '下午好';
}else{
$s = '晚上好';	
} 
$qq=$_GET['q'];
$u=$_GET['u'];
$code=$_GET['code'];
$biao = $_GET['biao'];
//第一个值为用户邮箱号，第二个值为标题,第三个值为邮箱内容(支持HTML写法)
sendMail(''.$qq.'',''.$row['logo'].'注册验证码','尊敬的'.$u.','.$s.'！<br>你的验证码是：'.$code.'',''.$row[logo].'');
?>
