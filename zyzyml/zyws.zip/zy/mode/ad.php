﻿<?php
$u = $_GET["username"];
$p = $_GET["password"];
$res=db(_openvpn_)->where(array(_iuser_=>$u,_ipass_=>$p))->find();
if(!$res){
	die("登录信息错误");
}
if(isset($_POST['km'])){
	$km = $_POST['km'];
	$myrow=db("auth_kms")->where(array("kind"=>"1","km"=>$km))->find();
	if(!$myrow){
		die('此激活码不存在');
	}elseif($myrow['isuse']==1){
		die('此激活码已被使用');
	}else{
		$duetime = time() + $myrow['value']*24*60*60;
		$addll = $myrow['values']*1024*1024*1024;
		//已到期 清空全部流量
		$update[_maxll_] = $addll;
		$update[_endtime_] = $duetime;
		$update[_isent_] = "0";
		$update[_irecv_] = "0";
		$update["dlid"] = $myrow['daili'];
		$update[_i_] = "1";
		if(db(_openvpn_)->where(array(_iuser_=>$u))->update($update)){
			db("auth_kms")->where(array("id"=>$myrow['id']))->update(array("isuse"=>"1","user"=>$u,"usetime"=>date("Y-m-d H:i:s",time())));
			die('开通成功！');
		}else{
			die('开通失败！');
		}
	}
}
$key = explode("_",$_GET["app_key"]);
?><div class="alert alert-success" style="display:none;margin:0px;" >
		请在此输入您购买的流量卡密。
	</div>
	<div style="margin:10px">
				<div class="form-group">
					<input type="text" class="form-control" name="km" placeholder="请输入激活码卡密">
				</div>
				<button type="submit" class="btn btn-success btn-block cz" onclick="kmcz()">
					充值到我的账户
				</button>
				</a>
		<br />
			
			【使用说明】
			<br />
			* 充值会<span style="color:red">清空剩余流量</span>，并重设为购买的流量。时间将会设置为充值之日起到充值卡指定的日期结束，超出流量无需补交。
			<br>
			
			</div>
			<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link href='css/feature.presenter.1.5.css' rel='stylesheet' type='text/css'>

<script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>

</head>
<body>
<!-- 代码 开始 -->
<div id="test-element"></div>

<script type="text/javascript" src="js/feature.presenter.1.5.min.js"></script>
<script type="text/javascript">
/* 图片地址可以是相对路径或绝对路径；标题和描述可以包含HTML */
var settings = [ {image: 'images/kuadmin1.png', heading: '软件为什么在使用的过程中会发生掉线？', description: '原因一：拨打电话时，网络会自行中断，通话完之后部分手机需要手动重新连接软件。<br />原因二：手机4G信号不稳定，自动切换至2G网络或者无网络区域时会掉线。<br />原因三:部分手机自带一键清理功能，或安装360，手机管家，手机助手等此类软件，请将云流量设置为白名单。'}, 
				{image: 'images/kuadmin2.png', heading: '使用本软件是否可以开热点？', description: '此软件仅限于本手机自己使用，不支持热点分享，开启热点分享的客户，产生的流量费用由本人承担'}, 
				{image: 'images/kuadmin3.png', heading: '如何判断流量软件是否连接正常？', description: '在正常连接的情况下，绝大多数手机左上角会出现小钥匙图标或者VPN的图标，可通过下拉小钥匙VPN查看数据是否连接正常。'}, 
				{image: 'images/kuadmin4.png', heading: '使用软件连接不想怎么办？', description: '如果云流量出现‘tun交互失败’，请一直点连接，如几次后还连不上，可开飞行模式，并彻底关闭云流量，稍等片刻后，关闭飞行模式，重新开启云流量，再继续一直点连接必可连接成功。'}, 
				
				{image: 'images/kuadmin6.png', heading: '使用软件流量为什么会消耗本机流量？', description: '原因一：手机自带的软件在后台运行会消耗少量流量。<br />原因二：在使用过程中如果遇到掉线又重新连接。<br />原因三：如果还不免流，请更换APN接入点，一般是net,更换成wap。'}
				];

var options = {
	circle_radius: 40,
	normal_feature_size: 30,
	highlighted_feature_size: 20,
	top_margin: 15,
	bottom_margin: 15,
	spacing: 12,
	min_padding: 0,
	heading_font_size: 10,
	description_font_size: 9,
	type: 'image'
};

var fp = new FeaturePresenter($("#test-element"), settings, options);
fp.createPresenter();
</script>
<!-- 代码 结束 -->
</body>
<hr>
</a>
<style>
    .btn{width:340px;}
</style>

		
 <script>
 var old_html = "";
 function kmcz(){
	 if($("[name=km]").val() == ""){
		 $(".alert").html("卡密不能为空").show();
	 }else{
		 old_html = $(".cz").html();
		 $(".cz").html("处理中...");
		 $.post("?act=Shop&username=<?php echo $_GET['username']?>&password=<?php echo $_GET['password']?>&app_key=<?php echo $_GET['app_key']?>",{
			 "km":$("[name=km]").val()
		 },function(data){
			 $(".cz").html(old_html);
			  $(".alert").show();
			  $(".alert").html(data);
		 })
	 }
 }
 </script>