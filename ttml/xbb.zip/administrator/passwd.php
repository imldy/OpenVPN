<?php
    $mod = 'blank';
    include ('../api.inc.php');
    $title = '修改密码';
    if ($islogin2 == 1) {
    } else exit ("<script language='javascript'>window.location.href='./login.php';</script>");
    include './head.php';
    if ($_POST['adminuser']) {
        $adminuser = daddslashes($_POST['adminuser']);
        $newpasswd = md5(trim($_POST['newpasswd']));
        if ($DB->query("update `admin` set `password` ='$newpasswd',`username` ='$adminuser' limit 1")) {
            echo "<script language='javascript'>alert('修改成功，请重新登录...')</script>";
            echo "<script language='javascript'>window.location.href='./index.php'</script>";
        } else {
            exit ("<script language='javascript'>alert('密码修改失败！');history.go(-1);</script>");
        }
    }
?>
<?php
    echo '<section id="content">
<section class="vbox">
<section class="scrollable padder">
<ul class="breadcrumb no-border no-radius b-b b-light pull-in">
<section class="panel panel-default">
              <header class="panel-heading font-bold"> 修改管理员账号密码 </header>
    <div class="panel-body">
		<form action="" method="post" class="form-horizontal">
   			<div class="form-group">
      			<label for="firstname" class="col-sm-1 control-label">新账号</label>
	      		<div class="col-sm-5">
	         		<input type="text" class="form-control" name="adminuser" placeholder="请输入新管理员账号">
	      		</div>
   			</div>
		   <div class="form-group">
		      <label for="lastname" class="col-sm-1 control-label">新密码</label>
		      <div class="col-sm-5">
		         <input type="password" class="form-control" name="newpasswd" placeholder="请输入新管理员密码">
		      </div>
		   </div>
		   <div class="form-group">
		      <div class="col-sm-offset-1 col-sm-10">
		         <button type="submit" class="btn btn-default">修改</button>
		      </div>
		   </div>
	</form>  


    </div>
</section>
</section>
</section>
</section>
<!-- end -->

';
    include './nav.php';
?>