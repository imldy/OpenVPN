﻿<?php
$mod='blank';
$title = "叮咚云控系统";
include('head.php');
include('nav.php');
?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="charset" content="utf-8">
<meta content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" name="viewport">
<title><?php echo $sitetitle; ?></title>
<link href="css/style.min2.css?v=4.0.0" rel="stylesheet">

        <div class="static-content-wrapper">
          <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
<!-- 引入封装了failback的接口--initGeetest -->



<?php







$appfile="../app_api/登陆.txt"; 
$appconn=file_get_contents($appfile); 
$appconn=str_replace("rn","<br/>",file_get_contents($appfile)); 

$app1file="../app_api/界面.txt"; 
$app1conn=file_get_contents($app1file); 
$app1conn=str_replace("rn","<br/>",file_get_contents($app1file)); 



if($_GET["type"]=="app"){


$myfile = fopen("../app_api/登陆.txt", "w") or die("Unable to open file!");
fwrite($myfile, $_POST["appcontent"]);
fclose($myfile);
echo "<script language=JavaScript>history.go(-1);location.reload();</script>";

}else if($_GET["type"]=="app1"){
	
	
	$myfile = fopen("../app_api/界面.txt", "w") or die("Unable to open file!");
fwrite($myfile, $_POST["app1content"]);
fclose($myfile);
echo "<script language=JavaScript>history.go(-1);location.reload();</script>";
	
}else{
	
}



?>
								</div>
<section class="panel panel-default">
              <header class="panel-heading font-bold">APP登陆界面公告</header>
              <div class="panel-body">
          <form action="cloudgg.php?type=app" method="post" class="form-horizontal" role="form">
              <div class="form-group"><label>&nbsp;&nbsp;公告内容：</label>
              <textarea class="form-control diff-textarea" placeholder="输入公告内容" name="appcontent" rows="6"><?php echo $appconn; ?></textarea>
             </div>
            <input type="submit" value="保存" class="btn btn-info btn-block">
          </form>
        </div>
                    
                  
                  <div class="form-group">
              </div>
            </section>
			
			
			<section class="panel panel-default">
              <header class="panel-heading font-bold">APP安装线路后界面公告</header>
               <div class="panel-body">
          <form action="cloudgg.php?type=app1" method="post" class="form-horizontal" role="form">
              <div class="form-group"><label>&nbsp;&nbsp;公告内容：</label>
              <textarea class="form-control diff-textarea" placeholder="输入公告内容" name="app1content" rows="6"><?php echo $app1conn; ?></textarea>
             </div>
            <input type="submit" value="保存" class="btn btn-info btn-block">
          </form>
        </div>
                    
			
			
</div>
  <script src="../datepicker/WdatePicker.js"></script>
 <?php include("footer.php"); ?>