<?php
return array (
  'ver' => '1.2',
  'release' => '2016-10-20',
  'vername' => '7k™',
);
?>