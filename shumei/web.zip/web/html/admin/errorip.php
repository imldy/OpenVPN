<!DOCTYPE html>
<html lang="zh"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<title>控制面板登录</title>
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Nova+Flat' rel='stylesheet' type='text/css'>
<link href="css/style.css" rel="stylesheet" /></head><body>
<div class="container"> 
<div class="row pad-top text-center">
<div class="col-md-6 col-md-offset-3 text-center">
<h1> 您的服务器IP授权验证失败，请使用正版官方程序</h1>
<h5> 如您已经购买服务器IP授权，请建议官网客服处理</h5> 
<h5> 树莓网官方网站 http://www.berryphone.club/<h5>
<h5> 客服QQ1356533106 <h5>
<span id="error-link"></span>
<h2>禁止访问！</h2></div></div>
<div class="row text-center">
<div class="col-md-8 col-md-offset-2">
<h3> </h3>
<a href="https://jq.qq.com/?_wv=1027&k=5wwTajc" class="btn btn-primary">加QQ群购买授权</a><br/><br/>
<br/>Copyright © 树莓网<a href="http://www.berryphone.club/" target="_blank" title="www.berryphone.club">树莓网</a> All rights reserved</a></div></div></div>
<script src="js/jquery-1.10.2.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/countUp.js"></script>
<script src="js/custom.js"></script>
</body>