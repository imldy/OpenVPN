<?php
/**
 * 凌云免流管理中心
 * by 天木兮 2018年10月15日
 */
include("../../Data/api.inc.php");
$row = $DB->get_row("SELECT * FROM Lyun"); 	
$dlconfig=$DB->get_row("SELECT * FROM auth_config WHERE 1");
if($_POST['user'] && $_POST['pass']){
$user=daddslashes($_POST['user']);
$pass=daddslashes($_POST['pass']);
$mail=daddslashes($_POST['mail']);
$a = date('Y-m-d');
$a_time = strtotime($a);
$b_time = strtotime('+'.$dlconfig['reg_endtime'].' Day',$a_time);		 
$rs = $DB->get_row("SELECT * FROM `openvpn` WHERE `iuser`='{$user}' limit 1");
$res = $DB->get_row("SELECT * FROM `openvpn` WHERE `mail`='{$mail}' limit 1");
$max = $dlconfig['reg_cash']*1024*1024;
if($dlconfig['activeok']==0){
if(!is_username($user)){
exit("<script language='javascript'>alert('账号只能是2~20位的字母数字！');history.go(-1);</script>");
}elseif($rs){
exit("<script language='javascript'>alert('该用户名已被使用！');history.go(-1);</script>");	
}elseif($res){
exit("<script language='javascript'>alert('每个邮箱只能绑定一个账号！');history.go(-1);</script>");	
}else{
$sql="insert into `openvpn` (`iuser`,`pass`,`isent`,`irecv`,`maxll`,`i`,`starttime`,`endtime`,`mail`,`tj_u`,`tian`) values ('{$user}','{$pass}',0,0,'{$max}','1','{$a_time}','{$b_time}','{$mail}',0,'0')";	
if($DB->query($sql)){
			exit("<script language='javascript'>alert('注册成功，请使用激活码充值使用！');window.location.href='../data/index.php?user={$user}&pass={$pass}';</script>");	
		}else{
			exit("<script language='javascript'>alert('注册失败，请联系管理员！');history.go(-1);</script>");
		}
	}
}else{
	exit("<script language='javascript'>alert('网站已经关闭注册，请联系管理员注册！');window.location.href='./index.php';</script>");
}}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no"/>
    <link rel="shortcut icon" href="../img/favicon_1.ico">

    <title>管理员注册 - <?php echo $row['logo'];?></title>
    <meta name="keywords" content="凌云免流，凌云流控，凌云流量，LY免流，LY流控">
    <meta name="description" content="凌云免流，凌云流控，凌云流量，LY免流，LY流控">
	<link href="../../assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/core.css" rel="stylesheet" type="text/css">
    <link href="css/components.css" rel="stylesheet" type="text/css">
    <link href="css/pages.css" rel="stylesheet" type="text/css">
	
    <link href="css/responsive.css" rel="stylesheet" type="text/css">


</head>
<body>
<div class="wrapper-page">
    <div class="panel panel-color panel-primary panel-pages">
        <div class="panel-heading bg-img">
            <div class="bg-overlay"></div>
            <h3 class="text-center m-t-10 text-white"><strong><?php echo $row['logo'];?>管理后台 - 注册</strong> </h3>
        </div>

        <div class="panel-body">
            <form class="form-horizontal m-t-20" action="./reg_user.php" method="post">

                <div class="form-group">
                    <div class="col-xs-12">
                        <input class="form-control input-lg" type="text" required="" name="user" placeholder="请输入要注册的账号">
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-xs-12">
                        <input class="form-control input-lg" type="password" required="" name="pass" placeholder="请输入要注册的密码">
                    </div>
                </div>
				
                <div class="form-group">
                    <div class="col-xs-12">
                        <input class="form-control input-lg" type="text" required="" name="mail" placeholder="请输入你真实的邮箱号">
                    </div>
                </div>
				
                 <div class="form-group text-center m-t-40">
                    <div class="col-xs-12">
                        <button class="btn btn-primary form-control" type="submit">立 即 注 册</button>
                    </div>
                </div>

                <div class="form-group m-t-30">
                    <div class="col-sm-7">
                        <a onclick="alert('请联系你的上级找回密码哦！')"><i class="fa fa-lock m-r-5"></i> 忘记密码?</a>
                    </div>
                    <div class="col-sm-5 text-right">
                        <a href="index.php">马上登陆</a>
                    </div> 
                </div>
            </form>
        </div>

    </div>
</div>
</body>
</html>