<?php

$file = "../../FAS.lock";

if(file_exists($file))
{
    require ("error.php");
	return;
}
else
{
 echo "";
}
?>
<?php
require('head.php');
require('nav.php');
function unsetLine($arr){
	foreach($arr as $v){
		if(strpos($v,"apache") === 0){
			
		}else{
			$line[] = $v;
		}
	}
	return $line;
}

$nums = db(_openvpn_)->getnums();
$user_num = db(_openvpn_)->where(["i"=>"1"])->getnums();
$nums2 = db(_openvpn_)->where(["online"=>"1"])->getnums();
$nums3 = db("auth_fwq")->where()->getnums();
$key = file_get_contents("license.key");
$version = '../version.php';
$ver = include($version);	

?>

<style>
#line
{
	width: 100%;
	height: 385px;
	
}
#pie
{
	width: 100%;
	height: 400px;
	
}
.box-group{
	color:#222;
	font-size:16px;
	text-align:center;
	border-bottom:4px solid #328cc9;
	padding:10px 0px;
	margin:0px 10px;
}
.i-box{
	margin-bottom:15px;
	background:#fff;
	height:85px;
	position:relative;
	padding:15px;
}
.i-box6{
	margin-bottom:15px;
	background:#fff;
	height:200px;
	position:relative;
	padding:15px;
}

.i-box .i-icon{
	position:absolute;
	width:55px;
	height:55px;
	line-height:55px;
	text-align:center;
	font-size:25px;
	background:#4bb0e5;
	color:#fff;
	border-radius:30px;
}
.i-box .i-right{
	padding-top:3px;
	margin-left:75px;
	height:60px;
}
</style>


 




	<div class="row">
    
	<div class="col-xs-12 col-md-3"> 
		<div class="i-box"> 
			<div class="i-icon">
				<i class="icon-group"></i>
			</div>
			<div class="i-right">
			<p>注册用户 <?=$nums?> 人          
	                       				</p> 
			<p>正常用户 <?=$user_num?> 人</p> 
			
			
			
			</div>             
		</div>             
    </div>      
<div class="col-xs-12 col-md-3"> 
		<div class="i-box"> 
			<div class="i-icon" style="background:#43ba9c">
				<i class="icon-heart"></i>
			</div>
			<div class="i-right">
			<p>在线人数 <?=$nums2?> 人</p> 
			<p>活跃程度 <?= round($nums2/$nums,4)*100;?> %</p> 
			</div>             
		</div>             
    </div>
    <div class="col-xs-12 col-md-3"> 
		<div class="i-box"> 
			<div class="i-icon" >
				<i class="icon-wrench"></i>
			</div>
			<div class="i-right">
			<p>
			                    		<?php
		 exec(" ps aux|grep jk.sh",$jiankong);
		$jiankong = unsetLine($jiankong);
		 $run = false;
		 foreach($jiankong as $v){
			// $run '<div style="border-bottom:1px dashed #ccc;margin-bottom:10px;"><span class="label label-info">监控运行中</span>&nbsp;<b>'.$v."</b></div>";
			 $run = true;
		 }
		 if($run){
			 echo ' ';
			 echo "[用户状态扫描] 运行正常";
			 echo ' ';
		 }else{
			 echo '';
			 echo "[用户状态扫描] 运行异常";
			 echo ' ';
		 }
		  ?></p> 
			<p>
				 <?php
		exec(" ps aux|grep FasAUTH.bin",$jiankong2);
		$jiankong2 = unsetLine($jiankong2);
		$run = false;
		foreach($jiankong2 as $v){
			//echo '<div style="border-bottom:1px dashed #ccc;margin-bottom:10px;"><span class="label label-info">监控运行中</span>&nbsp;<b>'.$v."</b></div>";
			 $run = true;
		 }
		  
		 if($run){
			 echo "[用户流量监控] 运行正常";
		 }else{
			 echo "[用户流量监控] 运行异常";
		 }
		  ?></p> 
			</div>             
		</div>             
    </div>      
    
    
                 
<div class="col-xs-12 col-md-3"> 
		<div class="i-box"> 
			<div class="i-icon" style="background:#5CB85C">
				<i class="icon-bell-alt"></i>
			</div>
			<div class="i-right">
			<p><?=$nums3?></p> 
			<p>服务器</p> 
			</div>             
		</div>             
    </div> 
    <div class="col-xs-12 col-md-3"> 
		<div class="i-box"> 
			<div class="i-icon" style="background:#5CB85C">
				<i class="icon-sitemap"></i>
			</div>
			<div class="i-right">
			<p>实时网速监控</p> 
			<p><h5><span class="bwjk">检测中</span>&nbsp;Mbps/s</h5>
			</p> 
			</div>             
		</div>             
    </div>      
     
<div class="col-xs-12 col-md-3"> 
		<div class="i-box"> 
			<div class="i-icon">
				<i class="icon-time"></i>
			</div>
			<div class="i-right">
			<p><?=date("Y/m/d H:i")?></p> 
			<p>系统时间</p> 
			</div> 
			      
		</div>             
    </div>      
 <div class="col-xs-12 col-md-3"> 
		<div class="i-box6"> 
			<div class="i-icon" >
				<i class="icon-bell-alt"></i>
			</div>
			<div class="i-right">
			<p>官方公告</p> 
			<p><?php $url = "https://raw.githubusercontent.com/Andyanna/openvpn/master/gonggao.txt"; 
                         $contents = file_get_contents($url); 
                         //如果出现中文乱码使用下面代码 
                         //$getcontent = iconv("gb2312", "utf-8",$contents); 
                         echo $contents; 
                         ?></b>
                         <?php $url1 = "https://raw.githubusercontent.com/Andyanna/openvpn/master/vpnip.html"; 
                         $contents1 = file_get_contents($url1); 
                         //如果出现中文乱码使用下面代码 
                         //$getcontent = iconv("gb2312", "utf-8",$contents); 
                         //echo $contents; 
                         ?></p> 
			</div>             
		</div>             
    </div>      

			
           
		<div class="col-xs-12 col-sm-9">
	</div>
	</div> 
	
	
	
       </section>
				
                 

                      <section class="panel panel-default">
                           <div class="panel-body">

                    <header class="panel-heading font-bold">
                                <strong>
                                    信息
                                </strong>
                            </header>
                      <div id="" class="panel-body">
              <ul class="list-group">
		
			<p><b>系统版本：</b><?php echo $ver['vername'].' v'.$ver['ver']; ?>
			  </li>
			</p>
			<p>
			  <b>最近更新时间：</b><?php echo $ver['release']; ?>
			  </li>
			  </p>
			  <b>官方最新软件版本：</b><?php $url2 = "https://raw.githubusercontent.com/Andyanna/openvpn/master/banben.txt"; 
                         $contents2 = file_get_contents($url2); 
                         //如果出现中文乱码使用下面代码 
                         //$getcontent = iconv("gb2312", "utf-8",$contents); 
                         echo $contents2; 
                         $contents2=floatval($contents2);
                         $thisbanben=$ver['ver'];
                         $thisbanben=floatval($thisbanben);
                         if($contents2>$thisbanben){
                        // echo "有新版本需要更新，请立即更新 <a href=http://www.berryphone.club/><strong>立即更新</strong></a></b>" ;
                         echo "有新版本需要更新，请立即更新，请在ssh输入updatevpn，即可一键更新" ;
                         }
                         if($contents2==$thisbanben){
                         echo '当前为最新版本';
                         }
                         ?>
			  </li>
			  </p>
			
			  <p><b>服务到期时间：</b>2035-07-07
			    </li>
			    </p>
			 
	 <?php
		exec("top -bn1 | grep Cpu",$cpuinfo);
		//99.2 id
		preg_match('/\s*([0-9\.]*)\s*id/is',$cpuinfo[0],$cpuinfo_free);
		$lyl = 100-(float)$cpuinfo_free[1];
		  ?>

  	</li>
			    </p>
			<b>PHP 版本：</b><?php echo phpversion() ?>
		 </li>
			    </p>
			<b>SQL 版本：</b><?php echo $mysqlversion ?>
	</li>
			    </p>
			<b>应用程序：</b><?php echo $_SERVER['SERVER_SOFTWARE'] ?>
	</li>
			    </p>
			<b>程序最大运行时间：</b><?php echo ini_get('max_execution_time') ?>s
			</li>
			    </p>
			<b>POST许可：</b><?php echo ini_get('post_max_size'); ?>
		</li>
			    </p>
			<b>文件上传限制：</b><?php echo ini_get('upload_max_filesize'); ?>
		</li>
			    </p>
	<h5>CPU利用率：<?php echo $lyl?>%</h5>
                        <div class="progress progress-striped active">
                            <div style="width: <?php echo $lyl?>%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="75" role="progressbar" class="progress-bar progress-bar-danger">
                                <span class="sr-only">80% Complete (success)</span>
                            </div>
                        </div>
					<h5>内存利用率：<?php echo $hdPercent?>%</h5>
						<div class="progress progress-striped active">
                            <div style="width: <?php echo $hdPercent?>%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="75" role="progressbar" class="progress-bar progress-bar-success">
                                <span class="sr-only">80% Complete (success)</span>
                            </div>
                        </div>



        </section>
        
        
        
        
        
        
        
       


	<div class="col-md-6">





				


        </div>
        </section>
	
	
	
	
	
	

	
		
		<div class="box" style="margin-bottom:15px">
			<div class="row"><div class="col-xs-12 col-sm-6"> 
				<h3>TCP端口监听</h3>
				<h6><b>*</b>您的系统目前以对如下TCP端口进行了监听</h6>
				<?php
						 exec(" netstat -nap|grep tcp|grep \"0.0.0.0:\"",$tcp);
						$tcp = unsetLine($tcp);
						preg_match_all("/\:([0-9]*)/",implode("\n",$tcp),$m);
						foreach($m[1] as $v){ 
							echo '<span class="label label-info">'.$v.'</span> ';
						}
						  ?>
				</div>
				<div class="col-xs-12 col-sm-6"> 
						 <h3>UDP端口监听</h3>
						  <h6><b>*</b>您的系统目前以对如下UDP端口进行了监听</h6>
						 <?php
							exec(" netstat -nap|grep udp|grep \"0.0.0.0:\"",$udp);
							$udp = unsetLine($udp);
							preg_match_all("/\:([0-9]*)/",implode("\n",$udp),$m);
							foreach($m[1] as $v){ 
								echo '<span class="label label-info">'.$v.'</span> ';
							}
						  ?>
				</div>
			</div>
		</div>


      <script type="text/javascript">
   
    $(function(){
		$.post("rateJson.php?act=bwi",{},function(data){
				$(".bwjk").html(data);
			});
		setTimeout(function(){
			$.post("rateJson.php?act=bwi",{},function(data){
				$(".bwjk").html(data);
			});
		}, 10000);
		
	});
</script>
 <?php
 include("footer.php");
 ?>