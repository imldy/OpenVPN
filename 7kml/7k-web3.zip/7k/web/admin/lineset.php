<?php
$mod='blank';
include("../api.inc.php");
if($active != 2)exit("Error");
$title='配置线路';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<!-- Body -->
<body>
    <!-- Loading Container -->
    <div class="loading-container">
        <div class="loading-progress">
            <div class="rotator">
                <div class="rotator">
                    <div class="rotator colored">
                        <div class="rotator">
                            <div class="rotator colored">
                                <div class="rotator colored"></div>
                                <div class="rotator"></div>
                            </div>
                            <div class="rotator colored"></div>
                        </div>
                        <div class="rotator"></div>
                    </div>
                    <div class="rotator"></div>
                </div>
                <div class="rotator"></div>
            </div>
            <div class="rotator"></div>
        </div>
    </div>
    <!--  /Loading Container -->
        <?php include 'nav.php';?>
             <!-- Page Content -->
            <div class="page-content">
                <!-- Page Breadcrumb -->
                <div class="page-breadcrumbs">
                    <ul class="breadcrumb">
                        <li>
                            <i class="fa fa-home"></i>
                            <a href="#">平台首页</a>
                        </li>
                        <li class="active"><?php echo $title ?></li>
                    </ul>
                </div>
                <!-- /Page Breadcrumb -->
                 <!-- Page Header -->
                <div class="page-header position-relative">
                    <div class="header-title">
                        <h1>
                            <?php echo $title ?>
                        </h1>
                    </div>
                    <!--Header Buttons-->
                    <div class="header-buttons">
                        <a class="sidebar-toggler" href="#">
                            <i class="fa fa-arrows-h"></i>
                        </a>
                        <a class="refresh" id="refresh-toggler" href="">
                            <i class="glyphicon glyphicon-refresh"></i>
                        </a>
                        <a class="fullscreen" id="fullscreen-toggler" href="#">
                            <i class="glyphicon glyphicon-fullscreen"></i>
                        </a>
                    </div>
                    <!--Header Buttons End-->
                </div>
                <!-- /Page Header -->   
<?php
$id = daddslashes($_GET['id']);
?>				
                <!-- Page Body -->
                <div class="page-body">
                    <h5 class="row-title"><i class="typcn typcn-th-small"></i>配置线路</h5>
                    <div class="row">
                        <div class="col-xs-12 col-md-12">
                            <div class="widget">
                                <div class="widget-header  with-footer">
                                    <span class="widget-caption">进行线路编号为 <?=$id?> 的配置</span>
                                    <div class="widget-buttons">
                                        <a href="#" data-toggle="maximize">
                                            <i class="fa fa-expand"></i>
                                        </a>
                                        <a href="#" data-toggle="collapse">
                                            <i class="fa fa-minus"></i>
                                        </a>
                                        <a href="#" data-toggle="dispose">
                                            <i class="fa fa-times"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="widget-body">
                                    <div class="alert alert-info fade in alert-radius-bordered alert-shadowed">
                                        <button class="close" data-dismiss="alert">
                                            ×
                                        </button>
                                        <i class="fa-fw fa fa-info"></i>

                                        <strong>请注意:</strong> 此处可以编辑修改自带云端①免流线路
                                    </div>

                    <div class="panel-body">





<?php
if(!$id || !$row = $DB->get_row("select * from `open` where id='$id' limit 1")){ exit("线路不存在!");}
if($_POST['type']=="update"){
echo '<div class="alert ';
//$category_id = daddslashes($_POST['category_id']);
$name = daddslashes($_POST['name']);
$mo = daddslashes($_POST['mo']);
  if($DB->query("update `open` set `name`='$name',`mo`='$mo' where id='$id'")){
    echo 'alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  修改成功！';
  }else{
    echo 'alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  修改失败！'.$DB->error();
  }
echo '</div>';
echo "<style>#lineset{display: none;}</style>";
//exit;
}
?>
      

                <form id="lineset" action="./lineset.php?id=<?=$id?>" method="post" role="form" class="form-horizontal">
                <input type="hidden" name="type" value="update" />

                    <div class="form-group">
                      <label class="col-sm-2 control-label">线路名称：</label>
                      <div class="col-sm-9">
                        <input type="text" class="form-control" id="field-1" placeholder="输入模式名称" name="name" data-validate="required" value="<?=$row['name']?>">
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="col-sm-2 control-label">模式内容：</label>
                      <div class="col-sm-9">
                         <textarea class="form-control" cols="5" id="field-5" name="mo" rows="6" data-validate="required"><?=$row['mo']?></textarea>
                      </div>
                    </div>   

                  <div class="form-group">
                    <label class="col-sm-2 control-label"></label>
                    <div class="col-sm-9">
                      <button type="submit" type="button" class="btn btn-info btn-block">修改</button>
                    </div>
                  </div>
                  
                </form>

                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
