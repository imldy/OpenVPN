<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>代理管理 - 代理列表</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">

    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">

<div class="wrapper wrapper-content animated fadeInUp">
<div class="row">
<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;width: 100%">
<section class="panel panel-default">
  <div class="ibox-title">
                        <h5>代理管理 >><small> 代理列表</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
<div class="panel-body">
				
<div class="form-group">                    
<?php
$my=$_GET['my'];
if($my=='black1'){
$user=$_GET['user'];
echo '
<div class="panel-heading w h"><h3 class="panel-title">代理设置</h3></div>
<div class="panel-body box">';
$id=$_GET['id'];
$sql=$DB->query("update `auth_daili` set `active`='0' where `user`='{$user}'");
if($sql){echo '<div class="box">恭喜亲设置成功，当前状态为未激活</div>';}
else{echo '<div class="box">噢，状态设置失败,请稍后重新尝试.</div>';}
echo '<hr/><a href="./daili_list.php" class="btn btn-success">返回代理列表</a></div>';
exit;}
elseif($my=='black2'){
$user=$_GET['user'];
echo '
<div class="panel-heading w h"><h3 class="panel-title">代理余额充值</h3></div>
<div class="panel-body box">
<form action="./daili_list.php?" method="get" class="form-inline" role="form">
            <div class="form-group">
              <label>为</label>
              '.$user.'
               <label>充值</label>
            </div>
            <div class="form-group">
            <input type="text" name="user" value='.$user.' hidden />
            <input type="text" name="my" value="black2" hidden/>
              <input type="text" name="s" value="" class="form-control" required/>
            </div>
            <input type="submit" value="充值" class="btn btn-primary"/>
          </form>
<div class="panel-body box">';
if($_GET['s'] && $_GET['user']){
	$s=$_GET['s'];
		if($s>999999){
		exit("<script language='javascript'>alert('数据非法！');history.go(-1);</script>");
	}
	$rs=$DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
	$rmb=$rs['rmb']+$s;
	$sql=$DB->query("update `auth_daili` set `rmb`='$rmb' where `user`='{$user}'");
	if($rs['tj_user']){
		$rmb2=$s*$conf_rate;
		$sql2=$DB->query("update `auth_daili` set `tj_rmb`=`tj_rmb`+{$rmb2} where `user`='{$rs['tj_user']}'");
	}
	if($sql){
		echo '<div class="box"><hr/>恭喜亲成功为'.$user.'充值，'.$s.'元！</div>';
		wlog('代理充值','管理员为代理'.$user.'充值'.$s.'元['.$date.']');
	}else{
		echo '<div class="box"><hr/>奥，为{$user}充值失败，请稍后重新尝试.</div>';
	}
echo '<hr/><a href="./daili_list.php" class="btn btn-success">返回代理列表</a></div>';
}exit;
}elseif($my=='black3'){
$user=$_GET['user'];
$rs=$DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
echo '
<div class="panel-heading w h"><h3 class="panel-title">代理密码设置</h3></div>
<div class="panel-body box">
<form action="./daili_list.php?" method="get" class="form-inline" role="form">
            <div class="form-group">
              <label>为</label>
              '.$user.'
               <label>更改密码</label>
            </div>
            <div class="form-group">
            <input type="text" name="user" value='.$user.' hidden />
            <input type="text" name="my" value="black3" hidden/>
          <input type="text" name="mima" value='.$rs['pass'].' />
            </div>
            <input type="submit" value="重置新密码" class="btn btn-primary"/>
          </form>
<div class="panel-body box">';
$mima=$_GET['mima'];
if($mima<>$rs['pass'] && $mima<>""){
$sql=$DB->query("update `auth_daili` set `pass`='$mima' where `user`='{$user}'");
if($sql){echo '<hr/>恭喜亲重置新密码成功！';
}else{echo '<hr/>奥，重置新密码失败，请稍后重新尝试.';}
echo '<hr/><a href="./daili_list.php" class="btn btn-success">返回代理列表</a></div>';}
exit;}
elseif($my=='black0'){
$user=$_GET['user'];
echo '
<div class="panel-heading w h"><h3 class="panel-title">代理账号激活</h3></div>
<div class="panel-body box">';
$id=$_GET['id'];
$sql=$DB->query("update `auth_daili` set `active`='1' where `user`='{$user}'");
if($sql){echo '恭喜亲成功激活代理账号';}
else{echo '奥，激活代理账号失败，请稍后重新尝试.';}
echo '<hr/><a href="./daili_list.php" class="btn btn-success">返回代理列表</a></div>';
exit;
}elseif($my=="vip"){
	$user=$_GET['user'];
	$rs=$DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
	$vip=$rs['vip'];
echo '
<div class="panel-heading w h"><h3 class="panel-title">代理VIP等级设置</h3></div>
<div class="panel-body box">
<form action="./daili_list.php?" method="get" class="form-inline" role="form">
            <div class="form-group">
              <label>为</label>
              '.$user.'
               <label>升级</label>
            </div>
            <div class="form-group">
            <input type="text" name="user" value='.$user.' hidden />
            <input type="text" name="my" value="vip" hidden/>
             <select name="vip" class="form-control">
                <option value="0">青铜代理</option>
                <option value="1">白银代理</option>
                <option value="2">黄金代理</option>
                <option value="3">铂金代理</option>
                <option value="4">钻石代理</option>
                <option value="5">王者代理</option>
              </select>
            </div>
            <input type="submit" value="升级" class="btn btn-primary"/>
          </form>
<div class="panel-body box">';
if(isset($_GET['vip']) && $_GET['user']){
	$vip=$_GET['vip'];

if($vip>5){
exit("<script language='javascript'>alert('数据非法！');history.go(-1);</script>");
}
$rs=$DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
$sql=$DB->query("update `auth_daili` set `vip`='$vip' where `user`='{$user}'");
if($sql){echo '<hr/>恭喜亲升级成功，当前为VIP'.$vip.'！';}
else{echo '<hr/>奥，升级VIP失败，请稍后重新尝试.';}
echo '<hr/><a href="./daili_list.php" class="btn btn-success">返回代理列表</a></div>';
}exit;
}elseif($my=="del"){
$user=$_GET['user'];
echo '
<div class="panel-heading w h"><h3 class="panel-title">删除代理结果</h3></div>
<div class="panel-body box">';
$sql=$DB->query("DELETE FROM auth_daili WHERE user='$user'");
if($sql){echo '恭喜亲成功删除代理'.$user.'';}
else{echo '奥，删除代理失败，请稍后重新尝试.';}
echo '<hr/><a href="./daili_list.php" class="btn btn-success">返回代理列表</a></div>';
exit;
}
 ?>

 <div class="table-responsive">
        <table class="table table-bordered table-hover">
          <thead><tr><th class="text-center">ID</th><th class="text-center">用户名</th><th class="text-center">密码</th><th class="text-center">状态</th><th class="text-center">账号</th><th class="text-center">卡密</th><th class="text-center">在线</th><th class="text-center">代理等级</th><th class="text-center">账户余额</th><th class="text-center">代理QQ</th><th class="text-center">管理操作</th></tr></thead>
          <tbody>
<?php
if(isset($_GET['sdl'])) {
	$sdl=$_GET['sdl'];
	$dl="1";
	if($_GET['type']==1) {
		$sql=" `user`='{$_GET['sdl']}'";
		$numrows=$DB->count("SELECT count(*) from `auth_daili` WHERE{$sql}");
	}elseif($_GET['type']==2) {
		$sql=" `vip`='{$_GET['kw']}'";
		$numrows=$DB->count("SELECT count(*) from `auth_daili` WHERE{$sql}");
	}
}else{
	$numrows=$DB->count("SELECT count(*) from `auth_daili` WHERE 1");
	$sql=" 1";
}

$pagesize=50;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
if($dl=="1"){
$rs=$DB->query("SELECT * FROM auth_daili where user='$sdl' limit $offset,$pagesize");
}else{
$rs=$DB->query("SELECT * FROM auth_daili limit $offset,$pagesize");
}

while($res = $DB->fetch($rs))
{
$vip=$res['vip'];
if($vip==1){
	$v="<font color='#FFB200'>白银代理</font>";
}elseif($vip==2){
	$v="<font color='#80FE80'>黄金代理</font>";
}elseif($vip==3){
	$v="<font color='#FEE680'>铂金代理</font>";
}elseif($vip==0){
	$v="<font color='#B26B00'>青铜代理</font>";
}elseif($vip==4){
		$v="<font color='#2D006B'>钻石代理</font>";
}elseif($vip==5){
	$v="<font color='red'>王</font><font color='green'>者</font><font color='#2D006B'>代</font><font color='#E60066'>理</font>";
}
if($res['active']==0){
	$isactive='<span class="label label-warning">未激活</span>';
}elseif($res['active']==1){
	$isactive='<span class="label label-primary">已激活</span>';
}
$online = $DB->count("SELECT count(*) from `openvpn` WHERE online=1 and dlid='".$res['id']."'");
$user = $DB->count("SELECT count(*) from `openvpn` WHERE dlid='".$res['id']."'");
$dlkms = $DB->count("SELECT count(*) from `auth_kms` WHERE daili='".$res['id']."'");
echo '<tr><td class="text-center">'.$res['id'].'</td>
<td class="text-center">'.$res['user'].'</td>
<td class="text-center">'.$res['pass'].'</td>
<td class="text-center">'.$isactive.'</td>
<td class="text-center">'.$user.'</td>
<td class="text-center">'.$dlkms.'</td>
<td class="text-center">'.$online.'</td>
<td class="text-center">'.$v.'</td>
<td class="text-center">'.$res['rmb'].'</td>
<th class="text-center">'.$res['qq'].'</th>
<td class="text-center">'.($res['active']==1?'<a href="./daili_list.php?my=black1&user='.$res['user'].'" class="btn btn-xs btn-success" onclick="return confirm(\'你确实要更改状态吗？\');">设为未激活</a>':'<a href="./daili_list.php?my=black0&user='.$res['user'].'" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要将此代理激活吗？\');">设置为激活</a>').'<a href="./daili_list.php?my=black2&user='.$res['user'].'" class="btn btn-xs btn-primary">为其充值</a><br/><a href="./daili_list.php?my=black3&user='.$res['user'].'" class="btn btn-xs btn-info">改密码</a><a href="./daili_list.php?my=vip&user='.$res['user'].'" class="btn btn-xs btn-warning">设置VIP等级</a><a href="./daili_list.php?my=del&user='.$res['user'].'" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要进行操作吗？\');">删除代理</a></td></tr>';
}
?>
          </tbody>
        </table>
      </div>
<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="daili_list.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="daili_list.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="daili_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="daili_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="daili_list.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="daili_list.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
?>
    </div>              
              </div>
            </section>
			  </div>
                        </div>
                    </div>
                </div>

    <!-- 全局js -->
    <script src="../../assets/js/jquery.min.js?v=2.1.4"></script>
    <script src="../../assets/js/bootstrap.min.js?v=3.3.6"></script>


    <!-- 自定义js -->
    <script src="../../assets/js/content.js?v=1.0.0"></script>

    </body>
</html>
