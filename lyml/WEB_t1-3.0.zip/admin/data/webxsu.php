<?php
/**
 * 凌云免流管理中心
 * by 天木兮 2018年10月15日
 */
include("../../Data/api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='../Lyun/index.php';</script>");
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>高级管理 - 系统服务设置</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    
	<script src="../../assets/js/jquery.min.js"></script>
	<script src="../../assets/js/bootstrap.min.js"></script>
    <!-- Data Tables -->
    <link href="../../assets/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">

    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>高级管理 <small>系统服务设置</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
					<h3>代理端口</h3>
	<button class="btn btn-primary btn-xs" data-toggle="modal" data-target="#addNesdk">添加新端口</button>&nbsp;
	<br>说明：为你一键开启本机服务器代理端口
	<br><hr>
	<h3>修改系统设置</h3>
	<button class="btn btn-success btn-xs" data-toggle="modal" data-target="#all_xsu">修改全局限速值</button>&nbsp;
	<button class="btn btn-info btn-xs" data-toggle="modal" data-target="#now_web">修改WEB端口</button>&nbsp;
	<button class="btn btn-info btn-xs" data-toggle="modal" data-target="#all_dns">编辑DNS规则</button>&nbsp;
	<br>说明：可一键修改当前WEB端口和VPN限速值
	<br><hr>
	<h3>重启系统服务</h3>
    <a class="btn btn-xs btn-warning" onclick="if(!confirm('你确实要重启数据库吗？')){return false;};mysql()">重启数据库</a>&nbsp;
	<a class="btn btn-info btn-xs" onclick="if(!confirm('你确实要重启防火墙吗？')){return false;};fhq()">重启防火墙</a>
	<a class="btn btn-danger btn-xs" onclick="if(!confirm('你确实要重启 httpd 吗？')){return false;};httpd()">重启 httpd</a>&nbsp;
	<a class="btn btn-primary btn-xs" onclick="if(!confirm('你确实要重启 VPN 吗？')){return false;};vpn()">重启 VPN</a>&nbsp;
	<br>说明：为你重新启动本机服务器相应的系统服务进程
				</div>
                </div>
            </div>
        </div>
    </div>
<!-- 模态框（Modal） -->
<div class="modal fade" id="all_xsu" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
					&times;
				</button>
				<h4 class="modal-title">
			  修改全局限速值
			</h4>
			</div>
			<div class="modal-body">
				<div id="xinxi" class="form-group">
                  <label for="name">请输入全局限速值(单位/KB)</label><br>
					<input id="zhi" class="form-control" value="<?php 
					                           $info = file_get_contents("/etc/Lyun/bwlimitplugin.cnf");
		                                       $p = '/default\s([0-9]*)/';
		                                       preg_match($p,$info,$m);
		                                       echo $m[1] ?>"style="border-radius:6px;"/> 
				</div>
			  <p>注:此功能可对本机所有用户进行限速，操作成功请重启vpn</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">
				   Close
				</button>
				<button onclick="SetXsu()" class="btn btn-primary" data-dismiss="modal">
					保持内容
				</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal -->
</div>
<!-- 模态框（Modal）end --> 
<div class="modal fade" id="all_dns" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
					&times;
				</button>
				<h4 class="modal-title">
			  修改DNS规则
			</h4>
			</div>
			<div class="modal-body">
				<div id="xinxi" class="form-group">
                  <label for="name">示例:127.0.0.1 www.baidu.com 则用户访问百度会被屏蔽</br>10.8.0.1（或者你的IP） a.com 则访问a.com会进入你的流控</label><br>
				  <?php $info = file_get_contents("/Data/Lyun_hosts"); ?>
                  <textarea class="form-control" rows="20" id="dnszhi" name="dnszhi"><?php echo $info ?></textarea>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">
				   Close
				</button>
				<button onclick="Setdns()" class="btn btn-primary" data-dismiss="modal">
					保持内容
				</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal -->
</div>
<!-- 模态框（Modal） -->
<div class="modal fade" id="now_web" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
					&times;
				</button>
				<h4 class="modal-title">
			  修改WEB端口
			</h4>
			</div>
			<div class="modal-body">
				<div id="xinxi" class="form-group">
                  <label for="name">请输入新WEB端口</label><br>
					<input id="webdk" class="form-control" value="1234" style="border-radius:6px;"/> 
				</div>
			  <p>注:此功能目前还未完善，请耐心等待下次更新<!-- 请不要使用已占用的端口,否则会造成后台打不开 --></p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">
				   Close
				</button>
				<button onclick="SetWeb()" class="btn btn-primary" data-dismiss="modal">
					保持内容
				</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal -->
</div>
<!-- 模态框（Modal）end --> 

<!-- 模态框（Modal） -->
<div class="modal fade" id="addNesdk" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
					&times;
				</button>
				<h4 class="modal-title">
			  添加新端口
			</h4>
			</div>
			<div class="modal-body">
				<div id="xinxi" class="form-group">
                  <label for="name">请输入要添加的端口</label><br>
					<input id="nesdk" class="form-control" value="8081" style="border-radius:6px;"/> 
				</div>
			  <p>注:首页可查看已开的端口,请不要添加已开的端口,</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">
				   Close
				</button>
				<button onclick="NesDk()" class="btn btn-primary" data-dismiss="modal">
					保持内容
				</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal -->
</div>
<!-- 模态框（Modal）end --> 
</body>
<script>
function SetXsu(){
$.get(
			'GetNet.php',{
				"act":"setxsu",
				"limit":$("#zhi").val()
			},function(data){
				if(data.status == "success"){
				    alert("修改全局限速值为"+$("#zhi").val()+"成功");
				}else{
				    alert("操作失败，请骚后再试！");
				}
			
			},"JSON"
		);
 }
 
function Setdns(){
$.get(
			'GetNet.php',{
				"act":"setdns",
				"limit":$("#dnszhi").val()
			},function(data){
				if(data.status == "success"){
				    alert("修改成功,请重启vpn");
				}else{
				    alert("操作失败，请骚后再试！");
				}
			
			},"JSON"
		);
 }
 
function SetWeb(){
$.get(
			'GetNet.php',{
				"act":"setweb",
				"webdk":$("#webdk").val()
			},function(data){
				if(data.status == "success"){
				    alert("修改WEB端口为"+$("#webdk").val()+"成功");
				}else{
				    alert(data.msg);
				}
			
			},"JSON"
		);
 }
 
function NesDk(){
$.get(
			'GetNet.php',{
				"act":"adddk",
				"nesdk":$("#nesdk").val()
			},function(data){
				if(data.status == "success"){
				    alert("添加新端口"+$("#nesdk").val()+"成功");
				}else{
				    alert(data.msg);
				}
			
			},"JSON"
		);
 }
 
function fhq(){
$.get(
			'GetNet.php',{
				"act":"fhq"
			},function(data){
				if(data.status == "success"){
				    alert("重启防火墙成功");
				}else{
				    alert(data.msg);
				}
			
			},"JSON"
		);
 }
 
function mysql(){
$.get(
			'GetNet.php',{
				"act":"mysql"
			},function(data){
				if(data.status == "success"){
				    alert("重启数据库成功");
				}else{
				    alert(data.msg);
				}
			
			},"JSON"
		);
 } 
 
function dnsmasq(){
$.get(
			'GetNet.php',{
				"act":"dnsmasq"
			},function(data){
				if(data.status == "success"){
				    alert("重启 dnsmasq 成功");
				}else{
				    alert(data.msg);
				}
			
			},"JSON"
		);
 }
 
function httpd(){
$.get(
			'GetNet.php',{
				"act":"httpd"
			},function(data){
				if(data.status == "success"){
				    alert("重启 Httpd 成功");
				}else{
				    alert(data.msg);
				}
			
			},"JSON"
		);
 }
 
function vpn(){
$.get(
			'GetNet.php',{
				"act":"vpn"
			},function(data){
				if(data.status == "success"){
				    alert("重启 VPN 成功");
				}else{
				    alert(data.msg);
				}
			
			},"JSON"
		);
 }
</script>
</html>
