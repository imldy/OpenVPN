<?php
$mod='blank';
include("../api.inc.php");
$title='账号列表';
$dlid=$_SESSION['dlid'];
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head2.php';?>
<body class="page-body">
    
    <?php include 'nav.php';?>

    <div class="page-container"><!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->
            
        <div class="main-content">
                    
            
            <h3 id="layout-toggles">
                代理中心
                <br />
            </h3>
            
            <br />

            <div class="row">
              <div class="col-sm-12">
                          <?php
if($my=='black0'){
$user=$_GET['user'];
echo '<div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert">
                      <span aria-hidden="true">×</span>
                      <span class="sr-only">Close</span>
                    </button>';
    $a = date('Y-m-d');
    $a_time = strtotime($a);
    $b_time = strtotime('+31 Day',$a_time);
    $sql=$DB->query("update `openvpn` set `endtime`='$b_time',`i` ='1',`tian` ='0' where `iuser`='{$user}'");
if($sql){echo '设置成功，'.$user.'状态为已激活！';}
else{echo '设置失败！'.$DB->error().'';}
echo '</div>';
}                 
                          ?>                  

                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">
                          <?php
                          if(!empty($_GET['kw'])) {
                            $sql=" `iuser`='{$_GET['kw']}' and `dlid`=$dlid";
                            $numrows=$DB->count("SELECT count(*) from `openvpn` WHERE{$sql}");
                            $con='包含 '.$_GET['kw'].' 的共有 <b>'.$numrows.'</b> 个账号';
                          }else{
                            $numrows=$DB->count("SELECT count(*) from `openvpn` WHERE `dlid`=$dlid");
                            $sql=" `dlid`=$dlid";
                            $con='共有 <b>'.$numrows.'</b> 个账号';
                          }

                          echo $con;
                          ?>
                      </h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">
                      <form action="qqlist.php"  method="get" role="form" class="form-inline validate">
                      <a href="search.php" class="btn btn-info">搜索卡密</a>
                        
                        <div class="form-group pull-right">
                        <div class="form-group">
                          <input type="text" class="form-control" size="25" placeholder="帐号" name="kw" data-validate="required">
                        </div>

                        <div class="form-group">
                          <button class="btn btn-secondary btn-single">查询</button>
                        </div>
                        
                        </div>
                        
                      </form>

                      <div class="table-responsive">
                      
                          <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                              <thead>
                                  <tr>
                                      <th>账号</th>
                                      <th>密码</th>
                                      <th>添加时间</th>
                                      <th>到期时间</th>
                                      <th>剩余流量</th>
                                      <th>总流量</th>
                                      <th>备注</th>
                                      <th>状态</th>
                                      <th>操作</th>
                                  </tr>
                              </thead>
                              <tbody>
                                   <?php
                                  $pagesize=30;
                                  $pages=intval($numrows/$pagesize);
                                  if ($numrows%$pagesize)
                                  {
                                   $pages++;
                                   }
                                  if (isset($_GET['page'])){
                                  $page=intval($_GET['page']);
                                  }
                                  else{
                                  $page=1;
                                  }
                                  $offset=$pagesize*($page - 1);
                                  //$zt = array('0'=>'<font color=green>正常</font>','1'=>'<font color=red>密码错误</font>','2'=>'<font color=red>冻结</font>','3'=>'<font color=red>开启设备锁</font>');
                                  $rs=$DB->query("SELECT * FROM `openvpn` WHERE{$sql} order by id desc limit $offset,$pagesize");
                                  while($res = $DB->fetch($rs))
                                  { 
                                    if($res['endtime']==0) {
                                        $ok='<a class="btn btn-xs btn-turquoise" href="./qqlist.php?my=black0&user='.$res['iuser'].'" onclick="return confirm(\'你确实要进行操作吗？\');">激活包月</a>';
                                    } else {
                                        $ok='';
                                    } 
                                    ?>
                                  <tr>
                                    <td><?=$res['iuser']?></td>
                                    <td><?=$res['pass']?></td>
                                    <td><?=date("Y-m-d",$res['starttime'])?></td>
                                    <td><?=date("Y-m-d",$res['endtime'])?></td>
                                    <td><?=round(($res['maxll']-$res['isent']-$res['irecv'])/1024/1024)?>MB</td>
                                    <td><?=round(($res['maxll'])/1024/1024)?>MB</td>
                                    <td><?=$res['notes']?></td>
                                    <td><?=($res['i']?'<span class="badge badge-secondary">开通</span>':'<span class="badge badge-default">禁用</span>')?></td>
                                    <td><?=$ok?></td>
                                  </tr>
                                  <?php }
                                  ?>     
                              </tbody>
                          </table>
                      
                      </div>

                        <?php
                        echo'<ul class="pagination pagination-sm">';
                        $first=1;
                        $prev=$page-1;
                        $next=$page+1;
                        $last=$pages;
                        if ($page>1)
                        {
                        echo '<li><a href="qqlist.php?page='.$first.$link.'">首页</a></li>';
                        echo '<li><a href="qqlist.php?page='.$prev.$link.'">&laquo;</a></li>';
                        } else {
                        echo '<li class="disabled"><a>首页</a></li>';
                        echo '<li class="disabled"><a>&laquo;</a></li>';
                        }
                        for ($i=1;$i<$page;$i++)
                        echo '<li><a href="qqlist.php?page='.$i.$link.'">'.$i .'</a></li>';
                        echo '<li class="disabled"><a>'.$page.'</a></li>';
                        for ($i=$page+1;$i<=$pages;$i++)
                        echo '<li><a href="qqlist.php?page='.$i.$link.'">'.$i .'</a></li>';
                        echo '';
                        if ($page<$pages)
                        {
                        echo '<li><a href="qqlist.php?page='.$next.$link.'">&raquo;</a></li>';
                        echo '<li><a href="qqlist.php?page='.$last.$link.'">尾页</a></li>';
                        } else {
                        echo '<li class="disabled"><a>&raquo;</a></li>';
                        echo '<li class="disabled"><a>尾页</a></li>';
                        }
                        echo'</ul>';
                        #分页
                        ?>
                      
                    </div>
                  
                  </div>
              </div>
            </div>

             <?php include("../copy2.php");?>
             
        </div>
        
    </div>
    
    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>

    <script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>

    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 