<?php
/**
 * 客户端模式
**/
$mod='blank';
include("../api.inc.php");
$title='添加账号';
include './head.php';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
include './nav.php';
?>
<?php
require_once ("head.php");
?>
<section id="content">
<section class="vbox">
<section class="scrollable padder">
<ul class="breadcrumb no-border no-radius b-b b-light pull-in">
	<li><a href="./"><i class="fa fa-home"></i> <?php echo $title ?></a></li>
</ul>
<?php
if($_POST['title']){
	echo '<section class="panel panel-default">
              <header class="panel-heading font-bold"> 添加模式结果 </header>
              <div class="panel-body">
<div class="panel-body">'; 
$title = $_REQUEST['title']; 
$category_id = $_REQUEST['category_id']; 
$content = $_REQUEST['content']; 
$sql="insert into `lyj_article` (`title`,`category_id`,`content`,`timeline`) values ('{$title}','{$category_id}','{$content}',NOW())"; 
if($DB->query($sql))
echo "成功添加一个模式"; 
else
echo "添加失败"; 
echo '<hr/><a href="./addovpn.php">>>返回继续添加</a><br><a href="./ovpnlist.php">>>返回模式列表</a></div></div>'; exit;  
}
?>
<section class="panel panel-default">
              <header class="panel-heading font-bold">添加线路模式 </header>
              <div class="panel-body">
          <form action="./addovpn.php" method="post" class="form-horizontal" role="form">
              <div class="form-group"><label>&nbsp;&nbsp;线路名称：</label> <input type="text" placeholder="输入线路名称" class="form-control" name="title" required="" aria-required="true"></div>
              <div class="form-group"><label>&nbsp;&nbsp;线路分类：</label> <input type="text" placeholder="移动=1 联通=2 电信=3" class="form-control" name="category_id" required="" aria-required="true"></div>
              <div class="form-group"><label>&nbsp;&nbsp;模式内容：</label>
              <textarea class="form-control diff-textarea" placeholder="输入完整ovpn模式内容" name="content" rows="6"></textarea>
             </div>
            <br/>
            <input type="submit" value="添加" class="btn btn-primary form-control"/>
          </form>
        </div>
      </div>
    </div>
  </div>
  <script src="../datepicker/WdatePicker.js"></script>
                  <div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
                    
                  
              </div>
            </section>
</section>
</section>

<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a></section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
<div class="wrapper">
	Notification
</div>
</aside>
<!-- end -->
<?php
require_once ("foot.php");
?>