<?php
$rs=$DB->get_row("SELECT * FROM website where id='$site_id'");
$logo=$rs['logo'];
$webtitle=$rs['title'];
$qq=$rs['qq'];
$app1=$rs['app1'];
$app2=$rs['app2'];
$ipinfo=$rs['ipinfo'];
$appleid1=$rs['appleid1'];
$appleps1=$rs['appleps1'];
$appleid2=$rs['appleid2'];
$appleps2=$rs['appleps2'];
$appleid3=$rs['appleid3'];
$appleps3=$rs['appleps3'];
$and_img1=$rs['and_img1'];
$and_img2=$rs['and_img2'];
$and_img3=$rs['and_img3'];
$and_img4=$rs['and_img4'];
$jia1=$rs['jia1'];
$jia2=$rs['jia2'];
$jia3=$rs['jia3'];
$jia4=$rs['jia4'];

$bn=$DB->get_row("SELECT * FROM banner where id='$site_id'");
$img1=$bn['img1'];
$tit1=$bn['tit1'];
$info1=$bn['info1'];
$img2=$bn['img2'];
$tit2=$bn['tit2'];
$info2=$bn['info2'];
$img3=$bn['img3'];
$tit3=$bn['tit3'];
$info3=$bn['info3'];

    //赠送新注册用户流量
    $rs=$DB->get_row("SELECT * FROM auth_config where id='$site_id'");
    $reg_cash_con=round($rs['reg_cash']/1024/1024)."MB";
    $user_endtime_con =$rs['user_endtime'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<title><?php echo $webtitle ?> - <?php echo $title ?></title>
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/animate.min.css" rel="stylesheet"> 
<link href="css/font-awesome.min.css" rel="stylesheet">
<link href="css/lightbox.css" rel="stylesheet">
<link href="css/main.css" rel="stylesheet">
<link id="css-preset" href="css/presets/preset1.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->


<link rel="shortcut icon" href="images/favicon.ico">
</head><!--/head-->
