<?php
/**
 * 登录后台
**/
 error_reporting(E_ALL); 
$mod='blank';
include("../api.inc.php");
if(isset($_POST['user']) && isset($_POST['pass'])){
  $user=daddslashes($_POST['user']);
  $pass=daddslashes($_POST['pass']);
  $row = $DB->get_row("SELECT * FROM auth_user WHERE user='$user' limit 1");
  if($user==$adminuser && $pass==$adminpass) {
    $session=md5($user.$pass.$password_hash);
    $token=authcode("{$user}\t{$session}", 'ENCODE', SYS_KEY);
    setcookie("ol_token", $token, time() + 604800);
    @header('Content-Type: text/html; charset=UTF-8');
    exit("<script language='javascript'>alert('登录成功！');window.location.href='index.php';</script>");
  }elseif ($pass != $row['pass']) {
    @header('Content-Type: text/html; charset=UTF-8');
    exit("<script language='javascript'>alert('用户名或密码不正确！');history.go(-1);</script>");
  }
}elseif(isset($_GET['logout'])){
  setcookie("ol_token", "", time() - 604800);
  @header('Content-Type: text/html; charset=UTF-8');
  exit("<script language='javascript'>alert('您已成功注销本次登录！');window.location.href='./login.php';</script>");
}elseif($islogin2==1){
  exit("<script language='javascript'>alert('您已登录！');window.location.href='index.php';</script>");
}

?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body>

 
            
                <script type="text/javascript">
                    jQuery(document).ready(function($)
                    {
                        // Reveal Login form
                        setTimeout(function(){ $(".fade-in-effect").addClass('in'); }, 1);
                        
                        
                        // Validation and Ajax action
                        $("form#login").validate({
                            rules: {
                                user: {
                                    required: true
                                },
                                
                                pass: {
                                    required: true
                                }
                            },
                            
                            messages: {
                                user: {
                                    required: '此为必填项！'
                                },
                                
                                pass: {
                                    required: '此为必填项！'
                                }
                            },
                            
                        });
                        
                        // Set Form focus
                        $("form#login .form-group:has(.form-control):first .form-control").focus();
                    });
                </script>
                
   <div class="wrapper">
      <div class="block-center mt-xl wd-xl">
         <!-- START panel-->
         <div class="panel panel-dark panel-flat">
            <div class="panel-heading text-center">
               <a href="#">
                  <img src="../assets/img/logo.png" alt="Image" class="block-center img-rounded">
               </a>
            </div>
            <div class="panel-body">
               <p class="text-center pv"><?php
  $rs=$DB->get_row("SELECT * FROM website");
  $webtitle=$rs['title'];
   echo $webtitle
    ?></p>
                <form action="./login.php" method="post" role="form" id="login" class="login-form fade-in-effect">
                  <div class="form-group has-feedback">
                     <input id="user" type="text" name="user" placeholder="请输入管理员帐号" autocomplete="off" required class="form-control">
                     <span class="fa fa-comment form-control-feedback text-muted"></span>
                  </div>                   
    
                  <div class="form-group has-feedback">
                     <input id="pass" name="pass" type="password" placeholder="请输入管理员密码" required class="form-control">
                     <span class="fa fa-lock form-control-feedback text-muted"></span>
                  </div>                    
                    
                   <div class="clearfix">
                     <div class="checkbox c-checkbox pull-left mt0">
                        <label>
                           <input type="checkbox" value="">
                           <span class="fa fa-check"></span>记住登录信息</label>
                     </div>                   


                  </div>
                  <button type="submit" class="btn btn-block btn-primary mt-lg">马上登录</button>
                    
                </form>
                
                
            </div>
            
        </div>


         <div class="p-lg text-center">
            <span>&copy;</span>
            <span>2016</span>
            <span>-</span>
            <span><?php
  $rs=$DB->get_row("SELECT * FROM website");
  $webtitle=$rs['title'];
   echo $webtitle
    ?></span>
         </div>
      </div>
   </div>

   <script src="../assets/modernizr/modernizr.custom.js"></script>
   <script src="../assets/jquery/dist/jquery.js"></script>
   <script src="../assets/bootstrap/dist/js/bootstrap.js"></script>
   <script src="../assets/jQuery-Storage-API/jquery.storageapi.js"></script>
   <script src="../assets/parsleyjs/dist/parsley.min.js"></script>
   <script src="../assetsjs/app.js"></script>
</body>
</html>