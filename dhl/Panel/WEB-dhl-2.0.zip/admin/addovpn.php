<?php
/**
 * 客户端模式
**/
$mod='blank';
include("../api.inc.php");
include './head.php';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
include './nav.php';
?>
<?php
require_once ("head.php");
?>
<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<?php
if($_POST['title']){
	echo '<section class="panel panel-default">
              <header class="panel-heading font-bold"> 添加模式结果 </header>
              <div class="panel-body">
<div class="panel-body">'; 
$title = $_REQUEST['title']; 
$category_id = $_REQUEST['category_id']; 
$content = $_REQUEST['content']; 
$sql="insert into `lyj_article` (`title`,`category_id`,`content`,`timeline`) values ('{$title}','{$category_id}','{$content}',NOW())"; 
if($DB->query($sql))
echo "成功添加一个模式"; 
else
echo "添加失败"; 
echo '<hr/><a href="./addovpn.php">>>返回继续添加</a><br><a href="./ovpnlist.php">>>返回模式列表</a></div></div>'; exit;  
}
?>
<div class="panel panel-primary">
        <div class="panel-heading"><h3 class="panel-title">添加模式</h3></div>
        <div class="panel-body">
          <form action="./addovpn.php" method="post" class="form-horizontal" role="form">
          	<div class="input-group">
              <span class="input-group-addon">线路名称</span>
			  <input type="text" name="title" class="form-control">
            </div><br/>
            <div class="input-group">
              <span class="input-group-addon">线路分类</span>
			  <select name="category_id" class="form-control">
			    <option value="1">移动</option>
              	<option value="2">联通</option>
				<option value="3">电信</option>
              </select>
            </div><br/>
			<div class="input-group">
              <span class="input-group-addon">模式内容</span>
			  <textarea class="form-control diff-textarea" placeholder="输入完整ovpn模式内容" name="content" rows="9"></textarea>
            </div><br/>
            <div class="form-group">
              <div class="col-sm-12"><input type="submit" name="submit" value="修改" class="btn btn-primary form-control"/></div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <script src="../datepicker/WdatePicker.js"></script><?php 