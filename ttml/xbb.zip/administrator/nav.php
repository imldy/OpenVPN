<?php
?>
<!-- 内页结束-->
    </div>
  </div>
</div>


</ui-view>
      </section>
   </div>
   <script src="http://cdn.xkmz.cc/xkmz/angle/vendor/modernizr/modernizr.custom.js"></script>
   <script src="http://cdn.xkmz.cc/xkmz/angle/vendor/matchMedia/matchMedia.js"></script>
   <script src="http://cdn.xkmz.cc/xkmz/angle/vendor/jquery/dist/jquery.js"></script>
   <script src="http://cdn.xkmz.cc/xkmz/angle/vendor/bootstrap/dist/js/bootstrap.js"></script>
   <script src="http://cdn.xkmz.cc/xkmz/angle/vendor/jQuery-Storage-API/jquery.storageapi.js"></script>
   <script src="http://cdn.xkmz.cc/xkmz/angle/vendor/angular/angular.min.js"></script>
   <script src="http://cdn.xkmz.cc/xkmz/angle/vendor/angular/angular-ui-router.min.js"></script>
   <script src="http://cdn.xkmz.cc/xkmz/angle/app/js/app.js"></script>
   <script src="http://cdn.xkmz.cc/xkmz/angle/vendor/animo.js/animo.js"></script>
   <script src="http://cdn.xkmz.cc/xkmz/angle/vendor/screenfull/dist/screenfull.js"></script>
   <script src="http://cdn.xkmz.cc/xkmz/angle/vendor/sweetalert/dist/sweetalert.min.js"></script>
   <script>
   $("#chk-music").click(function(){
		layer.load(1, {shade: [0.1,'#fff']});
		var url="/Set/music.html";
		xiaoke.postData(url, "do=1", function(d) {
			layer.closeAll('loading');
			if (d.code == 1) {
				window.location.href = "javascript:location.reload();";
			}else{
			   prompts(d)
			}
		});
	});
   </script>
   


</div>

</body>
</html>