#!/bin/bash
source /etc/openvpn/peizhi.cfg  
while true
do
mkdir /home/mysql/ >/dev/null 2>&1
cd /home/mysql/
mysqldump -h${localhost} -u${root} -p${mima} ${shujuku} >$(date +%Y-%m-%d).sql
echo  "$(date +%Y年%m月%d日%k时%M分) 成功备份数据库到(/home/mysql/$(date +%Y-%m-%d).sql)</br>"
sleep ${butime}
done