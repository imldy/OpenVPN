<?php
$mod='blank';
include("../api.inc.php");
$title='操作记录';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<html lang="en">
<?php include '../head.php';?>
<!-- Body -->
<body>
        <?php include 'nav.php';?>
		      <section>
         <!-- Page content-->
         <div class="content-wrapper">
            <h3><?php echo $title ?>
               <small>当前显示平台所有日志内容</small>
            </h3>


<?php

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='del'){
echo '<div class="alert';
$id=$_GET['id'];
$sql=$DB->query("DELETE FROM `auth_log` WHERE id='$id'");
if($sql){echo ' alert-success">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除成功！';}
else{echo ' alert-danger">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除失败！';}
echo '</div>';
}

elseif($my=='qk2'){//清空记录结果
echo '<div class="alert';
if($DB->query("DELETE FROM auth_ WHERE 1")==true){
echo ' alert-success">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>清空成功！';
}else{
echo' alert-danger">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>清空失败！';
}
echo '</div>';
}

else
{


$numrows=$DB->count("SELECT count(*) from `auth_log` WHERE 1");
$sql=" 1";
$con='平台共有 '.$numrows.' 个记录';


?>
            <div class="row">
               <div class="col-md-12">

					  		                       <div class="panel panel-default">
                        <div class="panel-heading">
                           <div class="panel-title"><?php echo $con; ?></div>
                        </div>
                        <div class="panel-body">
 

                      <form role="form" class="form-inline">
                      <a href="log.php?my=qk2" class="btn btn-danger"  onclick="if(!confirm('你确实清空吗？')){return false;}">清空</a>
                      </form>
					  <br><br>

                      <div class="table-responsive">
                      
                                  <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                                      <thead>
                                          <tr>
                                              <th>类型</th>
                                              <th data-priority="1">事件内容</th>
                                              <th data-priority="3">操作时间</th>
                                              <th data-priority="6">操作</th>
                                          </tr>
                                      </thead>
                                      <tbody>
                                            <?php
                                            $pagesize=30;
                                            $pages=intval($numrows/$pagesize);
                                            if ($numrows%$pagesize)
                                            {
                                             $pages++;
                                             }
                                            if (isset($_GET['page'])){
                                            $page=intval($_GET['page']);
                                            }
                                            else{
                                            $page=1;
                                            }
                                            $offset=$pagesize*($page - 1);

                                            $rs=$DB->query("SELECT * FROM `auth_log` WHERE{$sql} order by id desc limit $offset,$pagesize");
                                            while($res = $DB->fetch($rs))
                                            { ?>
                                            <tr>
                                            <th><span class="co-name"><?=$res['action']?></span></th>
                                            <td><?=$res['msg']?></td>
                                            <td><?=$res['time']?></td>
                                            <td><a href="./log.php?my=del&id=<?=$res['id']?>" class="btn btn-xs btn-danger" onclick="if(!confirm('你确实要删除此记录吗？')){return false;}">删除</a></td>
                                            </tr>
                                            <?php }
                                            ?> 
                                      </tbody>
                                  </table>
                      
                      </div>
                      <br>
                      <?php
                      echo'<ul class="pagination pagination-sm">';
                      $first=1;
                      $prev=$page-1;
                      $next=$page+1;
                      $last=$pages;
                      if ($page>1)
                      {
                      echo '<li><a href="log.php?page='.$first.$link.'">首页</a></li>';
                      echo '<li><a href="log.php?page='.$prev.$link.'">&laquo;</a></li>';
                      } else {
                      echo '<li class="disabled"><a>首页</a></li>';
                      echo '<li class="disabled"><a>&laquo;</a></li>';
                      }
                      for ($i=1;$i<$page;$i++)
                      echo '<li><a href="log.php?page='.$i.$link.'">'.$i .'</a></li>';
                      echo '<li class="disabled"><a>'.$page.'</a></li>';
                      for ($i=$page+1;$i<=$pages;$i++)
                      echo '<li><a href="log.php?page='.$i.$link.'">'.$i .'</a></li>';
                      echo '';
                      if ($page<$pages)
                      {
                      echo '<li><a href="log.php?page='.$next.$link.'">&raquo;</a></li>';
                      echo '<li><a href="log.php?page='.$last.$link.'">尾页</a></li>';
                      } else {
                      echo '<li class="disabled"><a>&raquo;</a></li>';
                      echo '<li class="disabled"><a>尾页</a></li>';
                      }
                      echo'</ul>';
                      #分页
                      }
                      ?>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
