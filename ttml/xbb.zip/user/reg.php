
<?php
/**
 * 注册
**/
$mod='blank';
include("../api.inc.php");
$dlconfig=$DB->get_row("SELECT * FROM auth_config WHERE 1");
if($_POST['user'] && $_POST['pass']){
	$user=daddslashes($_POST['user']);
	$pass=daddslashes($_POST['pass']);
	$qq=daddslashes($_POST['qq']);
	$fwq=daddslashes($_POST['fwq']);
	$tjid=daddslashes($_POST['id']);
	$verifycode=daddslashes($_POST['verifycode']);
	$row = $DB->get_row("SELECT * FROM `openvpn` WHERE `iuser`='$user' limit 1");
	$fqq = $DB->get_row("SELECT * FROM `openvpn` WHERE `qq`='$qq' limit 1");
	if(!is_username($user)){
		exit("<script language='javascript'>alert('用户名只能是2~20位的字母数字！');history.go(-1);</script>");
	}elseif($row){
		exit("<script language='javascript'>alert('用户名已被使用！');history.go(-1);</script>");
	}elseif($fqq){
		exit("<script language='javascript'>alert('QQ已被使用！');history.go(-1);</script>");
	}elseif($verifycode!=$_SESSION["verifycode"]){
//判断session值与用户输入的验证码是否一致;
		exit("<script language='javascript'>alert('验证码不正确！');history.go(-1);</script>");
	}elseif(!$tjid){
		$DB->query("insert `openvpn`(`iuser`,`pass`,`qq`,`isent`,`irecv`,`maxll`,`i`,`starttime`,`endtime`,`fwqid`) values('{$user}','{$pass}','{$qq}',0,0,0,0,'".time()."','".time()."','".$fwq."')");
		$row = $DB->get_row("SELECT * FROM `openvpn` WHERE `iuser`='$user' limit 1");
		if($row['id']){
			unset($_SESSION['verifycode']);
			exit("<script language='javascript'>alert('注册成功，返回登录！');window.location.href='/';</script>");
		}else{
			exit("<script language='javascript'>alert('注册失败，请联系管理员！');history.go(-1);</script>");
		}
	}else{
	$tj_user = $DB->get_row("SELECT * FROM `openvpn` WHERE `id`='$tjid' limit 1");
	if(!$tj_user){
		exit("<script language='javascript'>alert('推荐人不存在，请重新审核！');window.location.href='/';</script>");
		}else{
		//有推荐人 ， 注册段落	
		$DB->query("insert `openvpn`(`iuser`,`pass`,`qq`,`isent`,`irecv`,`maxll`,`i`,`starttime`,`endtime`,`fwqid`) values('{$user}','{$pass}','{$qq}',0,0,0,0,'".time()."','".time()."','".$fwq."')");
		$row = $DB->get_row("SELECT * FROM `openvpn` WHERE `iuser`='$user' limit 1");
		if($row['id']){
			unset($_SESSION['verifycode']);
			exit("<script language='javascript'>alert('注册成功，返回登录！');window.location.href='/';</script>");
		}else{
			exit("<script language='javascript'>alert('注册失败，请联系管理员！');history.go(-1);</script>");
		}
		//返还推荐人段落
		$addll = 500*1024*1024;
		$DB->query("update `openvpn` set `tj_user` ='$tj_user',`maxll` ='$addll' where `id`='{$tj_user['id']}'");
		
		}
		
		
		
	}
}

$fwqlist=$DB->query("SELECT * FROM auth_fwq");



?>

<!DOCTYPE html>
<!--[if IE 9]>
<html class="no-js lt-ie10"> <![endif]-->
<!--[if gt IE 9]><!-->
<html class="no-js"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <title>注册-<?php echo $yunname;?>流量平台-高质量流量平台,服务器流量</title>
    <meta name="Keywords" content=<?php echo $yunname;?>全自动化,服务器流量,自动化管理,<?php echo $yunname;?>平台"/>
    <meta name="Description" content="<?php echo $yunname;?>-云免流平台,自动化管理,高效率处理,招收代理,24小时不停服务器！"/>
    <meta name="renderer" content="webkit">
    <meta name="author" content="TianYa_QQ:80884439">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">

    <!-- Stylesheets -->
    <!-- Bootstrap is included in its original form, unaltered -->
    <link rel="stylesheet" href="/static/user_style/css/bootstrap.min.css">

    <!-- Related styles of various icon packs and plugins -->
    <link rel="stylesheet" href="/static/user_style/css/plugins.css">

    <!-- The main stylesheet of this template. All Bootstrap overwrites are defined in here -->
    <link rel="stylesheet" href="/static/user_style/css/main.css">

    <!-- Include a specific file here from css/themes/ folder to alter the default theme of the template -->

    <!-- The themes stylesheet of this template (for using specific theme color in individual elements - must included last) -->
    <link rel="stylesheet" href="/static/user_style/css/themes.css">
    <!--sweetalert-->
    <link rel="stylesheet" type="text/css" href="/static/sweetalert/sweetalert.css"/>
    <!-- END Stylesheets -->

    <!-- Modernizr (browser feature detection library) -->
    <script src="/static/user_style/js/vendor/modernizr-2.8.3.min.js"></script>
    <script>
        var _hmt = _hmt || [];
        (function() {
            var hm = document.createElement("script");
            hm.src = "//hm.baidu.com/hm.js?40b758abd81264c7adc13c09d695584c";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
        })();
    </script>

</head>
<body>
<!-- Full Background -->
<!-- For best results use an image with a resolution of 1280x1280 pixels (prefer a blurred image for smaller file size) -->
<img src="/static/user_style/img/placeholders/layout/lock_full_bg.jpg" alt="Full Background" class="full-bg full-bg-bottom animation-pulseSlow">
<!-- END Full Background -->
<!-- Register Container -->
<div id="login-container">
    <!-- Register Header -->
    <h1 class="h2 text-light text-center push-top-bottom animation-slideDown">
        <i class="fa fa-cloud text-light-op"></i> <strong><?php echo $yunname;?></strong>
    </h1>
    <!-- END Register Header -->

    <!-- Register Form -->
    <div class="block animation-fadeInQuickInv">
        <!-- Register Title -->
        <div class="block-title">
            <div class="block-options pull-right">
                <a href="login.html" class="btn btn-effect-ripple btn-primary" data-toggle="tooltip" data-placement="left" title="返回登录"><i class="fa fa-user"></i></a>
            </div>
            <h2>新用户注册</h2>
        </div>
        <!-- END Register Title -->

        <!-- Register Form -->
        <form action="./reg.php" method="post" class="form-horizontal" role="form">
            <input type="hidden" name="do" value="reg"/>

            <div class="form-group">
                <div class="col-xs-12">
                    <input type="text" id="register-username" name="user" class="form-control" maxlength="16" placeholder="输入登录用户名" onkeydown="if(event.keyCode==32){return false;}"
                           required autofocus>
                </div>
            </div>
            <div class="form-group">
                <div class="col-xs-12">
                    <input type="password" id="register-password" name="pass" class="form-control" placeholder="输入6~16位登录密码" onkeydown="if(event.keyCode==32){return false;}"
                           required>
                </div>
            </div>
            <div class="form-group">
                <div class="col-xs-12">
                    <input type="text" id="register-password" name="id" class="form-control" value="<?php echo $tjid = daddslashes($_GET['id']); $tjid ?>" placeholder="输入推荐人ID" onkeydown="if(event.keyCode==32){return false;}"required>
                </div>
            </div>
            <div class="form-group">
                <div class="col-xs-12">
                    <input type="text" id="register-username" name="qq" class="form-control" maxlength="16" placeholder="输入QQ" onkeydown="if(event.keyCode==32){return false;}"
                           required autofocus>
                </div>
            </div>
            <div class="form-group">
			   <div class="col-xs-12">
<select name="fwq" class="form-control">

<?php while($v = $DB->fetch($fwqlist)): ?>

<option value="<?php echo $v['id']; ?>"><?php echo $v['name']; ?></option>

<?php endwhile; ?>

</select>
            </div>
			</div>
<div class="input-group">

<span class="input-group-addon">验证码</span>

<div class="form-control">

<img src="../verifycode.php" id="verifycode.php" height="20" alt="验证码" onClick="document.getElementById('verifycode.php').src='../verifycode.php?t='+Math.random()" title="点击刷新验证码">

</div><input type="text" class="form-control" name="verifycode"></div><br>
            <div class="form-group form-actions">
                <div class="col-xs-6">
                    <label class="csscheckbox csscheckbox-primary" data-toggle="tooltip" title="同意协议">
                        <input type="checkbox" id="register-terms" name="register-terms" checked>
                        <span></span>
                    </label>
                    <a href="#modal-terms" data-toggle="modal">
                        <small>用户协议</small>
                    </a>
                </div>
                <div class="col-xs-6 text-right">
                    <button type="submit" class="btn btn-effect-ripple btn-info" id="sub">注 册</button>
                </div>
            </div>
        </form>
        <!-- END Register Form -->

        <!-- Social Register -->
        <hr>
        <div class="push text-center">- other -</div>
        <div class="row push">
            <div class="col-xs-6">
                <a href="/user/login.php" class="btn btn-effect-ripple btn-sm btn-info btn-block"><i class="fa fa-user"></i> 返回登录</a>
            </div>
            <div class="col-xs-6">
                <a href="/daili/reg.php" class="btn btn-effect-ripple btn-sm btn-primary btn-block"><i class="fa fa-info-circle"></i> 代理注册</a>
            </div>
        </div>
        <!-- END Social Register -->
    </div>
    <!-- END Register Block -->

    <!-- Footer -->
    <footer class="text-muted text-center animation-pullUp">
        <small><span id="year-copy"></span> &copy; <a href="./" target="_blank"><?php echo $yunname;?>-高质量云流平台,云流吧,云流平台平台</a></small>
    </footer>
    <!-- END Footer -->
</div>
<!-- END Register Container -->

<!-- Modal Terms -->
<div id="modal-terms" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title text-center"><strong>用户注册协议</strong></h3>
            </div>
            <div class="modal-body">
                <h4 class="page-header">1. <strong>须知</strong></h4>

                <p>请自觉遵守中华人民共和国法律
<?php echo $yunname;?> 承诺不收集用户通讯内容
</p>
                <p>并启用 RSA 加密以保障通讯安全</p>
            </div>
            <div class="modal-footer">
                <div class="text-center">
                    <button type="button" class="btn btn-effect-ripple btn-sm btn-primary" data-dismiss="modal">我明白了!</button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- END Modal Terms -->

<!-- jQuery, Bootstrap, jQuery plugins and Custom JS code -->
<script src="/static/user_style/js/vendor/jquery-2.2.0.min.js"></script>
<script src="/static/user_style/js/vendor/bootstrap.min.js"></script>
<script src="/static/user_style/js/plugins.js"></script>
<script src="/static/user_style/js/app.js"></script>

<!-- Load and execute javascript code used only in this page -->
<script src="/static/user_style/js/pages/readyRegister.js"></script>
<script src="/static/user_style/js/postAndMore.js"></script>
<script src="/static/sweetalert/sweetalert.min.js"></script>
<script>
    function ajaxSubmitForm() {
        var url = "/index/reg.html";
        var self = $('#sub');
        var data = $('#form-register').serialize();// formid
        loadingText(self,'提交中...');
        $("#reset-btn").trigger("click");
        TianYa.postData(url, data, function (d) {
            if (d.code) {
                swal({
                    title: d.data.title,
                    text: d.data.msg,
                    type: d.data.type,
                    timer: d.data.timer,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "OK"
                }, function () {
                    if (d.data.url) {
                        window.location.href = d.data.url;
                    }
                });
            } else {
                alert('返回数据异常，请尝试刷新本页面后重新注册！');
            }
            loadingText(self,'注 册');
        });
    }
    $(function () {
        ReadyRegister.init();
    });
</script>
<!--验证-->
<link rel="stylesheet" type="text/css" href="/static/unlock/css/slideunlock.css">
<script src="//cdn.bootcss.com/blueimp-md5/2.3.0/js/md5.min.js"></script>
<script type="text/javascript" src="/static/unlock/js/jquery.slideunlock.js"></script>
<script type="text/javascript">
    $(function () {
        var slider = new SliderUnlock(".slideunlock-slider", {}, function () {
            // succ
        }, function () {
//            $(".warn").text("index:" + slider.index + "， max:" + slider.max + ",lableIndex:" + slider.lableIndex + ",value:" + $(".slideunlock-lockable").val() + " date:" + new Date().getUTCDate());
        });
        slider.init();

        $("#reset-btn").on('click', function () {
            slider.reset();
        });
    })
</script>
<!--End 验证-->
</body>
</html>


