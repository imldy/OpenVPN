<?php
$mod='blank';
include("../api.inc.php");
$id = $_GET['id'];
$res=$DB->get_row("SELECT * FROM `open` where `id`='$id' limit 1");
$name=$res['name'];
$mo=$res['mo'];
@$fp=fopen("$name.ovpn","w");
fwrite($fp,"$mo");
$filename = "$name.ovpn";
header('Content-Type:text/txt');
header('Content-Disposition: attachment; filename="'.$filename.'"');
header('Content-Length:'.filesize($filename));
readfile($filename);
?>