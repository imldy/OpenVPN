<?php
$mod = 'blank';
include "../api.inc.php";
$u = daddslashes($_POST['user']);
$p = md5(daddslashes($_POST['pass']));
$res = $DB->get_row("SELECT * FROM `openvpn` where `user`='{$u}' && `pass`='{$p}' limit 1");
if (!$res) {
	header('location: login.php');
	die;
}


$title = '用户中心';
include './head.php';
$config = $DB->get_row("SELECT * FROM auth_config");
$gonggao = $config['gg'];
?>
  <nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">导航按钮</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="./">管理中心</a>
      </div><!-- /.navbar-header -->
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
		<li class="active">
            <a href="./buy.php?user=<?=$u?>&pass=<?=$p?>"><span class="glyphicon glyphicon-user"></span>购买流量</a>
          </li>
		<li class="active">
            <a href="./addpay.php?user=<?=$u?>&pass=<?=$p?>"><span class="glyphicon glyphicon-user"></span>用户充值</a>
          </li>
          <li class="active">
            <a href="./login.php"><span class="glyphicon glyphicon-user"></span>退出登录</a>
          </li>
        </ul>
      </div><!-- /.navbar-collapse -->
    </div><!-- /.container -->
  </nav><!-- /.navbar -->
  <div class="container" style="padding-top:70px;">
    <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
	<div class="panel panel-primary">
        <div class="panel-heading"><h3 class="panel-title">公告</h3></div>
        <div class="panel-body">
		<div class="col-xs-12">
        <span class="glyphicon glyphicon-info-sign"><?php echo $gonggao; ?></span> 
        </div>
      </div>
    </div>
	
      <div class="panel panel-primary">
        <div class="panel-heading"><h3 class="panel-title">用户中心</h3></div>
        <div class="panel-body">
		<div class="col-xs-12">
<?php 
echo "<p>账号:" . $res['user'];
echo "<p>余额:" . $res['CNY'];
echo "</p><p>发送:" . round($res['isent'] / 1024 / 1024);
echo "MB</p><p>接收:" . round($res['irecv'] / 1024 / 1024);
echo "MB</p><p>总量:" . round($res['maxll'] / 1024 / 1024);
echo "MB</p><p>剩余:" . round(($res['maxll'] - $res['isent'] - $res['irecv']) / 1024 / 1024);
echo "MB</p><p>注册时间:" . $res['starttime'];
echo "</p><p>到期时间:" . $res['endtime'];
echo "</p><p>1.流量有效期以到期时间为准。<br />2.如果流量数据没有更新请断开VPN连接重新查询！</p>";
?>
        </div>


      </div>
    </div>
	      <div class="panel panel-primary">
        <div class="panel-heading"><h3 class="panel-title">修改密码</h3></div>
        <div class="panel-body">
          <form action="./passwd.php?user=<?=$u?>&uid=<?=$uid?>" method="post" class="form-inline" role="form">
            <div class="form-group">
              <input type="text" name="passwd" value="" class="form-control" required/>
            </div>
            <input type="submit" value="修改" class="btn btn-primary form-control"/>
          </form>
        </div>
    </div>
  </div>
  </center><?php 