#!/bin/sh

DBHOST='localhost'
DBNAME='ov'
DBADMIN='root'
DBPASSWD='MySQLPass'

user=$common_name
#user="i"
mysql -h$DBHOST -u$DBADMIN -p$DBPASSWD -e "SELECT isent FROM openvpn WHERE iuser='$user';" $DBNAME>addlog.txt
mysql -h$DBHOST -u$DBADMIN -p$DBPASSWD -e "SELECT irecv FROM openvpn WHERE iuser='$user';" $DBNAME>>addlog.txt
recv=$(sed -n 2p addlog.txt)
sent=$(sed -n 4p addlog.txt)
recv=$[$recv+$bytes_sent]
sent=$[$sent+$bytes_received]
mysql -h$DBHOST -u$DBADMIN -p$DBPASSWD -e "UPDATE openvpn SET status=0 WHERE iuser='$user';" $DBNAME
mysql -h$DBHOST -u$DBADMIN -p$DBPASSWD -e "UPDATE openvpn SET isent = '$sent' WHERE iuser='$user';" $DBNAME
mysql -h$DBHOST -u$DBADMIN -p$DBPASSWD -e "UPDATE openvpn SET irecv = '$recv' WHERE iuser='$user';" $DBNAME
rm -rf addlog.txt
