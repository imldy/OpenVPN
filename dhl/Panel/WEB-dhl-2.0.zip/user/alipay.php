<?php

/* *
 * Code By 经典
 * 技术博客 http://lailailai.me
 * 
 * 本支付接口基于 金沙江支付平台 http://api.web567.net/
 */
 

/************★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★************/
include '../api.inc.php';
header("Content-type: text/html; charset=utf-8"); //如果中文乱码，改为UTF8编码

if($alipayid == "" or $alipaykey == "" or $alipayurl == ""){
	exit("<script language='javascript'>alert('收款帐号未设置，请仔细阅读说明文件！');history.back(-1);</script>");exit;
}
if(!$_GET['act']){//用户充值操作
	if(empty($_POST['total']) || empty($_GET['uid'])){
		exit("<script language='javascript'>alert('输入的信息不全！');history.back(-1);</script>");exit;
	}
	if(!is_numeric($_POST['total'])){
		exit("<script language='javascript'>alert('输入的金额不是数字！');history.back(-1);</script>");exit;
	}else if($_POST['total']<='0'){
		exit("<script language='javascript'>alert('输入的金额小于等于0！');history.back(-1);</script>");exit;
	}
	$uid = intval($_GET['uid']);
	if($uid<='0'){
		exit("<script language='javascript'>alert('输入的UID不正确！');history.back(-1);</script>");exit;
	}
		
	/******自定义订单信息*****/
    function generate_password( $length = 6 ){//随机6位加密字符
    // 密码字符集，可任意添加你需要的字符
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

    $password = '';
    for ( $i = 0; $i < $length; $i++ ) 
    {
         /* 这里提供两种字符获取方式
         第一种是使用 substr 截取$chars中的任意一位字符；
         第二种是取字符数组 $chars 的任意元素
        $password .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);*/
        $password .= $chars[ mt_rand(0, strlen($chars) - 1) ];
    }

        return $password;
    }
    $round = generate_password();
    $time = date('m').date('d').date('H').date('i').date('s');
    $addnum = 'alip'.$alipayid.'T'.$time.'R'.$round;
	/******自定义订单信息*****/
	
	$user = $_GET['user'];
	$total = $_POST['total'];					//post得到的支付金额 		【必须为整数或者带小数点的数字】
	$uid = $_GET['uid'];						//post得到的支付会员编号	【支付成功要给此会员操作增加现金、道具、积分、提示等操作】
	$apiid = $alipayid;						    //您的apiid 	【用于给您的账户增加收入】
	$apikey = md5($alipaykey);					//您的apikey	【用于支付安全验证】
	$showurl = $alipayurl.'/user/alipay.php?act=return';	//回调地址，见下		【用于反馈支付状态到贵站】
    
	$DB->query("INSERT INTO `auth_alipay`(`uid`,`user`, `total`, `addnum`, `time`, `status`) VALUES ('{$uid}' ,'{$user}' ,'{$total}' ,'{$addnum}' ,NOW() , '未付款')");//订单信息存入数据库，并且状态为'未付款'
	
	echo "
		<form name='form1' action='http://api.web567.net/plugin.php?id=add:alipay' method='POST'>
		    <input type='hidden' name='addnum' value='".$addnum."'>
			<input type='hidden' name='uid' value='".$uid."'>
			<input type='hidden' name='total' value='".$total."'>
			<input type='hidden' name='apiid' value='".$apiid."'>
			<input type='hidden' name='showurl' value='".$showurl."'>
			<input type='hidden' name='apikey' value='".$apikey."'>
		</form>
		<script>window.onload=function(){document.form1.submit();}</script> 
	";
}

/************★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★************/


if($_GET['act']=='return' or $_GET['act']=='bd'){	//返回地址
	$addnum = $_POST['addnum'] ? $_POST['addnum'] : $_GET['addnum'];		//接收到的订单编号
	$uid = $_POST['uid'] ? $_POST['uid'] : $_GET['uid'];				//接收到的支付会员编号
	$total = $_POST['total'] ? $_POST['total'] : $_GET['total'];			//接收到的支付金额
	$apikey = $_POST['apikey'] ? $_POST['apikey'] : $_GET['apikey'];		//接收到的验证加密字串


	if($apikey!=md5($alipaykey.$addnum)){		//此处代码的作用是：验证加密字串是否正确。
        exit("<script language='javascript'>alert('支付来路不正确，请重新支付！');window.location.href='../index.php';</script>");exit;//如果验证加密字串不正确的话就是非法回调，存在资金安全问题。让他跳转到首页去或者其他提示。
	}else{//验证成功，正常执行代码			
		$res = $DB->get_row("SELECT * FROM `auth_alipay` WHERE `addnum`='{$addnum}'");//查询数据库是否存在该订单
        if($res){
            $result = $DB->get_row("SELECT * FROM `auth_alipay` WHERE `addnum`='{$addnum}' and `status`='未付款'");//查询该订单是否为 '未付款'状态
            if($result){//第一次异步通知
                $DB->query("UPDATE `auth_alipay` SET `status` = '已付款' WHERE `addnum`='{$addnum}'"); //更新该订单为已付款状态
                $DB->query("UPDATE `openvpn` SET `CNY` = '{$total}' WHERE `id`='{$uid}'"); //为该订单的会员执行加款操作
            }else{//第二次同步通知
                exit("<script language='javascript'>alert('充值成功！');window.location.href='../index.php';</script>");exit;
            }
        }else{
            exit("<script language='javascript'>alert('充值失败，没有查询到该订单信息！');window.location.href='../index.php';</script>");exit; //订单不存在
        }
	}
}
/************★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★************/
?>