#! /bin/bash
DB='openvpn'
DBADMIN='root'
DBPASSWD='roottoor'
host='localhost'
port='3306'
mysql -h$host -P$port -u$DBADMIN -p$DBPASSWD -e "INSERT into log(username,start_time,trusted_ip,trusted_port,protocol,remote_ip,remote_netmask,status) VALUES('$common_name',now(),'$trusted_ip',$trusted_port,'$proto_1','$ifconfig_pool_remote_ip','$route_netmask_1',1)" $DB
mysql -h$host -P$port -u$DBADMIN -p$DBPASSWD -e "INSERT INTO stat (username) VALUES ('$common_name') ON DUPLICATE KEY UPDATE username=username;" $DB
mysql -h$host -P$port -u$DBADMIN -p$DBPASSWD -e "UPDATE stat SET origin_time=now() where origin_time='0000-00-00 00:00:00' and username='$common_name';" $DB
mysql -h$host -P$port -u$DBADMIN -p$DBPASSWD -e "UPDATE user SET use_cycle=(TO_DAYS(NOW()) - TO_DAYS(creation)) WHERE username='$common_name';" $DB
mysql -h$host -P$port -u$DBADMIN -p$DBPASSWD -e "UPDATE user SET surplus_cycle=(quota_cycle - use_cycle) WHERE username='$common_name';" $DB
mysql -h$host -P$port -u$DBADMIN -p$DBPASSWD -e "UPDATE user SET enabled=1 WHERE username='$common_name';" $DB
mysql -h$host -P$port -u$DBADMIN -p$DBPASSWD -e "UPDATE user SET active=0 WHERE (quota_cycle - use_cycle) <= 0 AND username='$common_name';" $DB
