<?php
@eval("//Encode by  phpjiami.com,Free user."); ?><?php

$mod='blank';
include("../api.inc.php");
$title='添加价格';
include './head.php';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
include './nav.php';
?>
    <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<?php
if($_POST['llpg']){
echo '<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">添加账号结果</h3></div>
<div class="panel-body">';
$llpg = daddslashes($_POST['llpg'])*1024*1024;
$day = daddslashes($_POST['day']);
$price = daddslashes($_POST['price']);

if(!$DB->get_row("select * from `auth_price` where `llpg`='$llpg' limit 1")){
	$sql="insert into `auth_price` (`llpg`,`day`,`price`,`time`) values ('{$llpg}','{$day}','{$price}',NOW())";
	if($DB->query($sql))
		echo "成功添加一个价格";
	else
		echo "添加失败：".$DB->error();
}else{
	echo "<script>alert('该价格已存在！');history.go(-1);</script>";
}
echo '<hr/><a href="./addprice.php">>>返回继续添加</a><br><a href="./price.php">>>返回价格列表</a></div></div>';
exit;
}
?>
      <div class="panel panel-primary">
        <div class="panel-heading"><h3 class="panel-title">添加价格</h3></div>
        <div class="panel-body">
          <form action="./addprice.php" method="post" class="form-horizontal" role="form">
            <div class="input-group">
			  <span class="input-group-addon">流量包(M)</span>
              <input type="text" name="llpg" value="" class="form-control" required/>
            </div><br/>
            <div class="input-group">
              <span class="input-group-addon">时长(天）</span>
			  <input type="text" name="day" value="" class="form-control" required>
            </div><br/>
            <div class="input-group">
              <span class="input-group-addon">价格(元)</span>
			  <input type="text" name="price" value="" class="form-control" required>
            </div><br/>
            <input type="submit" value="添加" class="btn btn-primary form-control"/>
          </form>
        </div>
      </div>
    </div>
  </div>
  <script src="../datepicker/WdatePicker.js"></script><?php 