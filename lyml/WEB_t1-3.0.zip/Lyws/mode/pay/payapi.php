<?php
/* *
 * 功能：向快支付接口发送交易信息
 * 
 * 以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 * 该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
 */
require_once("../../../Data/api.inc.php");
$row = $DB->get_row("SELECT * FROM `Ly_pay`");
$logo = $DB->get_row("SELECT * FROM `Lyun`");
echo '<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>'.$logo[logo].'在线购买</title>
</head>';
/**************************请求参数**************************/
        //快支付API接口地址
        $kypay = 'http://pay.kypay.top/';

        //页面跳转同步通知页面路径
        $return_url = $row['url'];
		
        if($_GET['dlid'] == '0'){
		
        //商户账号
        $alipay_user		= $row['user'];

        //商户KEY
        $alipay_pass		= $row['key'];
		
		}else{
			
		$res = $DB->get_row("SELECT * FROM `auth_daili` where id='{$_GET['dlid']}'");
			
		//代理商户账号
        $alipay_user		= $res['PayUser'];

        //代理商户KEY
        $alipay_pass		= $res['PayKey'];	
		}
        //商户订单号
        $out_trade_no = date("YmdHis").mt_rand(1000,9999);
        //商户网站订单系统中唯一订单号，必填

		//支付方式
        $type = $_POST['shop_pay'];
        //商品名称
		if($_POST['shop_name'] == ""){
         exit("<script language='javascript'>alert('亲，请选择商品再购买哦！');history.go(-1);</script>");
		}
        $name = $_POST['shop_name'];
		//付款金额
		$sqlA="SELECT * FROM `Ly_tc` where `name`='{$name}' && dlid='{$_GET['dlid']}'";
		$buy = $DB->get_row($sqlA);
        $money = $buy['money'];
		//站点名称
        $sitename = $logo[logo].'流量购买';

        //加密该订单交易信息
        $basetrade = base64_encode($out_trade_no);
		$baseurl = base64_encode($return_url);

/************************************************************/
$sql="insert into `Ly_buy` (`trade`,`i`,`tc`,`money`,`user`,`dlid`,`time`) values ('{$out_trade_no}',0,'{$name}','{$money}','{$_GET['u']}','{$_GET['dlid']}','".time()."')";
if ($DB->query($sql)){
$HOST = ''.$kypay.'api.php?money='.$money.'&sitename='.$sitename.'&name='.$name.'&type='.$type.'&return_url='.$baseurl.'&user='.$alipay_user.'&sing='.$basetrade.'';
exit("<script language='javascript'>window.location.href='".$HOST."';</script>");
}else{
exit("<script language='javascript'>alert('支付接口发生未知错误，请稍后再试！');history.go(-1);</script>");
}
?>
</body>
</html>