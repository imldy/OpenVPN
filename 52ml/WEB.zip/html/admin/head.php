<?php
@eval("//www.zhaoyuanma.com 免费版本加密! "); ?><?php
@eval("//Encode by  phpjiami.com,Free user."); ?><?php
/**
 * 管理中心
**/

$title='管理中心';
//读取图片换头像
 srand( microtime() * 1000000 );
 $num = rand( 1, 4 );
   
 switch( $num )
 {
 case 1: $image_file = "./sjimg/1.jpg";
     break;
 case 2: $image_file = "./sjimg/2.jpg";
     break;
 case 3: $image_file = "./sjimg/3.jpg";
     break;
 case 4: $image_file = "./sjimg/4.jpg";
     break;
 }
?>
<!DOCTYPE html>
<html lang="en" class="app"><head>
        <meta charset="utf-8" />
        <title>
            用户中心-
            用户名接口
        </title>
        <meta name="description" content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav"
        />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"
        />
        <link rel="stylesheet" href="/static/index/css/app.v2.css" type="text/css"
        />
        <link rel="stylesheet" href="/static/index/js/calendar/bootstrap_calendar.css"
        type="text/css" cache="false" />
<?php
$url = $_SERVER['PHP_SELF'];
if ($url == '/admin/index.php') {
    echo '
<script src="/static/qqlogin/jquery-2.2.0.min.js"></script>
<script src="/static/qqlogin/qqlogin.js"></script>
<script src="/static/qqlogin/login.js"></script>';
}
?>
<!--[if lt IE 9]>
<script src="/static/index/js/ie/html5shiv.js" cache="false"></script>
<script src="/static/index/js/ie/respond.min.js" cache="false"></script>
<script src="/static/index/js/ie/excanvas.js" cache="false"></script>
<![endif]-->
</head>
<body>
<section class="vbox">
<header class="bg-dark dk header navbar navbar-fixed-top-xs">
<div class="navbar-header aside-md">
	<a class="btn btn-link visible-xs" data-toggle="class:nav-off-screen" data-target="#nav"><i class="fa fa-bars"></i></a><a href="#" class="navbar-brand" data-toggle="fullscreen"><img src="/static/index/images/logo.png" class="m-r-sm">麒麟团队云流管理</a><a class="btn btn-link visible-xs" data-toggle="dropdown" data-target=".nav-user"><i class="fa fa-cog"></i></a>
</div>
<ul class="nav navbar-nav hidden-xs">
	<li class="dropdown"><a href="#" class="dropdown-toggle dker" data-toggle="dropdown"><i class="fa fa-building-o"></i><span class="font-bold"> 信息</span></a>
	<section class="dropdown-menu aside-xl on animated fadeInLeft no-borders lt">
	<div class="wrapper lter m-t-n-xs">
		<a href="#" class="thumb pull-left m-r"><img src="<?=$image_file?>" class="img-circle"></a>
		<div class="clear">
			<span class="text-white font-bold"><?php echo $row['user'] ?></span><small class="block">#<?php echo $row['lastip'] ?></small><a href="index.php" class="btn btn-xs btn-success m-t-xs"></a>
		</div>
	</div>
	<div class="row m-l-none m-r-none m-b-n-xs text-center">
		<div class="col-xs-12">
			<div class="padder-v">
				<span class="m-b-xs h4 block text-white">
				<?php echo $DB->count("select count(qid) as count from " . DBQZ . "_qq where uid='$row[uid]'") ?>
				</span><small class="text-muted">deer</small>
			</div>
		</div>
	</div>
	</section>
	</li>
	<li>
	<div class="m-t m-l">
		<a href="./update.php" class="dropdown-toggle btn btn-xs btn-primary" title="更新"><i class="fa fa-long-arrow-up"></i></a>
	</div>
	</li>
</ul>
<ul class="nav navbar-nav navbar-right hidden-xs nav-user">
	<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="thumb-sm avatar pull-left"><img src="<?=$image_file?>"></span> <?php echo $row['user'] ?> <b class="caret"></b></a>
	<ul class="dropdown-menu animated fadeInRight">
		<span class="arrow top"></span>
		<li><a href="./login.php?logout">退出</a></li>
	</ul>
	</li>
</ul>
</header>
<section>
<section class="hbox stretch">
<aside class="bg-light lter b-r aside-md hidden-print" id="nav">
<section class="vbox">
<section class="w-f scrollable">
<div class="slim-scroll" data-height="auto" data-disable-fade-out="true" data-distance="0" data-size="5px" data-color="#333333">
	<!-- nav -->
	<nav class="nav-primary hidden-xs">
	<ul class="nav">
		<li class="active"><a href="index.php" class="active"><i class="fa fa-dashboard icon"><b class="bg-danger"></b></i><span>平台首页</span></a></li>
		<li><a href="#layout"><i class="fa fa-columns icon"><b class="bg-warning"></b></i><span class="pull-right"><i class="fa fa-angle-down text"></i><i class="fa fa-angle-up text-active"></i></span><span>服务器管理
</span></a>
		<ul class="nav lt">
			<li><a href="./log.php"><i class="fa fa-angle-right"></i><span>操作记录</span></a></li>
            <li><a href="./fwqlist.php"><i class="fa fa-angle-right"></i><span>服务器列表</span></a></li>
            <li><a href="./addfwq.php"><i class="fa fa-angle-right"></i><span>添加服务器</span></a></li>
            <li><a href="./online.php"><i class="fa fa-angle-right"></i><span>在线用户</span></a></li>
			
		</ul>
		</li>
		<li><a href="#uikit"><i class="fa fa-flask icon"><b class="bg-success"></b></i><span class="pull-right"><i class="fa fa-angle-down text"></i><i class="fa fa-angle-up text-active"></i></span><span>账号管理</span></a>
		<ul class="nav lt">
			<li><a href="./pladd.php"><b class="badge bg-info pull-right"></b><i class="fa fa-angle-right"></i><span>批量添加账号</span></a></li>
			<li><a href="./addqq.php"><b class="badge bg-info pull-right"></b><i class="fa fa-angle-right"></i><span>添加账号</span></a></li>
            <li><a href="./qqlist.php"><b class="badge bg-info pull-right"><?php echo $DB->
                                            count("select count(uid) as count from " . DBQZ . "_user where 1=1") ?></b><i class="fa fa-angle-right"></i><span>账号列表</span></a></li>
			<li><a href="./daochu.php"><b class="badge bg-info pull-right"></b><i class="fa fa-angle-right"></i><span>导出账号</span></a></li>
		</ul>
		</li>
		
		<li>
		<a href="#admin"><i class="fa fa-file-text icon"><b class="bg-primary"></b></i><span class="pull-right"><i class="fa fa-angle-down text"></i><i class="fa fa-angle-up text-active"></i></span><span>卡密管理</span></a>
		<ul class="nav lt">
			<li><a href="./kmlist.php"><i class="fa fa-angle-right"></i><span>卡密列表</span></a></li>
			<li><a href="./search.php"><i class="fa fa-angle-right"></i><span>搜索卡密</span></a></li>
			
		</ul>
		</li>
	
<li>
		<a href="#layout"><i class="fa fa-coffee icon"><b class="bg-success"></b></i><span class="pull-right"><i class="fa fa-angle-down text"></i><i class="fa fa-angle-up text-active"></i></span><span>代理管理</span></a>
		<ul class="nav lt">
			<li><a href="./daili.php"><i class="fa fa-angle-right"></i><span>代理用户管理</span></a></li>
			<li><a href="./dlconfig.php"><i class="fa fa-angle-right"></i><span>代理页面管理</span></a></li>
			<li><a href="./dlkm.php"><i class="fa fa-angle-right"></i><span>代理卡密管理</span></a></li>
		</ul>
		</li>





		<li><a href="./login.php?logout"><i class="fa fa-power-off icon"><b class="bg-info"></b></i><span>退出Login</span></a></li>
	</ul>
	</nav>
	<!-- / nav -->
</div>
</section>
<footer class="footer lt hidden-xs b-t b-light">
            <a href="#nav" data-toggle="class:nav-xs" class="pull-right btn btn-sm btn-default btn-icon"> <i class="fa fa-angle-left text"></i> <i class="fa fa-angle-right text-active"></i> </a>
            <div class="btn-group hidden-nav-xs">
              <button type="button" title="Chats" class="btn btn-icon btn-sm btn-default" data-toggle="dropdown" data-target="#chat"><i class="fa fa-comment-o"></i></button>
              <button type="button" title="Contacts" class="btn btn-icon btn-sm btn-default" data-toggle="dropdown" data-target="#invite"><i class="fa fa-facebook"></i></button>
            </div>
          </footer>
</section>
</aside>
<!-- /.aside -->
<?php  