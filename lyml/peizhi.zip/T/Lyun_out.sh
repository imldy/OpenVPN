#!/bin/bash
#负载集群请直接使用官网脚本

# 获取系统设定的参数
source /etc/Lyun/Lyun.conf

php /Data/wwwroot/Lyun/Lyws/user_out.php "$common_name" "$bytes_received" "$bytes_sent"