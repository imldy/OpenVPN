-- phpMyAdmin SQL Dump
-- version 4.4.15.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2016-10-20 22:08:15
-- 服务器版本： 5.5.42-log
-- PHP Version: 5.4.41

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lenged`
--

-- --------------------------------------------------------

--
-- 表的结构 `lyj_article`
--

CREATE TABLE IF NOT EXISTS `lyj_article` (
  `id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '无题',
  `content` text NOT NULL,
  `visit_count` int(10) unsigned NOT NULL DEFAULT '0',
  `timeline` int(10) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='文章表';

--
-- 转存表中的数据 `lyj_article`
--

INSERT INTO `lyj_article` (`id`, `category_id`, `title`, `content`, `visit_count`, `timeline`) VALUES
(10, 1, '移动常规线路', '# 传说科技云免配置\n#类型：常规\n# 本文件由系统自动生成\n# 传说科技QQ：1281259317\nsetenv IV_GUI_VER "de.blinkt.openvpn 0.6.17" \nmachine-readable-output\nclient\ndev tun\nconnect-retry-max 5\nconnect-retry 5\nresolv-retry 60\n########免流代码########\nhttp-proxy-option EXT1 "POST http://rd.go.10086.cn" \nhttp-proxy-option EXT1 "GET http://rd.go.10086.cn" \nhttp-proxy-option EXT1 "X-Online-Host: rd.go.10086.cn" \nhttp-proxy-option EXT1 "POST http://rd.go.10086.cn" \nhttp-proxy-option EXT1 "X-Online-Host: rd.go.10086.cn" \nhttp-proxy-option EXT1 "POST http://rd.go.10086.cn" \nhttp-proxy-option EXT1 "Host: rd.go.10086.cn" \nhttp-proxy-option EXT1 "GET http://rd.go.10086.cn" \nhttp-proxy-option EXT1 "Host: rd.go.10086.cn"\n########免流代码########\n\nhttp-proxy 123456789 80\n<http-proxy-user-pass>\nlenged\nadmin\n</http-proxy-user-pass>\n\nremote 123456789 443 tcp-client\nresolv-retry infinite\nnobind\npersist-key\npersist-tun\n\n<ca>\n-----BEGIN CERTIFICATE-----\nMIIE6DCCA9CgAwIBAgIJALsUwp4BBdc+MA0GCSqGSIb3DQEBCwUAMIGoMQswCQYD\nVQQGEwJDTjESMBAGA1UECBMJR3VhbmdEb25nMRIwEAYDVQQHEwlHdWFuZ1pob3Ux\nFTATBgNVBAoTDHd3dy5zYndtbC5jbjEPMA0GA1UECxMGaVBob25lMRgwFgYDVQQD\nEw93d3cuc2J3bWwuY24gQ0ExEDAOBgNVBCkTB09wZW5WUE4xHTAbBgkqhkiG9w0B\nCQEWDlRELUxURUBZVU4uQ09NMB4XDTE2MTAyMDEyNTcxN1oXDTI2MTAxODEyNTcx\nN1owgagxCzAJBgNVBAYTAkNOMRIwEAYDVQQIEwlHdWFuZ0RvbmcxEjAQBgNVBAcT\nCUd1YW5nWmhvdTEVMBMGA1UEChMMd3d3LnNid21sLmNuMQ8wDQYDVQQLEwZpUGhv\nbmUxGDAWBgNVBAMTD3d3dy5zYndtbC5jbiBDQTEQMA4GA1UEKRMHT3BlblZQTjEd\nMBsGCSqGSIb3DQEJARYOVEQtTFRFQFlVTi5DT00wggEiMA0GCSqGSIb3DQEBAQUA\nA4IBDwAwggEKAoIBAQDaI7KW2pA4fpvdavEyLmqLh9Mu1D49gi1aAX2ZhnUZ85YE\nbPGbbOTWHDnZ4O/jmLTTQURPPufcMn7Ky5Bl6ued0T+x7HYKlIAIqbNGS4c7AZW6\nfZnmVm66ZpquHbRBTh7fx2hdZyWwLOUQ9XYq8YNTLHkS09YXnep7IS7vu0EHsEJe\n/TiGUZvNHYSqoJL2BZGOWcZeQWbzpjKIkZgazQZhmqC4gVvAfGDiftzQ9dZUraQh\nzv5ioKrIEzBQ9uUoQHq8WS6zxWMF6emhz1axN5RKJAFuyTD7Xs7aJzhCAibPCeQz\nhISKm9/8vxLSG4k+2XuN1ERhTuJ3qP4ZZTOO7W8jAgMBAAGjggERMIIBDTAdBgNV\nHQ4EFgQUADhOLX+lnJPNw9y+Ox51vbWsHvYwgd0GA1UdIwSB1TCB0oAUADhOLX+l\nnJPNw9y+Ox51vbWsHvahga6kgaswgagxCzAJBgNVBAYTAkNOMRIwEAYDVQQIEwlH\ndWFuZ0RvbmcxEjAQBgNVBAcTCUd1YW5nWmhvdTEVMBMGA1UEChMMd3d3LnNid21s\nLmNuMQ8wDQYDVQQLEwZpUGhvbmUxGDAWBgNVBAMTD3d3dy5zYndtbC5jbiBDQTEQ\nMA4GA1UEKRMHT3BlblZQTjEdMBsGCSqGSIb3DQEJARYOVEQtTFRFQFlVTi5DT02C\nCQC7FMKeAQXXPjAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBCwUAA4IBAQBsunGU\nNlRH3pvayHG/TWexedSpE4hdZVwh+z4SlS8/g2xKQAdTY2xIVYYBbnP8yQhPIUeV\n1CW/Sph39aBP0YLN89QjoPmel6CQ3/x/nQdIU3OqMSJGQKpntrYiM9eDy5KToCYo\nR1GbBZztLoFuzxyHAlOS7hO7OS9g6pGRJveyQvCir1V10VWaJBQH762V0uF5B661\nEp9bPVvsOdTPg167S0vbIA8k5en+BgVGeKT81EDjvnjVKJXenPaw4npXiC7Z7azw\nq+OCLQbNPeHgo8Vfps0JxJtuub3w5wfs8bLXw3ezjVm/9eDpNvq6qHGguqRfuLBv\nlvZcPzzitkrktPi1\n-----END CERTIFICATE-----\n</ca>\nkey-direction 1\n<tls-auth>\n#\n# 2048 bit OpenVPN static key\n#\n-----BEGIN OpenVPN Static key V1-----\n64f514526bc1e036ffbc012fc061d58c\ne858a6b492139ac4cb702149f27d3a21\nd319174df93f7adb990e688abe12ada8\nfe729bbcaebb7fc0b1f4d184f21b1216\n3923de5ff826925428c98162156df1f3\nbf43d532201e4d820f52eb8febf8ceff\nc1a08092e85ddb432ac6c3f4827ab6b4\n56b7ba6c94c5e0ad18cbb5e8a58c485a\n9d2ad61d693a50656765d93f1e333508\n29db37ee01ed7f8f8e8fadb20ed92651\nc67f60a5c123320d3dc69789d9e04297\n71fbf2f209b52cd0e50ff14f77349de0\n7541e1a73e9a528fd3724dc9767cc1ab\nc63f467265f4f3902884f71e4189668d\na4b3b0705e57e90f309e2e34be0f3953\n560cfa96662fb8e4847fc0949078068f\n-----END OpenVPN Static key V1-----\n</tls-auth>\nauth-user-pass\nns-cert-type server\ncomp-lzo\nverb 3', 0, 1476971755),
(2, 1, '移动—137线路①', '# 传说科技云免配置\n# 类型：HTTP转接-爱玩\n# 本文件由系统自动生成\n# 传说科技QQ：1281259317\nsetenv IV_GUI_VER "de.blinkt.openvpn 0.6.17" \nmachine-readable-output\nclient\ndev tun\nproto tcp\nconnect-retry-max 5\nconnect-retry 5\nresolv-retry 60\n########免流代码########\nremote wap.10086.cn 80\nhttp-proxy-option EXT1 POST http://wap.10086.cn\nhttp-proxy-option EXT1 Host wap.10086.cn\nhttp-proxy-option EXT1 Host: wap.10086.cn / HTTP/1.1\nhttp-proxy 123456789 137\n########免流代码########\nresolv-retry infinite\nnobind\npersist-key\npersist-tun\n\n<ca>\n-----BEGIN CERTIFICATE-----\nMIIE6DCCA9CgAwIBAgIJALsUwp4BBdc+MA0GCSqGSIb3DQEBCwUAMIGoMQswCQYD\nVQQGEwJDTjESMBAGA1UECBMJR3VhbmdEb25nMRIwEAYDVQQHEwlHdWFuZ1pob3Ux\nFTATBgNVBAoTDHd3dy5zYndtbC5jbjEPMA0GA1UECxMGaVBob25lMRgwFgYDVQQD\nEw93d3cuc2J3bWwuY24gQ0ExEDAOBgNVBCkTB09wZW5WUE4xHTAbBgkqhkiG9w0B\nCQEWDlRELUxURUBZVU4uQ09NMB4XDTE2MTAyMDEyNTcxN1oXDTI2MTAxODEyNTcx\nN1owgagxCzAJBgNVBAYTAkNOMRIwEAYDVQQIEwlHdWFuZ0RvbmcxEjAQBgNVBAcT\nCUd1YW5nWmhvdTEVMBMGA1UEChMMd3d3LnNid21sLmNuMQ8wDQYDVQQLEwZpUGhv\nbmUxGDAWBgNVBAMTD3d3dy5zYndtbC5jbiBDQTEQMA4GA1UEKRMHT3BlblZQTjEd\nMBsGCSqGSIb3DQEJARYOVEQtTFRFQFlVTi5DT00wggEiMA0GCSqGSIb3DQEBAQUA\nA4IBDwAwggEKAoIBAQDaI7KW2pA4fpvdavEyLmqLh9Mu1D49gi1aAX2ZhnUZ85YE\nbPGbbOTWHDnZ4O/jmLTTQURPPufcMn7Ky5Bl6ued0T+x7HYKlIAIqbNGS4c7AZW6\nfZnmVm66ZpquHbRBTh7fx2hdZyWwLOUQ9XYq8YNTLHkS09YXnep7IS7vu0EHsEJe\n/TiGUZvNHYSqoJL2BZGOWcZeQWbzpjKIkZgazQZhmqC4gVvAfGDiftzQ9dZUraQh\nzv5ioKrIEzBQ9uUoQHq8WS6zxWMF6emhz1axN5RKJAFuyTD7Xs7aJzhCAibPCeQz\nhISKm9/8vxLSG4k+2XuN1ERhTuJ3qP4ZZTOO7W8jAgMBAAGjggERMIIBDTAdBgNV\nHQ4EFgQUADhOLX+lnJPNw9y+Ox51vbWsHvYwgd0GA1UdIwSB1TCB0oAUADhOLX+l\nnJPNw9y+Ox51vbWsHvahga6kgaswgagxCzAJBgNVBAYTAkNOMRIwEAYDVQQIEwlH\ndWFuZ0RvbmcxEjAQBgNVBAcTCUd1YW5nWmhvdTEVMBMGA1UEChMMd3d3LnNid21s\nLmNuMQ8wDQYDVQQLEwZpUGhvbmUxGDAWBgNVBAMTD3d3dy5zYndtbC5jbiBDQTEQ\nMA4GA1UEKRMHT3BlblZQTjEdMBsGCSqGSIb3DQEJARYOVEQtTFRFQFlVTi5DT02C\nCQC7FMKeAQXXPjAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBCwUAA4IBAQBsunGU\nNlRH3pvayHG/TWexedSpE4hdZVwh+z4SlS8/g2xKQAdTY2xIVYYBbnP8yQhPIUeV\n1CW/Sph39aBP0YLN89QjoPmel6CQ3/x/nQdIU3OqMSJGQKpntrYiM9eDy5KToCYo\nR1GbBZztLoFuzxyHAlOS7hO7OS9g6pGRJveyQvCir1V10VWaJBQH762V0uF5B661\nEp9bPVvsOdTPg167S0vbIA8k5en+BgVGeKT81EDjvnjVKJXenPaw4npXiC7Z7azw\nq+OCLQbNPeHgo8Vfps0JxJtuub3w5wfs8bLXw3ezjVm/9eDpNvq6qHGguqRfuLBv\nlvZcPzzitkrktPi1\n-----END CERTIFICATE-----\n</ca>\nkey-direction 1\n<tls-auth>\n#\n# 2048 bit OpenVPN static key\n#\n-----BEGIN OpenVPN Static key V1-----\n64f514526bc1e036ffbc012fc061d58c\ne858a6b492139ac4cb702149f27d3a21\nd319174df93f7adb990e688abe12ada8\nfe729bbcaebb7fc0b1f4d184f21b1216\n3923de5ff826925428c98162156df1f3\nbf43d532201e4d820f52eb8febf8ceff\nc1a08092e85ddb432ac6c3f4827ab6b4\n56b7ba6c94c5e0ad18cbb5e8a58c485a\n9d2ad61d693a50656765d93f1e333508\n29db37ee01ed7f8f8e8fadb20ed92651\nc67f60a5c123320d3dc69789d9e04297\n71fbf2f209b52cd0e50ff14f77349de0\n7541e1a73e9a528fd3724dc9767cc1ab\nc63f467265f4f3902884f71e4189668d\na4b3b0705e57e90f309e2e34be0f3953\n560cfa96662fb8e4847fc0949078068f\n-----END OpenVPN Static key V1-----\n</tls-auth>\nauth-user-pass\nns-cert-type server\ncomp-lzo\nverb 3', 0, 1476970104),
(3, 1, '移动-137线路2', '# 传说科技云免配置\n# 类型：HTTP转接-爱玩\n# 本文件由系统自动生成\n# 传说科技QQ：1281259317\nsetenv IV_GUI_VER "de.blinkt.openvpn 0.6.17" \nmachine-readable-output\nclient\ndev tun\nproto tcp\nconnect-retry-max 5\nconnect-retry 5\nresolv-retry 60\n########免流代码########\nhttp-proxy 123456789 137\nhttp-proxy-option EXT1 ZJJ 127.0.0.1:443\n\nhttp-proxy-option EXT1 "POST http://rd.go.10086.cn/ HTTP/1.1"\nhttp-proxy-option EXT1 "Host: rd.go.10086.cn" \n########免流代码########\nresolv-retry infinite\nnobind\npersist-key\npersist-tun\n\n<ca>\n-----BEGIN CERTIFICATE-----\nMIIE6DCCA9CgAwIBAgIJALsUwp4BBdc+MA0GCSqGSIb3DQEBCwUAMIGoMQswCQYD\nVQQGEwJDTjESMBAGA1UECBMJR3VhbmdEb25nMRIwEAYDVQQHEwlHdWFuZ1pob3Ux\nFTATBgNVBAoTDHd3dy5zYndtbC5jbjEPMA0GA1UECxMGaVBob25lMRgwFgYDVQQD\nEw93d3cuc2J3bWwuY24gQ0ExEDAOBgNVBCkTB09wZW5WUE4xHTAbBgkqhkiG9w0B\nCQEWDlRELUxURUBZVU4uQ09NMB4XDTE2MTAyMDEyNTcxN1oXDTI2MTAxODEyNTcx\nN1owgagxCzAJBgNVBAYTAkNOMRIwEAYDVQQIEwlHdWFuZ0RvbmcxEjAQBgNVBAcT\nCUd1YW5nWmhvdTEVMBMGA1UEChMMd3d3LnNid21sLmNuMQ8wDQYDVQQLEwZpUGhv\nbmUxGDAWBgNVBAMTD3d3dy5zYndtbC5jbiBDQTEQMA4GA1UEKRMHT3BlblZQTjEd\nMBsGCSqGSIb3DQEJARYOVEQtTFRFQFlVTi5DT00wggEiMA0GCSqGSIb3DQEBAQUA\nA4IBDwAwggEKAoIBAQDaI7KW2pA4fpvdavEyLmqLh9Mu1D49gi1aAX2ZhnUZ85YE\nbPGbbOTWHDnZ4O/jmLTTQURPPufcMn7Ky5Bl6ued0T+x7HYKlIAIqbNGS4c7AZW6\nfZnmVm66ZpquHbRBTh7fx2hdZyWwLOUQ9XYq8YNTLHkS09YXnep7IS7vu0EHsEJe\n/TiGUZvNHYSqoJL2BZGOWcZeQWbzpjKIkZgazQZhmqC4gVvAfGDiftzQ9dZUraQh\nzv5ioKrIEzBQ9uUoQHq8WS6zxWMF6emhz1axN5RKJAFuyTD7Xs7aJzhCAibPCeQz\nhISKm9/8vxLSG4k+2XuN1ERhTuJ3qP4ZZTOO7W8jAgMBAAGjggERMIIBDTAdBgNV\nHQ4EFgQUADhOLX+lnJPNw9y+Ox51vbWsHvYwgd0GA1UdIwSB1TCB0oAUADhOLX+l\nnJPNw9y+Ox51vbWsHvahga6kgaswgagxCzAJBgNVBAYTAkNOMRIwEAYDVQQIEwlH\ndWFuZ0RvbmcxEjAQBgNVBAcTCUd1YW5nWmhvdTEVMBMGA1UEChMMd3d3LnNid21s\nLmNuMQ8wDQYDVQQLEwZpUGhvbmUxGDAWBgNVBAMTD3d3dy5zYndtbC5jbiBDQTEQ\nMA4GA1UEKRMHT3BlblZQTjEdMBsGCSqGSIb3DQEJARYOVEQtTFRFQFlVTi5DT02C\nCQC7FMKeAQXXPjAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBCwUAA4IBAQBsunGU\nNlRH3pvayHG/TWexedSpE4hdZVwh+z4SlS8/g2xKQAdTY2xIVYYBbnP8yQhPIUeV\n1CW/Sph39aBP0YLN89QjoPmel6CQ3/x/nQdIU3OqMSJGQKpntrYiM9eDy5KToCYo\nR1GbBZztLoFuzxyHAlOS7hO7OS9g6pGRJveyQvCir1V10VWaJBQH762V0uF5B661\nEp9bPVvsOdTPg167S0vbIA8k5en+BgVGeKT81EDjvnjVKJXenPaw4npXiC7Z7azw\nq+OCLQbNPeHgo8Vfps0JxJtuub3w5wfs8bLXw3ezjVm/9eDpNvq6qHGguqRfuLBv\nlvZcPzzitkrktPi1\n-----END CERTIFICATE-----\n</ca>\nkey-direction 1\n<tls-auth>\n#\n# 2048 bit OpenVPN static key\n#\n-----BEGIN OpenVPN Static key V1-----\n64f514526bc1e036ffbc012fc061d58c\ne858a6b492139ac4cb702149f27d3a21\nd319174df93f7adb990e688abe12ada8\nfe729bbcaebb7fc0b1f4d184f21b1216\n3923de5ff826925428c98162156df1f3\nbf43d532201e4d820f52eb8febf8ceff\nc1a08092e85ddb432ac6c3f4827ab6b4\n56b7ba6c94c5e0ad18cbb5e8a58c485a\n9d2ad61d693a50656765d93f1e333508\n29db37ee01ed7f8f8e8fadb20ed92651\nc67f60a5c123320d3dc69789d9e04297\n71fbf2f209b52cd0e50ff14f77349de0\n7541e1a73e9a528fd3724dc9767cc1ab\nc63f467265f4f3902884f71e4189668d\na4b3b0705e57e90f309e2e34be0f3953\n560cfa96662fb8e4847fc0949078068f\n-----END OpenVPN Static key V1-----\n</tls-auth>\nauth-user-pass\nns-cert-type server\ncomp-lzo\nverb 3', 0, 1476970301),
(4, 1, '移动—咪咕转接', '# 传说科技云免配置\n# 类型：HTTP转接-爱玩\n# 本文件由系统自动生成\n# 传说科技QQ：1281259317\nsetenv IV_GUI_VER "de.blinkt.openvpn 0.6.17" \nmachine-readable-output\nclient\ndev tun\nproto tcp\nconnect-retry-max 5\nconnect-retry 5\nresolv-retry 60\nremote migumovie.lovev.com 80\n########免流代码########\nhttp-proxy 123456789 8080\nhttp-proxy-option EXT1 ZJJ 127.0.0.1:443\nhttp-proxy-option EXT1 "X-Online-Host: migumovie.lovev.com"\n########免流代码########\nresolv-retry infinite\nnobind\npersist-key\npersist-tun\n\n<ca>\n-----BEGIN CERTIFICATE-----\nMIIE6DCCA9CgAwIBAgIJALsUwp4BBdc+MA0GCSqGSIb3DQEBCwUAMIGoMQswCQYD\nVQQGEwJDTjESMBAGA1UECBMJR3VhbmdEb25nMRIwEAYDVQQHEwlHdWFuZ1pob3Ux\nFTATBgNVBAoTDHd3dy5zYndtbC5jbjEPMA0GA1UECxMGaVBob25lMRgwFgYDVQQD\nEw93d3cuc2J3bWwuY24gQ0ExEDAOBgNVBCkTB09wZW5WUE4xHTAbBgkqhkiG9w0B\nCQEWDlRELUxURUBZVU4uQ09NMB4XDTE2MTAyMDEyNTcxN1oXDTI2MTAxODEyNTcx\nN1owgagxCzAJBgNVBAYTAkNOMRIwEAYDVQQIEwlHdWFuZ0RvbmcxEjAQBgNVBAcT\nCUd1YW5nWmhvdTEVMBMGA1UEChMMd3d3LnNid21sLmNuMQ8wDQYDVQQLEwZpUGhv\nbmUxGDAWBgNVBAMTD3d3dy5zYndtbC5jbiBDQTEQMA4GA1UEKRMHT3BlblZQTjEd\nMBsGCSqGSIb3DQEJARYOVEQtTFRFQFlVTi5DT00wggEiMA0GCSqGSIb3DQEBAQUA\nA4IBDwAwggEKAoIBAQDaI7KW2pA4fpvdavEyLmqLh9Mu1D49gi1aAX2ZhnUZ85YE\nbPGbbOTWHDnZ4O/jmLTTQURPPufcMn7Ky5Bl6ued0T+x7HYKlIAIqbNGS4c7AZW6\nfZnmVm66ZpquHbRBTh7fx2hdZyWwLOUQ9XYq8YNTLHkS09YXnep7IS7vu0EHsEJe\n/TiGUZvNHYSqoJL2BZGOWcZeQWbzpjKIkZgazQZhmqC4gVvAfGDiftzQ9dZUraQh\nzv5ioKrIEzBQ9uUoQHq8WS6zxWMF6emhz1axN5RKJAFuyTD7Xs7aJzhCAibPCeQz\nhISKm9/8vxLSG4k+2XuN1ERhTuJ3qP4ZZTOO7W8jAgMBAAGjggERMIIBDTAdBgNV\nHQ4EFgQUADhOLX+lnJPNw9y+Ox51vbWsHvYwgd0GA1UdIwSB1TCB0oAUADhOLX+l\nnJPNw9y+Ox51vbWsHvahga6kgaswgagxCzAJBgNVBAYTAkNOMRIwEAYDVQQIEwlH\ndWFuZ0RvbmcxEjAQBgNVBAcTCUd1YW5nWmhvdTEVMBMGA1UEChMMd3d3LnNid21s\nLmNuMQ8wDQYDVQQLEwZpUGhvbmUxGDAWBgNVBAMTD3d3dy5zYndtbC5jbiBDQTEQ\nMA4GA1UEKRMHT3BlblZQTjEdMBsGCSqGSIb3DQEJARYOVEQtTFRFQFlVTi5DT02C\nCQC7FMKeAQXXPjAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBCwUAA4IBAQBsunGU\nNlRH3pvayHG/TWexedSpE4hdZVwh+z4SlS8/g2xKQAdTY2xIVYYBbnP8yQhPIUeV\n1CW/Sph39aBP0YLN89QjoPmel6CQ3/x/nQdIU3OqMSJGQKpntrYiM9eDy5KToCYo\nR1GbBZztLoFuzxyHAlOS7hO7OS9g6pGRJveyQvCir1V10VWaJBQH762V0uF5B661\nEp9bPVvsOdTPg167S0vbIA8k5en+BgVGeKT81EDjvnjVKJXenPaw4npXiC7Z7azw\nq+OCLQbNPeHgo8Vfps0JxJtuub3w5wfs8bLXw3ezjVm/9eDpNvq6qHGguqRfuLBv\nlvZcPzzitkrktPi1\n-----END CERTIFICATE-----\n</ca>\nkey-direction 1\n<tls-auth>\n#\n# 2048 bit OpenVPN static key\n#\n-----BEGIN OpenVPN Static key V1-----\n64f514526bc1e036ffbc012fc061d58c\ne858a6b492139ac4cb702149f27d3a21\nd319174df93f7adb990e688abe12ada8\nfe729bbcaebb7fc0b1f4d184f21b1216\n3923de5ff826925428c98162156df1f3\nbf43d532201e4d820f52eb8febf8ceff\nc1a08092e85ddb432ac6c3f4827ab6b4\n56b7ba6c94c5e0ad18cbb5e8a58c485a\n9d2ad61d693a50656765d93f1e333508\n29db37ee01ed7f8f8e8fadb20ed92651\nc67f60a5c123320d3dc69789d9e04297\n71fbf2f209b52cd0e50ff14f77349de0\n7541e1a73e9a528fd3724dc9767cc1ab\nc63f467265f4f3902884f71e4189668d\na4b3b0705e57e90f309e2e34be0f3953\n560cfa96662fb8e4847fc0949078068f\n-----END OpenVPN Static key V1-----\n</tls-auth>\nauth-user-pass\nns-cert-type server\ncomp-lzo\nverb 3', 0, 1476970411),
(5, 1, '移动—138线路', '# 传说科技云免配置\n# 类型：HTTP转接-爱玩\n# 本文件由系统自动生成\n# 传说科技QQ：1281259317\nsetenv IV_GUI_VER "de.blinkt.openvpn 0.6.17" \nmachine-readable-output\nclient\ndev tun\nproto tcp\nconnect-retry-max 5\nconnect-retry 5\nresolv-retry 60\n########免流代码########\nremote wap.10086.cn 80\nhttp-proxy-option EXT1 POST http://wap.10086.cn\nhttp-proxy-option EXT1 Host wap.10086.cn\nhttp-proxy-option EXT1 Host: wap.10086.cn / HTTP/1.1\nhttp-proxy 123456789 138\n########免流代码########\nresolv-retry infinite\nnobind\npersist-key\npersist-tun\n\n<ca>\n-----BEGIN CERTIFICATE-----\nMIIE6DCCA9CgAwIBAgIJALsUwp4BBdc+MA0GCSqGSIb3DQEBCwUAMIGoMQswCQYD\nVQQGEwJDTjESMBAGA1UECBMJR3VhbmdEb25nMRIwEAYDVQQHEwlHdWFuZ1pob3Ux\nFTATBgNVBAoTDHd3dy5zYndtbC5jbjEPMA0GA1UECxMGaVBob25lMRgwFgYDVQQD\nEw93d3cuc2J3bWwuY24gQ0ExEDAOBgNVBCkTB09wZW5WUE4xHTAbBgkqhkiG9w0B\nCQEWDlRELUxURUBZVU4uQ09NMB4XDTE2MTAyMDEyNTcxN1oXDTI2MTAxODEyNTcx\nN1owgagxCzAJBgNVBAYTAkNOMRIwEAYDVQQIEwlHdWFuZ0RvbmcxEjAQBgNVBAcT\nCUd1YW5nWmhvdTEVMBMGA1UEChMMd3d3LnNid21sLmNuMQ8wDQYDVQQLEwZpUGhv\nbmUxGDAWBgNVBAMTD3d3dy5zYndtbC5jbiBDQTEQMA4GA1UEKRMHT3BlblZQTjEd\nMBsGCSqGSIb3DQEJARYOVEQtTFRFQFlVTi5DT00wggEiMA0GCSqGSIb3DQEBAQUA\nA4IBDwAwggEKAoIBAQDaI7KW2pA4fpvdavEyLmqLh9Mu1D49gi1aAX2ZhnUZ85YE\nbPGbbOTWHDnZ4O/jmLTTQURPPufcMn7Ky5Bl6ued0T+x7HYKlIAIqbNGS4c7AZW6\nfZnmVm66ZpquHbRBTh7fx2hdZyWwLOUQ9XYq8YNTLHkS09YXnep7IS7vu0EHsEJe\n/TiGUZvNHYSqoJL2BZGOWcZeQWbzpjKIkZgazQZhmqC4gVvAfGDiftzQ9dZUraQh\nzv5ioKrIEzBQ9uUoQHq8WS6zxWMF6emhz1axN5RKJAFuyTD7Xs7aJzhCAibPCeQz\nhISKm9/8vxLSG4k+2XuN1ERhTuJ3qP4ZZTOO7W8jAgMBAAGjggERMIIBDTAdBgNV\nHQ4EFgQUADhOLX+lnJPNw9y+Ox51vbWsHvYwgd0GA1UdIwSB1TCB0oAUADhOLX+l\nnJPNw9y+Ox51vbWsHvahga6kgaswgagxCzAJBgNVBAYTAkNOMRIwEAYDVQQIEwlH\ndWFuZ0RvbmcxEjAQBgNVBAcTCUd1YW5nWmhvdTEVMBMGA1UEChMMd3d3LnNid21s\nLmNuMQ8wDQYDVQQLEwZpUGhvbmUxGDAWBgNVBAMTD3d3dy5zYndtbC5jbiBDQTEQ\nMA4GA1UEKRMHT3BlblZQTjEdMBsGCSqGSIb3DQEJARYOVEQtTFRFQFlVTi5DT02C\nCQC7FMKeAQXXPjAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBCwUAA4IBAQBsunGU\nNlRH3pvayHG/TWexedSpE4hdZVwh+z4SlS8/g2xKQAdTY2xIVYYBbnP8yQhPIUeV\n1CW/Sph39aBP0YLN89QjoPmel6CQ3/x/nQdIU3OqMSJGQKpntrYiM9eDy5KToCYo\nR1GbBZztLoFuzxyHAlOS7hO7OS9g6pGRJveyQvCir1V10VWaJBQH762V0uF5B661\nEp9bPVvsOdTPg167S0vbIA8k5en+BgVGeKT81EDjvnjVKJXenPaw4npXiC7Z7azw\nq+OCLQbNPeHgo8Vfps0JxJtuub3w5wfs8bLXw3ezjVm/9eDpNvq6qHGguqRfuLBv\nlvZcPzzitkrktPi1\n-----END CERTIFICATE-----\n</ca>\nkey-direction 1\n<tls-auth>\n#\n# 2048 bit OpenVPN static key\n#\n-----BEGIN OpenVPN Static key V1-----\n64f514526bc1e036ffbc012fc061d58c\ne858a6b492139ac4cb702149f27d3a21\nd319174df93f7adb990e688abe12ada8\nfe729bbcaebb7fc0b1f4d184f21b1216\n3923de5ff826925428c98162156df1f3\nbf43d532201e4d820f52eb8febf8ceff\nc1a08092e85ddb432ac6c3f4827ab6b4\n56b7ba6c94c5e0ad18cbb5e8a58c485a\n9d2ad61d693a50656765d93f1e333508\n29db37ee01ed7f8f8e8fadb20ed92651\nc67f60a5c123320d3dc69789d9e04297\n71fbf2f209b52cd0e50ff14f77349de0\n7541e1a73e9a528fd3724dc9767cc1ab\nc63f467265f4f3902884f71e4189668d\na4b3b0705e57e90f309e2e34be0f3953\n560cfa96662fb8e4847fc0949078068f\n-----END OpenVPN Static key V1-----\n</tls-auth>\nauth-user-pass\nns-cert-type server\ncomp-lzo\nverb 3', 0, 1476970472),
(6, 1, '移动—咪咕转接线路②', '# 传说科技云免配置\n# 类型：HTTP转接\n# 本文件由系统自动生成\n# 传说科技QQ：1281259317\nsetenv IV_GUI_VER "de.blinkt.openvpn 0.6.17" \nmachine-readable-output\nclient\ndev tun\nproto tcp\nconnect-retry-max 5\nconnect-retry 5\nresolv-retry 60\n########免流代码########\nremote migumovie.lovev.com 80\nhttp-proxy-option EXT1 POST migumovie.lovev.com\nhttp-proxy-option EXT1 Host migumovie.lovev.com\nhttp-proxy-option EXT1 Host: migumovie.lovev.com / HTTP/1.1\nhttp-proxy 123456789 8080\n########免流代码########\n\nresolv-retry infinite\nnobind\npersist-key\npersist-tun\n\n<ca>\n-----BEGIN CERTIFICATE-----\nMIIE6DCCA9CgAwIBAgIJALsUwp4BBdc+MA0GCSqGSIb3DQEBCwUAMIGoMQswCQYD\nVQQGEwJDTjESMBAGA1UECBMJR3VhbmdEb25nMRIwEAYDVQQHEwlHdWFuZ1pob3Ux\nFTATBgNVBAoTDHd3dy5zYndtbC5jbjEPMA0GA1UECxMGaVBob25lMRgwFgYDVQQD\nEw93d3cuc2J3bWwuY24gQ0ExEDAOBgNVBCkTB09wZW5WUE4xHTAbBgkqhkiG9w0B\nCQEWDlRELUxURUBZVU4uQ09NMB4XDTE2MTAyMDEyNTcxN1oXDTI2MTAxODEyNTcx\nN1owgagxCzAJBgNVBAYTAkNOMRIwEAYDVQQIEwlHdWFuZ0RvbmcxEjAQBgNVBAcT\nCUd1YW5nWmhvdTEVMBMGA1UEChMMd3d3LnNid21sLmNuMQ8wDQYDVQQLEwZpUGhv\nbmUxGDAWBgNVBAMTD3d3dy5zYndtbC5jbiBDQTEQMA4GA1UEKRMHT3BlblZQTjEd\nMBsGCSqGSIb3DQEJARYOVEQtTFRFQFlVTi5DT00wggEiMA0GCSqGSIb3DQEBAQUA\nA4IBDwAwggEKAoIBAQDaI7KW2pA4fpvdavEyLmqLh9Mu1D49gi1aAX2ZhnUZ85YE\nbPGbbOTWHDnZ4O/jmLTTQURPPufcMn7Ky5Bl6ued0T+x7HYKlIAIqbNGS4c7AZW6\nfZnmVm66ZpquHbRBTh7fx2hdZyWwLOUQ9XYq8YNTLHkS09YXnep7IS7vu0EHsEJe\n/TiGUZvNHYSqoJL2BZGOWcZeQWbzpjKIkZgazQZhmqC4gVvAfGDiftzQ9dZUraQh\nzv5ioKrIEzBQ9uUoQHq8WS6zxWMF6emhz1axN5RKJAFuyTD7Xs7aJzhCAibPCeQz\nhISKm9/8vxLSG4k+2XuN1ERhTuJ3qP4ZZTOO7W8jAgMBAAGjggERMIIBDTAdBgNV\nHQ4EFgQUADhOLX+lnJPNw9y+Ox51vbWsHvYwgd0GA1UdIwSB1TCB0oAUADhOLX+l\nnJPNw9y+Ox51vbWsHvahga6kgaswgagxCzAJBgNVBAYTAkNOMRIwEAYDVQQIEwlH\ndWFuZ0RvbmcxEjAQBgNVBAcTCUd1YW5nWmhvdTEVMBMGA1UEChMMd3d3LnNid21s\nLmNuMQ8wDQYDVQQLEwZpUGhvbmUxGDAWBgNVBAMTD3d3dy5zYndtbC5jbiBDQTEQ\nMA4GA1UEKRMHT3BlblZQTjEdMBsGCSqGSIb3DQEJARYOVEQtTFRFQFlVTi5DT02C\nCQC7FMKeAQXXPjAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBCwUAA4IBAQBsunGU\nNlRH3pvayHG/TWexedSpE4hdZVwh+z4SlS8/g2xKQAdTY2xIVYYBbnP8yQhPIUeV\n1CW/Sph39aBP0YLN89QjoPmel6CQ3/x/nQdIU3OqMSJGQKpntrYiM9eDy5KToCYo\nR1GbBZztLoFuzxyHAlOS7hO7OS9g6pGRJveyQvCir1V10VWaJBQH762V0uF5B661\nEp9bPVvsOdTPg167S0vbIA8k5en+BgVGeKT81EDjvnjVKJXenPaw4npXiC7Z7azw\nq+OCLQbNPeHgo8Vfps0JxJtuub3w5wfs8bLXw3ezjVm/9eDpNvq6qHGguqRfuLBv\nlvZcPzzitkrktPi1\n-----END CERTIFICATE-----\n</ca>\nkey-direction 1\n<tls-auth>\n#\n# 2048 bit OpenVPN static key\n#\n-----BEGIN OpenVPN Static key V1-----\n64f514526bc1e036ffbc012fc061d58c\ne858a6b492139ac4cb702149f27d3a21\nd319174df93f7adb990e688abe12ada8\nfe729bbcaebb7fc0b1f4d184f21b1216\n3923de5ff826925428c98162156df1f3\nbf43d532201e4d820f52eb8febf8ceff\nc1a08092e85ddb432ac6c3f4827ab6b4\n56b7ba6c94c5e0ad18cbb5e8a58c485a\n9d2ad61d693a50656765d93f1e333508\n29db37ee01ed7f8f8e8fadb20ed92651\nc67f60a5c123320d3dc69789d9e04297\n71fbf2f209b52cd0e50ff14f77349de0\n7541e1a73e9a528fd3724dc9767cc1ab\nc63f467265f4f3902884f71e4189668d\na4b3b0705e57e90f309e2e34be0f3953\n560cfa96662fb8e4847fc0949078068f\n-----END OpenVPN Static key V1-----\n</tls-auth>\nauth-user-pass\nns-cert-type server\ncomp-lzo\nverb 3', 0, 1476970521),
(7, 3, '电信—爱玩线路①', '# 传说科技云免配置\n# 类型：HTTP转接-爱玩\n# 本文件由系统自动生成\n# 传说科技QQ：1281259317\nsetenv IV_GUI_VER "de.blinkt.openvpn 0.6.17" \nmachine-readable-output\nclient\ndev tun\nproto tcp\nconnect-retry-max 5\nconnect-retry 5\nresolv-retry 60\n########免流代码########\nremote cdn.4g.play.cn 443\nhttp-proxy-option EXT1 "GET http://cdn.4g.play.cn "\nhttp-proxy-option EXT1 "POST http://cdn.4g.play.cn "\nhttp-proxy-option EXT1 "X-Online-Host: cdn.4g.play.cn "\nhttp-proxy-option EXT1 "Host: cdn.4g.play.cn " \nhttp-proxy 123456789 8080\n########免流代码########\nresolv-retry infinite\nnobind\npersist-key\npersist-tun\n\n<ca>\n-----BEGIN CERTIFICATE-----\nMIIE6DCCA9CgAwIBAgIJALsUwp4BBdc+MA0GCSqGSIb3DQEBCwUAMIGoMQswCQYD\nVQQGEwJDTjESMBAGA1UECBMJR3VhbmdEb25nMRIwEAYDVQQHEwlHdWFuZ1pob3Ux\nFTATBgNVBAoTDHd3dy5zYndtbC5jbjEPMA0GA1UECxMGaVBob25lMRgwFgYDVQQD\nEw93d3cuc2J3bWwuY24gQ0ExEDAOBgNVBCkTB09wZW5WUE4xHTAbBgkqhkiG9w0B\nCQEWDlRELUxURUBZVU4uQ09NMB4XDTE2MTAyMDEyNTcxN1oXDTI2MTAxODEyNTcx\nN1owgagxCzAJBgNVBAYTAkNOMRIwEAYDVQQIEwlHdWFuZ0RvbmcxEjAQBgNVBAcT\nCUd1YW5nWmhvdTEVMBMGA1UEChMMd3d3LnNid21sLmNuMQ8wDQYDVQQLEwZpUGhv\nbmUxGDAWBgNVBAMTD3d3dy5zYndtbC5jbiBDQTEQMA4GA1UEKRMHT3BlblZQTjEd\nMBsGCSqGSIb3DQEJARYOVEQtTFRFQFlVTi5DT00wggEiMA0GCSqGSIb3DQEBAQUA\nA4IBDwAwggEKAoIBAQDaI7KW2pA4fpvdavEyLmqLh9Mu1D49gi1aAX2ZhnUZ85YE\nbPGbbOTWHDnZ4O/jmLTTQURPPufcMn7Ky5Bl6ued0T+x7HYKlIAIqbNGS4c7AZW6\nfZnmVm66ZpquHbRBTh7fx2hdZyWwLOUQ9XYq8YNTLHkS09YXnep7IS7vu0EHsEJe\n/TiGUZvNHYSqoJL2BZGOWcZeQWbzpjKIkZgazQZhmqC4gVvAfGDiftzQ9dZUraQh\nzv5ioKrIEzBQ9uUoQHq8WS6zxWMF6emhz1axN5RKJAFuyTD7Xs7aJzhCAibPCeQz\nhISKm9/8vxLSG4k+2XuN1ERhTuJ3qP4ZZTOO7W8jAgMBAAGjggERMIIBDTAdBgNV\nHQ4EFgQUADhOLX+lnJPNw9y+Ox51vbWsHvYwgd0GA1UdIwSB1TCB0oAUADhOLX+l\nnJPNw9y+Ox51vbWsHvahga6kgaswgagxCzAJBgNVBAYTAkNOMRIwEAYDVQQIEwlH\ndWFuZ0RvbmcxEjAQBgNVBAcTCUd1YW5nWmhvdTEVMBMGA1UEChMMd3d3LnNid21s\nLmNuMQ8wDQYDVQQLEwZpUGhvbmUxGDAWBgNVBAMTD3d3dy5zYndtbC5jbiBDQTEQ\nMA4GA1UEKRMHT3BlblZQTjEdMBsGCSqGSIb3DQEJARYOVEQtTFRFQFlVTi5DT02C\nCQC7FMKeAQXXPjAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBCwUAA4IBAQBsunGU\nNlRH3pvayHG/TWexedSpE4hdZVwh+z4SlS8/g2xKQAdTY2xIVYYBbnP8yQhPIUeV\n1CW/Sph39aBP0YLN89QjoPmel6CQ3/x/nQdIU3OqMSJGQKpntrYiM9eDy5KToCYo\nR1GbBZztLoFuzxyHAlOS7hO7OS9g6pGRJveyQvCir1V10VWaJBQH762V0uF5B661\nEp9bPVvsOdTPg167S0vbIA8k5en+BgVGeKT81EDjvnjVKJXenPaw4npXiC7Z7azw\nq+OCLQbNPeHgo8Vfps0JxJtuub3w5wfs8bLXw3ezjVm/9eDpNvq6qHGguqRfuLBv\nlvZcPzzitkrktPi1\n-----END CERTIFICATE-----\n</ca>\nkey-direction 1\n<tls-auth>\n#\n# 2048 bit OpenVPN static key\n#\n-----BEGIN OpenVPN Static key V1-----\n64f514526bc1e036ffbc012fc061d58c\ne858a6b492139ac4cb702149f27d3a21\nd319174df93f7adb990e688abe12ada8\nfe729bbcaebb7fc0b1f4d184f21b1216\n3923de5ff826925428c98162156df1f3\nbf43d532201e4d820f52eb8febf8ceff\nc1a08092e85ddb432ac6c3f4827ab6b4\n56b7ba6c94c5e0ad18cbb5e8a58c485a\n9d2ad61d693a50656765d93f1e333508\n29db37ee01ed7f8f8e8fadb20ed92651\nc67f60a5c123320d3dc69789d9e04297\n71fbf2f209b52cd0e50ff14f77349de0\n7541e1a73e9a528fd3724dc9767cc1ab\nc63f467265f4f3902884f71e4189668d\na4b3b0705e57e90f309e2e34be0f3953\n560cfa96662fb8e4847fc0949078068f\n-----END OpenVPN Static key V1-----\n</tls-auth>\nauth-user-pass\nns-cert-type server\ncomp-lzo\nverb 3', 0, 1476970575),
(8, 3, '电信—爱玩②', '# 传说科技云免配置\n# 类型：HTTP转接-爱玩\n# 本文件由系统自动生成\n# 传说科技QQ：1281259317\nsetenv IV_GUI_VER "de.blinkt.openvpn 0.6.17" \nmachine-readable-output\nclient\ndev tun\nproto tcp\nconnect-retry-max 5\nconnect-retry 5\nresolv-retry 60\nremote cdn.4g.play.cn 80\n########免流代码########\nhttp-proxy 123456789 8080\nhttp-proxy-option EXT1 ZJJ 127.0.0.1:443\nhttp-proxy-option EXT1 "POST http://cdn.4g.play.cn/ HTTP/1.1"\nhttp-proxy-option EXT1 "Host: cdn.4g.play.cn" \n########免流代码########\nresolv-retry infinite\nnobind\npersist-key\npersist-tun\n\n<ca>\n-----BEGIN CERTIFICATE-----\nMIIE6DCCA9CgAwIBAgIJALsUwp4BBdc+MA0GCSqGSIb3DQEBCwUAMIGoMQswCQYD\nVQQGEwJDTjESMBAGA1UECBMJR3VhbmdEb25nMRIwEAYDVQQHEwlHdWFuZ1pob3Ux\nFTATBgNVBAoTDHd3dy5zYndtbC5jbjEPMA0GA1UECxMGaVBob25lMRgwFgYDVQQD\nEw93d3cuc2J3bWwuY24gQ0ExEDAOBgNVBCkTB09wZW5WUE4xHTAbBgkqhkiG9w0B\nCQEWDlRELUxURUBZVU4uQ09NMB4XDTE2MTAyMDEyNTcxN1oXDTI2MTAxODEyNTcx\nN1owgagxCzAJBgNVBAYTAkNOMRIwEAYDVQQIEwlHdWFuZ0RvbmcxEjAQBgNVBAcT\nCUd1YW5nWmhvdTEVMBMGA1UEChMMd3d3LnNid21sLmNuMQ8wDQYDVQQLEwZpUGhv\nbmUxGDAWBgNVBAMTD3d3dy5zYndtbC5jbiBDQTEQMA4GA1UEKRMHT3BlblZQTjEd\nMBsGCSqGSIb3DQEJARYOVEQtTFRFQFlVTi5DT00wggEiMA0GCSqGSIb3DQEBAQUA\nA4IBDwAwggEKAoIBAQDaI7KW2pA4fpvdavEyLmqLh9Mu1D49gi1aAX2ZhnUZ85YE\nbPGbbOTWHDnZ4O/jmLTTQURPPufcMn7Ky5Bl6ued0T+x7HYKlIAIqbNGS4c7AZW6\nfZnmVm66ZpquHbRBTh7fx2hdZyWwLOUQ9XYq8YNTLHkS09YXnep7IS7vu0EHsEJe\n/TiGUZvNHYSqoJL2BZGOWcZeQWbzpjKIkZgazQZhmqC4gVvAfGDiftzQ9dZUraQh\nzv5ioKrIEzBQ9uUoQHq8WS6zxWMF6emhz1axN5RKJAFuyTD7Xs7aJzhCAibPCeQz\nhISKm9/8vxLSG4k+2XuN1ERhTuJ3qP4ZZTOO7W8jAgMBAAGjggERMIIBDTAdBgNV\nHQ4EFgQUADhOLX+lnJPNw9y+Ox51vbWsHvYwgd0GA1UdIwSB1TCB0oAUADhOLX+l\nnJPNw9y+Ox51vbWsHvahga6kgaswgagxCzAJBgNVBAYTAkNOMRIwEAYDVQQIEwlH\ndWFuZ0RvbmcxEjAQBgNVBAcTCUd1YW5nWmhvdTEVMBMGA1UEChMMd3d3LnNid21s\nLmNuMQ8wDQYDVQQLEwZpUGhvbmUxGDAWBgNVBAMTD3d3dy5zYndtbC5jbiBDQTEQ\nMA4GA1UEKRMHT3BlblZQTjEdMBsGCSqGSIb3DQEJARYOVEQtTFRFQFlVTi5DT02C\nCQC7FMKeAQXXPjAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBCwUAA4IBAQBsunGU\nNlRH3pvayHG/TWexedSpE4hdZVwh+z4SlS8/g2xKQAdTY2xIVYYBbnP8yQhPIUeV\n1CW/Sph39aBP0YLN89QjoPmel6CQ3/x/nQdIU3OqMSJGQKpntrYiM9eDy5KToCYo\nR1GbBZztLoFuzxyHAlOS7hO7OS9g6pGRJveyQvCir1V10VWaJBQH762V0uF5B661\nEp9bPVvsOdTPg167S0vbIA8k5en+BgVGeKT81EDjvnjVKJXenPaw4npXiC7Z7azw\nq+OCLQbNPeHgo8Vfps0JxJtuub3w5wfs8bLXw3ezjVm/9eDpNvq6qHGguqRfuLBv\nlvZcPzzitkrktPi1\n-----END CERTIFICATE-----\n</ca>\nkey-direction 1\n<tls-auth>\n#\n# 2048 bit OpenVPN static key\n#\n-----BEGIN OpenVPN Static key V1-----\n64f514526bc1e036ffbc012fc061d58c\ne858a6b492139ac4cb702149f27d3a21\nd319174df93f7adb990e688abe12ada8\nfe729bbcaebb7fc0b1f4d184f21b1216\n3923de5ff826925428c98162156df1f3\nbf43d532201e4d820f52eb8febf8ceff\nc1a08092e85ddb432ac6c3f4827ab6b4\n56b7ba6c94c5e0ad18cbb5e8a58c485a\n9d2ad61d693a50656765d93f1e333508\n29db37ee01ed7f8f8e8fadb20ed92651\nc67f60a5c123320d3dc69789d9e04297\n71fbf2f209b52cd0e50ff14f77349de0\n7541e1a73e9a528fd3724dc9767cc1ab\nc63f467265f4f3902884f71e4189668d\na4b3b0705e57e90f309e2e34be0f3953\n560cfa96662fb8e4847fc0949078068f\n-----END OpenVPN Static key V1-----\n</tls-auth>\nauth-user-pass\nns-cert-type server\ncomp-lzo\nverb 3', 0, 1476970644),
(9, 2, '联通复活线路', '# 传说科技云免配置\n# 类型：HTTP转接-爱玩\n# 本文件由系统自动生成\n# 传说科技QQ：1281259317\nsetenv IV_GUI_VER "de.blinkt.openvpn 0.6.17" \nmachine-readable-output\nclient\ndev tun\nproto tcp\nconnect-retry-max 5\nconnect-retry 5\nresolv-retry 60\nremote 123456789 443\n########免流代码########\nhttp-proxy-option VERSION 1.1\nhttp-proxy-option EXT1 "Host: sales.wostore.cn:8081"\nhttp-proxy-option EXT1 "Proxy-Connection: keep-alive"\nhttp-proxy 211.137.84.224 28080\n########免流代码########\nresolv-retry infinite\nnobind\npersist-key\npersist-tun\n\n<ca>\n-----BEGIN CERTIFICATE-----\nMIIE6DCCA9CgAwIBAgIJALsUwp4BBdc+MA0GCSqGSIb3DQEBCwUAMIGoMQswCQYD\nVQQGEwJDTjESMBAGA1UECBMJR3VhbmdEb25nMRIwEAYDVQQHEwlHdWFuZ1pob3Ux\nFTATBgNVBAoTDHd3dy5zYndtbC5jbjEPMA0GA1UECxMGaVBob25lMRgwFgYDVQQD\nEw93d3cuc2J3bWwuY24gQ0ExEDAOBgNVBCkTB09wZW5WUE4xHTAbBgkqhkiG9w0B\nCQEWDlRELUxURUBZVU4uQ09NMB4XDTE2MTAyMDEyNTcxN1oXDTI2MTAxODEyNTcx\nN1owgagxCzAJBgNVBAYTAkNOMRIwEAYDVQQIEwlHdWFuZ0RvbmcxEjAQBgNVBAcT\nCUd1YW5nWmhvdTEVMBMGA1UEChMMd3d3LnNid21sLmNuMQ8wDQYDVQQLEwZpUGhv\nbmUxGDAWBgNVBAMTD3d3dy5zYndtbC5jbiBDQTEQMA4GA1UEKRMHT3BlblZQTjEd\nMBsGCSqGSIb3DQEJARYOVEQtTFRFQFlVTi5DT00wggEiMA0GCSqGSIb3DQEBAQUA\nA4IBDwAwggEKAoIBAQDaI7KW2pA4fpvdavEyLmqLh9Mu1D49gi1aAX2ZhnUZ85YE\nbPGbbOTWHDnZ4O/jmLTTQURPPufcMn7Ky5Bl6ued0T+x7HYKlIAIqbNGS4c7AZW6\nfZnmVm66ZpquHbRBTh7fx2hdZyWwLOUQ9XYq8YNTLHkS09YXnep7IS7vu0EHsEJe\n/TiGUZvNHYSqoJL2BZGOWcZeQWbzpjKIkZgazQZhmqC4gVvAfGDiftzQ9dZUraQh\nzv5ioKrIEzBQ9uUoQHq8WS6zxWMF6emhz1axN5RKJAFuyTD7Xs7aJzhCAibPCeQz\nhISKm9/8vxLSG4k+2XuN1ERhTuJ3qP4ZZTOO7W8jAgMBAAGjggERMIIBDTAdBgNV\nHQ4EFgQUADhOLX+lnJPNw9y+Ox51vbWsHvYwgd0GA1UdIwSB1TCB0oAUADhOLX+l\nnJPNw9y+Ox51vbWsHvahga6kgaswgagxCzAJBgNVBAYTAkNOMRIwEAYDVQQIEwlH\ndWFuZ0RvbmcxEjAQBgNVBAcTCUd1YW5nWmhvdTEVMBMGA1UEChMMd3d3LnNid21s\nLmNuMQ8wDQYDVQQLEwZpUGhvbmUxGDAWBgNVBAMTD3d3dy5zYndtbC5jbiBDQTEQ\nMA4GA1UEKRMHT3BlblZQTjEdMBsGCSqGSIb3DQEJARYOVEQtTFRFQFlVTi5DT02C\nCQC7FMKeAQXXPjAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBCwUAA4IBAQBsunGU\nNlRH3pvayHG/TWexedSpE4hdZVwh+z4SlS8/g2xKQAdTY2xIVYYBbnP8yQhPIUeV\n1CW/Sph39aBP0YLN89QjoPmel6CQ3/x/nQdIU3OqMSJGQKpntrYiM9eDy5KToCYo\nR1GbBZztLoFuzxyHAlOS7hO7OS9g6pGRJveyQvCir1V10VWaJBQH762V0uF5B661\nEp9bPVvsOdTPg167S0vbIA8k5en+BgVGeKT81EDjvnjVKJXenPaw4npXiC7Z7azw\nq+OCLQbNPeHgo8Vfps0JxJtuub3w5wfs8bLXw3ezjVm/9eDpNvq6qHGguqRfuLBv\nlvZcPzzitkrktPi1\n-----END CERTIFICATE-----\n</ca>\nkey-direction 1\n<tls-auth>\n#\n# 2048 bit OpenVPN static key\n#\n-----BEGIN OpenVPN Static key V1-----\n64f514526bc1e036ffbc012fc061d58c\ne858a6b492139ac4cb702149f27d3a21\nd319174df93f7adb990e688abe12ada8\nfe729bbcaebb7fc0b1f4d184f21b1216\n3923de5ff826925428c98162156df1f3\nbf43d532201e4d820f52eb8febf8ceff\nc1a08092e85ddb432ac6c3f4827ab6b4\n56b7ba6c94c5e0ad18cbb5e8a58c485a\n9d2ad61d693a50656765d93f1e333508\n29db37ee01ed7f8f8e8fadb20ed92651\nc67f60a5c123320d3dc69789d9e04297\n71fbf2f209b52cd0e50ff14f77349de0\n7541e1a73e9a528fd3724dc9767cc1ab\nc63f467265f4f3902884f71e4189668d\na4b3b0705e57e90f309e2e34be0f3953\n560cfa96662fb8e4847fc0949078068f\n-----END OpenVPN Static key V1-----\n</tls-auth>\nauth-user-pass\nns-cert-type server\ncomp-lzo\nverb 3', 0, 1476970911),
(11, 2, '联通常规线路', '# 传说科技云免配置\n#类型：常规\n# 本文件由系统自动生成\n# 传说科技QQ：1281259317\nsetenv IV_GUI_VER "de.blinkt.openvpn 0.6.17" \nmachine-readable-output\nclient\ndev tun\nconnect-retry-max 5\nconnect-retry 5\nresolv-retry 60\n########免流代码########\nhttp-proxy-option EXT1 "POST http://wap.10010.com" \nhttp-proxy-option EXT1 "GET http://wap.10010.com" \nhttp-proxy-option EXT1 "X-Online-Host: wap.10010.com" \nhttp-proxy-option EXT1 "POST http://wap.10010.com" \nhttp-proxy-option EXT1 "X-Online-Host: wap.10010.com" \nhttp-proxy-option EXT1 "POST http://wap.10010.com" \nhttp-proxy-option EXT1 "Host: wap.10010.com" \nhttp-proxy-option EXT1 "GET http://wap.10010.com" \nhttp-proxy-option EXT1 "Host: wap.10010.com"\n########免流代码########\n\nhttp-proxy 123456789 80\n<http-proxy-user-pass>\nlenged\nadmin\n</http-proxy-user-pass>\n\nremote 123456789 443 tcp-client\nresolv-retry infinite\nnobind\npersist-key\npersist-tun\n\n<ca>\n-----BEGIN CERTIFICATE-----\nMIIE6DCCA9CgAwIBAgIJALsUwp4BBdc+MA0GCSqGSIb3DQEBCwUAMIGoMQswCQYD\nVQQGEwJDTjESMBAGA1UECBMJR3VhbmdEb25nMRIwEAYDVQQHEwlHdWFuZ1pob3Ux\nFTATBgNVBAoTDHd3dy5zYndtbC5jbjEPMA0GA1UECxMGaVBob25lMRgwFgYDVQQD\nEw93d3cuc2J3bWwuY24gQ0ExEDAOBgNVBCkTB09wZW5WUE4xHTAbBgkqhkiG9w0B\nCQEWDlRELUxURUBZVU4uQ09NMB4XDTE2MTAyMDEyNTcxN1oXDTI2MTAxODEyNTcx\nN1owgagxCzAJBgNVBAYTAkNOMRIwEAYDVQQIEwlHdWFuZ0RvbmcxEjAQBgNVBAcT\nCUd1YW5nWmhvdTEVMBMGA1UEChMMd3d3LnNid21sLmNuMQ8wDQYDVQQLEwZpUGhv\nbmUxGDAWBgNVBAMTD3d3dy5zYndtbC5jbiBDQTEQMA4GA1UEKRMHT3BlblZQTjEd\nMBsGCSqGSIb3DQEJARYOVEQtTFRFQFlVTi5DT00wggEiMA0GCSqGSIb3DQEBAQUA\nA4IBDwAwggEKAoIBAQDaI7KW2pA4fpvdavEyLmqLh9Mu1D49gi1aAX2ZhnUZ85YE\nbPGbbOTWHDnZ4O/jmLTTQURPPufcMn7Ky5Bl6ued0T+x7HYKlIAIqbNGS4c7AZW6\nfZnmVm66ZpquHbRBTh7fx2hdZyWwLOUQ9XYq8YNTLHkS09YXnep7IS7vu0EHsEJe\n/TiGUZvNHYSqoJL2BZGOWcZeQWbzpjKIkZgazQZhmqC4gVvAfGDiftzQ9dZUraQh\nzv5ioKrIEzBQ9uUoQHq8WS6zxWMF6emhz1axN5RKJAFuyTD7Xs7aJzhCAibPCeQz\nhISKm9/8vxLSG4k+2XuN1ERhTuJ3qP4ZZTOO7W8jAgMBAAGjggERMIIBDTAdBgNV\nHQ4EFgQUADhOLX+lnJPNw9y+Ox51vbWsHvYwgd0GA1UdIwSB1TCB0oAUADhOLX+l\nnJPNw9y+Ox51vbWsHvahga6kgaswgagxCzAJBgNVBAYTAkNOMRIwEAYDVQQIEwlH\ndWFuZ0RvbmcxEjAQBgNVBAcTCUd1YW5nWmhvdTEVMBMGA1UEChMMd3d3LnNid21s\nLmNuMQ8wDQYDVQQLEwZpUGhvbmUxGDAWBgNVBAMTD3d3dy5zYndtbC5jbiBDQTEQ\nMA4GA1UEKRMHT3BlblZQTjEdMBsGCSqGSIb3DQEJARYOVEQtTFRFQFlVTi5DT02C\nCQC7FMKeAQXXPjAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBCwUAA4IBAQBsunGU\nNlRH3pvayHG/TWexedSpE4hdZVwh+z4SlS8/g2xKQAdTY2xIVYYBbnP8yQhPIUeV\n1CW/Sph39aBP0YLN89QjoPmel6CQ3/x/nQdIU3OqMSJGQKpntrYiM9eDy5KToCYo\nR1GbBZztLoFuzxyHAlOS7hO7OS9g6pGRJveyQvCir1V10VWaJBQH762V0uF5B661\nEp9bPVvsOdTPg167S0vbIA8k5en+BgVGeKT81EDjvnjVKJXenPaw4npXiC7Z7azw\nq+OCLQbNPeHgo8Vfps0JxJtuub3w5wfs8bLXw3ezjVm/9eDpNvq6qHGguqRfuLBv\nlvZcPzzitkrktPi1\n-----END CERTIFICATE-----\n</ca>\nkey-direction 1\n<tls-auth>\n#\n# 2048 bit OpenVPN static key\n#\n-----BEGIN OpenVPN Static key V1-----\n64f514526bc1e036ffbc012fc061d58c\ne858a6b492139ac4cb702149f27d3a21\nd319174df93f7adb990e688abe12ada8\nfe729bbcaebb7fc0b1f4d184f21b1216\n3923de5ff826925428c98162156df1f3\nbf43d532201e4d820f52eb8febf8ceff\nc1a08092e85ddb432ac6c3f4827ab6b4\n56b7ba6c94c5e0ad18cbb5e8a58c485a\n9d2ad61d693a50656765d93f1e333508\n29db37ee01ed7f8f8e8fadb20ed92651\nc67f60a5c123320d3dc69789d9e04297\n71fbf2f209b52cd0e50ff14f77349de0\n7541e1a73e9a528fd3724dc9767cc1ab\nc63f467265f4f3902884f71e4189668d\na4b3b0705e57e90f309e2e34be0f3953\n560cfa96662fb8e4847fc0949078068f\n-----END OpenVPN Static key V1-----\n</tls-auth>\nauth-user-pass\nns-cert-type server\ncomp-lzo\nverb 3', 0, 1476972205);

-- --------------------------------------------------------

--
-- 表的结构 `lyj_category`
--

CREATE TABLE IF NOT EXISTS `lyj_category` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT '默认栏目',
  `description` varchar(255) NOT NULL DEFAULT '栏目简介',
  `sortby` int(5) NOT NULL DEFAULT '0',
  `hidden` int(2) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='栏目表';

--
-- 转存表中的数据 `lyj_category`
--

INSERT INTO `lyj_category` (`id`, `name`, `description`, `sortby`, `hidden`) VALUES
(1, '移动', '', 1, 0),
(2, '联通', '', 2, 0),
(3, '电信', '', 3, 0);

-- --------------------------------------------------------

--
-- 表的结构 `lyj_link`
--

CREATE TABLE IF NOT EXISTS `lyj_link` (
  `id` int(8) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `name` varchar(200) NOT NULL DEFAULT '链接名称',
  `description` varchar(255) NOT NULL DEFAULT '链接简介',
  `url` varchar(255) NOT NULL DEFAULT 'http://',
  `icon` varchar(255) NOT NULL DEFAULT 'http://',
  `sortby` int(5) NOT NULL DEFAULT '0',
  `hidden` int(2) NOT NULL DEFAULT '0',
  `timeline` int(8) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='友链表';

--
-- 转存表中的数据 `lyj_link`
--

INSERT INTO `lyj_link` (`id`, `category_id`, `name`, `description`, `url`, `icon`, `sortby`, `hidden`, `timeline`) VALUES
(2, 1, '卡密地址', '链接简介', 'http://baidu.com', '.', 0, 0, 1470804616),
(3, 1, '卡密购买', '链接简介', 'http://www.lenged.cn', '.', 1, 0, 1470804640),
(4, 1, '流控地址', '链接简介', 'http://123456789:8888/', '.', 2, 0, 1470804683),
(5, 1, '官方商城', '链接简介', 'http://lenged.cn', '.', 3, 0, 1470804714),
(6, 1, '使用说明', '链接简介', 'http://dd', '.', 4, 0, 1470804734),
(7, 1, '背景图片', '链接简介', 'http://1', '.', 5, 0, 1470804751);

-- --------------------------------------------------------

--
-- 表的结构 `lyj_setting`
--

CREATE TABLE IF NOT EXISTS `lyj_setting` (
  `id` int(10) unsigned NOT NULL,
  `skey` varchar(100) NOT NULL DEFAULT '要设置的键',
  `sval` varchar(1024) NOT NULL DEFAULT '要设置的值'
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='设置表';

--
-- 转存表中的数据 `lyj_setting`
--

INSERT INTO `lyj_setting` (`id`, `skey`, `sval`) VALUES
(1, 'contact', ''),
(2, 'seo_title', ''),
(3, 'seo_keywords', '欢迎使用传说流控系统！'),
(4, 'seo_description', '欢迎使用传说流控系统，祝您使用愉快！'),
(5, 'copyright', '');

-- --------------------------------------------------------

--
-- 表的结构 `lyj_token`
--

CREATE TABLE IF NOT EXISTS `lyj_token` (
  `id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `token` varchar(32) NOT NULL,
  `expire_timeline` int(10) NOT NULL,
  `update_timeline` int(10) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='ç™»å½•ä»¤ç‰Œè¡¨';

--
-- 转存表中的数据 `lyj_token`
--

INSERT INTO `lyj_token` (`id`, `user_id`, `token`, `expire_timeline`, `update_timeline`) VALUES
(1, 1, '9fda638ea1677b070005c07a98b4bd39', 1472321068, 1469729068),
(2, 2, '1ade3b90bde227ec3242fa4c65369ad9', 1789665003, 1789665003);

-- --------------------------------------------------------

--
-- 表的结构 `lyj_user`
--

CREATE TABLE IF NOT EXISTS `lyj_user` (
  `id` int(10) unsigned NOT NULL,
  `account` varchar(15) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `nick` varchar(15) NOT NULL,
  `face` varchar(255) DEFAULT NULL,
  `sex` int(2) DEFAULT '0',
  `device_id` varchar(20) NOT NULL,
  `is_forbidden` int(10) NOT NULL DEFAULT '0',
  `is_app` int(2) DEFAULT '0',
  `timeline` int(10) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='用户表';

--
-- 转存表中的数据 `lyj_user`
--

INSERT INTO `lyj_user` (`id`, `account`, `password`, `nick`, `face`, `sex`, `device_id`, `is_forbidden`, `is_app`, `timeline`) VALUES
(1, 'admin', 'e10adc3949ba59abbe56e057f20f883e', '传说科技', '', 1, '1789665003', 0, 0, 0),
(2, 'zjj', '369189fb6b1d00e690a15496240d09d8', '传说科技', '', 1, '1789665003', 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lyj_article`
--
ALTER TABLE `lyj_article`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `title` (`title`);

--
-- Indexes for table `lyj_category`
--
ALTER TABLE `lyj_category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `lyj_link`
--
ALTER TABLE `lyj_link`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `url` (`url`);

--
-- Indexes for table `lyj_setting`
--
ALTER TABLE `lyj_setting`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `skey` (`skey`);

--
-- Indexes for table `lyj_token`
--
ALTER TABLE `lyj_token`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `lyj_user`
--
ALTER TABLE `lyj_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `account` (`account`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `lyj_article`
--
ALTER TABLE `lyj_article`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `lyj_category`
--
ALTER TABLE `lyj_category`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `lyj_link`
--
ALTER TABLE `lyj_link`
  MODIFY `id` int(8) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `lyj_setting`
--
ALTER TABLE `lyj_setting`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `lyj_token`
--
ALTER TABLE `lyj_token`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `lyj_user`
--
ALTER TABLE `lyj_user`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
