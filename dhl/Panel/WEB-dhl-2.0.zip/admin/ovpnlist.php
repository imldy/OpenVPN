<?php
$mod='blank';
include("../api.inc.php");
$title='模式列表';
include './head.php';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
include './nav.php';

?>
<?php
require_once ("head.php");

?>
<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<div class="panel panel-primary">
<div class="panel-heading w h"><h3 class="panel-title"><?php echo $title ?></h3></div>
<div class="panel-body box">
			
<?php

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='del'){
echo '
<div class="panel-heading w h"><h3 class="panel-title">删除模式</h3></div>
<div class="panel-body box">';
$id=$_REQUEST['id'];
$sql=$DB->query("DELETE FROM `lyj_article` WHERE id='$id'");
if($sql){echo '删除成功！';}
else{echo '删除失败！';}
echo '<hr/><a href="./ovpnlist.php">>>返回模式列表</a></div></div>';
}
?><div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">	   
      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th>名称</th><th>添加时间</th><th>操作</th></tr></thead>
          <tbody>
<?php

$rs=$DB->query("SELECT * FROM `lyj_article` ");
while($res = $DB->fetch($rs))
{ ?>
<tr>
<td><?=$res['title']?></td>
<td><?=$res['timeline']?></td>
<td><a class="btn btn-xs btn-success" href="./ovpnset.php?ovpn=<?=$res['id']?>">配置</a>&nbsp;<a href="./ovpnlist.php?my=del&id=<?=$res['id']?>" class="btn btn-xs btn-danger" onclick="if(!confirm('你确实要删除此模式吗？')){return false;}">删除</a></td>
</tr>

<?php }
?>
          </tbody>
        </table>
      </div>

    </div>
  </div>
<script type="text/javascript">
    function del(){
      var str="";
      $("input[name='ids']").each(function(){ 
          if($(this).prop('checked')){
            str += $(this).val()+","
          }
      })
      $.post('delall.php?action=delall',{ids:str},function(data){
        alert(data);
        window.location.reload();
      });
      
    }
   function checkAll(obj){
      $("input[type='checkbox']").prop('checked', $(obj).prop('checked'));
  }

</script>
                  
                    
                  
              </div>
            </section>
</section>
</section>

<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a></section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
<div class="wrapper">
	Notification
</div>
</aside>
<!-- end -->
<?php
require_once ("foot.php");
?>