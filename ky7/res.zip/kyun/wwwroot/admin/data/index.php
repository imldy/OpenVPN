<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：显示平台所有功能列表
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

if($is_login == 'ok'){
$user = db("openvpn")->where(array())->getnums();
$kms = db("ky_km")->where(array('kind'=>'1'))->getnums();
?>
<html>
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width,user-scalable=no"/>
    <meta name="renderer" content="webkit">
    <title>管理员平台 - <?php echo admin_copy(logo);?></title>

    <meta name="keywords" content="快云免流，快云流控，快云流量，NB免流，NB流控">
    <meta name="description" content="快云免流，快云流控，快云流量，NB免流，NB流控">

    <link rel="shortcut icon" href="../../assets/img/favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
<style> 
.parent { 
   position: absolute;
   top: 10px;
   right: 6px;
} 
</style> 
	
</head>
<body class="fixed-sidebar full-height-layout gray-bg" style="overflow:hidden">
 <div id="Awrapper">
    <div id="wrapper">
	 <!--左侧导航开始-->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="nav-close"><i class="fa fa-times-circle"></i>
            </div>
            <div class="sidebar-collapse">
                <ul class="nav" id="side-menu">
                    <li class="nav-header">
                        <div class="dropdown profile-element">
                            <a data-toggle="dropdown" class="dropdown-toggle" href="N17_admin.php">
                                <span class="clear">
                                    <span class="block m-t-xs" style="font-size:20px;">
									 <img alt="image" class="img-circle"  height="160" width="160" src="<?php echo admin_copy(logo2);?>"></img>
                                    </span>
                                </span>
                               </a>
                           </div>
						<div class="logo-element"><img alt="image" class="img-circle"  height="70" width="70" src="<?php echo admin_copy(logo2);?>">
                       </div>
                     </li>
                    <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                        <span class="ng-scope">数据信息</span>
                    </li>
                    <li>
                        <a class="J_menuItem" href="N17_admin.php">
                            <i class="fa fa-dashboard"></i>
                            <span class="nav-label">平台首页</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa fa-recycle"></i>
                            <span class="nav-label">实时监控</span>
                            <span class="fa arrow"></span>
                        </a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a class="J_menuItem" href="online_list.php">在线检测</a>
                            </li>
                            <li>
                                <a class="J_menuItem" href="jiankong.php">监控日志</a>
                            </li>
                            <li>
                                <a class="J_menuItem" href="user_log.php">操作记录</a>
                            </li>
                        </ul>
                    </li>
                    <li class="line dk"></li>
                    <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                        <span class="ng-scope">用户信息</span>
                    </li>
                    <li>
                      <a href="#"><i class="fa fa-users"></i><span class="nav-label">账号管理</span><span class="label label-info pull-right">New</span></a>
                        <ul class="nav nav-second-level">
                           <li><a class="J_menuItem" href="add_user.php">添加新账号</a>
                            </li>
							<li><a class="J_menuItem" href="padd_user.php">批量添加账号</a>
                            </li>
                            <li><a class="J_menuItem" href="user_list.php">账号列表<span class="label label-info pull-right"><?php echo $user;?></span></a>
                            </li>
							<li><a class="J_menuItem" href="user_area.php">用户分布情况<span class="label label-danger pull-right">New</span></a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-book"></i><span class="nav-label">卡密管理</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li><a class="J_menuItem" href="kms_list.php">卡密列表<span class="label label-info pull-right"><?php echo $kms;?></span></a>
                            </li>
                            <li><a class="J_menuItem" href="suo_kms.php">搜索卡密</a>
                            </li>
                            <li><a class="J_menuItem" href="ago_kms.php">上次生成卡密</a>
                            </li>
                        </ul>
                    </li>
					 <li>
                        <a href="#"><i class="fa fa-shopping-cart"></i><span class="nav-label">套餐管理</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                           <li>
						    <a class="J_menuItem" href="add_taocan.php">添加新套餐</a>
                            </li>
							 <li><a class="J_menuItem" href="taocan_list.php">套餐列表</a>
                            </li>
                            <li><a class="J_menuItem" href="pay_set.php">支付接口信息</a>
                            </li>
							<li><a class="J_menuItem" href="buy_list.php">交易记录列表</a>
                            </li>
                        </ul>
                    </li>
					 <li>
                        <a href="#"><i class="fa fa-sitemap"></i><span class="nav-label">负载集群管理</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
							<li><a class="J_menuItem" href="add_note.php">添加新节点</a>
                            </li>
                           <li><a class="J_menuItem" href="note_list.php">节点列表</a>
                            </li>
                        </ul>
                    </li>
                    <li class="line dk"></li>
                    <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                        <span class="ng-scope">代理信息</span>
                    </li>
                    <li>
                      <a href="#"><i class="fa fa-cube"></i><span class="nav-label">代理管理</span><span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
						 <li><a class="J_menuItem" href="add_daili.php">添加新代理</a>
                            </li>
						  <li><a class="J_menuItem" href="daili_list.php">代理列表</a>
                            </li>
							<li><a class="J_menuItem" href="line_check.php">代理线路审核</a>
                            </li>
						 </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-shield"></i><span class="nav-label">云端管理</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
						   <li><a class="J_menuItem" href="add_ggao.php">发布新公告</a>
                            </li>
							 <li><a class="J_menuItem" href="ggao_list.php">公告列表</a>
                            </li>
							<li><a class="J_menuItem" href="fank_list.php">用户反馈列表</a>
                            </li>
                        </ul>
                    </li>
					  <li>
                        <a href="#"><i class="fa fa-shekel"></i><span class="nav-label">线路管理</span><span class="label label-danger pull-right">Hot</span></a>
						 <ul class="nav nav-second-level">
						     
							<li><a class="J_menuItem" href="add_line.php">添加新线路</a>
                            </li>
                            <li><a class="J_menuItem" href="line_list.php">线路列表</a>
                            </li>
						  <li><a class="J_menuItem" href="set_zhshu.php">修改线路证书</a>
                            </li>
                        </ul>
					 </li>
                    <li class="line dk"></li>
                    <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                        <span class="ng-scope">服务信息</span>
                    </li>
					 <li>
                        <a href="#"><i class="fa fa-user-md"></i><span class="nav-label">高级管理 </span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
						 <li>
						  <a class="J_menuItem" href="kyun_cfg.php">平台信息</a>
							<li>
                             <a class="J_menuItem" href="system.php">系统服务设置</a>
                            </li>
						  <li><a class="J_menuItem" href="pass_set.php">修改密码</a>
                            </li>
                        </ul>
                    </li>
					<li>
                        <a href="../Kyun/index.php?logout"><i class="fa fa-sign-in"></i><span class="nav-label">退出登录</span></a>
				    </li>
                    <li>
                        <a href="#"><i class="fa fa-gears"></i><span class="nav-label">系统版本信息 </span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li><a class="J_menuItem">PHP 版本：<?php echo PHP_VERSION;?></a>
                            </li>
                            <li><a class="J_menuItem">MySQL 版本：5.5.52</a>
                            </li>
                            <li><a class="J_menuItem">WEB 版本：N17-<?=$NowVersion?>  </a>
                            </li>
                        </ul>
                    </li>
                 </ul>
			   <br>
            </div>
        </nav>
        <!--左侧导航结束-->
        <!--右侧部分开始-->
         <div id="page-wrapper" class="gray-bg dashbard-1">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
                    <div class="navbar-header">
					  <a class="navbar-minimalize minimalize-styl-2 btn btn-info" href="#"><i class="fa fa-bars"></i> </a>
                        <form role="search" class="navbar-form-custom" method="post" action="#">
                            <div class="form-group">
                                <input type="text" placeholder="OpenVPN丨<?php echo admin_copy(logo);?>" class="form-control" name="top-search" id="top-search">
                            </div>
                        </form>
                    </div> 
				   <div class="parent pull-right">
				         <a id="btn" class="btn btn-sm btn-white"><i class="fa fa-expand"></i>&nbsp;全屏</a>
						 <a class="btn btn-sm btn-white" onclick="ShuaXin()"><i class="fa fa-refresh"></i>&nbsp;刷新</a>
						 <a class="btn btn-sm btn-white" href="../Kyun/index.php?logout"><i class="fa fa-sign-in"></i>&nbsp;注销</a>
                        </div>
                </nav>
            </div>
        <div class="row J_mainContent" id="content-main">
                <iframe id="J_iframe" width="100%" height="100%" src="N17_admin.php" frameborder="0" data-id="N17_admin.php" scrolling="yes"></iframe>
         </div>  
     <!--右侧部分结束-->
    </div>
   </div>  
    <!-- 全局js -->
    <script src="../../assets/js/jquery.min.js?v=2.1.4"></script>
    <script src="../../assets/js/bootstrap.min.js?v=3.3.6"></script>
    <script src="../../assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="../../assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script type="text/javascript" src="../../assets/js/index.js"></script>
    <script src="../../assets/js/hAdmin.js?v=4.1.0"></script> 
</body>
<script language="JavaScript">
function ShuaXin()
{
  document.getElementById('J_iframe').contentWindow.location.reload(true);
}

function fullScreen(el) {
    var rfs = el.requestFullScreen || el.webkitRequestFullScreen || el.mozRequestFullScreen || el.msRequestFullScreen,
        wscript;
 
    if(typeof rfs != "undefined" && rfs) {
        rfs.call(el);
        return;
    }
 
    if(typeof window.ActiveXObject != "undefined") {
        wscript = new ActiveXObject("WScript.Shell");
        if(wscript) {
            wscript.SendKeys("{F11}");
        }
    }
}

function exitFullScreen(el) {
    var el= document,
    	cfs = el.cancelFullScreen || el.webkitCancelFullScreen || el.mozCancelFullScreen || el.exitFullScreen,
        wscript;
 
    if (typeof cfs != "undefined" && cfs) {
      cfs.call(el);
      return;
    }
 
    if (typeof window.ActiveXObject != "undefined") {
        wscript = new ActiveXObject("WScript.Shell");
        if (wscript != null) {
            wscript.SendKeys("{F11}");
        }
  }
}

function f_IsFullScreen() { 
  return (document.body.scrollHeight == window.screen.height && document.body.scrollWidth == window.screen.width); 
} 

var btn = document.getElementById('btn');  
        var content = document.getElementById('Awrapper');  
        btn.onclick = function(){
          if(!f_IsFullScreen()){
			  fullScreen(content);
			  $("#btn").html('<i class="fa fa-compress"></i>&nbsp;退出');		
		  }else{
			  exitFullScreen();
			   $("#btn").html('<i class="fa fa-expand"></i>&nbsp;全屏');		
		  }			
     }  
</script>
</html>
<?php
}else{
	exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");
} 	
?>