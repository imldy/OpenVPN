<?php
/**
 * 登录后台
**/
error_reporting(E_ALL); 
$mod='blank';
include("../api.inc.php");
if(isset($_POST['user']) && isset($_POST['pass'])){
	$user=daddslashes($_POST['user']);
	$pass=daddslashes($_POST['pass']);
	//$row = $DB->get_row("SELECT * FROM `admin` limit 1");
	//$user==$row['username'] && $pass==$row['password']
	if($user==$adminuser && $pass==$adminpass) {
		$session=md5($user.$pass.$password_hash);
		$token=authcode("{$user}\t{$session}", 'ENCODE', SYS_KEY);
		setcookie("ol_token", $token, time() + 604800);
		@header('Content-Type: text/html; charset=UTF-8');
		exit("<script language='javascript'>alert('登录成功！');window.location.href='./';</script>");
	}elseif ($pass != $row['pass']) {
		@header('Content-Type: text/html; charset=UTF-8');
		exit("<script language='javascript'>alert('用户名或密码不正确！');history.go(-1);</script>");
	}
}elseif(isset($_GET['logout'])){
	setcookie("ol_token", "", time() - 604800);
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('您已成功注销本次登录！');window.location.href='./login.php';</script>");
}elseif($islogin2==1){
	exit("<script language='javascript'>alert('您已登录！');window.location.href='./';</script>");
}

?>
<!DOCTYPE html>
<html>  
<head>
    <meta charset="utf-8"/>
	<title>管理员后台</title>
    <!--<link href="http://fonts.googleapis.com/css?family=Lato:100,300,400,700" media="all" rel="stylesheet" type="text/css" />-->
        <link rel="shortcut icon" href="../images/favicon.ico">
	<link href="../css/bootstrap.min.css" media="all" rel="stylesheet" type="text/css" /><link href="../css/font-awesome.css" media="all" rel="stylesheet" type="text/css" /><link href="../css/se7en-font.css" media="all" rel="stylesheet" type="text/css" /><link href="../css/style.css" media="all" rel="stylesheet" type="text/css" />
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<script src="../js/jquery-ui.js" type="text/javascript"></script>
	<script src="../js/jquery.cookie.js" type="text/javascript"></script>
	<script src="../js/bootstrap.min.js" type="text/javascript"></script><script src="../js/raphael.min.js" type="text/javascript"></script><script src="../js/jquery.mousewheel.js" type="text/javascript"></script><script src="../js/jquery.vmap.min.js" type="text/javascript"></script><script src="../js/jquery.vmap.sampledata.js" type="text/javascript"></script><script src="../js/jquery.vmap.world.js" type="text/javascript"></script><script src="../js/jquery.bootstrap.wizard.js" type="text/javascript"></script><script src="../js/fullcalendar.min.js" type="text/javascript"></script><script src="../js/gcal.js" type="text/javascript"></script><script src="../js/jquery.dataTables.min.js" type="text/javascript"></script><script src="../js/datatable-editable.js" type="text/javascript"></script><script src="../js/jquery.easy-pie-chart.js" type="text/javascript"></script><script src="../js/excanvas.min.js" type="text/javascript"></script><script src="../js/jquery.isotope.min.js" type="text/javascript"></script><script src="../js/masonry.min.js" type="text/javascript"></script><script src="../js/modernizr.custom.js" type="text/javascript"></script><script src="../js/jquery.fancybox.pack.js" type="text/javascript"></script><script src="../js/select2.js" type="text/javascript"></script><script src="../js/styleswitcher.js" type="text/javascript"></script><script src="../js/wysiwyg.js" type="text/javascript"></script><script src="../js/jquery.inputmask.min.js" type="text/javascript"></script><script src="../js/jquery.validate.js" type="text/javascript"></script><script src="../js/bootstrap-fileupload.js" type="text/javascript"></script><script src="../js/bootstrap-datepicker.js" type="text/javascript"></script><script src="../js/bootstrap-timepicker.js" type="text/javascript"></script><script src="../js/bootstrap-colorpicker.js" type="text/javascript"></script><script src="../js/bootstrap-switch.min.js" type="text/javascript"></script><script src="../js/daterange-picker.js" type="text/javascript"></script><script src="../js/date.js" type="text/javascript"></script><script src="../js/morris.min.js" type="text/javascript"></script><script src="../js/skycons.js" type="text/javascript"></script><script src="../js/jquery.sparkline.min.js" type="text/javascript"></script><script src="../js/fitvids.js" type="text/javascript"></script><script src="../js/main.js" type="text/javascript"></script><script src="../js/respond.js" type="text/javascript"></script>
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport">
  </head>
  <body class="login1">
    <!-- Login Screen -->
    <div class="login-wrapper">
      <div class="login-container">
        <form id="myform" action="./login.php" method="post" class="panel-body wrapper-lg">
		  <div class="form-group">
            <input id="username" class="form-control" placeholder="管理员" type="text" name="user">
          </div>
          <div class="form-group">
            <input id="password" class="form-control" placeholder="密码" type="password" name="pass"><input type="submit" value="&#xf054;">
          </div>
          <div class="form-options clearfix">
            <!--<a class="pull-right" href="#">忘记密码?</a>-->
            <div class="text-left">
              <label class="checkbox"><input id="remember" type="checkbox"><span>记住密码</span></label>
            </div>
          </div>
        </form>
		<p class="text-muted text-center">大灰狼免流</font></br>dhlml.cn</p>
        <div class="social-login clearfix"></div>
      </div>
    </div>
    <!-- End Login Screen -->
    <script type="text/javascript">
    $(document).ready(function(){
    	if($.cookie('rmbUser') == 'true'){
            $('#remember').attr('checked',true);
            $('#username').val($.cookie('username'));
            $('#password').val($.cookie('password'));
        }

    	$('#myform').submit(function() {
    		if($('#remember').is(':checked')){
    	        $.cookie('rmbUser','true',{expires:7});
    	        $.cookie('username',$('#username').val(),{expires:7});
    	        $.cookie('password',$('#password').val(),{expires:7});
    	    }else{
    	        $.cookie('rmbUser','false',{expires:-1});
    	        $.cookie('username','',{expires:-1});
    	        $.cookie('password','',{expires:-1});
    	    }
      		 return true; 
   		});
        
    });
  	</script>
  </body>
</html>