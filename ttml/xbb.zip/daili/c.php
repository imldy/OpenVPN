<?php

$mod='blank';
include("../api.inc.php");
$title='代理中心';
include './head.php';
$dlid=$_SESSION['dlid'];
$row = $DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$rs=$DB->get_row("SELECT * FROM auth_config WHERE 1");
$vip=$row['vip'];
$rmb=$row['rmb'];
$km = daddslashes($_POST['km']);
$kmrow = $DB->get_row("SELECT * FROM auth_kms WHERE km='{$km}' and kind=2 limit 1");
echo $kmrow
?>