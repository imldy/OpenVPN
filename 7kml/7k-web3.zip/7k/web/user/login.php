<?php

/**
 * 登录
**/
$mod='blank';
include("../api.inc.php");
$title='用户登录';

?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body>

			
				<script type="text/javascript">
					jQuery(document).ready(function($)
					{
						// Reveal Login form
						setTimeout(function(){ $(".fade-in-effect").addClass('in'); }, 1);
						
						
						// Validation and Ajax action
						$("form#login").validate({
							rules: {
								user: {
									required: true
								},
								
								pass: {
									required: true
								}
							},
							
							messages: {
								user: {
									required: '此为必填项！'
								},
								
								pass: {
									required: '此为必填项！'
								}
							},
							
						});
						
						// Set Form focus
						$("form#login .form-group:has(.form-control):first .form-control").focus();
					});
				</script>
				

   <div class="wrapper">
      <div class="block-center mt-xl wd-xl">
         <!-- START panel-->
         <div class="panel panel-dark panel-flat">
            <div class="panel-heading text-center">
               <a href="#">
                  <img src="../assets/img/logo.png" alt="Image" class="block-center img-rounded">
               </a>
            </div>
            <div class="panel-body">
               <p class="text-center pv"><?php
  $rs=$DB->get_row("SELECT * FROM website");
  $webtitle=$rs['title'];
   echo $webtitle
    ?></p> 
	  <form action="index.php" method="get" role="form" id="login" class="login-form fade-in-effect">
					
                  <div class="form-group has-feedback">
                     <input id="user" name="user" type="text" placeholder="请输入您的帐号" autocomplete="off" required class="form-control">
                     <span class="fa fa-comment form-control-feedback text-muted"></span>
                  </div>
				  
                  <div class="form-group has-feedback">
                     <input id="pass" name="pass" type="text" placeholder="请输入您的密码" autocomplete="off" required class="form-control">
                     <span class="fa fa-lock form-control-feedback text-muted"></span>
                  </div>
                  <p>
					<div class="login-footer text-center">
						如忘记密码，请与代理商联系找回！
						
					</div>	<p>				
					<div class="loginbox-submit">
						<button type="submit" class="btn btn-info  btn-block text-center">
							马上登录
						</button>
					</div>
               <p class="pt-lg text-center">还没有帐号？立即注册吧！</p><a href="reg.php" class="btn btn-block btn-default">立即注册</a>
            </div>					

					
				</form>

				
			</div>
			
		</div>
		
         <div class="p-lg text-center">
            <span>&copy;</span>
            <span>2016</span>
            <span>-</span>
            <span><?php
  $rs=$DB->get_row("SELECT * FROM website");
  $webtitle=$rs['title'];
   echo $webtitle
    ?></span>
         </div>
      </div>
   </div>

   <script src="../assets/modernizr/modernizr.custom.js"></script>
   <script src="../assets/jquery/dist/jquery.js"></script>
   <script src="../assets/bootstrap/dist/js/bootstrap.js"></script>
   <script src="../assets/jQuery-Storage-API/jquery.storageapi.js"></script>
   <script src="../assets/parsleyjs/dist/parsley.min.js"></script>
   <script src="../assetsjs/app.js"></script>
</body>
</html>