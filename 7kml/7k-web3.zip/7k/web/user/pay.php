<?php
$mod='blank';
include("../api.inc.php");

$u = daddslashes($_GET['user']);
$p = daddslashes($_GET['pass']);
$res=$DB->get_row("SELECT * FROM `openvpn` where `iuser`='$u' && `pass`='$p' limit 1");
if(!$res){
//	header('location: login.php');
		exit("<script language='javascript'>alert('未正确登录，或用户名或密码不正确！');window.location.href='/user/login.php';</script>");
}

/*获取代理信息*/
$daili_info = $DB->get_row("SELECT * FROM openvpn where `iuser`='{$u}'");
$daili_info_id=$daili_info['dlid'];
//echo "<script language='javascript'>alert('获取代理信息：".$daili_info_id."');</script>";

if($daili_info_id){
	$config_dl = $DB->get_row("SELECT * FROM auth_daili WHERE id='$daili_info_id' limit 1");
	$config_name=$config_dl['name'];//代理姓名
	$config_qq=$config_dl['qq'];
	$config_tel=$config_dl['tel'];
	$config_buy=$config_dl['buy'];//购买链接
	$config_buy2=$config_dl['buy2'];//购买代码
	//echo "<script language='javascript'>alert('获取代理信息：".$config_name."');</script>";
}else{
	$rs=$DB->get_row("SELECT * FROM website where id='$site_id'");
	$config_name=$rs['title'];
	$config_qq=$rs['qq'];
	$config_tel=$rs['tel'];

	$rs2=$DB->get_row("SELECT * FROM auth_config");
	$config_buy=$rs2['shopUrl'];
	$config_buy2=$rs2['shopCode'];
}


    //获取套餐信息：
    $id = daddslashes($_GET['id']);
    $kmtype=$DB->get_row("SELECT * FROM `kmtype` WHERE `id` = $id");
    $kmtype_name = $kmtype['name'];
    $kmtype_rmb = $kmtype['km_rmb'];
    //$kmtype_rmb = '0.01';//调试价格

?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<!-- Body -->
<body>
        <?php include 'nav.php';?>
		      <section>
         <!-- Page content-->
         <div class="content-wrapper">
            <h3><?php echo $title ?>
               <small>请确认订单信息</small>
            </h3>
 

					<form action="/pay/alipayapi.php" class="alipayform" method="post" target="_blank">
					<ul class="list-group list-group-minimal">
						<li class="list-group-item">
							<?php
							$d=time();
							?>
							<span class="badge btn-green badge-warning"><?php echo "" . date("Ymdhis", $d);?></span>
							<input type="text" name="WIDout_trade_no" id="out_trade_no" value="<?php echo "" . date("Ymdhis", $d);?>" class="hide">
							订单号
						</li>
						<li class="list-group-item">
							<span class="badge btn-green badge-info"><?php echo $kmtype_name?></span>
							<input type="text" name="WIDsubject" value="<?php echo $kmtype_name?>" class="hide">
							商品名称
						</li>
						<li class="list-group-item">
							<span class="badge btn-green badge-danger"><?php echo $kmtype_rmb?></span>
							<input type="text" name="WIDtotal_fee" value="<?php echo $kmtype_rmb?>" class="hide">
							付款金额
						</li>
						<input type="text" name="WIDbody" value="<?php echo $u?>" class="hide">
					</ul>
					<button type="submit" class="btn btn-success btn-icon btn-block">
						<i class="fa fa-check"></i>
						<span>确认支付</span>
					</button>
					<a href="javascript:history.go(-1)" type="submit" class="btn btn-white btn-icon btn-block">
						<i class="fa fa-reply"></i>
						<span>重选套餐</span>
					</a>
					</form>
					
				</div>

			</div>

			<!-- Main Footer -->
			<?php include("../copy.php");?>
