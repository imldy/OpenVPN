<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
exit("<script language='javascript'>window.location.href='./Kyun';</script>");
?>