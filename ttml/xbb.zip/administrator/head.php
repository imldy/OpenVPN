<?php
?>
<?php
    echo '

<!DOCTYPE html>


<html lang="en">

<head>
<meta charset="UTF-8">
<title>';
    echo $title
?><?php
    echo " - 天天免流管理中心</title>
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
<link rel=\"shortcut icon\" href=\"../static/index/images/favicon.ico\">
   <link rel=\"stylesheet\" href=\"/static/fontawesome/css/font-awesome.min.css\">
   <link rel=\"stylesheet\" href=\"/static/simple-line-icons/css/simple-line-icons.css\">
   <link rel=\"stylesheet\" href=\"http://cdn.xkmz.cc/xkmz/angle/vendor/animate.css/animate.min.css\">
   <link rel=\"stylesheet\" href=\"http://cdn.xkmz.cc/xkmz/angle/vendor/whirl/dist/whirl.css\">
   <link rel=\"stylesheet\" href=\"http://cdn.xkmz.cc/xkmz/angle/vendor/weather-icons/css/weather-icons.min.css\">
   <link rel=\"stylesheet\" href=\"http://cdn.xkmz.cc/xkmz/angle/app/css/bootstrap.css\" id=\"bscss\">
   <link rel=\"stylesheet\" href=\"http://cdn.xkmz.cc/xkmz/angle/app/css/app.css\" id=\"maincss\">
   <link rel=\"stylesheet\" href=\"http://cdn.xkmz.cc/xkmz/angle/vendor/sweetalert/dist/sweetalert.css\">

<link rel=\"stylesheet\" href=\"http://cdn.xkmz.cc/xkmz/angle/vendor/layer/skin/layer.css\" id=\"layui_layer_skinlayercss\"></head>

<body>
   <div class=\"wrapper\">
      <header class=\"topnavbar-wrapper\">
         <nav role=\"navigation\" class=\"navbar topnavbar\" style=\"font-size:14px;\">
            <div class=\"navbar-header\">
              <a href=\"./\" class=\"navbar-brand\">
               </a>
            </div>
            <div class=\"nav-wrapper\">
               <ul class=\"nav navbar-nav\">
                  <li>
                     <a href=\"javascript:;\" data-trigger-resize=\"\" data-toggle-state=\"aside-collapsed\" class=\"hidden-xs\">
                        <em class=\"fa fa-navicon\"></em>
                     </a>
                     <a href=\"javascript:;\" data-toggle-state=\"aside-toggled\" data-no-persist=\"true\" class=\"visible-xs sidebar-toggle\">
                        <em class=\"fa fa-navicon\"></em>
                     </a>
                  </li>
                  <li>
                     <a href=\"./qqlist.php\" ui-sref=\"userinfo\">
                        <em class=\"icon-user\"></em>
                     </a>
                  </li>
                  <li>
                     <a href=\"./login.php?logout\">
                        <em class=\"icon-lock\"></em>
                     </a>
                  </li>
                  <li>
                     <a href=\"./addqq.php\" ui-sref=\"add\">
                        <em class=\"icon-plus\"></em>
                     </a>
                  </li>
               </ul>
               <ul class=\"nav navbar-nav navbar-right\">
                  <li>
                     <a href=\"javascript:;\" data-search-open=\"\">
                        <em class=\"icon-magnifier\"></em>
                     </a>
                  </li>
                  <li class=\"visible-lg\">
                     <a href=\"javascript:;\" data-toggle-fullscreen=\"\">
                        <em class=\"icon-size-fullscreen\"></em>
                     </a>
                  </li>
               </ul>
            </div>
            <form action=\"qqlist.php\" method=\"get\" class=\"navbar-form ng-pristine ng-valid\">
               <div class=\"form-group has-feedback\">
                  <input type=\"text\" placeholder=\"搜索用户\" name=\"kw\" class=\"form-control\" style=\"padding-right: 65px;\" maxlength=\"10\" onkeyup=\"this.value=this.value.replace(/\D/g,'')\">
                  <label class=\"form-control-feedback\" id=\"search\"><em class=\"icon-magnifier\"></em></label>
               </div>
            </form>
         </nav>
      </header>
      <aside class=\"aside\">
         <div class=\"aside-inner\">
            <nav data-sidebar-anyclick-close=\"\" class=\"sidebar\">
               <ul class=\"nav\">
                  <li ng-class=\"{active:path=='/'}\" href=\"./index.php\"ng-click=\"val = 'a'\" class=\"active\">
                     <a href=\"./index.php\" ui-sref=\"user\">
                        <em class=\"icon-home\" style=\"font-size:14px;\"></em>
                        <span>平台首页</span>
                     </a>
                  </li>
                  <li ng-class=\"{active:val == 2}\" ng-click=\"val = 2\">
                     <a href=\".daigua\" data-toggle=\"collapse\">
                        <em class=\"icon-rocket\" style=\"font-size:14px;\"></em>
                        <span>服务管理</span>
                     </a>
                     <ul class=\"nav sidebar-subnav collapse daigua\">
                        <li ng-class=\"{active:path == '/daigua/add'}\">
                           <a href=\"./fwqlist.php\" ui-sref=\"daigua({xz:'add'})\">
                              <span>服务列表</span>
                           </a>
                        </li>
                        <li ng-class=\"{active:path == '/daigua/list'}\">
                           <a href=\"./addfwq.php\" ui-sref=\"daigua({xz:'list'})\">
                              <span>添加服务</span>
                           </a>
                        </li>
                        <li ng-class=\"{active:path == '/daigua/km'}\">
                           <a href=\"./log.php\" ui-sref=\"daigua({xz:'km'})\">
                              <span>操作记录</span>
                           </a>
                        </li>
                        <li ng-class=\"{active:path == '/daigua/km'}\">
                           <a href=\"./dlconfig.php\" ui-sref=\"daigua({xz:'km'})\">
                              <span>平台设置</span>
                           </a>
                        </li>
                     </ul>
                  </li>
				  <li ng-class=\"{active:val == 1}\" ng-click=\"val = 1\">
                     <a href=\".shoop\" data-toggle=\"collapse\">
                        <em class=\"icon-chemistry\" style=\"font-size:14px;\"></em>
                        <span>在线监控</span>
                     </a>
                     <ul class=\"nav sidebar-subnav collapse shoop\">
                        <li ng-class=\"{active:path == '/shoop/vip'}\">
                           <a href=\"./tcpzx.php\" ui-sref=\"shoop({xz:'vip'})\">
                              <span>TCP在线</span>
                           </a>
                        </li>
                        <li ng-class=\"{active:path == '/shoop/peie'}\">
                           <a href=\"./jian.php\" ui-sref=\"shoop({xz:'peie'})\">
                              <span>TCP监控</span>
                           </a>
                        </li>
						<li ng-class=\"{active:path == '/shoop/peiei'}\">
                           <a href=\"./mysqlbf.php\" ui-sref=\"shoop({xz:'peie'})\">
                              <span>备份日志</span>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li ng-class=\"{active:val == 1}\" ng-click=\"val = 1\">
                     <a href=\".shop\" data-toggle=\"collapse\">
                        <em class=\"icon-handbag\" style=\"font-size:14px;\"></em>
                        <span>账号管理</span>
                     </a>
                     <ul class=\"nav sidebar-subnav collapse shop\">
                        <li ng-class=\"{active:path == '/shop/vip'}\">
                           <a href=\"./addqq.php\" ui-sref=\"shop({xz:'vip'})\">
                              <span>添加账号</span>
                           </a>
                        </li>
                        <li ng-class=\"{active:path == '/shop/peie'}\">
                           <a href=\"./pladd.php\" ui-sref=\"shop({xz:'peie'})\">
                              <span>批量添加</span>
                           </a>
                        </li>
                        <li ng-class=\"{active:path == '/shop/daigua'}\">
                           <a href=\"./qqlist.php\" ui-sref=\"shop({xz:'daigua'})\">
                              <span>账号列表</span>
                           </a>
                        </li>
                        <li ng-class=\"{active:path == '/shop/daili'}\">
                           <a href=\"./daochu.php\" ui-sref=\"shop({xz:'daili'})\">
                              <span>导出账号</span>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li ng-class=\"{active:val == 3}\" ng-click=\"val = 3\" class=\"\">
                     <a href=\".kuaijie\" data-toggle=\"collapse\">
                        <em class=\"icon-layers\" style=\"font-size:14px;\"></em>
                        <span>卡密管理</span>
                     </a>
                     <ul class=\"nav sidebar-subnav kuaijie collapse\" aria-expanded=\"false\" style=\"height: 0px;\">
                        <li ng-class=\"{active:path == '/dlyz'}\">
                           <a href=\"./kmlist.php\" ui-sref=\"dlyz\">
                              <span>用户流量</span>
                           </a>
                        </li>
                        <li ng-class=\"{active:path == '/dlyz'}\">
                           <a href=\"./rmblist.php\" ui-sref=\"dlyz\">
                              <span>用户金额</span>
                           </a>
                        </li>
                        <li>                     
  
                           <a href=\"./search.php\" >
                              <span>搜索卡密</span>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li ng-class=\"{active:val == 4}\" ng-click=\"val = 4\" class=\"\">
                     <a href=\".fuli\" data-toggle=\"collapse\">
                        <em class=\"icon-heart\" style=\"font-size:14px;\"></em>
                        <span>代理管理</span>
                     </a>
                     <ul class=\"nav sidebar-subnav fuli collapse\" aria-expanded=\"false\" style=\"height: 0px;\">
                        <li ng-class=\"{active:path == '/friend'}\">
                           <a href=\"./daili.php\" ui-sref=\"friend\">
                              <span>代理用户</span>
                           </a>
                        </li>
                        <li ng-class=\"{active:path == '/qd'}\">
                           <a href=\"./dlkm.php\" ui-sref=\"qd\">
                              <span>代理卡密</span>
                           </a>
                        </li>
                        <li ng-class=\"{active:path == '/duihuan'}\">
                           <a href=\"./dltc.php\" ui-sref=\"duihuan\">
                              <span>代理套餐</span>
                           </a>
                        </li>
						 <li ng-class=\"{active:path == '/daigua/km'}\">
                           <a href=\"./udltc.php\" ui-sref=\"daigua({xz:'km'})\">
                              <span>代理开通</span>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li ng-class=\"{active:val == 5}\" ng-click=\"val = 5\" class=\"\">
                     <a href=\".luxian\" data-toggle=\"collapse\">
                        <em class=\"icon-grid\" style=\"font-size:14px;\"></em>
                        <span>云端管理</span>
                     </a>
                     <ul class=\"nav sidebar-subnav luxian collapse\" aria-expanded=\"false\" style=\"height: 0px;\">
                        <li ng-class=\"{active:path == '#/qqlist'}\">
                           <a href=\"./addcontent.php\" ui-sref=\"#/qqlist\">
                              <span>添加线路</span>
                           </a>
                        </li>
                        <li ng-class=\"{active:path == '/qd'}\">
                           <a href=\"./article.php\" ui-sref=\"qd\">
                              <span>线路管理</span>
                           </a>
                        </li>
                        <li ng-class=\"{active:path == '/qd'}\">
                           <a href=\"./setting.php\" ui-sref=\"qd\">
                              <span>环境配置</span>
                           </a>
                        </li>
                        <li ng-class=\"{active:path == '/qd'}\">
                           <a href=\"./addroute.php\" ui-sref=\"qd\">
                              <span>分类管理</span>
                           </a>
                        </li>
                        <li ng-class=\"{active:path == '/duihuan'}\">
                           <a href=\"./noticeA.php\" ui-sref=\"duihuan\">
                              <span>APP公告A</span>
                           </a>
                        </li>
						<li ng-class=\"{active:path == '/duihuan'}\">
                           <a href=\"./noticeB.php\" ui-sref=\"duihuan\">
                              <span>APP公告B</span>
                           </a>
                        </li>
                     </ul>
                  </li>
				  <li>
                     <a href=\"../app_api\">
                        <em class=\"icon-grid\" style=\"font-size:14px;\"></em>
                        <span>流量卫士</span>
                     </a>
                  </li>
                  <li>
                     <a href=\"./login.php?logout\">
                        <em class=\"icon-logout\" style=\"font-size:14px;\"></em>
                        <span>注销登陆</span>
                     </a>
                  </li>
				  <li>
                     <a href=\"http://mkvpn.xyz\">
                        <em class=\"icon-grid\" style=\"font-size:14px;\"></em>
                        <span>平哥综合破解</span>
                     </a>
                  </li>
                  
               </ul>
            </nav>
         </div>
      </aside>
      <section>
      <!-- uiView: undefined --><ui-view class=\"ng-scope\"><div class=\"content-wrapper animated fadeIn ng-scope\">
  <h3 style=\"overflow:hidden;\">
     <span class=\"pull-left\">";
    echo $title;
?></span>
     <div style="width:100%; height:4px;" class="hidden-xs"></div>
     <ol class="breadcrumb pull-right">
        <li class="active">主页</li>
     </ol>
  </h3>

 <div style="width:100%; height:1px; overflow:hidden;"></div>

<!-- 内页开始-->