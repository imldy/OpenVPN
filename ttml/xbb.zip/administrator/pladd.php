<?php
    $mod = 'blank';
    include ('../api.inc.php');
    $title = '批量添加账号';
    include './head.php';
    if ($islogin2 == 1) {
    } else exit ("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<?php
    echo '
<section id="content">
<section class="vbox">
<section class="scrollable padder">
<ul class="breadcrumb no-border no-radius b-b b-light pull-in">
<section class="panel panel-default">
              <header class="panel-heading font-bold"> 批量添加账号 </header>
              <div class="panel-body">
				
';
    if ($_POST['num']) {
        $dqr = $_POST['enddate'];
        $notes = daddslashes($_POST['notes']);
        $num = daddslashes($_POST['num']);
        $prefix = daddslashes($_POST['prefix']);
        $strlen0 = daddslashes($_POST['strlen']);
        $suffix = daddslashes($_POST['suffix']);
        $fwqid = daddslashes($_POST['fwqid']);
        $wpass = daddslashes($_POST['pass']);
        $maxll = daddslashes($_POST['maxll']) *1024*1024;
        $state = daddslashes($_POST['state']);
        $endtime = strtotime(date('Y-m-d', strtotime("+$dqr day")));
        $tian = $_POST['tian'];
        function getuser($var2 = strlen0) {
            $var4 = '0123456789';
            $var5 = strlen($var4);
            $var6 = '';
            for ($var7 = 0;$var7<$var2;$var7++) {
                $var6.= $var4[mt_rand(0, $var5-1) ];
            }
            return $var6;
        }
        function getpass($var8 = wpass) {
            $var10 = '0123456789';
            $var11 = strlen($var10);
            $var12 = '';
            for ($var13 = 0;$var13<$var8;$var13++) {
                $var12.= $var10[mt_rand(0, $var11-1) ];
            }
            return $var12;
        }
        for ($x = 0;$x<$num;$x++) {
            $user = getuser($strlen0);
            $pass = getpass($wpass);
            if (!$DB->get_row("select * from `openvpn` where `iuser`='$user' limit 1")) {
                $id = strtoupper(substr(md5($uin.time()), 0, 8) .'-'.uniqid());
                $sql = "insert into `openvpn` (`iuser`,`pass`,`isent`,`irecv`,`maxll`,`i`,`starttime`,`endtime`,`fwqid`,`notes`) values ('{$user
            }
            ','{$pass
        }
        ',0,0,'{$maxll
    }
    ','{$state
    }
    ','".time() ."','{$endtime
    }
    ','{$fwqid
    }
    ','{$notes
    }
    ')";
    if ($DB->query($sql)) echo "{$user
    }
    ----{$pass
    }
    ----{$notes
    }
    <br />";
    else echo '添加失败：'.$DB->error() .'<br />';
    } else {
        echo '该账号已存在！<br />';
    }
    }
    echo '<hr/><a href="./pladd.php">>>返回继续添加</a><br><a href="./qqlist.php">>>返回账号列表</a></div></div>';
?>
<?php
    echo '                  <div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
                    
                  
              </div>
            </section>
</section>
</section>

<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a></section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
<div class="wrapper">
	Notification
</div>
</aside>
<!-- end -->
';
    require_once ('foot.php');
    exit;
    }
    $fwqlist = $DB->query('SELECT * FROM auth_fwq');
?>
<?php
    echo '      


          
          <form action="./pladd.php" method="post" class="form-horizontal" role="form">
            <div class="input-group">
			  <span class="input-group-addon">账号个数</span>
              <input type="text" name="num" value="" class="form-control" required/>
            </div><br/>
            <div class="input-group">
			  <span class="input-group-addon">账号随机数长度</span>
              <input type="text" name="strlen" value="" class="form-control" required/>
            </div><br/>
            <div class="input-group">
              <span class="input-group-addon">密码随机数长度</span>
			  <input type="text" name="pass" value="" class="form-control" required>
            </div><br/>
            <div class="input-group">
              <span class="input-group-addon">账号状态</span>
			  <select name="state" class="form-control">
              	<option value="0">0_禁用</option>
				<option value="1">1_开通</option>
              </select>
            </div><br/>
            <div class="input-group">
              <span class="input-group-addon">总流量(M)</span>
			  <input type="text" name="maxll" value="" class="form-control" required>
            </div><br/>
			<div class="input-group">
              <span class="input-group-addon">到期日期</span>
			  <input type="text" name="enddate" value="" class="form-control" required>
            </div><br/>
            <div class="">
			  <label class="control-label">选择服务器</label>
				<select name="fwqid" class="form-control">
				';
    while ($v = $DB->fetch($fwqlist)):
?>
				  <option value="<?php
    echo $v['id'];
?>"><?php
    echo $v['name'];
?></option>
				<?php
    endwhile;
?>
<?php
    echo '				</select>
            </div><br/>
            <div class="input-group">
			  <span class="input-group-addon">备注</span>
              <input type="text" name="notes" value="" class="form-control" />
            </div><br/>
            <input type="submit" value="添加" class="btn btn-primary form-control"/>
          </form>
        </div>
      </div>
    </div>
  </div>
  <script src="../datepicker/WdatePicker.js"></script>
                  <div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
                    
                  
              </div>
            </section>
</section>
</section>

<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a></section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
<div class="wrapper">
	Notification
</div>
</aside>
<!-- end -->
';
    include './nav.php';
?>