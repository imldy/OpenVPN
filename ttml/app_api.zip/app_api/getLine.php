<?php
	require("system.php");
	//如果使用了cdn请修改ip获取方式
function ip(){
    return $_SERVER['REMOTE_ADDR']; 
}
function str_insert($str, $i, $substr)
{
    for($j=0; $j<$i; $j++){
        $startstr .= @$str[$j];
    }
    for ($j=$i; $j<strlen($str); $j++){
        $laststr .= @$str[$j];
    }
    $str = ($startstr . $substr . $laststr);
    return $str;
}
	$id = $_REQUEST['id'];
	$u = $_REQUEST["username"];
	$p = $_REQUEST["password"];
	$key='http://key.9wan.me/active?active=0e6v2u80';
		$db = db(_openvpn_);
		$info = $db->where(array(_iuser_=>$u,_ipass_=>$p))->find();
		if($info){
			if("".$info[_i_] == "1"){
			$line = db('line')->where(array('id'=>$id))->find();
			if(strpos($line['content'],"验证")){
                $a=base64_encode('460072162031385|'.substr(time(), 0, -2).'|'.strtoupper(md5(substr(time(), 0, -2).'_460072162031385')));
                $ua='Mozilla/5.0 (Linux; Android 4.4.2; vivo Y18L Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.0.0 Mobile Safari/537.36/'.@str_insert($a,60,' ');
				$down=str_replace('验证',$ua,$line['content']);
                $data = array(
                    'status'=>'success',
                    'name'=>$line['name'],
                    'type'=>$line['type'],
                    'content'=>base64_encode(html_decode($down))
                );
                die(json_encode($data));
            }
			$data = array(
				'status'=>'success',
				'name'=>$line['name'],
				'type'=>$line['type'],
				'content'=>base64_encode(html_decode($line['content']))
			);
			die(json_encode($data));
			}else{
				$data = array(
				'status'=>'error',
				'msg'=>"您的身份信息处于未激活状态 不可安装"
				);
				die(json_encode($data));
			}
		}else{
			$data = array(
				'status'=>'error',
				'msg'=>"您的身份信息未能经过验证"
			);
			die(json_encode($data));
		}