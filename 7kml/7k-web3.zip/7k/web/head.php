<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
   <meta name="description" content="Bootstrap Admin App + jQuery">
   <meta name="keywords" content="app, responsive, jquery, bootstrap, dashboard, admin">
   <title><?php
  $rs=$DB->get_row("SELECT * FROM `website` where id='{$site_id}' limit 1");
  $webtitle=$rs['title'];
   echo $webtitle
    ?></title>
   <link rel="stylesheet" href="../assets/fontawesome/css/font-awesome.min.css">
   <link rel="stylesheet" href="../assets/simple-line-icons/css/simple-line-icons.css">
   <link rel="stylesheet" href="../assets/animate.css/animate.min.css">
   <link rel="stylesheet" href="../assets/whirl/dist/whirl.css">
   <link rel="stylesheet" href="../assets/weather-icons/css/weather-icons.min.css">
   <link rel="stylesheet" href="../assets/css/bootstrap.css" id="bscss">
   <link rel="stylesheet" href="../assets/css/app.css" id="maincss">
</head>
