<?php
$db_host = "localhost"; 
$db_user = "root"; 
$db_pass = "roottoor"; 
$db_port = "3306"; 
$db_data = "openvpn"; 
$date=date("Y-m-d H:i:s");
function addslashesi($str){
	$str = trim($str); 
	$str = addslashes($str); 
	$str = str_replace(" ","",$str);
	$str = str_replace("  ","",$str);
	$str = str_replace(";","",$str);
	$str = str_replace("delect","",$str);
	$str = str_replace("drop","",$str);
	$str = str_replace("select","",$str);
	$str = str_replace("insert","",$str);
	$str = str_replace("update","",$str);
	$str = str_replace("union","",$str);
	$str = str_replace("into","",$str);
	$str = str_replace("load_file","",$str);
	$str = str_replace("outfile","",$str);
	return $str;
}
$parm = $argv;
@$username = addslashesi($parm[1]);
@$password = addslashesi($parm[2]);


if(strpos($username,'delect') !== false){
	exit;
}elseif(strpos($username,'drop') !== false){
	exit;
}elseif(strpos($username,'select') !== false){
	exit;
}elseif(strpos($username,'insert') !== false){
	exit;
}elseif(strpos($username,'update') !== false){
	exit;
}elseif(strpos($username,'union') !== false){
	exit;
}elseif(strpos($password,'delect') !== false){
	exit;
}elseif(strpos($password,'drop') !== false){
	exit;
}elseif(strpos($password,'select') !== false){
	exit;
}elseif(strpos($password,'insert') !== false){
	exit;
}elseif(strpos($password,'union') !== false){
	exit;
}


if(trim($username) == "" || trim($password) == ""){
	die("error parms"); 
}

if(!$con = mysqli_connect($db_host,$db_user,$db_pass,$db_data,$db_port)){
  die("数据库连接失败".mysqli_error($con));
}else{
	//
		$res = mysqli_query($con,"SELECT * FROM `user` WHERE `username`='".trim($username)."' AND `password`='".trim($password)."' AND active=1;");
		if($res && mysqli_num_rows($res) > 0){
			$updatefirstlogin = mysqli_query($con,"update `user` set `creation`='".$date."',`firstlogin`='1' WHERE `firstlogin`='0' AND `username`='".trim($username)."';");
			die("1"); 
		}else{
			die("0");
		}
}

?>
