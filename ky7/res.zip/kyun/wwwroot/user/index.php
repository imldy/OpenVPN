<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：用户登陆账号密码验证
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
  
// 加载系统配置文件
require("../Data/system.php");

if(isset($_POST['user']) && isset($_POST['pass'])){
	 $user=daddslashes($_POST['user']);
	 $pass=daddslashes($_POST['pass']);
	 exit("<script>window.location.href='./data/index.php?user=".$user."&pass=".$pass."';</script>");
}elseif(isset($_GET['logout'])){
	exit("<script>alert('您已成功注销本次登陆！');window.location.href='./Kyun/index.php';</script>");
}else{		 
   exit("<script>window.location.href='./Kyun/index.php';</script>");
}
?>