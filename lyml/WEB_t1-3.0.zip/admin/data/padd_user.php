<?php
/**
 * 凌云免流管理中心
 * by 天木兮 2018年10月15日
 */
include("../../Data/api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='../Lyun/index.php';</script>");
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>账号管理 - 批量添加账号</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> <link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="../../assets/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>账号管理 >><small>批量添加账号</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="form_basic.html#">
                              </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
<?php
function getkm($len = 18){
	$str = "09876543210123456789";
	$strlen = strlen($str);
	$randstr = "";
	for ($i = 0; $i < $len; $i++) {
		$randstr .= $str[mt_rand(0, $strlen - 1)];
	}
	return $randstr;
}
if ($_POST['num']) {
echo '
<div class="panel-heading w h"><h3 class="panel-title">批量添加账号结果</h3></div>
<div class="panel-body box">';	
$num = daddslashes($_POST['num']);
$strlen = daddslashes($_POST['strlen']);
$tian = daddslashes($_POST['tian']);
$maxll = daddslashes($_POST['maxll']) * 1024 * 1024;
$max = $maxll*1024;
$state = daddslashes($_POST['state']);
$endtime = time()+3600*24*daddslashes($_POST['tian']);
for($i = 0 ; $i < $num; $i++){
$user=getkm($strlen);
$pass=getkm($strlen);
if (!$DB->get_row("select * from `openvpn` where `iuser`='$user' limit 1")) {
$id = strtoupper(substr(md5($uin . time()), 0, 8) . '-' . uniqid());
$sql = "insert into `openvpn` (`iuser`,`pass`,`isent`,`irecv`,`maxll`,`i`,`starttime`,`endtime`,`mail`,`tj_u`,`tian`) values ('{$user}','{$pass}',0,0,'{$max}','{$state}','" . time() . "','{$endtime}',0,0,'{$tian}')";
if ($DB->query($sql)) 
echo '账号：'.$user.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;密码：'.$pass.'<br>';
else 
echo '<div class="box">奥，添加账号失败,' . $DB->error() . '</div>';
} else {
echo '<div class="box">亲，该账号已存在.</div>';
 }}
echo '<hr/><a href="./padd_user.php" class="btn btn-success">返回继续添加</a></div></div>';
}else {				
        echo '         <form action="./padd_user.php" method="post" class="form-horizontal">
                            <div class="form-group has-success">
                                <label class="col-sm-2 control-label">账号数量</label>

                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="num">
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
                           
                            <div class="form-group has-error">
                                <label class="col-sm-2 control-label">账号密码长度</label>
                             
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="strlen">
                                </div>
							  </div>
							  <div class="hr-line-dashed"></div>
                              <div class="form-group has-success">
                            <label class="col-sm-2 control-label">账号状态</label>
                             <div class="col-sm-10">
                                    <select class="form-control m-b" name="state">
									    <option value="2">未激活</option>
                                        <option value="1">开通</option>
                                    </select>
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
                             <div class="form-group has-warning">
                                <label class="col-sm-2 control-label">使用天数</label>

                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="tian">
                                </div>
                            </div>
							
							 <div class="hr-line-dashed"></div>
                             <div class="form-group has-success">
                                <label class="col-sm-2 control-label">总流量（单位/G）</label>

                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="maxll">
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-4 col-sm-offset-2">
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                                </div>
                            </div>
                        </form>';
}
?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 全局js -->
    <script src="../../assets/js/jquery.min.js?v=2.1.4"></script>
    <script src="../../assets/js/bootstrap.min.js?v=3.3.6"></script>

    <!-- 自定义js -->
    <script src="../../assets/js/content.js?v=1.0.0"></script>

    <!-- iCheck -->
    <script src="../../assets/js/plugins/iCheck/icheck.min.js"></script>

</body>

</html>
