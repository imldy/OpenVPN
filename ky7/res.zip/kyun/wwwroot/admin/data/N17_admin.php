<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：管理员数据整体概况
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

if($is_login == 'ok'){
$db =db("openvpn");
$db2 =db("top");
$user = $db->where(array())->getnums();
$ok_user = $db->where(array('i'=>'1'))->getnums();
$all_online = $db->where(array('online'=>'1'))->getnums();
$udp = $db->where(array('online'=>'1','xieyi'=>'udp'))->getnums();
$tcp = $db->where(array('online'=>'1','xieyi'=>'tcp-server'))->getnums();
$allKB2 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-10 day"))))->getallnums("data")/1024/1024/1024), 2);
$allKB3 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-9 day"))))->getallnums("data")/1024/1024/1024), 2);
$allKB4 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-8 day"))))->getallnums("data")/1024/1024/1024), 2);
$allKB5 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-7 day"))))->getallnums("data")/1024/1024/1024), 2);
$allKB6 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-6 day"))))->getallnums("data")/1024/1024/1024), 2);
$allKB7 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-5 day"))))->getallnums("data")/1024/1024/1024), 2);
$allKB8 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-4 day"))))->getallnums("data")/1024/1024/1024), 2);
$allKB9 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-3 day"))))->getallnums("data")/1024/1024/1024), 2);
$allKB10 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-2 day"))))->getallnums("data")/1024/1024/1024), 2);
$allKB11 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-1 day"))))->getallnums("data")/1024/1024/1024), 2);
$allKB12 = round(($db2->where(array("time"=>date("Y-m-d")))->getallnums("data")/1024/1024/1024), 2);
?>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="renderer" content="webkit">

    <title>管理员平台 - N17-6.0</title>

    <meta name="keywords" content="快云免流，快云流控，快云流量，NB免流，NB流控">
    <meta name="description" content="快云免流，快云流控，快云流量，NB免流，NB流控">
    <link rel="shortcut icon" href="../../assets/img/favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
    <link href="../../assets/css/export.css" rel="stylesheet">
	<script src="../../assets/js/amcharts.js"></script>
    <script src="../../assets/js/gauge.js"></script>
    <script src="../../assets/js/light.js"></script>
<style>
#NetWork {
  width: 100%;
  height: 200px;
}										
</style>
</head>	
<body class="gray-bg">
    <div class="wrapper wrapper-content">
        <div class="row">
            <div class="col-sm-12">
			<div class="ibox-mulu">
          <h3> &nbsp;&nbsp; <i class="fa fa-dashboard fa-lg"></i> 平台首页 > 整体概览</h3>
              </div>
			  <br>
                <div class="row">
                    <div class="col-sm-4">
                        <div class="row row-sm text-center">
                            <div class="col-xs-6">
                                <div class="panel padder-v item">
                                    <div class="h1 text-info font-thin h1"><?php echo $user;?></div>
                                    <span class="text-muted text-xs">账号数量</span>
                                    <div class="top text-right w-full">
                                        <i class="fa fa-caret-down text-warning m-r-sm"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-6">
                                <div class="panel padder-v item bg-info">
                                    <div class="h1 text-fff font-thin h1"><?php echo $ok_user;?></div>
                                    <span class="text-muted text-xs">正常账号</span>
                                    <div class="top text-right w-full">
                                        <i class="fa fa-caret-down text-primary m-r-sm"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-6">
                                <div class="panel padder-v item bg-primary">
                                    <div class="h1 text-fff font-thin h1"><?php echo $all_online;?></div>
                                    <span class="text-muted text-xs">总在线人数</span>
                                    <div class="bottom text-left">
                                        <i class="fa fa-caret-up text-info m-l-sm"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-6">
                                <div class="panel padder-v item">
                                    <div class="font-thin h1"><?php echo date("H:i",time())?></div>
                                    <span class="text-muted text-xs">当前时间</span>
                                    <div class="bottom text-left">
                                        <i class="fa fa-caret-up text-warning m-l-sm"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="ibox">
                            <div class="ibox-content">
							<h3>流量使用折线图(单位/G)</h3>
                                <div id="line" style="height:217px;">加载中,请骚等...</div>
                            </div>
                        </div>
                    </div>
                </div>
             <div class="row">
		  <div class="col-sm-6">
		<div class="row">
	 <div class="col-sm-12">
	<div class="ibox">
	 <div class="ibox-content">
	  <h3>官方公告列表</h3>
    欢迎你使用快云流控烟雨如花复活版，欢迎加入我们的交流群302638446
	 </div> 
	   </div> 
	     </div>
			<div class="col-sm-5">
                <div class="ibox">
                    <div class="ibox-content">
                       <h4>用户活跃度</h4>
					   <p>TCP在线 <?=$tcp?>人 UDP在线 <?=$udp?>人</p>
                        <div class="text-center">
                            <div id="online"><h3>Loading</h3></div>
                        </div>
                    </div>
                </div>
            </div>
			   <div class="col-sm-7">
				 <div class="ibox">
                    <div class="ibox-content">
					<div style="border-bottom:none;background:#fff;">
	                <h3> 网速实时监控</h3>
	                 </div>
					 <div id="NetWork"><h3>Loading</h3></div>	
                    </div>
                </div>
			</div>
			 <div class="col-xs-6">
			    <?php
                  $Ky = exec("Kps Ky");
                     if($Ky == 'ok'){
					    echo '<div class="ibox"><div class="ibox-success"><h3 class="text-center">监控状态 [运行正常]</h3></div></div>';
					  }else{
					    echo '<div class="ibox-erorr"><h3 class="text-center">监控状态 [运行异常]</h3></div>';
					  }                  ?>
               </div>	
		    <div class="col-xs-6">
                <?php
                  $op = exec("Kps openvpn");  
                     if($op == 'ok'){
					    echo '<div class="ibox"><div class="ibox-success"><h3 class="text-center">VPN 状态 [运行正常]</h3></div></div>';
					  }else{
					    echo '<div class="ibox"><div class="ibox-erorr"><h3 class="text-center">VPN 状态 [运行异常]</h3></div>';
					  }                 ?>
               </div>	
			  </div>
			  
				<div class="row">
			<div class="col-sm-12">
             <div class="ibox">
               <div class="ibox-content">
				<div class="row">
			      <div class="col-sm-6">
                  <h3>开启的TCP端口</h3>
                  <?php
                    exec("netstat -nap|grep tcp|grep \"0 0.0.0.0:\"",$tcp);
                     preg_match_all("/\:([0-9]*)/",implode("\n",$tcp),$m);
                     foreach($m[1] as $v){ 
                     echo '<span class="label label-primary">'.$v.'</span> ';}?>
                   </div>
		          <div class="col-sm-6">
                        <h3>开启的UDP端口</h3>
                  <?php
                    exec("netstat -nap|grep udp|grep \"0 0.0.0.0:\"",$udp);
                     preg_match_all("/\:([0-9]*)/",implode("\n",$udp),$m);
                     foreach($m[1] as $v){ 
                     echo '<span class="label label-primary">'.$v.'</span> ';}?>
                 </div>
			  </div>
		     </div>
           </div>
		 </div>
		</div>
	 </div>
   <div class="col-sm-6">
    <div class="row">
	    <div class="col-sm-12">
            <div class="ibox">
		    <div class="ibox-content">
               <div class="row">
              <div class="col-sm-4">
             <div class="ibox">
              <div class="ibox-content">
			   <center>
				最近使用状态
					<br>今天： <?php echo $allKB12.' G';?>
					  <br> 昨天： <?php echo $allKB11.' G';?>
				    	</center>
						</div></div></div>				  
 <?php
    function array_space_del($arr){
			 foreach($arr as $key=>$vo){
				 if(trim($vo) != ""){
					 $b[] = $vo;
				 }
			 }
			 return $b;
		 }
     exec("ifconfig",$net);
		 foreach($net as $line){
			 if(trim($line)==""){
				$nets[] = $netinfo;
				$netinfo = array();
			 }else{
				$netinfo[] = $line;
			 }
		 }
		foreach($nets as $info){
			$t = explode(":",$info[0]);
			$netname = $t[0];
			
			foreach($info as $v){
				$t2 = explode(" ",$v);
				$t2 = array_space_del($t2);
				
				switch($t2[0]){
					case $netname.":":
						$net_mtu = $t2[3];
					break;
					
					case "inet":
						$net_ip = $t2[1];
					break;
					
					case "RX":
						if($t2[1] == "packets"){
							$net_recv = $t2[4];
						}
					break;
					
					case "TX":
						if($t2[1] == "packets"){
							$net_sent = $t2[4];
						}
					break;
				}
			}
    $TX = printmb($net_sent);
    $RX = printmb($net_recv);
   echo '<div class="col-sm-4">
             <div class="ibox">
              <div class="ibox-content">
			  <center>
				<span class="label label-primary">',$netname,'</span> 网卡状态
					<br>接收：', $RX,
					  '<br>发送：', $TX,
						'</div></div></div></center>';
}                                              ?>	
		</div>
		  </div>
		   </div>
		   </div> 			
             </div>
		      </div>
				 <div class="col-sm-6">
				    <div class="ibox float-e-margins">
                        <div class="ibox-content">
                            <div id="vertical-timeline" class="vertical-container">
								
								   <div class="vertical-timeline-block">
                                    <div class="vertical-timeline-icon navy-bg">
                                        <i class="fa fa-gears"></i>
                                    </div>

                                    <div class="vertical-timeline-content">
                                        <h2>版本检测更新</h2>
                                        <p>当前版本：N17-<?php echo $NowVersion;?> &nbsp;
										<?php
										$NewVersion='7.0';
										if($NewVersion == $NowVersion){
										    echo "当前版本已是最新，无需更新。";
										    $News='没事就想去官网逛';
										    $GW='https://yyrh.me';	
										}elseif($NewVersion > $NowVersion){
										    echo '检测到<font size="3" color="red">New</font>版本：N17-',$NewVersion;
										    $News='查看 V'.$NewVersion.'更新内容';
										    $GW='https://yyrh.me';
										}else{
											echo '检测到<font size="3" color="red">New</font>版本：N17-',$NewVersion;
										    $News='查看 V'.$NewVersion.'更新内容';
											$GW='https://yyrh.me';
										}?>
                                        </p>
                                        <a href="<?php echo $GW;?>" class="btn btn-sm btn-primary"><?php echo $News;?></a>
                                        <span class="vertical-date">
                                     <small>检测时间 <?php echo date("Y年m月d日")?></small>
                                </span>
                                    </div>
                                </div>
                            </div>
                         </div>
                       </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- 全局js -->
    <script src="../../assets/js/jquery.min.js"></script>
    <!-- Flot -->
    <script src="../../assets/js/plugins/flot/jquery.flot.js"></script>
	
	<script src="../../assets/js/plugins/sparkline/jquery.sparkline.min.js"></script>
    <script src="../../assets/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="../../assets/js/plugins/flot/jquery.flot.resize.js"></script>
	<script src="../../assets/js/plugins/flot/jquery.flot.pie.js"></script>
    <!--flotdemo-->
<script type="text/javascript">
// 网络实时监控
var gaugeChart = AmCharts.makeChart( "NetWork", {
  "type": "gauge",
  "theme": "light",
  "axes": [ {
    "axisThickness": 1,
    "axisAlpha": 0.2,
    "tickAlpha": 0.2,
    "valueInterval": 3,
    "bands": [ {
      "color": "#cc4748",
      "endValue": 3,
      "startValue": 0
    }, {
      "color": "#fdd400",
      "endValue": 6,
      "startValue": 3
    }, {
      "color": "#addab5",
      "endValue": 9,
      "startValue": 6
    }, {
      "color": "#87c892",
      "endValue": 12,
      "startValue": 9
    }, {
      "color": "#61b770",
      "endValue": 15,
      "startValue": 12
    },{
      "color": "#34733f",
      "endValue": 18,
      "startValue": 15
    } ],
    "bottomText": "0 Mbps/s",
    "bottomTextYOffset": -3,
    "endValue": 18
  } ],
  "arrows": [ {} ],
  "export": {
    "enabled": true
  }
} );

setInterval( randomValue, 1000 );

// set random value
function randomValue() {
$.get(
	   'GetNet.php',{
			"act":"net"
		},function(data){
			if(data.status == "success"){
			     value = data.net;
			}else{
			     value = 0;
			}
		},"JSON"
	);
  if ( gaugeChart ) {
    if ( gaugeChart.arrows ) {
      if ( gaugeChart.arrows[ 0 ] ) {
        if ( gaugeChart.arrows[ 0 ].setValue ) {
          gaugeChart.arrows[ 0 ].setValue( value );
          gaugeChart.axes[ 0 ].setBottomText( value + " Mbps/s" );
        }
      }
    }
  }
}

// 流量折线图
$(function() {
             series = [{
                data: [
				   [1, <?php echo $allKB2;?>],
				   [2, <?php echo $allKB3;?>],
				   [3, <?php echo $allKB4;?>],
				   [4, <?php echo $allKB5;?>],
				   [5, <?php echo $allKB6;?>],
				   [6, <?php echo $allKB7;?>],
				   [7, <?php echo $allKB8;?>],
				   [8, <?php echo $allKB9;?>],
				   [9, <?php echo $allKB10;?>],
				   [10, <?php echo $allKB11;?>],
				   [11, <?php echo $allKB12;?>],
				   [12, 0]
				],
                lines: {
                    show: true,
					fill: true,
					fillColor:"#D2E9FF"
                },
				legend:{
						show:true,	
						position:"ne"
				}, 
				points: { 
				    show: true 
				}
            }];

            var plot = $.plot($("#line"),series, {
                grid: {
                    color: "#999999",
					tickColor: "#f7f9fb",
                    borderWidth:0,
                    minBorderMargin: 20,
                    labelMargin: 10,
					hoverable: true,
                    backgroundColor: {
                        colors: ["#fff", "#fff"]
                    }
                },
				tooltip : {
                },
                colors: ["#4fc5ea"],
                xaxis: {
					ticks: [
					    [1, "<?php echo date("d",strtotime("-11 day")).'日';?>"],
						[2, "<?php echo date("d",strtotime("-10 day")).'日';?>"], 
						[3, "<?php echo date("d",strtotime("-9 day")).'日';?>"], 
						[4, "<?php echo date("d",strtotime("-8 day")).'日';?>"], 
						[5, "<?php echo date("d",strtotime("-7 day")).'日';?>"],
						[6, "<?php echo date("d",strtotime("-6 day")).'日';?>"],
						[7, "<?php echo date("d",strtotime("-5 day")).'日';?>"],
						[8, "<?php echo date("d",strtotime("-4 day")).'日';?>"],
						[9, "<?php echo date("d",strtotime("-3 day")).'日';?>"],
						[10, "<?php echo date("d",strtotime("-2 day")).'日';?>"],
						[11, "<?php echo date("d",strtotime("-1 day")).'日';?>"],
						[12, "<?php echo date("d").'日';?>"]
					]
				},
                yaxis: { 
					ticks: 5,
					min: 0
				}
            });
        });
		
 // 用户活跃度
 $(document).ready(function () {		
      $("#online").sparkline([<?php echo $ok_user - $all_online;?>, <?php echo $all_online;?>], {
           type: 'pie',
           height: '170',
          sliceColors: ['#87CEFA', '#2E8B57']
       });
});
</script>
 </body>
</html>
<?php
}else{
   exit("<script>window.location.href='../index.php';</script>");	
} 
?>