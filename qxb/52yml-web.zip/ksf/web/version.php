<?php
return array (
  'ver' => '1.7 （07121750）',
  'release' => '2016-07-12',
  'vername' => '七小白™',
);
?>