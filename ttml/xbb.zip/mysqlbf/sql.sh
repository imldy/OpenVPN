#!/bin/bash
#本脚本由花白编写
#填写信息部分****************************************************************************************
#DATE=`date +%Y_%m_%d`
localhost='localhost';  #数据库地址
root='root';            #数据库账号
sqlpass="root";        #数据库密码
sqlname="ov.sql";       #备份数据库名
shijian="21600";        #设置更新周期,单位为秒
#填写信息部分****************************************************************************************
#执行脚本部分****************************************************************************************
while true
do
echo -e "$(date +%Y年%m月%d日%k时%M分) 开始执行备份数据花白v2.0..."
mkdir /home/sjkbf/ >/dev/null 2>&1
mkdir /home/sjkbf/$(date +%Y-%m-%d) >/dev/null 2>&1
cd /home/sjkbf/$(date +%Y-%m-%d)
#rm -rf /root/sjkbf/$DATE/$sqlname
mysqldump -h${localhost} -u${root} -p${sqlpass} ov >${sqlname}
echo
echo -e "$(date +%Y年%m月%d日%k时%M分) 成功备份数据库 数据文件库位于/home/sjkbf/$(date +%Y-%m-%d),文件名：${sqlname}"
sleep ${shijian}
done
#执行脚本部分****************************************************************************************
#花白