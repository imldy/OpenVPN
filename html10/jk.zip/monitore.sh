#!/bin/sh
shijian=5;
phone=NULL;
echo  $(date +%Y年%m月%d日%k时%M分)正在清除缓存文件
rm -rf /var/www/html/resources/name
rm -rf /var/www/html/resources/port
rm -rf /var/www/html/resources/received
rm -rf /var/www/html/resources/send
rm -rf /var/www/html/resources/gg
echo  $(date +%Y年%m月%d日%k时%M分)开始执行流量监控...
while true
do
awk -F: '$1~/[B][y][t][e][s][ ][R][e][c][e][i][v][e][d][,][B][y][t][e][s][ ][S][e][n][t]/,/[R][O][U][T][I][N][G][ ][T][A][B][L][E]/{print $0}' '/var/www/html/resources'/openvpn-status.txt | awk -F"," '{print $1 >"/var/www/html/resources/name"}'
awk -F: '$1~/[B][y][t][e][s][ ][R][e][c][e][i][v][e][d][,][B][y][t][e][s][ ][S][e][n][t]/,/[R][O][U][T][I][N][G][ ][T][A][B][L][E]/{print $0}' '/var/www/html/resources'/openvpn-status.txt | awk -F"," '{print $2 }' | awk -F":" '{print $2 >"/var/www/html/resources/port"}'
awk -F: '$1~/[B][y][t][e][s][ ][R][e][c][e][i][v][e][d][,][B][y][t][e][s][ ][S][e][n][t]/,/[R][O][U][T][I][N][G][ ][T][A][B][L][E]/{print $0}' '/var/www/html/resources'/openvpn-status.txt | awk -F"," '{print $3 >"/var/www/html/resources/received"}'
awk -F: '$1~/[B][y][t][e][s][ ][R][e][c][e][i][v][e][d][,][B][y][t][e][s][ ][S][e][n][t]/,/[R][O][U][T][I][N][G][ ][T][A][B][L][E]/{print $0}' '/var/www/html/resources'/openvpn-status.txt | awk -F"," '{print $4 >"/var/www/html/resources/send"}'
i=2
until [ $i = -1 ]
do
name1=$(sed -n ${i}p /var/www/html/resources/name)
port1=$(sed -n ${i}p /var/www/html/resources/port)
received1=$(sed -n ${i}p /var/www/html/resources/received)
send1=$(sed -n ${i}p /var/www/html/resources/send)
if [ ! -n "$port1" ];
then
i=-1
else
mysql -hlocalhost -P3306 -uroot -pmysqlpass -e "use mysqldb;SELECT used_quota FROM user WHERE username='$name1';">>/var/www/html/resources/gg
mysql -hlocalhost -P3306 -uroot -pmysqlpass -e "use mysqldb;SELECT quota_bytes FROM user WHERE username='$name1';">>/var/www/html/resources/gg
used_quota=$(sed -n 2p /var/www/html/resources/gg)
quota_bytes=$(sed -n 4p /var/www/html/resources/gg)
rm -rf /var/www/html/resources/gg
let all=$quota_bytes-$used_quota
let ggg=$received1+$send1
if [ "$all" -lt "$ggg"  ];
then
/var/www/html/resources/sha1.sh $name1
echo  $(date +%Y年%m月%d日%k时%M分)成功清理超出流量用户:"$name1">>/var/www/html/resources/jklog.txt
fi
i=$(( $i + 1 ))
fi
done
rm -rf /var/www/html/resources/name
rm -rf /var/www/html/resources/port
rm -rf /var/www/html/resources/received
rm -rf /var/www/html/resources/send
sleep $shijian
done