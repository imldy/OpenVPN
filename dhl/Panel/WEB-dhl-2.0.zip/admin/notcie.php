<?php
@eval("//www.zhaoyuanma.com 免费版本加密! "); ?><?php
/**
 * 代理管理
**/
$mod = 'blank';
include "../api.inc.php";
$title = '公告管理';
include './head.php';
$rs = $DB->get_row("SELECT * FROM auth_config");
$gonggs = $rs['ggs'];
if ($islogin2 == 1) {
} else {
	die("<script language='javascript'>window.location.href='./login.php';</script>");
}
include './nav.php';
?>
    <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<?php 
$my = $_POST['my'];
if ($my == 'config') {
	echo '<div class="panel panel-primary">
	<div class="panel-heading w h"><h3 class="panel-title">公告管理页面设置</h3></div>
	<div class="panel-body box">';
	$ggs = daddslashes($_POST['gonggs']);
	$sql = $DB->query("update `auth_config` set `ggs`='{$ggs}' where 1");
	if ($sql) {
		echo '保存成功！';
	} else {
		echo '保存失败！';
	}
	echo '<hr/><a href="./config.php">>>公告管理页面设置</a></div></div>';
	die;
}
?>
      <div class="panel panel-primary">
        <div class="panel-heading"><h3 class="panel-title">公告管理</h3></div>
        <div class="panel-body">
          <form action="./config.php" method="post" class="form-horizontal" role="form">
            <div class="form-group">
            	<input type="hidden" name="my" value="config"/>
              <label class="col-sm-2 control-label">用户公告</label><br>
			<div class="col-sm-10"><textarea class="form-control" name="gonggs" rows="5" cols="50" required><?php 
echo $gonggs;
?>
</textarea></div>
            </div>
            <input type="submit" value="保存" class="btn btn-primary form-control"/>
          </form>
           <div class="table-responsive">
        <table class="table table-striped">
</table>
        </div>
		<div class="panel-footer">
          <span class="glyphicon glyphicon-info-sign"></span> 管理员在这里可以管理用户公告。
        </div>
      </div>
    </div>
  </div><?php 