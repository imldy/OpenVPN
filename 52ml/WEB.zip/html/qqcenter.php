<?php
@eval("//Encode by  phpjiami.com,Free user."); ?><?php
require_once ("head.php");
$qid=is_numeric($_GET['qid'])?$_GET['qid']:'0';
if(!$qid || !$qrow=$DB->get_row("select * from ".DBQZ."_qq where qid='$qid' and uid='$userrow[uid]' limit 1")){
	msg("QQ不存在！","/user");
}
$title = '主界面 / QQ'.$qrow['uin'].'管理';
if($_GET['do']=='open'){
	if($_GET['fun']=='zan'){
		$is=is_numeric($_GET['is'])?$_GET['is']:'0';
		$DB->query("update ".DBQZ."_qq set iszan='$is' where qid='$qid'");
		if($is=='1'){
		msg("秒赞开启成功！","qqcenter.php?qid=$qid");
		}else{
		msg("秒赞已关闭！","qqcenter.php?qid=$qid");
		}
	}
	if($_GET['fun']=='pl'){
		$is=is_numeric($_GET['is'])?$_GET['is']:'0';
		$DB->query("update ".DBQZ."_qq set ispl='$is' where qid='$qid'");
		if($is=='1'){
		msg("评论开启成功！","qqcenter.php?qid=$qid");
		}else{
		msg("评论已关闭！","qqcenter.php?qid=$qid");
		}
	}
	if($_GET['fun']=='shuo'){
		$is=is_numeric($_GET['is'])?$_GET['is']:'0';
		$DB->query("update ".DBQZ."_qq set isshuo='$is' where qid='$qid'");
		if($is=='1'){
		msg("自动说说开启成功！","qqcenter.php?qid=$qid");
		}else{
		msg("自动说说已关闭！","qqcenter.php?qid=$qid");
		}
	}
	if($_GET['fun']=='qzone'){
		$is=is_numeric($_GET['is'])?$_GET['is']:'0';
		$DB->query("update ".DBQZ."_qq set isqzone='$is' where qid='$qid'");
		if($is=='1'){
		msg("空间自动签到开启成功！","qqcenter.php?qid=$qid");
		}else{
		msg("空间自动签到已关闭！","qqcenter.php?qid=$qid");
		}
	}
	if($_GET['fun']=='vip'){
		$is=is_numeric($_GET['is'])?$_GET['is']:'0';
		$DB->query("update ".DBQZ."_qq set isvip='$is' where qid='$qid'");
		if($is=='1'){
		msg("QQ会员自动签到开启成功！","qqcenter.php?qid=$qid");
		}else{
		msg("QQ会员自动签到已关闭！","qqcenter.php?qid=$qid");
		}
	}
	if($_GET['fun']=='group'){
		$is=is_numeric($_GET['is'])?$_GET['is']:'0';
		$DB->query("update ".DBQZ."_qq set isgroup='$is' where qid='$qid'");
		if($is=='1'){
		msg("QQ群自动签到开启成功！","qqcenter.php?qid=$qid");
		}else{
		msg("QQ群自动签到已关闭！","qqcenter.php?qid=$qid");
		}
	}
}
if($_GET['do']=='delete'){
	$DB->query("delete from ".DBQZ."_qq where qid='$qid'");
	msg("删除QQ成功！","/user");
}
if($_GET['do']=='set'){
	$zanrate=$_POST['zanrate'];
	$DB->query("update ".DBQZ."_qq set zanrate='$zanrate' where qid='$qid'");
	$plrate=$_POST['plrate'];
	$DB->query("update ".DBQZ."_qq set plrate='$plrate' where qid='$qid'");
	$plcon=$_POST['plcon'];
	$DB->query("update ".DBQZ."_qq set plcon='$plcon' where qid='$qid'");
	$shuorate=$_POST['shuorate'];
	$DB->query("update ".DBQZ."_qq set shuorate='$shuorate' where qid='$qid'");
	$shuotype=$_POST['shuotype'];
	$DB->query("update ".DBQZ."_qq set shuotype='$shuotype' where qid='$qid'");
	msg("设置保存成功！","qqcenter.php?qid=$qid");
}
?>
      <section id="content">
        <section class="vbox">
          <header class="header bg-white b-b b-light">
            <p><?=$title?></p>
          </header>
          <section class="scrollable">
            <section class="hbox stretch">
              <aside class="aside-lg bg-light lter b-r">
                <section class="vbox">
                  <section class="scrollable">
                    <div class="wrapper">
                      <div class="clearfix m-b"> <a href="#" class="pull-left thumb m-r"> <img src="http://q4.qlogo.cn/headimg_dl?dst_uin=<?=$qrow['uin']?>&spec=100" class="img-circle"> </a>
                        <div class="clear">
                          <div class="h3 m-t-xs m-b-xs"><?=get_qqnick($qrow['uin'])?></div>
                          <small class="text-muted"><i class="fa fa-map-marker"></i> <?=$qrow['addtime']?></small> </div>
                      </div>
					  <div class="panel wrapper panel-success">
                        <div class="row">
                          <div class="col-xs-12" align="center"> <span class="m-b-xs h1 block"><?php if($qrow['skeyzt']){echo'<font color="red">需要更新</font>';}else{echo'<font color="green">状态正常</font>';}?></span> </div>
                        </div>
                      </div>
                      <div class="btn-group btn-group-justified m-b"> <a href="?qid=<?=$qid?>&do=open&is=<?=get_if($qrow['iszan'])?>&fun=zan" class="btn btn-primary btn-rounded"> <?=get_iszan($qrow['iszan'])?> </a></div>
					  <div class="btn-group btn-group-justified m-b"> <a href="?qid=<?=$qid?>&do=delete" class="btn btn-danger btn-rounded"> <span class="text"> <i class="fa fa-times"></i> 删除QQ </span> </a></div>
                      <div> <small class="text-uc text-xs text-muted">最后一次运行时间</small>
                        <p><?=$qrow['lastzan']?></p> 
                      </div>
                    </div>
                  </section>
                </section>
              </aside>
			  <aside class="bg-white">
                <section class="vbox">
                  <header class="header bg-light bg-gradient">
                    <ul class="nav nav-tabs nav-white">
                      <li class="active"><a href="#function" data-toggle="tab">功能列表</a></li>
					  <li class=""><a href="#set" data-toggle="tab">功能设置</a></li>
                    </ul>
                  </header>
                  <section class="scrollable">
        <div class="tab-content">
                      <div class="tab-pane active" id="function">
                        <ul class="list-group no-radius m-b-none m-t-n-xxs list-group-lg no-border">
						  <li class="list-group-item"> <a href="#" class="clear"> <small class="pull-right">默认开启</small> <strong class="block">状态自动更新</strong> <small>若skey出现异常，自动更新功能将启动 </small> </a> </li>
						  <li class="list-group-item"> <a href="?qid=<?=$qid?>&do=open&is=<?=get_if($qrow['ispl'])?>&fun=pl" class="clear"> <small class="pull-right"><?=$qrow['lastpl']?></small> <strong class="block">说说自动评论[<?=get_is($qrow['ispl'])?>]</strong> <small>QQ空间动态评论 自定义内容 若内容为空则为随机 </small> </a> </li>
                          <li class="list-group-item"> <a href="?qid=<?=$qid?>&do=open&is=<?=get_if($qrow['isshuo'])?>&fun=shuo" class="clear"> <small class="pull-right"><?=$qrow['lastshuo']?></small> <strong class="block">空间自动说说[<?=get_is($qrow['isshuo'])?>]</strong> <small>QQ空间自动发说说 随机图片随机内容 默认60分钟/次... </small> </a> </li>
						  <li class="list-group-item"> <a href="?qid=<?=$qid?>&do=open&is=<?=get_if($qrow['isqzone'])?>&fun=qzone" class="clear"> <small class="pull-right"><?=$qrow['lastqzone']?></small> <strong class="block">空间自动签到[<?=get_is($qrow['isqzone'])?>]</strong> <small>QQ空间自动签到 随机内容 </small> </a> </li>
						  <li class="list-group-item"> <a href="?qid=<?=$qid?>&do=open&is=<?=get_if($qrow['isvip'])?>&fun=vip" class="clear"> <small class="pull-right"><?=$qrow['lastvip']?></small> <strong class="block">会员自动签到[<?=get_is($qrow['isvip'])?>]</strong> <small>QQVIP会员自动签到 </small> </a> </li>
						  <li class="list-group-item"> <a href="?qid=<?=$qid?>&do=open&is=<?=get_if($qrow['isgroup'])?>&fun=group" class="clear"> <small class="pull-right"><?=$qrow['lastgroup']?></small> <strong class="block">QQ群自动签到[<?=get_is($qrow['isgroup'])?>]</strong> <small>QQ群自动签到 </small> </a> </li>
                        </ul>
                      </div>
            <div class="tab-pane" id="set">
                <div class="text-center wrapper">
				    <div class="ibox float-e-margins">
						<div class="ibox-content">
							<form action="?qid=<?=$qid?>&do=set" method="post">
								<div class="list-group-item">
								<div class="ibox-title"><h5>点赞设置</h5></div>
								    <div class="input-group">
                                     <div class="input-group-addon">频率</div>
                                     <select name="zanrate" class="form-control">
									 <option value="30"<?php if($qrow['zanrate']=='30'){echo 'selected=""';}?>>30秒</option>
									 <option value="60"<?php if($qrow['zanrate']=='60'){echo 'selected=""';}?>>1分钟</option>
									 </select>
									</div>
								</div>
								<div class="list-group-item">
								<div class="ibox-title"><h5>评论设置</h5></div>
								    <div class="input-group">
                                     <div class="input-group-addon">频率</div>
                                     <select name="plrate" class="form-control">
									 <option value="30"<?php if($qrow['plrate']=='30'){echo 'selected=""';}?>>30秒</option>
									 <option value="60"<?php if($qrow['plrate']=='60'){echo 'selected=""';}?>>1分钟</option>
									 </select>
									</div>
									<div class="input-group">
                                     <div class="input-group-addon">评论内容</div>
                                     <textarea class="form-control" name="plcon"><?=$qrow['plcon']?></textarea>
									</div>
								</div>
								<div class="list-group-item">
								<div class="ibox-title"><h5>说说设置</h5></div>
								    <div class="input-group">
                                     <div class="input-group-addon">频率</div>
                                     <select name="shuorate" class="form-control">
									 <option value="900"<?php if($qrow['shuorate']=='900'){echo 'selected=""';}?>>15分钟</option>
									 <option value="1800"<?php if($qrow['shuorate']=='1800'){echo 'selected=""';}?>>30分钟</option>
									 <option value="3600"<?php if($qrow['shuorate']=='3600'){echo 'selected=""';}?>>60分钟</option>
									 </select>
									</div>
									<div class="input-group">
									 <div class="input-group-addon">类型</div>
                                     <select name="shuotype" class="form-control">
									 <option value="0"<?php if($qrow['shuotype']=='0'){echo 'selected=""';}?>>图片文字说说</option>
									 <option value="1"<?php if($qrow['shuotype']=='1'){echo 'selected=""';}?>>搞笑视频说说</option>
									 </select>
									</div>
								</div>
								     <div class="list-group-item">
                                      <input type="submit" name="submit" value="保存配置" class="btn btn-primary btn-block">
                                     </div>
							</form>
						</div>
					</div>
				</div>
            </div>
        </div>
                  </section>
                </section>
              </aside>
            </section>
          </section>
        </section>
        <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a> </section>
      <aside class="bg-light lter b-l aside-md hide" id="notes">
        <div class="wrapper">Notification</div>
      </aside>
<!-- end -->
<?php
function get_iszan($do){
	if($do){
		return '<span class="text"> <i class="fa fa-eye"></i> 秒赞开启中 </span>';
	}else{
		return '<span class="text"> <i class="fa fa-eye-slash"></i> 秒赞已关闭 </span>';
	}
}
function get_is($do){
	if($do){
		return '<font color="green"><span class="text"> <i class="fa fa-eye"></i> 开启中 </span></font>';
	}else{
		return '<font color="red"><span class="text"> <i class="fa fa-eye-slash"></i> 已关闭 </span></font>';
	}
}
function get_if($do){
	if($do){
		return '0';
	}else{
		return '1';
	}
}
require_once ("foot.php");
?>
<?php 