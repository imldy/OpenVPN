<?php
$mod='blank';
include("../api.inc.php");

$userid=$_SESSION['userid'];

$u = daddslashes($_GET['user']);

$p = daddslashes($_GET['pass']);



if($u==""){
$res = $DB->get_row("SELECT * FROM openvpn WHERE id='$userid' limit 1");
$qdres = $DB->get_row("SELECT * FROM auth_qd WHERE iuser='{$res['iuser']}' limit 1");
}else{
$res=$DB->get_row("SELECT * FROM `openvpn` where `iuser`='$u' && `pass`='$p' limit 1");
}


if(!$res){
//	header('location: login.php');
		exit("<script language='javascript'>window.location.href='./login.php';</script>");
}

if($_POST['km']){
	$km = daddslashes($_POST['km']);
	$myrow=$DB->get_row("select * from auth_kms where kind=1 and km='$km' limit 1");
	if($res['maxll']/1024/1024/1024>9999){
		exit("<script language='javascript'>alert('包月无限流量用户，无法充值！');history.go(-1);</script>");
}
	if(!$myrow){
		exit("<script language='javascript'>alert('此激活码不存在');history.go(-1);</script>");
	}elseif($myrow['isuse']==1){
		exit("<script language='javascript'>alert('此激活码已被使用');history.go(-1);</script>");
	}else{
		$duetime = ($res['endtime'] < time() ? time() : $res['endtime']) + $myrow['value']*24*60*60;
		$addll = $myrow['values']*1024*1024*1024;
		if($res['endtime'] < time()){//已到期
			$sql="update `openvpn` set `isent`='0',`irecv`='0',`maxll`='{$addll}',`endtime`='{$duetime}',`dlid`='{$myrow['daili']}',`i`='1' where `iuser`='{$res['iuser']}' && `pass`='{$res['pass']}'";
			if($DB->query($sql)){
				$DB->query("update `auth_kms` set `isuse` ='1',`user` ='$u',`usetime` ='$date' where `id`='{$myrow['id']}'");
				wlog('账号激活','用户'.$res['iuser'].'使用激活码'.$km.'开通账号['.$date.']');
				exit("<script language='javascript'>alert('开通成功！');history.go(-1);</script>");
			}else{
				exit("<script language='javascript'>alert('开通失败！');history.go(-1);</script>");
			}
		}else{
			$sql="update `openvpn` set `maxll`=`maxll` + '{$addll}',`endtime`='{$duetime}',`dlid`='{$myrow['daili']}',`i`='1' where `iuser`='{$res['iuser']}' && `pass`='{$res['pass']}'";
			if($DB->query($sql)){
				$DB->query("update `auth_kms` set `isuse` ='1',`user` ='$u',`usetime` ='$date' where `id`='{$myrow['id']}'");
				wlog('账号激活','用户'.$res['iuser'].'使用激活码'.$km.'续费账号['.$date.']');
				exit("<script language='javascript'>alert('购买成功！');history.go(-1);</script>");
			}else{
				exit("<script language='javascript'>alert('购买失败！');history.go(-1);</script>");
			}
		}
		//$duetime = ($res['endtime'] < time() ? time() : $res['endtime']) + $myrow['value']*24*60*60;
		//$addll = ($res['endtime'] < time() ? $myrow['values'] : $res['endtime']) + $myrow['values'];
		//$sql="update `openvpn` set `maxll`=`maxll` + '0',`endtime`='{$duetime}' where `iuser`='{$u}' && `pass`='{$p}'";
		
	}
	//if($DB->query("update `openvpn` set `pass`='$pass',`maxll`='$maxll',`i`='$state',`endtime`='$endtime' where iuser='$user'"))
}elseif($_POST['do']){
	$is = daddslashes($_POST['is']);
    if($is==1){
	$addll = '1'*1024*1024*1024;//流量数量(G)
	$rmb = '4';//购买价格
	$duetime = '31'*24*60*60;//流量到期日
		$srmb=$res['userrmb']-$rmb;
		
		if($srmb>=0){
	
		}else{
			exit("<script language='javascript'>alert('生成失败，余额不足，请联系管理员充值！');history.go(-1);</script>");
		}
if($res['maxll']/1024/1024/1024>9999){
		exit("<script language='javascript'>alert('包月无限流量用户，无法充值！');history.go(-1);</script>");
}
		$sql=$DB->query("update `openvpn` set `userrmb`='$srmb' where `id`='{$res['id']}';");
		if($sql){
	$DB->query("update `openvpn` set `maxll`=`maxll` + '{$addll}',`endtime`=`endtime` + '{$duetime}',`i`='1' where `iuser`='{$res['iuser']}' && `pass`='{$res['pass']}'");
	wlog('账号激活','用户'.$u.'使用激活码'.$km.'续费账号['.$date.']');
	exit("<script language='javascript'>alert('购买成功！');history.go(-1);</script>");
		}else{
			exit("<script language='javascript'>alert('扣款失败，请联系管理员！');history.go(-1);</script>");
		}
if($res['maxll']/1024/1024/1024>9999){
		exit("<script language='javascript'>alert('包月无限流量用户，无法充值！');history.go(-1);</script>");
}
		//$duetime = ($res['endtime'] < time() ? time() : $res['endtime']) + $myrow['value']*24*60*60;
		//$addll = ($res['endtime'] < time() ? $myrow['values'] : $res['endtime']) + $myrow['values'];
		//$sql="update `openvpn` set `maxll`=`maxll` + '0',`endtime`='{$duetime}' where `iuser`='{$res['iuser']}' && `pass`='{$p}'";
		
	}elseif($is==2){
	$addll = '3'*1024*1024*1024;//流量数量(G)
	$rmb = '10';//购买价格
	$duetime = '31'*24*60*60;//流量到期日
		$srmb=$res['userrmb']-$rmb;
		
		if($srmb>=0){
	
		}else{
			exit("<script language='javascript'>alert('生成失败，余额不足，请联系管理员充值！');history.go(-1);</script>");
		}
if($res['maxll']/1024/1024/1024>9999){
		exit("<script language='javascript'>alert('包月无限流量用户，无法充值！');history.go(-1);</script>");
}
		$sql=$DB->query("update `openvpn` set `userrmb`='$srmb' where `id`='{$res['id']}';");
		if($sql){
		$DB->query("update `openvpn` set `maxll`=`maxll` + '{$addll}',`endtime`=`endtime` + '{$duetime}',`i`='1' where `iuser`='{$res['iuser']}' && `pass`='{$res['pass']}'");
		wlog('账号激活','用户'.$u.'使用激活码'.$km.'续费账号['.$date.']');
		exit("<script language='javascript'>alert('购买成功！');history.go(-1);</script>");
		}else{
			exit("<script language='javascript'>alert('扣款失败，请联系管理员！');history.go(-1);</script>");
		}
if($res['maxll']/1024/1024/1024>9999){
		exit("<script language='javascript'>alert('包月无限流量用户，无法充值！');history.go(-1);</script>");
}

		
		
		//$duetime = ($res['endtime'] < time() ? time() : $res['endtime']) + $myrow['value']*24*60*60;
		//$addll = ($res['endtime'] < time() ? $myrow['values'] : $res['endtime']) + $myrow['values'];
		//$sql="update `openvpn` set `maxll`=`maxll` + '0',`endtime`='{$duetime}' where `iuser`='{$res['iuser']}' && `pass`='{$p}'";
		
	}elseif($is==3){
	$addll = '5'*1024*1024*1024;//流量数量(G)
	$rmb = '15';//购买价格
	$duetime = '31'*24*60*60;//流量到期日
		$srmb=$res['userrmb']-$rmb;
		
		if($srmb>=0){
	
		}else{
			exit("<script language='javascript'>alert('生成失败，余额不足，请联系管理员充值！');history.go(-1);</script>");
		}
if($res['maxll']/1024/1024/1024>9999){
		exit("<script language='javascript'>alert('包月无限流量用户，无法充值！');history.go(-1);</script>");
}
		$sql=$DB->query("update `openvpn` set `userrmb`='$srmb' where `id`='{$res['id']}';");
		if($sql){
		$DB->query("update `openvpn` set `maxll`=`maxll` + '{$addll}',`endtime`=`endtime` + '{$duetime}',`i`='1' where `iuser`='{$res['iuser']}' && `pass`='{$res['pass']}'");
		wlog('账号激活','用户'.$u.'使用激活码'.$km.'续费账号['.$date.']');
		exit("<script language='javascript'>alert('购买成功！');history.go(-1);</script>");
		}else{
			exit("<script language='javascript'>alert('扣款失败，请联系管理员！');history.go(-1);</script>");
		}

		
		
		//$duetime = ($res['endtime'] < time() ? time() : $res['endtime']) + $myrow['value']*24*60*60;
		//$addll = ($res['endtime'] < time() ? $myrow['values'] : $res['endtime']) + $myrow['values'];
		//$sql="update `openvpn` set `maxll`=`maxll` + '0',`endtime`='{$duetime}' where `iuser`='{$res['iuser']}' && `pass`='{$p}'";
		
	}elseif($is==4){
	$addll = '10'*1024*1024*1024;//流量数量(G)
	$rmb = '28';//购买价格
	$duetime = '31'*24*60*60;//流量到期日
		$srmb=$res['userrmb']-$rmb;
		
		if($srmb>=0){
	
		}else{
if($res['maxll']/1024/1024/1024>9999){
		exit("<script language='javascript'>alert('包月无限流量用户，无法充值！');history.go(-1);</script>");
}
			exit("<script language='javascript'>alert('生成失败，余额不足，请联系管理员充值！');history.go(-1);</script>");
		}
		$sql=$DB->query("update `openvpn` set `userrmb`='$srmb' where `id`='{$res['id']}';");
		if($sql){
		$DB->query("update `openvpn` set `maxll`=`maxll` + '{$addll}',`endtime`=`endtime` + '{$duetime}',`i`='1' where `iuser`='{$res['iuser']}' && `pass`='{$res['pass']}'");
		wlog('账号激活','用户'.$u.'使用激活码'.$km.'续费账号['.$date.']');
		exit("<script language='javascript'>alert('购买成功！');history.go(-1);</script>");
		}else{
			exit("<script language='javascript'>alert('扣款失败，请联系管理员！');history.go(-1);</script>");
		}


		
		
		//$duetime = ($res['endtime'] < time() ? time() : $res['endtime']) + $myrow['value']*24*60*60;
		//$addll = ($res['endtime'] < time() ? $myrow['values'] : $res['endtime']) + $myrow['values'];
		//$sql="update `openvpn` set `maxll`=`maxll` + '0',`endtime`='{$duetime}' where `iuser`='{$res['iuser']}' && `pass`='{$p}'";
		
	}elseif($is==5){
	$addll = '99999999'*1024*1024*1024;//流量数量(G)
	$rmb = '40';//购买价格
	$duetime = '31'*24*60*60;//流量到期日
		$srmb=$res['userrmb']-$rmb;
		
		if($srmb>=0){
	
		}else{
			exit("<script language='javascript'>alert('生成失败，余额不足，请联系管理员充值！');history.go(-1);</script>");
		}
if($res['maxll']/1024/1024/1024>9999){
		exit("<script language='javascript'>alert('包月无限流量用户，无法充值！');history.go(-1);</script>");
}
		$sql=$DB->query("update `openvpn` set `userrmb`='$srmb' where `id`='{$res['id']}';");
		if($sql){
				$DB->query("update `openvpn` set `maxll`=`maxll` + '{$addll}',`endtime`=`endtime` + '{$duetime}',`i`='1' where `iuser`='{$res['iuser']}' && `pass`='{$res['pass']}'");
				wlog('账号激活','用户'.$u.'使用激活码'.$km.'续费账号['.$date.']');
				exit("<script language='javascript'>alert('购买成功！');history.go(-1);</script>");
		}else{
			exit("<script language='javascript'>alert('扣款失败，请联系管理员！');history.go(-1);</script>");
		}


		
		//$duetime = ($res['endtime'] < time() ? time() : $res['endtime']) + $myrow['value']*24*60*60;
		//$addll = ($res['endtime'] < time() ? $myrow['values'] : $res['endtime']) + $myrow['values'];
		//$sql="update `openvpn` set `maxll`=`maxll` + '0',`endtime`='{$duetime}' where `iuser`='{$res['iuser']}' && `pass`='{$p}'";
		
	}
	//if($DB->query("update `openvpn` set `pass`='$pass',`maxll`='$maxll',`i`='$state',`endtime`='$endtime' where iuser='$user'"))
}

$title='用户中心';
include './head.php';


?>





<section id="content"> 
 <div class="container"> 
 <div class="m-b-lg m-t-lg"> 

 <div class="col-lg-6">
                        <div class="panel panel-info" draggable="true">
                            <div class="panel-heading">在线充值</div>
                            <div class="list-group-item">友情提醒：如您是第一次使用请先进行免流测试<a href="/Index/help/xz/5.html"><kbd>[免流测试教程]</kbd></a></div>
                            <form action="" role="form" method="post">
                            <input type="hidden" name="do" value="2">
                            <div class="list-group-item"><a class="btn w-xs btn-primary">包月流量</a> <!--<a href="/Index/liuliang/xz/1.html" class="btn w-xs btn-info">包年流量</a>--></div>
                            <div class="list-group-item">包月流量有效期为31天，请在31天内使用完，过期作废!(提前续费可享受流量不清零哦)</div>                            <div class="list-group-item">
                                <p style="margin-bottom:6px;font-size:12px;">请选择要充值的流量：</p>
								
								

                                <div class="form-control-1">
                                    <div class="radio">
                                      <label class="i-checks" style="width:125px;">
                                        <input type="radio" name="is" value="1" checked="">
                                        <i></i>1GB流量
                                      </label>
                                    </div>
                                </div>	

                                
                                <div class="form-control-1">
                                    <div class="radio">
                                      <label class="i-checks" style="width:125px;">
                                        <input type="radio" name="is" value="2" checked="">
                                        <i></i>3GB流量
                                      </label>
                                    </div>
                                </div>
                                
                                <div class="form-control-1">
                                    <div class="radio">
                                      <label class="i-checks" style="width:125px;">
                                        <input type="radio" name="is" value="3">
                                        <i></i>5GB流量
                                      </label>
                                    </div>
                                </div>
                                
                                <div class="form-control-1">
                                    <div class="radio">
                                      <label class="i-checks" style="width:125px;">
                                        <input type="radio" name="is" value="4">
                                        <i></i>10GB流量
                                      </label>
                                    </div>
                                </div>
                                
                                <div class="form-control-1">
                                    <div class="radio">
                                      <label class="i-checks" style="width:125px;">
                                        <input type="radio" name="is" value="5">
                                        <i></i>包月无限
                                      </label>
                                    </div>
                                </div>
                                
                            </div>
                            <div class="list-group-item">
                                流量价格：<span style="font-size:18px; color:#FF6133;" id="rmb">28</span> 元 
								
								
                            </div>
                            <div class="list-group-item">
                                <input type="submit" name="submit" value="确定充值" class="btn btn-info btn-block" onclick="this.value='正在充值中，请稍等···'">
                            </div>
                            </form>
                            <div class="list-group-item">
                                <span style="font-size:10px; color:#999;">系统24小时自动处理订单，付款后自动开通，无需等待。</span>
                            </div>
                        </div>
                    </div>
					

					
<div class="col-lg-6">
                        <div class="panel panel-info" draggable="true">
                            <div class="panel-heading">使用卡密</div>
                            <form action="" method="POST" class="form-inline">
                            <input type="hidden" name="do" value="1">
                            <div class="list-group-item">
                                <div class="input-group">
                                  <span class="input-group-addon">卡密</span>
                                  <input type="text" class="form-control" name="km" placeholder="请输入卡密">
                                </div>
                            </div>
                            
                            <div class="list-group-item">
                                <input type="submit" name="submit" value="确定使用" class="btn btn-info btn-block" onclick="this.value='正在使用中，请稍等···'">
                            </div>
                            </form>
                        </div>
                    </div>
  <script src="http://cdn.xkmz.cc/jisuyun/angular/js/jquery.min.js"></script>
  <script src="http://cdn.xkmz.cc/jisuyun/angular/js/bootstrap.js"></script>
  <script src="http://cdn.xkmz.cc/jisuyun/angular/js/sweetalert.min.js"></script>
  <script src="http://cdn.xkmz.cc/jisuyun/angular/js/app-tooltip-demo.js"></script>
  <script src="http://cdn.xkmz.cc/jisuyun/angular/js/layer.js"></script>

  



<script type="text/javascript">
var id = $("input[name='is']:checked").val();
var rmb2 = 0.00;
var rmb;
if(id=='5'){
	rmb = 40.00;
}else if(id=='4'){
	rmb = 28.00;
}else if(id=='3'){
	rmb = 15.00;
}else if(id=='2'){
	rmb = 10.00;
}else{
	rmb = 4.00;
}
$("#rmb").text(rmb);
if(rmb>rmb2){
	$("#rmb2").show();
}else{
	$("#rmb2").hide();
}

$(function(){
  $("input[type='radio']").click(function(){
    var id= $(this).val();
	if(id=='5'){
		rmb = 40.00;
	}else if(id=='4'){
		rmb = 28.00;
	}else if(id=='3'){
		rmb = 15.00;
	}else if(id=='2'){
		rmb = 10.00;
	}else{
		rmb = 4.00;
	}
	$("#rmb").text(rmb);
	if(rmb>rmb2){
		$("#rmb2").show();
	}else{
		$("#rmb2").hide();
	}
  });
});
</script>

  <script type="text/javascript">
    +function ($) {
      $(function(){
        // class
        $(document).on('click', '[data-toggle^="class"]', function(e){
          e && e.preventDefault();
          console.log('abc');
          var $this = $(e.target), $class , $target, $tmp, $classes, $targets;
          !$this.data('toggle') && ($this = $this.closest('[data-toggle^="class"]'));
          $class = $this.data()['toggle'];
          $target = $this.data('target') || $this.attr('href');
          $class && ($tmp = $class.split(':')[1]) && ($classes = $tmp.split(','));
          $target && ($targets = $target.split(','));
          $classes && $classes.length && $.each($targets, function( index, value ) {
            if ( $classes[index].indexOf( '*' ) !== -1 ) {
              var patt = new RegExp( '\\s' + 
                  $classes[index].
                    replace( /\*/g, '[A-Za-z0-9-_]+' ).
                    split( ' ' ).
                    join( '\\s|\\s' ) + 
                  '\\s', 'g' );
              $($this).each( function ( i, it ) {
                var cn = ' ' + it.className + ' ';
                while ( patt.test( cn ) ) {
                  cn = cn.replace( patt, ' ' );
                }
                it.className = $.trim( cn );
              });
            }
            ($targets[index] !='#') && $($targets[index]).toggleClass($classes[index]) || $this.toggleClass($classes[index]);
          });
          $this.toggleClass('active');
        });

        // collapse nav
        $(document).on('click', 'nav a', function (e) {
          var $this = $(e.target), $active;
          $this.is('a') || ($this = $this.closest('a'));
          
          $active = $this.parent().siblings( ".active" );
          $active && $active.toggleClass('active').find('> ul:visible').slideUp(200);
          
          ($this.parent().hasClass('active') && $this.next().slideUp(200)) || $this.next().slideDown(200);
          $this.parent().toggleClass('active');
          
          $this.next().is('ul') && e.preventDefault();

          setTimeout(function(){ $(document).trigger('updateNav'); }, 300);      
        });
      });
    }(jQuery);
	var xiha={
		postData: function(url, parameter, callback, dataType, ajaxType) {
			if(!dataType) dataType='json';
			$.ajax({
				type: "POST",
				url: url,
				async: true,
				dataType: dataType,
				json: "callback",
				data: parameter,
				timeout : 10000, //超时时间设置，单位毫秒
				success: function(data) {
					if (callback == null) {
						return;
					} 
					callback(data);
				},
				error: function(request,status,err) {
					layer.closeAll('loading');
					if (status == "timeout"){
						swal({title:"请求超时，请重试！",type:"warning"});
					}else{
						swal({title:"链接失败，请重试！",type:"warning"});
					}
					return false;
				}
			});
		}
	}
  </script>
