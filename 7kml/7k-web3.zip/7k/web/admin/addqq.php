<?php
$mod='blank';
include("../api.inc.php");
$title='添加账号';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<!-- Body -->
<body>
        <?php include 'nav.php';?>
		      <section>
         <!-- Page content-->
         <div class="content-wrapper">
            <h3><?php echo $title ?>
               <small>可以生成所需要的格式的帐号密码.</small>
            </h3>


<?php
if($_POST['user']){
echo '';
$notes = daddslashes($_POST['notes']);
$fwqid = daddslashes($_POST['fwqid']);
$user = daddslashes($_POST['user']);
$pass = daddslashes($_POST['pass']);
$maxll = daddslashes($_POST['maxll'])*1024*1024;
$state = daddslashes($_POST['state']);
$tian = daddslashes($_POST['tian']);
//$endtime = strtotime($_POST['enddate']);
$tian = $_POST['tian'];
$url = $_SERVER['HTTP_HOST'];
if(!$DB->get_row("select * from `openvpn` where `iuser`='$user' limit 1")){
  $id=strtoupper(substr(md5($uin.time()),0,8).'-'.uniqid());
  $sql="insert into `openvpn` (`iuser`,`pass`,`isent`,`irecv`,`maxll`,`i`,`starttime`,`endtime`,`fwqid`,`notes`,`tian`,`url`) values ('{$user}','{$pass}',0,0,'{$maxll}','{$state}','".time()."','".time()."','{$fwqid}','{$notes}','{$tian}','{$url}')";
  if($DB->query($sql))
    echo '<div class="alert alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  成功添加一个账号</div>
                <a href="javascript:history.go(-1)" class="btn btn-success btn-icon btn-icon-standalone">
                  <i class="fa fa-edit"></i>
                  <span>继续添加</span>
                </a>
                <a href="qqlist.php" class="btn btn-info btn-icon btn-icon-standalone">
                  <i class="fa fa-list-ol"></i>
                  <span>查看列表</span>
                </a>
                  <style>#addqq{display: none;}</style></div>';
  else
    echo '<div class="alert alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>添加失败：'.$DB->error().'</div>
                <a href="javascript:history.go(-1)" class="btn btn-danger btn-icon btn-icon-standalone">
                  <i class="fa fa-edit"></i>
                  <span>继续添加</span>
                </a>
                <a href="qqlist.php" class="btn btn-info btn-icon btn-icon-standalone">
                  <i class="fa fa-list-ol"></i>
                  <span>查看列表</span>
                </a>
                <style>#addqq{display: none;}</style>';
}else{
  echo "<script>alert('该账号已存在！');history.go(-1);</script>";
}
echo '';
//exit;
}

$fwqlist=$DB->query("SELECT * FROM auth_fwq");
?>
      

            <div class="row">
               <div class="col-md-12">
                <form id="addqq" action="./addqq.php" method="post" role="form" class="form-horizontal validate">
                  		                       <div class="panel panel-default">
                        <div class="panel-heading">
                           <div class="panel-title">添加账号</div>
                        </div>
						<div class="panel-body">
                  <div class="form-group">
                    <label class="col-sm-2 control-label">会员账号</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="field-1" placeholder="请输入帐号" name="user" data-validate="required">
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label">帐号密码</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="field-1" placeholder="请输入密码" name="pass" data-validate="required">
                    </div>
                  </div>  

                  <div class="form-group">
                    <label class="col-sm-2 control-label">是否开通</label>
                    <div class="col-sm-9">
                      <select name="state" class="form-control">
                        <option value="1">开通</option>
                        <option value="0">禁用</option>
                      </select> 
                    </div>
                  </div>  

                  <div class="form-group">
                    <label class="col-sm-2 control-label">开通流量</label>
                    <div class="col-sm-9">
                      <div class="input-group">
                        <input type="text" class="form-control" name="maxll" data-validate="required,number">
                        <span class="input-group-addon">MB</span> 
                      </div>
                    </div>
                  </div>

                  <!--div class="form-group">
                    <label class="col-sm-2 control-label">到期日期</label>
                    <div class="col-sm-9">
                      <div class="input-group">
                        <input type="text" class="form-control datepicker" data-format="yyyy/mm/dd " name="enddate" data-validate="required,date">
                        
                        <div class="input-group-addon">
                          <a href="#"><i class="linecons-calendar"></i></a>
                        </div>
                      </div>
                    </div>
                  </div-->

                  <div class="form-group">
                    <label class="col-sm-2 control-label">激活天数</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="field-1" placeholder="请输入使用天数" name="tian" data-validate="required">
                    </div>
                  </div>  

              <!-- <div class="input-group">
              <span class="input-group-addon">使用天数</span>
              <input type="text" name="tian" value="" class="form-control"  autocomplete="off" required>
              </div><br/> -->

                  <div class="form-group">

                    <label class="col-sm-2 control-label">选择服务器</label>
                    <div class="col-sm-9">
                      <select class="form-control" name="fwqid">
                      <?php while($v = $DB->fetch($fwqlist)): ?>
                        <option value="<?php echo $v['id']; ?>"><?php echo $v['name']; ?></option>
                      <?php endwhile; ?>
                      </select>
                    </div>
                      
                  </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label">账户备注</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="field-1" placeholder="请输入备注" name="notes">
                    </div>
                  </div>  

                  <div class="form-group">
                    <label class="col-sm-2 control-label"></label>
                    <div class="col-sm-9">
                      <button type="submit" type="button" class="btn btn-info btn-block">添加</button>
                    </div>
                  </div>
                  
                </form>   
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>

