﻿<?php

/**
 * 登录
**/
$mod='blank';
include("../api.inc.php");
$title='云免用户登录';
include './head.php';
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>XGAD的姿势交流主站</title>
<script src="http://apps.bdimg.com/libs/jquery/1.11.3/jquery.min.js">

</script>
  <!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
  <script src="js/skel.min.js"></script>
  <script src="js/init.js"></script>
  <noscript>
    <link rel="stylesheet" href="css/skel.css" />
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/style-wide.css" />
    <link rel="stylesheet" href="css/style-noscript.css" />
  </noscript>
  <!--[if lte IE 9]><link rel="stylesheet" href="css/ie/v9.css" /><![endif]-->
  <!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
<style>
html, body {background:url(css.jpg); margin: 0; padding:0;}
canvas { width: 100%; height: 100%; position: absolute; }

/* Demo Buttons Style */
.codrops-demos {
	font-size: 0.8em;
	text-align:center;
	position:absolute;
	z-index:99;
	width:96%;
}

.codrops-demos a {
	display: inline-block;
	margin: 0.35em 0.1em;
	padding: 0.5em 1.2em;
	outline: none;
	text-decoration: none;
	text-transform: uppercase;
	letter-spacing: 1px;
	font-weight: 700;
	border-radius: 2px;
	font-size: 110%;
	border: 2px solid transparent;
	color:#fff;
}

.codrops-demos a:hover,
.codrops-demos a.current-demo {
	border-color: #383a3c;
}
</style>
</head>

<body>


<canvas></canvas>

<div id="wrapper">

  <div id="overlay"></div>
  <div id="main">

    <!-- Header -->
    <header id="header">
      <div class="container" style="padding-top:70px;width:100%;">
    <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
      <div class="filter: Alpha(Opacity=10); //IE浏览器

	 -moz-opacity:0.5;  //火狐浏览器

     opacity:0.5; //其他浏览器

	 position:absolute;">
        <div class="panel-heading"><h3 class="panel-title" >客户登陆</h3></div>
        <div class="panel-body">
          <form action="./index.php" method="get" class="form-horizontal" role="form">
            <div class="input-group">
              <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
              <input type="text" name="user" value="" class="form-control" placeholder="用户名" required="required"/>
            </div><br/>
            <div class="input-group">
              <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
              <input type="password" name="pass" class="form-control" placeholder="密码" required="required"/>
            </div><br/>
            <div class="form-group">
              <div class="col-xs-6"><input type="submit" value="立即登陆" class="btn btn-success form-control"/></div>
              <div class="col-xs-6"><a href="reg.php" class="btn btn-info form-control"/>用户注册</a></div>

            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

    <!-- Footer -->

  </div>
</div>
</body>
</html>
