<?php
/**
 * 添加模式
**/
$mod='blank';
include("../api.inc.php");
if($active != 2)exit("Error");
$title='添加模式';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<!-- Body -->
<body>
          <?php include 'nav.php';?>
		      <section>
         <!-- Page content-->
         <div class="content-wrapper">
            <h3><?php echo $title ?>
               <small>此处可以编辑自带云端②公告信息</small>
            </h3>
            <div class="row">
               <div class="col-md-12">

					  		                       <div class="panel panel-default">
                        <div class="panel-heading">
                           <div class="panel-title">云端②内公告</div>
                        </div>
                        <div class="panel-body"> 



                    <form action="./notice.php" method="post" class="form-horizontal" role="form">

                      <div class="form-group">
                        <label class="col-sm-2 control-label">公告内容：</label>
                        <div class="col-sm-9">
                           <textarea class="form-control diff-textarea" placeholder="输入公告内容" name="content" rows="6"><?php echo file_get_contents('../mgg.txt'); ?></textarea>
                        </div></div>
<?php
header("Content-Type:text/html;charset=utf-8");
if(isset($_POST['content'])){
	$res = file_put_contents('../mgg.txt',$_POST['content']);
	if(false===$res) 
		echo '写入失败,目录'.__DIR__.'权限不足';
}
?>
                   
                      <div class="form-group">
                        <label class="col-sm-2 control-label"></label>
                        <div class="col-sm-9">
                          <button type="submit" type="button" class="btn btn-info btn-block">添加</button>
                        </div>
                      </div>
                    </form>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
 
                <!-- Page Body -->
            <div class="row">
               <div class="col-md-12">

					  		                       <div class="panel panel-default">
                        <div class="panel-heading">
                           <div class="panel-title">云端②外公告</div>
                        </div>
                        <div class="panel-body"> 




                    <form action="./notice.php" method="post" class="form-horizontal" role="form">

                      <div class="form-group">
                        <label class="col-sm-2 control-label">公告内容：</label>
                        <div class="col-sm-9">
                           <textarea class="form-control diff-textarea" placeholder="输入公告内容" name="content" rows="6"><?php echo file_get_contents('../mgn.txt'); ?></textarea>
                        </div></div>
<?php
header("Content-Type:text/html;charset=utf-8");
if(isset($_POST['content'])){
	$res = file_put_contents('../mgn.txt',$_POST['content']);
	if(false===$res) 
		echo '写入失败,目录'.__DIR__.'权限不足';
}
?>
                   
                      <div class="form-group">
                        <label class="col-sm-2 control-label"></label>
                        <div class="col-sm-9">
                          <button type="submit" type="button" class="btn btn-info btn-block">添加</button>
                        </div>
                      </div>
                    </form>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div> 
            <!-- Main Footer -->
            <?php include("../copy.php");?>
