<?php
function checkIfActive($string) {
	$array=explode(',',$string);
	$php_self=substr($_SERVER['PHP_SELF'],strrpos($_SERVER['PHP_SELF'],'/')+1);
	$php_self=str_replace('.php','',$php_self);
	if (in_array($php_self,$array)){
		return 'active';
	}else
		return null;
}
?>
<script src="js/amcharts.js" type="text/javascript"></script>
<script src="js/serial.js" type="text/javascript"></script>
<script src="js/pie.js" type="text/javascript"></script>
<section class="vbox">
  <header class="bg-dark dk header navbar navbar-fixed-top-xs">
    <div class="navbar-header aside-md"> <a class="btn btn-link visible-xs" data-toggle="class:nav-off-screen" data-target="#nav"> <i class="fa fa-bars"></i> </a> <a href="#" class="navbar-brand" data-toggle="fullscreen"><img src="images/logo.png" class="m-r-sm">叮咚云控v5</a> <a class="btn btn-link visible-xs" data-toggle="dropdown" data-target=".nav-user"> <i class="fa fa-cog"></i> </a> </div>
    <ul class="nav navbar-nav hidden-xs">
      <li class="dropdown">
	  <a href="http://www.dingd.cn/index.php?ref=app_admin" class=" dker" target="_blank"> <i class="fa fa-building-o"></i> <span class="font-bold">官网</span> </a>
        
      </li>
      
    </ul>
    <!--<ul class="nav navbar-nav navbar-right hidden-xs nav-user">
      <li class="hidden-xs"> <a href="#" class="dropdown-toggle dk" data-toggle="dropdown"> <i class="fa fa-bell"></i> <span class="badge badge-sm up bg-danger m-l-n-sm count">2</span> </a>
        <section class="dropdown-menu aside-xl">
          <section class="panel bg-white">
            <header class="panel-heading b-light bg-light"> <strong>You have <span class="count">2</span> notifications</strong> </header>
            <div class="list-group list-group-alt animated fadeInRight"> <a href="#" class="media list-group-item"> <span class="pull-left thumb-sm"> <img src="images/avatar.jpg" alt="John said" class="img-circle"> </span> <span class="media-body block m-b-none"> Use awesome animate.css<br>
              <small class="text-muted">10 minutes ago</small> </span> </a> <a href="#" class="media list-group-item"> <span class="media-body block m-b-none"> 1.0 initial released<br>
              <small class="text-muted">1 hour ago</small> </span> </a> </div>
            <footer class="panel-footer text-sm"> <a href="#" class="pull-right"><i class="fa fa-cog"></i></a> <a href="#notes" data-toggle="class:show animated fadeInRight">See all the notifications</a> </footer>
          </section>
        </section>
      </li>
      <li class="dropdown hidden-xs"> <a href="#" class="dropdown-toggle dker" data-toggle="dropdown"><i class="fa fa-fw fa-search"></i></a>
        <section class="dropdown-menu aside-xl animated fadeInUp">
          <section class="panel bg-white">
            <form role="search">
              <div class="form-group wrapper m-b-none">
                <div class="input-group">
                  <input type="text" class="form-control" placeholder="Search">
                  <span class="input-group-btn">
                  <button type="submit" class="btn btn-info btn-icon"><i class="fa fa-search"></i></button>
                  </span> </div>
              </div>
            </form>
          </section>
        </section>
      </li>
      
    </ul>-->
  </header>
  <section>
    <section class="hbox stretch"> <!-- .aside -->
      <aside class="bg-dark lter aside-md hidden-print" id="nav">
        <section class="vbox">
          <header class="header bg-primary lter text-center clearfix">
            <div class="btn-group">
              <button type="button" class="btn btn-sm btn-dark btn-icon" title="New project"><i class="fa fa-plus"></i></button>
              <div class="btn-group hidden-nav-xs">
                <a type="button" class="btn btn-sm btn-primary dropdown-toggle"  href="../admin" > 切换到流控后台</a>
                
              </div>
            </div>
          </header>
          <section class="w-f scrollable">
            <div class="slim-scroll" data-height="auto" data-disable-fade-out="true" data-distance="0" data-size="5px" data-color="#333333"> <!-- nav -->
              <nav class="nav-primary hidden-xs">
                <ul class="nav">
                  <li class="<?php echo checkIfActive('admin')?>"> <a href="admin.php" > <i class="fa fa-dashboard icon"> <b class="bg-danger"></b> </i> <span>控制台首页</span> </a> </li>
                  <li class="<?php echo checkIfActive('qq_admin,user,AdminShengji,AdminSplash')?>" > <a href="#layout" > <i class="fa fa-columns icon"> <b class="bg-warning"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span> <span>系统设置</span> </a>
                    <ul class="nav lt">
                     <li class="<?php echo checkIfActive("qq_admin");  ?>"><a href="qq_admin.php"><i class="fa fa-circle-o"></i> 高级设置</a></li>

					<li class="<?php echo checkIfActive("user");  ?>"><a href="user.php"><i class="fa fa-circle-o"></i> 管理密码</a></li>
				 
					<li class="<?php echo checkIfActive("AdminShengji");  ?>"><a href="AdminShengji.php"><i class="fa fa-circle-o"></i> 升级推送</a></li>
					<li class="<?php echo checkIfActive("AdminSplash");  ?>"><a href="AdminSplash.php"><i class="fa fa-circle-o"></i> 启动图设置</a></li>
                    </ul>
                  </li>
                  <li class="<?php echo checkIfActive('online,count,online_udp,qset,down,addqq,user_list,mysql')?>"> <a href="#uikit" > <i class="fa fa-flask icon"> <b class="bg-success"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span> <span>数据管理</span> </a>
                    <ul class="nav lt">
						<li><a href="user_list.php"><i class="fa fa-circle-o"></i> 用户列表</a></li>  
						<li><a href="online.php"><i class="fa fa-circle-o"></i> 在线监测</a></li>  
						<li class="<?php echo checkIfActive("count");  ?>"><a href="count.php"><i class="fa fa-circle-o"></i> 检测维护</a></li>
						<li class="<?php echo checkIfActive("mysql");  ?>"><a href="mysql.php"><i class="fa fa-circle-o"></i> 数据备份</a></li>
                    </ul>
                  </li>
                  <li class=<?php echo checkIfActive('add_line,list_line')?>"" > <a href="#pages" > <i class="fa fa-file-text icon"> <b class="bg-primary"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span> <span>线路管理</span> </a>
                    <ul class="nav lt">
                        <li class="<?php echo checkIfActive("list_line");  ?>"><a href="list_line.php"><i class="fa fa-circle-o"></i> 线路列表</a></li>
						<li class="<?php echo checkIfActive("add_line");  ?>"><a href="add_line.php"><i class="fa fa-circle-o"></i> 添加线路</a></li>
                    </ul>
                  </li>
				  
				  <li class="<?php echo checkIfActive('add_gg,list_gg')?>"> <a href="#pages" > <i class="fa fa-envelope-o icon"> <b class="bg-primary"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span> <span>公告管理</span> </a>
                    <ul class="nav lt">
                    <li class="<?php echo checkIfActive("cloudgg");  ?>"><a href="cloudgg.php"><i class="fa fa-circle-o"></i> app滚动公告</a></li>
                    <li class="<?php echo checkIfActive("add_gg");  ?>"><a href="add_gg.php"><i class="fa fa-circle-o"></i> 发布公告</a></li>
					<li class="<?php echo checkIfActive("list_gg");  ?>"><a href="list_gg.php"><i class="fa fa-circle-o"></i> 公告列表</a></li>
   
                    </ul>
                  </li> 
				  
	
                 
                  <li class="  <?php echo checkIfActive("qq_admin_daili");  ?>>"> <a href="qq_admin_daili.php" > <i class="fa fa-pencil icon"> <b class="bg-info"></b> </i> <span>代理设置</span> </a> </li>
                </ul>
              </nav>
              <!-- / nav --> </div>
          </section>
          <footer class="footer lt hidden-xs b-t b-dark">
            <!--<div id="chat" class="dropup">
              <section class="dropdown-menu on aside-md m-l-n">
                <section class="panel bg-white">
                  <header class="panel-heading b-b b-light">Active chats</header>
                  <div class="panel-body animated fadeInRight">
                    <p class="text-sm">No active chats.</p>
                    <p><a href="#" class="btn btn-sm btn-default">Start a chat</a></p>
                  </div>
                </section>
              </section>
            </div>
            <div id="invite" class="dropup">
              <section class="dropdown-menu on aside-md m-l-n">
                <section class="panel bg-white">
                  <header class="panel-heading b-b b-light"> John <i class="fa fa-circle text-success"></i> </header>
                  <div class="panel-body animated fadeInRight">
                    <p class="text-sm">No contacts in your lists.</p>
                    <p><a href="#" class="btn btn-sm btn-facebook"><i class="fa fa-fw fa-facebook"></i> Invite from Facebook</a></p>
                  </div>
                </section>
              </section>
            </div>-->
            <a href="#nav" data-toggle="class:nav-xs" class="pull-right btn btn-sm btn-dark btn-icon"> <i class="fa fa-angle-left text"></i> <i class="fa fa-angle-right text-active"></i> </a>
           
          </footer>
        </section>
      </aside>
      <!-- /.aside -->
      <section id="content">
        <section class="vbox">
          <section class="scrollable padder">
            <ul class="breadcrumb no-border no-radius b-b b-light pull-in">
              <li><a href="index.html"><i class="fa fa-home"></i> 主页</a></li>
              <li class="active">工作区</li>
            </ul>
