<?php
$mod='blank';
include("../api.inc.php");
$title='支付宝设置';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<!-- Body -->
<body>
        <?php include 'nav.php';?>
		      <section>
         <!-- Page content-->
         <div class="content-wrapper">
            <h3><?php echo $title ?>
               <small>请自行到支付宝官网申请开通接口</small>
            </h3>
<?php
$id =$site_id;
if(!$id || !$row = $DB->get_row("select * from `alipay` where id='$id' limit 1")){ exit("不存在!");}
if($_POST['type']=="update"){
echo '<div class="alert ';
$partner = daddslashes($_POST['partner']);
$alikey = daddslashes($_POST['alikey']);
$url = daddslashes($_POST['url']);
  if($DB->query("update `alipay` set `partner`='$partner',`alikey`='$alikey',`url`='$url' where id='$id'")){
    echo 'alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  修改成功！';
  }else{
    echo 'alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  修改失败！'.$DB->error();
  }
echo '</div>';
echo "<style>#payset{display: none;}</style>";
//exit;
}
?>
      
            <div class="row">
               <div class="col-md-12">

					  		                       <div class="panel panel-default">
                        <div class="panel-heading">

                        <div class="panel-body">
                <form id="payset" action="./payset.php?id=<?=$id?>" method="post" role="form" class="form-horizontal">
                <input type="hidden" name="type" value="update" />

                  <div class="form-group">
                    <label class="col-sm-2 control-label">合作身份者ID</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="field-1" name="partner" data-validate="required,number,min[16]" value="<?=$row['partner']?>" placeholder="以2088开头由16位纯数字组成的字符串，">
                      <p class="text-success">查看地址：https://b.alipay.com/order/pidAndKey.htm</p>
                    </div>
                  </div>  

                  <div class="form-group">
                    <label class="col-sm-2 control-label">MD5密钥</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="alikey" data-validate="required,min[16]" value="<?=$row['alikey']?>" placeholder="由数字和字母组成的32位字符串">
                        <p class="text-success">查看地址：https://b.alipay.com/order/pidAndKey.htm</p>
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label">网站网址</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="url" data-validate="required" value="<?=$row['url']?>" placeholder="需www.abc.com格式的完整路径">
                        <p class="text-success">不能加?id=123这类自定义参数，必须外网可以正常访问</p>
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label"></label>
                    <div class="col-sm-9">
                      <button type="submit" type="button" class="btn btn-info btn-block">设置</button>
                    </div>
                  </div>
                  
                </form>

                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
