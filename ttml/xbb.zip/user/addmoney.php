<?php
$mod='blank';
include("../api.inc.php");

$userid=$_SESSION['userid'];

$u = daddslashes($_GET['user']);

$p = daddslashes($_GET['pass']);



if($u==""){
$res = $DB->get_row("SELECT * FROM openvpn WHERE id='$userid' limit 1");
$qdres = $DB->get_row("SELECT * FROM auth_qd WHERE iuser='{$res['iuser']}' limit 1");
}else{
$res=$DB->get_row("SELECT * FROM `openvpn` where `iuser`='$u' && `pass`='$p' limit 1");
}


if(!$res){
//	header('location: login.php');
		exit("<script language='javascript'>window.location.href='./login.php';</script>");
}



if($_POST['km']){
	$km = daddslashes($_POST['km']);
	$myrow=$DB->get_row("select * from auth_kms where kind=2 and km='$km' limit 1");
	if(!$myrow){
		exit("<script language='javascript'>alert('此激活码不存在');history.go(-1);</script>");
	}elseif($myrow['isuse']==1){
		exit("<script language='javascript'>alert('此激活码已被使用');history.go(-1);</script>");
	}else{
if($myrow['maxll']/1024/1024/1024>9999){
		exit("<script language='javascript'>alert('包月无限流量用户，无法充值！');history.go(-1);</script>");
}
		$rmb = $myrow['money'];
        $sql="update `openvpn` set `userrmb`=`userrmb` + '{$rmb}' where `iuser`='{$res['iuser']}' && `pass`='{$res['pass']}'";
			if($DB->query($sql)){
				$DB->query("update `auth_kms` set `isuse` ='1',`user` ='{$res['iuser']}',`usetime` ='$date' where `id`='{$myrow['id']}'");
				wlog('账号激活','用户'.$u.'使用激活码'.$km.'续费账号['.$date.']');
				exit("<script language='javascript'>alert('续费成功！');history.go(-1);</script>");
			}else{
				exit("<script language='javascript'>alert('续费失败！');history.go(-1);</script>");
			}
		
		
		//$duetime = ($res['endtime'] < time() ? time() : $res['endtime']) + $myrow['value']*24*60*60;
		//$addll = ($res['endtime'] < time() ? $myrow['values'] : $res['endtime']) + $myrow['values'];
		//$sql="update `openvpn` set `maxll`=`maxll` + '0',`endtime`='{$duetime}' where `iuser`='{$res['iuser']}' && `pass`='{$p}'";
		
	}
	//if($DB->query("update `openvpn` set `pass`='$pass',`maxll`='$maxll',`i`='$state',`endtime`='$endtime' where iuser='$user'"))
}

$title='用户中心';
include './head.php';

$config = $DB->get_row("SELECT * FROM auth_config");
$gonggao=$config['ggs'];//公告获取
?>

<section id="content"> 
 <div class="container"> 
 <div class="m-b-lg m-t-lg"> 


<div class="wrapper">



<div class="col-lg-6">
                        <div class="panel panel-info">
                            <div class="panel-heading text-center">
                                <h4 class="font-bold no-margins" style="margin:5px;">在线充值</h4>
                            </div>
                            <div class="panel-body">
                                <div class="tooltip-demo text-center">
                                    <div id="qrcode" title="http://qq.jisuyun.cc/download/jisuyun.apk"><canvas width="200" height="200" style="display: none;"></canvas><img src="http://qr.liantu.com/api.php?text=" height="200" width="200" style="display: initial;"></div>
                                    <h5>系统24小时自动处理订单，如充值后未到账请联系客服。</h5>
                                    <h3>您也可以直接：<a href="http://qq.jisuyun.cc/download/jisuyun.apk" target="_blank">联系客服</a></h3>
                                    <h4><a class="btn m-b-xs btn-primary btn-rounded" href="http://">在线购买</a></h4>
                                </div>
                            </div>
                        </div>
                    </div>

	
<div class="col-lg-6">
                        <div class="panel panel-info" draggable="true">
                            <div class="panel-heading">使用卡密</div>
                            <form role="form" method="POST" class="form-inline">
                            <input type="hidden" name="do" value="1">
                            <div class="list-group-item">
                                <div class="input-group">
                                  <span class="input-group-addon">卡密</span>
                                  <input type="text" class="form-control" name="km" placeholder="请输入余额卡密">
                                </div>
                            </div>
                            
                            <div class="list-group-item">
                                <input type="submit" name="submit" value="确定使用" class="btn btn-info btn-block" onclick="this.value='正在使用中，请稍等···'">
                            </div>
                            </form>
                        </div>
                    </div>

			</div>
			</div>
			</section>

  </center>