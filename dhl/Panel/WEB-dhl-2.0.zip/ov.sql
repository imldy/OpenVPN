-- phpMyAdmin SQL Dump
-- version 4.0.10.15
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2016-11-10 19:39:27
-- 服务器版本: 5.1.73-log
-- PHP 版本: 5.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `ov`
--

-- --------------------------------------------------------

--
-- 表的结构 `auth_alipay`
--

CREATE TABLE IF NOT EXISTS `auth_alipay` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` varchar(64) NOT NULL,
  `user` varchar(64) NOT NULL,
  `total` varchar(64) NOT NULL,
  `addnum` varchar(64) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `auth_config`
--

CREATE TABLE IF NOT EXISTS `auth_config` (
  `id` varchar(80) NOT NULL DEFAULT '1',
  `gg` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `auth_config`
--

INSERT INTO `auth_config` (`id`, `gg`) VALUES
('1', '欢迎使用大灰狼WEB控制面板！');

-- --------------------------------------------------------

--
-- 表的结构 `auth_fwq`
--

CREATE TABLE IF NOT EXISTS `auth_fwq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `ipport` varchar(64) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `auth_fwq`
--

INSERT INTO `auth_fwq` (`id`, `name`, `ipport`, `time`) VALUES
(1, '本地服务器', '127.0.0.1:88', '2016-07-12 09:46:20');

-- --------------------------------------------------------

--
-- 表的结构 `auth_log`
--

CREATE TABLE IF NOT EXISTS `auth_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) NOT NULL,
  `msg` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `auth_price`
--

CREATE TABLE IF NOT EXISTS `auth_price` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `price` varchar(64) NOT NULL,
  `day` varchar(64) NOT NULL,
  `llpg` varchar(64) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `auth_price`
--

INSERT INTO `auth_price` (`id`, `price`, `day`, `llpg`, `time`) VALUES
(1, '1', '30', '104857600', '2016-11-09 01:03:24'),
(2, '2', '30', '209715200', '2016-11-09 11:34:54');

-- --------------------------------------------------------

--
-- 表的结构 `lyj_article`
--

CREATE TABLE IF NOT EXISTS `lyj_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '无题',
  `content` text NOT NULL,
  `visit_count` int(10) unsigned NOT NULL DEFAULT '0',
  `timeline` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文章表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `lyj_category`
--

CREATE TABLE IF NOT EXISTS `lyj_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '默认栏目',
  `description` varchar(255) NOT NULL DEFAULT '栏目简介',
  `sortby` int(5) NOT NULL DEFAULT '0',
  `hidden` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='栏目表' AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `lyj_category`
--

INSERT INTO `lyj_category` (`id`, `name`, `description`, `sortby`, `hidden`) VALUES
(1, '移动', '', 1, 0),
(2, '联通', '', 2, 0),
(3, '电信', '', 3, 0);

-- --------------------------------------------------------

--
-- 表的结构 `lyj_link`
--

CREATE TABLE IF NOT EXISTS `lyj_link` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `name` varchar(200) NOT NULL DEFAULT '链接名称',
  `description` varchar(255) NOT NULL DEFAULT '链接简介',
  `url` varchar(255) NOT NULL DEFAULT 'http://',
  `icon` varchar(255) NOT NULL DEFAULT 'http://',
  `sortby` int(5) NOT NULL DEFAULT '0',
  `hidden` int(2) NOT NULL DEFAULT '0',
  `timeline` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='友链表' AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `lyj_link`
--

INSERT INTO `lyj_link` (`id`, `category_id`, `name`, `description`, `url`, `icon`, `sortby`, `hidden`, `timeline`) VALUES
(1, 1, '流控地址', '我的加速器我做主', 'http://IPAddress:88/', 'http://www.baidu.com/', 1, 0, 0),
(2, 1, '卡密地址', '链接简介', 'http://IPAddress:88', '.', 0, 0, 1471028321),
(3, 1, '官方商城', '链接简介', 'http://ip:port/', '.', 2, 0, 1471029048),
(4, 1, '使用说明', '链接简介', 'http://ip:port/index.html', '.', 3, 0, 1471029100),
(5, 1, '背景图片', '链接简介', 'http://图片', '.', 4, 0, 1471029221),
(6, 1, '淘口令', '链接简介', 'http://sd', '.', 5, 0, 1471029271);

-- --------------------------------------------------------

--
-- 表的结构 `lyj_setting`
--

CREATE TABLE IF NOT EXISTS `lyj_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `skey` varchar(100) NOT NULL DEFAULT '要设置的键',
  `sval` varchar(1024) NOT NULL DEFAULT '要设置的值',
  PRIMARY KEY (`id`),
  UNIQUE KEY `skey` (`skey`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='设置表' AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `lyj_setting`
--

INSERT INTO `lyj_setting` (`id`, `skey`, `sval`) VALUES
(1, 'contact', 'QQnumber'),
(2, 'seo_title', 'QQkey'),
(3, 'seo_keywords', 'http://www.baidu.com/1.jpg'),
(4, 'seo_description', '河南移动用户今天请更新线路'),
(5, 'copyright', 'http://IPAddress:88/');

-- --------------------------------------------------------

--
-- 表的结构 `lyj_token`
--

CREATE TABLE IF NOT EXISTS `lyj_token` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `token` varchar(32) NOT NULL,
  `expire_timeline` int(10) NOT NULL,
  `update_timeline` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='登录令牌表' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `lyj_token`
--

INSERT INTO `lyj_token` (`id`, `user_id`, `token`, `expire_timeline`, `update_timeline`) VALUES
(1, 1, 'md5Toeken', 1473619585, 1473619585);

-- --------------------------------------------------------

--
-- 表的结构 `openvpn`
--

CREATE TABLE IF NOT EXISTS `openvpn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(16) NOT NULL,
  `CNY` varchar(64) NOT NULL DEFAULT '0',
  `isent` bigint(128) DEFAULT '0',
  `irecv` bigint(128) DEFAULT '0',
  `maxll` bigint(128) NOT NULL,
  `pass` varchar(32) NOT NULL,
  `i` int(1) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `starttime` timestamp NULL DEFAULT NULL,
  `endtime` timestamp NULL DEFAULT '1970-12-11 16:00:00',
  `notes` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `iuser` (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
