<?php
/**
 * 搜索授权
**/
$mod='blank';
include("../api.inc.php");
$title='搜索卡密';
$dlid=$_SESSION['dlid'];
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<!-- Body -->
<body>
        <?php include 'nav.php';?>
		      <section>
         <!-- Page content-->
         <div class="content-wrapper">
            <h3><?php echo $title ?>

            </h3>
            
            <br />

            <div class="row">
                
                <div class="col-sm-12">
                    
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            在线充值
                        </div>
                        
                        <div class="panel-body">
                            
                            <div class="row">
                                <div class="col-sm-12">
                                    
                                    <form action="/pay/alipayapi.php" class="alipayform validate" method="post" target="_blank">
                                    <ul class="list-group list-group-minimal">
                                        <li class="list-group-item">
                                            <?php
                                            $d=time();
                                            ?>
                                            <span class="badge badge-roundless badge-warning"><?php echo "" . date("Ymdhis", $d);?></span>
                                            <input type="text" name="WIDout_trade_no" id="out_trade_no" value="<?php echo "" . date("Ymdhis", $d);?>" class="hide">
                                            订单号
                                        </li>
                                        <li class="list-group-item">
                                            <span class="badge badge-roundless badge-info">代理充值余额</span>
                                            <input type="text" name="WIDsubject" value="代理充值余额" class="hide">
                                            商品名称
                                        </li>
                                        <li class="list-group-item">
                                            <div class="input-group">
                                                <input type="text" class="form-control no-right-border form-focus-info"  name="WIDtotal_fee" placeholder="请输入充值金额" data-validate="required,number,min[1]">
                                                <!--input type="text" class="form-control no-right-border form-focus-info"  name="WIDtotal_fee" value ="0.10"-->
                                                <span class="input-group-btn">
                                                    <button class="btn btn-info" type="button">￥</button>
                                                </span>
                                            </div>
                                        </li>
                                        <input type="text" name="WIDbody" value="<?php echo $dlid?>" class="hide">
                                    </ul>
                                    <button type="submit" class="btn btn-success btn-icon btn-block">
                                        <i class="fa fa-check"></i>
                                        <span>确认支付</span>
                                    </button>
                                    </form>
                                    
                                </div>
                            </div>
                            
                        </div>
                        
                    </div>
                </div>

            </div>

             <?php include("../copy.php");?>
             