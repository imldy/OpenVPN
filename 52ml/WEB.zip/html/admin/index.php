<?php
@eval("//www.zhaoyuanma.com 免费版本加密! "); ?><?php
@eval("//Encode by  phpjiami.com,Free user."); ?><?php
/**
 * 管理中心
**/
$mod='blank';
include("../api.inc.php");
$title='管理中心';
include './head.php';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
include './nav.php';
$count=$DB->count("SELECT count(*) from `openvpn` WHERE 1");
$count2=$DB->count("SELECT count(*) from `openvpn` WHERE i=1");
$countdaili=$DB->count("SELECT count(*) from `auth_daili` WHERE 1");
$mysqlversion=$DB->count("select VERSION()");
		// 获取版本号更新日期
		$version = '../version.php';
		$ver = include($version);										
		$hosturl= urlencode('http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']);
		$updatehost = 'http://97cn.top/up.php';
		$updatehosturl = $updatehost.'?a=client_check_time&v='.$ver.'&u='.$hosturl;
		$domain_time = file_get_contents($updatehosturl);
		 if($domain_time=='0'){
			$domain_time='授权已过期，请联系官方';
		 }else {
                        $domain_time=''.date("Y-m-d",$domain_time).'';
		 }		
		 

 
 //读取图片换头像
 srand( microtime() * 1000000 );
 $num = rand( 1, 4 );
   
 switch( $num )
 {
 case 1: $image_file = "./sjimg/1.jpg";
     break;
 case 2: $image_file = "./sjimg/2.jpg";
     break;
 case 3: $image_file = "./sjimg/3.jpg";
     break;
 case 4: $image_file = "./sjimg/4.jpg";
     break;
 }

?>

    <section id="content">
        <section class="vbox">
            <section class="scrollable padder">
                <ul class="breadcrumb no-border no-radius b-b b-light pull-in">
                    <li>
                        <a href="#">
                            <i class="fa fa-home">
                            </i>
                            <?php echo $title ?>
                        </a>
                    </li>
                </ul>
                <section class="panel panel-default">
                    <div class="row m-l-none m-r-none bg-light lter">
                        <div class="col-sm-6 col-md-3 padder-v b-r b-light">
                            <span class="fa-stack fa-2x pull-left m-r-sm">
                                <i class="fa fa-circle fa-stack-2x text-info">
                                </i>
                                <i class="fa fa-male fa-stack-1x text-white">
                                </i>
                            </span>
                            <a class="clear" href="../admin/qqlist.php">
                                <span class="h3 block m-t-xs">
                                    <strong>
                                        <?php echo $count?>
                                    </strong>
                                </span>
                                <small class="text-muted text-uc">
                                    注册用户
                                </small>
                            </a>
                        </div>
                        <div class="col-sm-6 col-md-3 padder-v b-r b-light lt">
                            <span class="fa-stack fa-2x pull-left m-r-sm">
                                <i class="fa fa-circle fa-stack-2x text-warning">
                                </i>
                                <i class="fa fa-bug fa-stack-1x text-white">
                                </i>
                            </span>
                            <a class="clear" href="./qqlist.php">
                                <span class="h3 block m-t-xs">
                                    <strong id="bugs">
                                        <?php echo $count2?>
                                    </strong>
                                </span>
                                <small class="text-muted text-uc">
                                    状态正常
                                </small>
                            </a>
                        </div>
                        <div class="col-sm-6 col-md-3 padder-v b-r b-light">
                            <span class="fa-stack fa-2x pull-left m-r-sm">
                                <i class="fa fa-circle fa-stack-2x text-danger">
                                </i>
                                <i class="fa fa-fire-extinguisher fa-stack-1x text-white">
                                </i>
                            </span>
                            <a class="clear" href="./online.php">
                                <span class="h3 block m-t-xs">
                                    <strong id="firers">
                                        <?php //echo $DB->
                                            //在线人数接口
											$str=file_get_contents('../res/openvpn-status.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
											echo $onlinenum = (int)((substr_count($str,date('Y'))-1)/2);
                                            ?>
                                    </strong>
                                </span>
                                <small class="text-muted text-uc">
                                    在线人数
                                </small>
                            </a>
                        </div>
                        <div class="col-sm-6 col-md-3 padder-v b-r b-light lt">
                            <span class="fa-stack fa-2x pull-left m-r-sm">
                                <i class="fa fa-circle fa-stack-2x icon-muted">
                                </i>
                                <i class="fa fa-clock-o fa-stack-1x text-white">
                                </i>
                            </span>
                            <a class="clear" href="#">
                                <span class="h3 block m-t-xs">
                                    <strong>
                                        <?php echo date( "H:i") ?>
                                    </strong>
                                </span>
                                <small class="text-muted text-uc">
                                    目前时间
                                </small>
                            </a>
                        </div>
                    </div>
                </section>
                <div class="col-md-6">
                    <section class="panel panel-default well m-t">
                        <header class="panel-heading font-bold">
                            今日公告:<br>欢迎进入麒麟团队流控管理面板
                        </header>
                         <strong></strong></section>
                </div>
				<div class="col-md-6">
                    <section class="panel panel-default">
                  <div class="panel-body">
                    <div class="clearfix text-center m-t">
                      <div class="inline">
                        <div class="easypiechart" data-percent="100" data-line-width="5" data-bar-color="#32CD32" data-track-Color="#f5f5f5" data-scale-Color="false" data-size="130" data-line-cap='butt' data-animate="1000">
                          <div class="thumb-lg"> 

                          <img src="<?=$image_file?>"  class="img-circle"> </div>
                        </div>
                        <div class="h4 m-t m-b-xs"><?php echo $row[ 'user'] ?></div>
                        <small class="text-muted m-b"><?php echo date("Y-m-d H:i:s") ?></small> </div>
                    </div>
                  </div>
                </section>

                </div>
                <div class="row">
                    <div class="col-md-6">
                        <section class="panel panel-default">
                            <header class="panel-heading font-bold">
                                服务器状态</header>
                            <div class="panel-body">
                                <form action="#" class="form-inline" method="post" role="form">
                                    <div class="form-group">
		<li class="list-group-item">
			<b>PHP 版本：</b><?php echo phpversion() ?>
			<?php if(ini_get('safe_mode')) { echo '线程安全'; } else { echo '非线程安全'; } ?>
		</li>
		<li class="list-group-item">
			<b>MySQL 版本：</b><?php echo $mysqlversion ?>
		</li>
		<li class="list-group-item">
			<b>服务器软件：</b><?php echo $_SERVER['SERVER_SOFTWARE'] ?>
		</li>
		
		<li class="list-group-item">
			<b>程序最大运行时间：</b><?php echo ini_get('max_execution_time') ?>s
		</li>
		<li class="list-group-item">
			<b>POST许可：</b><?php echo ini_get('post_max_size'); ?>
		</li>
		<li class="list-group-item">
			<b>文件上传许可：</b><?php echo ini_get('upload_max_filesize'); ?>
		</div>
<div class="line line-dashed line-lg pull-in">
</div>
                                    <div class="form-group"></div>
                                    <div class="line line-dashed line-lg pull-in">
                                    </div>
                                    <div class="form-group code" style="display: none;">
                                        <span id="codeimg">
                                        </span>
                                    </div>
                                    <div class="line line-dashed line-lg pull-in code" style="display: none;">
                                    </div>
                                    <div class="form-group code" style="display: none;">
                                        <input type="text" class="form-control" id="code" placeholder="验证码">
                                    </div>
                                    <div class="line line-dashed line-lg pull-in">
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label" for="field-2" id="load">
                                        </label>
                                    </div>
                                </form>
                            </div>
                        </section>
                    </div>
                    <div class="col-md-6">
                        <section class="panel b-light">
                            <header class="panel-heading bg-primary dker no-border">
                                <strong>
                                    授权信息
                                </strong>
                            </header>
                      <div id="" class="panel-heading bg-primary dker no-border">
              <ul class="list-group">
		
			<p><b>系统版本：麒麟团队1.8</b>
			  </li>
			</p>
			<p>
			  <b>最近更新时间：2016-6-22</b>
			  </li>
			  </p>
			
			  <p><b>服务到期时间：无限期</b>
			    </li>
			    </p>
			  <p><b><a href="update.php?a=index"><strong>在线更新待开发</strong></a></b></p>
		</li>
	          </ul>              		
	</div>
	
              </div>
                        </section>
            <div>
                <a href="#" class="btn btn-default btn-sm m-b">
                    <i class="fa fa-plus icon-muted">
                    </i>
                    more
                </a>
              </div>
      </section>
        </section>
        <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen"
        data-target="#nav">
        </a>
    <aside class="bg-light lter b-l aside-md hide" id="notes">
        <div class="wrapper">
            Notification
        </div>
    </aside>
    <!-- end -->
<?php require_once ( "foot.php"); ?><?php  