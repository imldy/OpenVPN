<?php
return array (
  'base_url' => 'http://127.0.0.1/7kyun',
  'db.type' => 'mysql',
  'db.host' => 'localhost',
  'db.port' => 3306,
  'db.user' => 'root',
  'db.pass' => '123456',
  'db.name' => 'ov',
)
?>