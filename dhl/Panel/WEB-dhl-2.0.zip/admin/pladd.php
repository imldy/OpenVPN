<?php

$mod='blank';
include("../api.inc.php");
$title='批量添加账号';
include './head.php';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
include './nav.php';
?>
    <?php
require_once ("head.php");

?>
<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<div class="panel panel-primary">
<div class="panel-heading w h"><h3 class="panel-title"><?php echo $title ?></h3></div>
<div class="panel-body box">
				
<?php
if($_POST['num']){

$notes = daddslashes($_POST['notes']);
$num = daddslashes($_POST['num']);
$prefix = daddslashes($_POST['prefix']);
$strlen = daddslashes($_POST['strlen']);
$suffix = daddslashes($_POST['suffix']);
$pass = md5(daddslashes($_POST['pass']));
$maxll = daddslashes($_POST['maxll'])*1024*1024;
$state = daddslashes($_POST['state']);
$endtime = strtotime($_POST['enddate']);
$tian = $_POST['tian'];

for($x=0; $x<$num; $x++){

$user = $prefix.getstr($strlen).$suffix;

if(!$DB->get_row("select * from `openvpn` where `iuser`='$user' limit 1")){
	$id=strtoupper(substr(md5($uin.time()),0,8).'-'.uniqid());
	$sql="insert into `openvpn` (`iuser`,`pass`,`isent`,`irecv`,`maxll`,`i`,`starttime`,`endtime`,`notes`,`status`) values ('{$user}','{$pass}',0,0,'{$maxll}','{$state}','".time()."','{$endtime}','{$notes}',0)";
	if($DB->query($sql))
		echo "{$user}----{$pass}----{$notes}<br />";
	else
		echo "添加失败：".$DB->error()."<br />";
}else{
	echo "该账号已存在！<br />";
}


}
echo '<hr/><a href="./pladd.php">>>返回继续添加</a><br><a href="./qqlist.php">>>返回账号列表</a></div></div>';
?>
                  <div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
                    
                  
              </div>
            </section>
</section>
</section>

<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a></section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
<div class="wrapper">
	Notification
</div>
</aside>
<!-- end -->
<?php
require_once ("foot.php");

exit;
}

$fwqlist=$DB->query("SELECT * FROM auth_fwq");
?>
      


          
          <form action="./pladd.php" method="post" class="form-horizontal" role="form">
            <div class="input-group">
			  <span class="input-group-addon">账号个数</span>
              <input type="text" name="num" value="" class="form-control" required/>
            </div><br/>
            <div class="input-group">
			  <span class="input-group-addon">账号前缀</span>
              <input type="text" name="prefix" value="" class="form-control" />
            </div><br/>
            <div class="input-group">
			  <span class="input-group-addon">随机数长度</span>
              <input type="text" name="strlen" value="" class="form-control" required/>
            </div><br/>
            <div class="input-group">
			  <span class="input-group-addon">账号后缀</span>
              <input type="text" name="suffix" value="" class="form-control" />
            </div><br/>
            <div class="input-group">
              <span class="input-group-addon">密码</span>
			  <input type="text" name="pass" value="" class="form-control" required>
            </div><br/>
            <div class="input-group">
              <span class="input-group-addon">账号状态</span>
			  <select name="state" class="form-control">
              	<option value="0">0_禁用</option>
				<option value="1">1_开通</option>
              </select>
            </div><br/>
            <div class="input-group">
              <span class="input-group-addon">总流量(M)</span>
			  <input type="text" name="maxll" value="" class="form-control" required>
            </div><br/>
			<div class="input-group">
              <span class="input-group-addon">到期日期</span>
			  <input type="text" name="enddate" value="" class="form-control Wdate" onClick="WdatePicker({isShowClear:false})" autocomplete="off" required>
            </div><br/>
            <div class="input-group">
			  <span class="input-group-addon">备注</span>
              <input type="text" name="notes" value="" class="form-control" />
            </div><br/>
            <input type="submit" value="添加" class="btn btn-primary form-control"/>
          </form>
        </div>
      </div>
    </div>
  </div>
  <script src="../datepicker/WdatePicker.js"></script>
                  <div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
                    
                  
              </div>
            </section>
</section>
</section>

<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a></section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
<div class="wrapper">
	Notification
</div>
</aside>
<!-- end -->
<?php
require_once ("foot.php");
?><?php 