<?php
include("../api.inc.php");
$config = $DB->get_row("SELECT * FROM auth_config");
echo $config['ggs']; //公告获取
?>