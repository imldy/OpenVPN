<?php
    $mod = 'blank';
    include ('../api.inc.php');
    $title = '代理套餐';
    include './head.php';
    if ($islogin2 == 1) {
    } else exit ("<script language='javascript'>window.location.href='./login.php';</script>");
    $fwqlist = $DB->query('SELECT * FROM auth_fwq');
    $numrows1 = $DB->count('SELECT count(*) from `auth_dltc` WHERE 1') +1;
?>
<?php
    echo '<section id="content">
<section class="vbox">
<section class="scrollable padder">
<ul class="breadcrumb no-border no-radius b-b b-light pull-in">
<section class="panel panel-default">
              <header class="panel-heading font-bold"> 套餐管理 </header>
              <div class="panel-body">
';
    if ($my == 'del') {
        echo '<div class="panel panel-success">
<div class="panel-heading w h"><h3 class="panel-title">删除套餐</h3></div>
<div class="panel-body box">';
        $id = $_GET['id'];
        $sql = $DB->query("DELETE FROM auth_dltc WHERE id='$id'");
        if ($sql) {
            echo '删除成功！';
        } else {
            echo '删除失败！';
        }
        echo '<hr/><a href="./udltc.php">>>返回套餐列表</a></div></div>';
    }
    if ($my == 'add') {
        $ID = strval($_POST['id']);
        $name = strval($_POST['name']);
        $vip = strval($_POST['vip']);
        $rmb = intval($_POST['rmb']);
        if (!$DB->get_row("select * from `auth_dltc` where `id`='$id' limit 1")) {
            $id = strtoupper(substr(md5($uin.time()), 0, 8) .'-'.uniqid());
            $sql = "insert into `auth_dltc` (`id`,`name`,`vip`,`rmb`) values ({$ID
        }
        ,'{$name
    }
    ','{$vip
    }
    ','{$rmb
    }
    ')";
    if ($DB->query($sql)) echo '添加成功:'.$name;
    else echo '添加失败：'.$DB->error();
    } else {
        echo "<script>alert('该套餐已存在！');history.go(-1);</script>";
    }
    echo '<hr/><a href="./udltc.php">>>返回继续添加</a><br><a href="./udltc.php">>>返回套餐列表</a></div></div>';
    exit;
    }
?><?php
    echo '      
          <form action="./udltc.php?my=add" method="post" class="form-horizontal" role="form">
            <div class="input-group">
              <span class="input-group-addon">套餐ID</span>
			  <input type="text" name="id" value="';
    echo $numrows1;
?><?php
    echo '" class="form-control" required>
            </div><br/>
            <div class="input-group">
              <span class="input-group-addon">套餐名称</span>
			  <input type="text" name="name" value="" class="form-control" required>
            </div><br/>
			<div class="input-group">
              <span class="input-group-addon">套餐价钱</span>
			  <input type="text" name="rmb" value="0.00" class="form-control" required>
            </div><br/>
            <div class="input-group">
              <span class="input-group-addon">代理等级</span>
			  <select name="vip" class="form-control">
                <option value="0">普通代理</option>
                <option value="1">铜牌代理</option>
                <option value="2">银牌代理</option>
                <option value="3">金牌代理</option>
                <option value="4">钻石代理</option>
                <option value="5">至尊代理</option>
              </select>
            </div><br/>


            <input type="submit" value="添加" class="btn btn-primary form-control"/>
          </form>


';
    $numrows = $DB->count('SELECT count(*) from `auth_dltc` WHERE 1');
    $sql = ' 1';
    $con = '平台共有 <b>'.$numrows.'</b> 个卡密';
?>
<?php
    echo '      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th>序号</th><th>名称</th><th>价钱</th><th>等级</th><th>操作</th></tr></thead>
          <tbody>
';
    $pagesize = 30;
    $pages = intval($numrows/$pagesize);
    if ($numrows%$pagesize) {
        $pages++;
    }
    if (isset($_GET['page'])) {
        $page = intval($_GET['page']);
    } else {
        $page = 1;
    }
    $offset = $pagesize*($page-1);
    $rs = $DB->query("SELECT * FROM `auth_dltc` WHERE{$sql
    }
     order by id desc limit $offset,$pagesize");
    while ($res = $DB->fetch($rs)) {
        if ($res['vip'] == 0) {
            $isactive = '<font color="red">普通代理</font>';
        } elseif ($res['vip'] == 1) {
            $isactive = '<font color="green">铜牌代理</font>';
        } elseif ($res['vip'] == 2) {
            $isactive = '<font color="green">银牌代理</font>';
        } elseif ($res['vip'] == 3) {
            $isactive = '<font color="green">金牌代理</font>';
        } elseif ($res['vip'] == 4) {
            $isactive = '<font color="green">钻石代理</font>';
        } elseif ($res['vip'] == 5) {
            $isactive = '<font color="green">至尊代理</font>';
        }
        echo '
<tr>
<td><b>'.$res['id'].'</b></td>

<td><b>'.$res['name'].'</b></td>

<td><b>'.$res['rmb'].'/元</b></td>

<td><b>'.$isactive.'</b></td>

<td><a href="./udltc.php?my=del&id='.$res['id']."\" class=\"btn btn-xs btn-danger\" onclick=\"return confirm('你确实要删除此套餐吗？');\">删除</a></td></tr>";
    }
?>
<?php
    echo '
    </div>
  </div>
</section>
</section>
</section>
<!-- end -->
';
    include './nav.php';
?>