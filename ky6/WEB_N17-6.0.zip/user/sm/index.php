﻿<html class="no-js"> 
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>帮助中心</title>
    <meta name="keywords" content="云流量,免流,云流量,免流量,安卓苹果免流,云免平台,OpenVPN免流,免费云免,移动联通电信流量"/>
    <meta name="description" content="云流量的服务器采用国内高带宽/高品质BGP节点，适用于iOS/Android手机，移动/联通/电信三网通用，即刻节省您的话费，并且这一切都是免费的！">
    <meta name="applicable-device" content="pc,mobile">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-transform"/>
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0">

    <!-- Stylesheets -->
    <!-- Bootstrap is included in its original form, unaltered -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Related styles of various icon packs and plugins -->
    <link rel="stylesheet" href="css/plugins.css">

    <!-- The main stylesheet of this template. All Bootstrap overwrites are defined in here -->
    <link rel="stylesheet" href="css/main.css">

    <!-- Include a specific file here from css/themes/ folder to alter the default theme of the template -->

    <!-- The themes stylesheet of this template (for using specific theme color in individual elements - must included last) -->
    <link rel="stylesheet" href="css/themes.css">

    <!-- Modernizr (browser feature detection library) -->
    <script src="http://7xonv5.com1.z0.glb.clouddn.com/vendor/modernizr-2.8.3.min.js"></script>
    
    </head>
<body>
<!-- Page Wrapper -->
<div id="page-wrapper" class="page-loading-off">
    <!-- Preloader -->
    <div class="preloader">
        <div class="inner">
            <!-- Animation spinner for all modern browsers -->
            <div class="preloader-spinner themed-background hidden-lt-ie10"></div>

            <!-- Text for IE9 -->
            <h3 class="text-primary visible-lt-ie10"><strong>Loading..</strong></h3>
        </div>
    </div>
    <!-- END Preloader -->

    <!-- Page Container -->
    <div id="page-container" class="sidebar-visible-lg-full">


        <!-- Main Container -->
        <div id="main-container" style="margin-left: 0;">
            <!-- Page content -->
            
<div id="page-content">
    <!-- Content -->
    <div class="row">
        <div class="col-md-10 col-md-offset-1 col-lg-8 col-lg-offset-2">
            <div class="widget">
                <div class="widget-image widget-image-xs">
                   <img src="./picture/xxs.png">
                    <div class="widget-image-content">
                        <h2 class="widget-heading text-light"><strong>帮助中心</strong></h2>
                        <h3 class="widget-heading text-light-op h4">常见的问题都可以在这里得到解答</h3>
                    </div>
                </div>
                <div class="widget-content widget-content-full">
                    <table class="table table-striped table-borderless remove-margin">
                        <tbody>
<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
$row = $DB->get_row("SELECT * FROM kyun"); 	
?>                                       
                                                    <tr>
                            <td class="text-center"><a href="javascript:void(0)" onclick="alert('你可以通过购买测试卡测试成功免流后，建议进行付费购买流量享受更好的网速！')" class="text-black">#
                                <?php echo $row[logo];?>是否可免费试用？</a></td>
                        </tr>
                        <tr>
                            <td class="text-center"><a href="./pd.html" target="_blank" class="text-black text-danger"># 免流测试步骤，初次使用必看！</a></td>
                        </tr>
                        <tr>
                            <td class="text-center"><a href="./az.html" target="_blank" class="text-black"># 安卓手机使用教程</a></td>
                        </tr>
                        <tr>
                            <td class="text-center"><a href="./ios.html" target="_blank" class="text-black"># iOS 苹果使用教程</a></td>
                        </tr>
						<tr>
                            <td class="text-center"><a href="javascript:void(0)" onclick="alert('如果线路上写了需要Wap的必须使用Wap接入点后再进行连接免流，没写的请优先使用Net接入点，否则可能会导致免流失败（如果Net不免可以尝试换为Wap后再试）！')" class="text-black">#
                                应该如何选择APN接入点，Wap还是Net？</a></td>
                        </tr>
                        <tr>
                            <td class="text-center"><a href="/apn.html" target="_blank" class="text-black"># Wap接入点修改教程</a></td>
                        </tr>
                        <tr>
                            <td class="text-center"><a href="javascript:void(0)" onclick="alert('请检查输入的账号密码是否正确，以及流量是否已经耗尽，登录官网可查询信息')" class="text-black"># 苹果APP连接服务器提示“Authentication failed”？</a></td>
                        </tr>
						<tr>
                            <td class="text-center"><a href="javascript:void(0)" onclick="alert('请开启手机的飞行模式静待几秒后再关闭，之后重新连接服务器即可，若依旧提示请使用Wap接入点。')" class="text-black"># 连接服务器提示代理On错误？</a></td>
                        </tr>
						<tr>
                            <td class="text-center"><a href="javascript:void(0)" onclick="alert('请使用3G/4G网络连接服务器，关闭WIFI，重新安装一次线路后重试！')" class="text-black"># 连接服务器提示节点超时/维护？</a></td>
                        </tr>
						<tr>
                            <td class="text-center"><a href="javascript:void(0)" onclick="alert('请查看自己是否还有剩余流量，若有剩余流量请重新安装一次线路后重试！')" class="text-black"># 连接服务器提示流量耗尽？</a></td>
                        </tr>
						<tr>
                            <td class="text-center"><a href="javascript:void(0)" onclick="alert('请重启手机一次即可，若重启无法解决则说明手机不支持。')" class="text-black"># 提示“创建Tun接口发生问题”</a></td>
                        </tr>
                        <tr>
                            <td class="text-center"><a href="javascript:void(0)" onclick="alert('若所有的地区线路和全国线路经过你测试后都无法免流，请耐心等待新的线路更新！不是所有地区都可以免流成功！')" class="text-black">#
                                为什么会扣自身手机流量？无法免流？</a></td>
                        </tr>
                        <tr>
                            <td class="text-center"><strong>提醒：请勿多人同时共用同一账号，会出现顶号掉线！</strong></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
               
            </div>
    <!-- End Content -->
</div>

            <!-- END Page Content -->
        </div>
        <div class="text-center push-bit-top-bottom">
            <small class="help-block">© 2017 <?php echo $row[logo];?></small>
        </div>
        <!-- END Main Container -->
    </div>
    <!-- END Page Container -->
</div>
<!-- END Page Wrapper -->

<!-- jQuery, Bootstrap, jQuery plugins and Custom JS code -->
<script src="http://7xonv5.com1.z0.glb.clouddn.com/vendor/jquery-2.2.0.min.js"></script>
<script src="http://7xonv5.com1.z0.glb.clouddn.com/vendor/bootstrap.min.js"></script>
<script src="js/plugins.js"></script>
<script src="js/app.js"></script>
<!-- sweetalert -->
<!-- <script src="js/sweetalert.min.js"></script> -->
<!-- <link rel="stylesheet" href="css/sweetalert.css"/> -->
<link rel="stylesheet" href="css/sweetalert_1.css"/>
<script src="js/sweetalert.min_1.js"></script>


</body>
</html>