<?php
/*
*/
	//系统配置文件
	$cfg['host'] = null;
	$cfg['host']['hostname'] = 'ip'; //数据库地址
	$cfg['host']['username'] = 'root'; //数据库用户名
	$cfg['host']['password'] = '数据库密码'; //数据库密码
	$cfg['host']['database'] = 'ov'; 
	$cfg['host']['charset'] = 'utf8';
	$cfg['host']['ddcms'] = '';
	$cfg['host']['port'] = '3306'; //数据库端口 
	
	//请配置用户信息表 通常情况默认即可
	$cfg['host']['user_data'] = 'openvpn';

	//请配置后台登陆用户名
	$cfg['admin']['username'] = 'admin';
	
	//请配置后台登陆密码
	$cfg['admin']['password'] = 'admin';
	
	
	//请配置用户注册地址
	$cfg['cfg']['reg'] = 'http://ip:端口/user/reg.php';
	
	
	
	
	//请配置个人中心地址 通常 您只需要将IP和端口替换为自己的 而不需要改动其他参数
	//自动在地址中附加了用户名和密码
	$cfg['cfg']['userCenter'] = 'http://ip:端口/user/index.php?user='.$_GET['username'].'&pass='.$_GET['password'];
	
	
	
	$cfg['app_key']['tk'] = "随便写够32位就行";//32位key
	
	
	
	//详细配置参数

	$_SERVER['ddcms']['cfg'] = $cfg;