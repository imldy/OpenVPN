<?php

/**
 *
 * @author 瑾年<1789665003@qq.com>
 * @copyright Li YuJiang, All Rights Reserved
 * @version 2015/7/26
 * Created by IntelliJ IDEA
 */
abstract class LoginedController extends BackendController
{

    public function __construct()
    {
        parent::__construct();
        $token = isset($_REQUEST['token']) ? $_REQUEST['token'] : '';
        if (empty($token)) {
            //$this->goToLogin();
            return;
        }
        $tokenController = new TokenController();
        if ($tokenController->check($token)) {
            $this->template->assign('token', $_REQUEST['token']);
        } else {
                     $this->template->assign('token', $_REQUEST['token']);
            //$this->goToLogin();
        }
    }

    protected function goToLogin()
    {
        Flight::getInstance()->redirect('./admin.php?c=Unlogin');
    }
}