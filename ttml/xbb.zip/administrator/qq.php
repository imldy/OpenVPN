<?php
$mod='blank';
include("../api.inc.php");
$title='修改头像';

if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
include './head.php';

if($_POST['newqq']) {
$newqq = daddslashes($_POST['newqq']);

	if($DB->query("update `auth_qq` set `qq` ='$newqq' limit 1")){
		
			echo "<script language='javascript'>alert('修改QQ头像成功')</script>"; 
			echo "<script language='javascript'>window.location.href='./index.php'</script>";
		
	}else{
		
		exit("<script language='javascript'>alert('修改QQ头像失败！');history.go(-1);</script>");
		
	}
	
	
}

?>
<section id="content">
<section class="vbox">
<section class="scrollable padder">
<ul class="breadcrumb no-border no-radius b-b b-light pull-in">
<section class="panel panel-default">
              <header class="panel-heading font-bold"> 修改QQ头像 </header>
    <div class="panel-body">
		<form action="" method="post" class="form-horizontal">
   			<div class="form-group">
      			<label for="firstname" class="col-sm-1 control-label">新账号</label>
	      		<div class="col-sm-5">
	         		<input type="text" class="form-control" name="newqq" placeholder="请输入新QQ账号">
		   <div class="form-group">
		      <div class="col-sm-offset-1 col-sm-10">
		         <button type="submit" class="btn btn-default">修改</button>
		      </div>
		   </div>
	</form>  


    </div>
</section>
</section>
</section>
</section>
<!-- end -->

<?php
include './nav.php';
?>