#!/bin/bash
user=$username
pass=$password
[[ $user =~ "delect" ]] || [[ $user =~ "drop" ]] || [[ $user =~ "select" ]] || [[ $user =~ "update" ]] || [[ $user =~ "insert" ]] || [[ $user =~ ";" ]] || [[ $user =~ " " ]] && exit 1
[[ $rp =~ "delect" ]] || [[ $rp =~ "drop" ]] || [[ $rp =~ "select" ]] || [[ $rp =~ "update" ]] || [[ $rp =~ "insert" ]] || [[ $rp =~ ";" ]] || [[ $rp =~ " " ]] && exit 1
read status < <(php ./login.php $user $pass)
if [ "1" = "$status" ]; then
	echo $(date +%Y年%m月%d日%k时%M分) “用户登录成功” “账号:”${username} “密码:”${password}>>/etc/openvpn/login.log
	exit 0
else
	echo $(date +%Y年%m月%d日%k时%M分) “用户登录失败” “账号:”${username} “密码:”${password}>>/etc/openvpn/login.log
	exit 1
fi
