<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：管理员登陆信息验证
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../Data/system.php");

if(isset($_POST['user']) || isset($_POST['pass']) || isset($_POST['twopass'])){
	$username = daddslashes($_POST['user']);
	$passwrod = daddslashes($_POST['pass']);
	$tpass = daddslashes($_POST['twopass']);
	// 双MD5加密
	$userA = md5($username);
	$user = md5($userA);
	$passA = md5($passwrod);
	$pass = md5($passA);
	$admin = db('ky_gl')->where(array("username"=>'u'.$user,"password"=>'p'.$pass))->find();
	if($admin){
	  $twopass = file_get_contents("/kyun/configure/admin_twopass.key");
	  if($tpass == $twopass){
		  $token = md5('u'.$user.'p'.$pass.'@*/.,#$&~');
		  setcookie("login",$token,time() + 86400 * 3);
		  $ip = get_ip();
		  db('ky_gl')->where(array("id"=>'1'))->update(array('client_ip'=>$ip,'login_time'=>time()));
		  exit("<script>alert('登陆管理中心成功！');window.location.href='./data/index.php';</script>");
	  }else{
		  exit("<script>alert('二级密码不正确！');history.go(-1);</script>");
	  }
	}else{
		exit("<script>alert('账号或密码不正确！');history.go(-1);</script>");
	}
}elseif($_GET['logout']){
	setcookie("login", "", time() - 86400 * 3);
	exit("<script>alert('您已成功注销本次登陆！');window.location.href='./Kyun/index.php';</script>");
}elseif($is_login == 'ok'){
	exit("<script>alert('您已经登陆了哦！');window.location.href='./data/index.php';</script>");
}else{
    exit("<script>window.location.href='./Kyun/index.php';</script>");
}
?>