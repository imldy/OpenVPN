<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：加盟商数据整体概况
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

$dlid = $_SESSION['dlid'];
if($dlid<>""){
$db =db("openvpn");
$db2 =db("top");
$db3 =db("ky_km");
$db4 =db("ky_yd");
$km = $db3->where(array('daili'=>$dlid))->getnums();
$user = $db->where(array('dlid'=>$dlid))->getnums();
$dl_km = $db3->where(array('daili'=>$dlid,'isuse'=>'0'))->getnums();
$online_user = $db->where(array('dlid'=>$dlid,'online'=>'1'))->getnums();
$row = db("ky_dl")->where(array('id'=>$dlid))->find();
$gg = db('ky_gg')->where(array('dlid'=>'0'))->order('id DESC')->find();
$is_read = $db4->where(array('readid'=>$gg['id'],"username"=>$row['user']))->find();
if(!$is_read){
  $db4->insert(array('username'=>$row['user'],'readid'=>$gg['id']));
}
$nums = $db4->where(array('readid'=>$gg['id']))->getnums();
$allKB2 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-10 day")),'dlid'=>$dlid))->getallnums("data")/1024/1024/1024), 2);
$allKB3 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-9 day")),'dlid'=>$dlid))->getallnums("data")/1024/1024/1024), 2);
$allKB4 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-8 day")),'dlid'=>$dlid))->getallnums("data")/1024/1024/1024), 2);
$allKB5 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-7 day")),'dlid'=>$dlid))->getallnums("data")/1024/1024/1024), 2);
$allKB6 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-6 day")),'dlid'=>$dlid))->getallnums("data")/1024/1024/1024), 2);
$allKB7 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-5 day")),'dlid'=>$dlid))->getallnums("data")/1024/1024/1024), 2);
$allKB8 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-4 day")),'dlid'=>$dlid))->getallnums("data")/1024/1024/1024), 2);
$allKB9 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-3 day")),'dlid'=>$dlid))->getallnums("data")/1024/1024/1024), 2);
$allKB10 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-2 day")),'dlid'=>$dlid))->getallnums("data")/1024/1024/1024), 2);
$allKB11 = round(($db2->where(array("time"=>date("Y-m-d",strtotime("-1 day")),'dlid'=>$dlid))->getallnums("data")/1024/1024/1024), 2);
$allKB12 = round(($db2->where(array("time"=>date("Y-m-d"),'dlid'=>$dlid))->getallnums("data")/1024/1024/1024), 2);
?>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="renderer" content="webkit">

    <title>加盟商后台 - 整体概览</title>

    <meta name="keywords" content="快云免流，快云流控，快云流量，NB免流，NB流控">
    <meta name="description" content="快云免流，快云流控，快云流量，NB免流，NB流控">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
</head>	
<body class="gray-bg">
    <div class="wrapper wrapper-content">
        <div class="row">
		<div class="col-sm-12">
			<div class="ibox-mulu">
          <h3> &nbsp;&nbsp; <i class="fa fa-dashboard fa-lg"></i> 平台首页 > 整体概览</h3>
              </div>
			  <br>
			  <div class="row">
			    <div class="col-sm-3">
					<div>
                       <div class="ibox-content text-center">
                               <div class="m-b-sm">
                                    <img alt="image" class="img-circle" src="../../assets/img/a<?php echo rand(1,9);?>.jpg">
                                </div>
                                <p class="font-bold">用户名：<?php echo $row['user'];?></p>

                                <div class="text-center">
                                    <a class="btn btn-xs btn-primary">折扣：<?php echo $row['rebate'];?> %</a>
                                    <a class="btn btn-xs btn-info">余额: <?php echo $row['money'];?> 元</a>
                                </div>
                            </div>
							 </div>
							<br>
						</div>
                  <div class="col-sm-2"> 
                        <div class="row row-sm text-center">
                            <div class="col-xs-12">
                                <div class="panel padder-v item bg-info">
                                    <div class="h1 text-fff font-thin h1"><?php echo $user;?></div>
                                    <span class="text-muted text-xs">账号数量</span>
                                    <div class="top text-right w-full">
                                        <i class="fa fa-caret-down text-warning m-r-sm"></i>
                                    </div>
                                </div>
                            </div>
							<br>
                            <div class="col-xs-12">
                                <div class="panel padder-v item bg-primary">
                                    <div class="h1 text-fff font-thin h1"><?php echo $online_user;?></div>
                                    <span class="text-muted text-xs">总在线人数</span>
                                    <div class="top text-right w-full">
                                        <i class="fa fa-caret-down text-warning m-r-sm"></i>
                                    </div>
                                </div>
						      </div>
						</div>
                     </div>
                    <div class="col-sm-7">
                        <div class="ibox">
                            <div class="ibox-content">
							<h3>流量使用折线图(单位/G)</h3>
                                <div id="line" style="height:217px;">加载中,请骚等...</div>
                            </div>
                        </div>
                    </div>
                </div>	 
			<div class="row">
              <div class="col-sm-5">
                <div class="ibox">
					   <div class="ibox-content">
					     <h4>平台卡密使用信息</h4>
						    <br>
                                <div class="progress progress-striped active">
                                    <div style="width: 100%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="75" role="progressbar" class="progress-bar progress-bar-success"><h5>未使用卡密 <?php echo $dl_km;?> 张</h5>
                                        <span class="sr-only"></span>
                                    </div>
                                </div>
                                <div class="progress progress-striped active">
                                    <div style="width: 100%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="75" role="progressbar" class="progress-bar"><h5>平台总卡密 <?php echo $km;?> 张</h5>
                                        <span class="sr-only"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                     </div>
				 <div class="col-sm-7">
				    <div class="ibox float-e-margins">

                            <div id="vertical-timeline" class="vertical-container light-timeline">
                                    <div class="vertical-timeline-icon navy-bg">
                                        <i class="fa fa-volume-up"></i>
                                    </div>

                                       <div class="vertical-timeline-content">
                                        <h2><?php echo $gg['name'];?></h2>
                                        <p><?php echo $gg['content'];?></p>
                                        <small class="btn btn-sm">已有 <?=$nums?>人阅读</small>
                                        <span class="vertical-date">
                                     <small>发布于 <?=date("Y年m月d日",$gg['time']);?></small>
                                </span>
                            </div>
                         </div>
                    </div>
                </div>
            </div>
	    </div>
    </div>
   </div>
    <script src="../../assets/js/jquery.min.js"></script>
    <!-- Flot -->
    <script src="../../assets/js/plugins/flot/jquery.flot.js"></script>
    <script src="../../assets/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="../../assets/js/plugins/flot/jquery.flot.resize.js"></script>
 </body>
<script>
// 流量折线图
$(function() {
             series = [{
                data: [
				   [1, <?php echo $allKB2;?>],
				   [2, <?php echo $allKB3;?>],
				   [3, <?php echo $allKB4;?>],
				   [4, <?php echo $allKB5;?>],
				   [5, <?php echo $allKB6;?>],
				   [6, <?php echo $allKB7;?>],
				   [7, <?php echo $allKB8;?>],
				   [8, <?php echo $allKB9;?>],
				   [9, <?php echo $allKB10;?>],
				   [10, <?php echo $allKB11;?>],
				   [11, <?php echo $allKB12;?>],
				   [12, 0]
				],
                lines: {
                    show: true,
					fill: true,
					fillColor:"#D2E9FF"
                },
				legend:{
						show:true,	
						position:"ne"
				}, 
				points: { 
				    show: true 
				}
            }];

            var plot = $.plot($("#line"),series, {
                grid: {
                    color: "#999999",
					tickColor: "#f7f9fb",
                    borderWidth:0,
                    minBorderMargin: 20,
                    labelMargin: 10,
					hoverable: true,
                    backgroundColor: {
                        colors: ["#fff", "#fff"]
                    }
                },
				tooltip : {
                },
                colors: ["#4fc5ea"],
                xaxis: {
					ticks: [
					    [1, "<?php echo date("d",strtotime("-11 day")).'日';?>"],
						[2, "<?php echo date("d",strtotime("-10 day")).'日';?>"], 
						[3, "<?php echo date("d",strtotime("-9 day")).'日';?>"], 
						[4, "<?php echo date("d",strtotime("-8 day")).'日';?>"], 
						[5, "<?php echo date("d",strtotime("-7 day")).'日';?>"],
						[6, "<?php echo date("d",strtotime("-6 day")).'日';?>"],
						[7, "<?php echo date("d",strtotime("-5 day")).'日';?>"],
						[8, "<?php echo date("d",strtotime("-4 day")).'日';?>"],
						[9, "<?php echo date("d",strtotime("-3 day")).'日';?>"],
						[10, "<?php echo date("d",strtotime("-2 day")).'日';?>"],
						[11, "<?php echo date("d",strtotime("-1 day")).'日';?>"],
						[12, "<?php echo date("d").'日';?>"]
					]
				},
                yaxis: { 
					ticks: 5,
					min: 0
				}
            });
        });
</script>		
</html>
<?php
}else{
   exit("<script>window.location.href='../index.php';</script>");	
} 
?>