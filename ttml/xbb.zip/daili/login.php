<?php
/**
 * 登录
**/
$mod='blank';
include("../api.inc.php");
if(isset($_POST['user']) && isset($_POST['pass'])){
	$user=daddslashes($_POST['user']);
	$pass=daddslashes($_POST['pass']);
	$row = $DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
	$dlid=$row['id'];
	if($row['active']=="1" && $dlid<>""){
		
	}else{exit("<script language='javascript'>alert('用户不存在或未激活，如已经注册请联系管理员付费激活！');history.go(-1);</script>");}
	
	if($user==$row['user'] && $pass==$row['pass']) {
		$session=md5($user.$pass.$password_hash);
		$token=authcode("{$user}\t{$session}", 'ENCODE', SYS_KEY);
		//setcookie("ol_token", $token, time() + 604800);
		$row = $DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
		$dlid=$row['id'];
		$_SESSION['dlid']=$dlid;
		@header('Content-Type: text/html; charset=UTF-8');
		exit("<script language='javascript'>alert('登陆代理中心成功！');window.location.href='./';</script>");
	}elseif ($pass != $row['pass']) {
		@header('Content-Type: text/html; charset=UTF-8');
		exit("<script language='javascript'>alert('用户名或密码不正确！');history.go(-1);</script>");
	}
}elseif(isset($_GET['logout'])){
	setcookie("ol_token", "", time() - 604800);
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('您已成功注销本次登陆！');window.location.href='./login.php';</script>");
}elseif($islogin2==1){
	exit("<script language='javascript'>alert('您已登陆！');window.location.href='./';</script>");
}
$title='代理登录';
?>
<!DOCTYPE html>
<html>  
<head>
    <meta charset="utf-8"/>
	<title>代理登录 - <?php echo $yunname;?>代理中心 - 专业虚拟流量产品平台</title>
    <!--<link href="http://fonts.googleapis.com/css?family=Lato:100,300,400,700" media="all" rel="stylesheet" type="text/css" />-->
<script src="../themes/note/js/app.v1.js"></script>
<script src="../themes/note/js/charts/easypiechart/jquery.easy-pie-chart.js"></script>
<script src="../themes/note/js/charts/sparkline/jquery.sparkline.min.js"></script>
<script src="../themes/note/js/charts/flot/jquery.flot.min.js"></script>
<script src="../themes/note/js/charts/flot/jquery.flot.tooltip.min.js"></script>
<script src="../themes/note/js/charts/flot/jquery.flot.resize.js"></script>
<script src="../themes/note/js/charts/flot/jquery.flot.grow.js"></script>
<script src="../themes/note/js/charts/flot/demo.js"></script>
<script src="../themes/note/js/calendar/bootstrap_calendar.js"></script>
<script src="../themes/note/js/calendar/demo.js"></script>
<script src="../themes/note/js/sortable/jquery.sortable.js"></script>
<script src="../themes/note/js/app.plugin.js"></script>
<meta name="description" content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav"/>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
<link rel="stylesheet" href="../themes/note/css/font.css" type="text/css"/>
<link rel="stylesheet" href="../themes/note/js/calendar/bootstrap_calendar.css" type="text/css"/>
<link rel="stylesheet" href="../themes/note/css/app.v1.css" type="text/css"/>
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport">
</head>




<form action="./login.php" method="post" class="form-horizontal" role="form">
<div class="modal in" id="ajaxModal" aria-hidden="false" style="display: block;">
	<div class="modal-over">
		<div class="modal-center animated fadeInUp text-center" style="width:200px;margin:-80px 0 0 -100px;">
			<div class="thumb-md">
				<img src="../themes/note/images/avatar.jpg" class="img-circle b-a b-light b-3x">
			</div>
			<p class="text-white h4 m-t m-b">
				Mr.Qiselu
			</p>
			<input type="username" class="form-control text-sm" name="user" placeholder="用户名"><br>
			<div class="input-group">
				<input type="password" class="form-control text-sm" name="pass" placeholder="密码">
				<span class="input-group-btn"><button class="btn btn-success" type="submit" data-dismiss="modal">
				<i class="fa fa-arrow-right"></i></button></span>
			</div>
<section class="vbox">
<section class="scrollable">
<div class="wrapper">
<div class="btn-group btn-group-justified m-b">
	<a href="./reg.php" class="btn btn-primary btn-rounded" data-toggle="button">
	<span class="text"><i class="fa fa-eye"></i> 注册 </span>
	<span class="text-active"></span></a>
	<a href="../user/login.php" class="btn btn-dark btn-rounded" data-loading-text="Connecting">
	<i class="fa fa-comment-o"></i> 用户 </a>
</div>
</div>
</section>
</section>
		</div>
	</div>
</div>

</form>
  