			<div class="page-title">
				
				<div class="title-env">
					<h1 class="title"><?php echo "欢迎您，".$res['iuser'];?>！</h1>
				</div>
				<?=($res['i']?'<div class="label label-secondary m-t-10">账号正常</div>':'<div class="label label-danger m-t-10">账号禁用</div>')?>

			            <div class="breadcrumb-env">
			            
			               <ol class="breadcrumb bc-1">
			                 <li>
			                  <a href="login.php"><i class="fa-sign-out"></i>退出</a>
			                </li>
			              </ol>
			                  
			             </div>

			</div>