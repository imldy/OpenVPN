<?php
echo '﻿';
include('head.php');
include('nav.php');
;echo '<script>
alert(\'请使用浩天免流一键脚本 ③ 制作APP！\');
</script>
';include('haosky.php');?>