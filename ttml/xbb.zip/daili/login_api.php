<?php
$mod='blank';
include("../api.inc.php");
$title='代理中心';
$dlid=$_SESSION['dlid'];
$row = $DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$rs=$DB->get_row("SELECT * FROM auth_config WHERE 1");
$vip=$row['vip'];
$rmb=$row['rmb'];
if($vip==1){
	$dljg=$rs['dl1'];
	$dljgs=$rs['dls1'];
	$v="铜牌代理";
}elseif($vip==2){
	$dljg=$rs['dl2'];
	$dljgs=$rs['dls2'];
	$v="银牌代理";
}elseif($vip==3){
	$dljg=$rs['dl3'];
	$dljgs=$rs['dls3'];
	$v="金牌代理";
}elseif($vip==0){
	$dljg=$rs['dl0'];
	$dljgs=$rs['dls0'];
	$v="普通代理";
	//exit("<script language='javascript'>window.location.href='./login.php';</script>");
}elseif($vip==4){
	$dljg=$rs['dl4'];
	$dljgs=$rs['dls4'];
		$v="钻石代理";
}elseif($vip==5){
	$dljg=$rs['dl5'];
	$dljgs=$rs['dls5'];
	$v="至尊代理";
}

if(isset($_GET['user']) && isset($_GET['pass'])){
	$user=daddslashes($_GET['user']);
	$pass=daddslashes($_GET['pass']);
	$row = $DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
	$dlid=$row['id'];
	if($row['active']=="1" && $dlid<>""){
		
	}else{exit("<script language='javascript'>alert('用户不存在或未激活，如已经注册请联系管理员付费激活！');history.go(-1);</script>");}
	
	if($user==$row['user'] && $pass==$row['pass']) {
		$session=md5($user.$pass.$password_hash);
		$token=authcode("{$user}\t{$session}", 'ENCODE', SYS_KEY);
		//setcookie("ol_token", $token, time() + 604800);
		$row = $DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
		$dlid=$row['id'];
		$_SESSION['dlid']=$dlid;
		@header('Content-Type: text/html; charset=UTF-8');
		
	}elseif ($pass != $row['pass']) {
		@header('Content-Type: text/html; charset=UTF-8');
		exit("<script language='javascript'>alert('用户名或密码不正确！');history.go(-1);</script>");
	}
}



//$v="<font color='red'>VIP$vip</font>";
$config = $DB->get_row("SELECT * FROM auth_config");
$gonggao=$config['gg'];//公告获取
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

if($_POST['pass'] && $_POST['newpass']){
	$pass = daddslashes($_POST['pass']);
	$newpass = daddslashes($_POST['newpass']);
	if($DB->query("update `auth_daili` set `pass` ='$newpass' where `id`='$dlid' and `pass`='$pass' limit 1")){
		exit("<script language='javascript'>alert('密码修改成功！');history.go(-1);</script>");
	}else{
		exit("<script language='javascript'>alert('密码修改失败！');history.go(-1);</script>");
	}
}





function getkm($len = 18)
{
	$str = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	$strlen = strlen($str);
	$randstr = "";
	for ($i = 0; $i < $len; $i++) {
		$randstr .= $str[mt_rand(0, $strlen - 1)];
	}
	return $randstr;
}

$my=isset($_GET['my'])?$_GET['my']:null;



if($my=='km'){
$kind=1;

$num='1';
$value=intval($_POST['value']);
$values=strval($_POST['values']);
if($num<=0){exit("<script language='javascript'>alert('生成失败，卡密数量必须大于0！');history.go(-1);</script>");}
if($value<=0){exit("<script language='javascript'>alert('生成失败，生成天数必须大于0！');history.go(-1);</script>");}
if($values<=0){exit("<script language='javascript'>alert('生成失败，流量必须大于0GB！');history.go(-1);</script>");}
$money = ($value*$dljg+$values*$dljgs)*$num;
$rmb=$row['rmb']-$money;
if($rmb>=0){
	
}else{
	exit("<script language='javascript'>alert('生成失败，余额不足，请联系管理员充值！');history.go(-1);</script>");
}
$sql=$DB->query("update `auth_daili` set `rmb`='$rmb' where `id`=$dlid;");
if($sql){
	
}else{
	exit("<script language='javascript'>alert('扣款失败，请联系管理员！');history.go(-1);</script>");
}

echo "您购买的卡密：";
echo "

";
for ($i = 0; $i < $num; $i++) {
	$km=getkm(18);
	$sql=$DB->query("insert into `auth_kms` (`kind`,`daili`,`km`,`value`,`values`,`money`,`addtime`) values ('".$kind."','".$dlid."','".$km."','".$value."','".$values."','".$money."','".$date."')");
	if($sql) {
		echo "$km";
	}
}


}

if($my=='banben'){
echo "1.0";
}


if($my=='dailiapp'){
echo "http://112.74.177.149:8888/app/daili.apk";
}


if($my=='kmgl'){
include './head.php';
echo "
      <div class='table-responsive'>
        <table class='table table-striped'>
          <thead>
		  <tr>
		  <th>序号</th>
		  <th>卡密</th>
		  <th>信息</th>
		  <th>状态</th>
		  <th>添加时间</th>
		  <th>使用时间</th>
		  <th>操作</th>
		  </tr></thead>
          <tbody>
";

$pagesize=30;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
$rs=$DB->query("SELECT * FROM auth_kms WHERE daili=$dlid order by id desc limit $offset,$pagesize");
//$rs=$DB->query("SELECT * FROM auth_kms WHERE{$sql} order by id desc limit $offset,$pagesize");
while($res = $DB->fetch($rs))
{
if($res['isuse']==1) {
	$isuse='<font color="red">已使用</font><br/>使用者:'.$res['user'];
} elseif($res['isuse']==0) {
	$isuse='<font color="green">未使用</font>';
}
echo '
<tr><td><b>'.$res['id'].'</b></td><td>

<b>'.$res['km'].'</b></td>

<td>'.$res['value'].'天/'.$res['values'].'GB/￥'.$res['money'].'</td>

<td>'.$isuse.'</td><td>'.$res['addtime'].'</td>


<td>'.$res['usetime'].'</td>

<td><a href="./kmlist.php?my=del&id='.$res['id'].'" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要删除此卡密吗？\');">删除</a></td></tr>';
}
}







if($my=='zhgl'){
include './head.php';
echo "

      <div class='table-responsive'>
        <table class='table table-striped'>
          <thead>
		  <tr>
		  <th>序号</th>
		  <th>账号</th>
		  <th>密码</th>
		  <th>状态</th>
		  <th>添加时间</th>
		  <th>到期时间</th>
		  <th>剩余流量</th>
		  <th>总共流量</th>
		  <th>操作</th>
		  </tr></thead>
          <tbody>

";
$pagesize=30;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
$rs=$DB->query("SELECT * FROM openvpn WHERE notes=$dlid ");
while($res = $DB->fetch($rs))
{

echo '
<tr><td><b>'.$res['id'].'</b></td>

<td><b>'.$res['iuser'].'</b>
<td>'.$res['pass'].'</td>
<td>'.($res['i']?'开通':'禁用').'</td>
<td>'.date("Y-m-d",$res['starttime']).'</td>
<td>'.date("Y-m-d",$res['endtime']).'</td>
<td>'.round(($res['maxll']-$res['isent']-$res['irecv'])/1024/1024).'M</td>
<td>'.round(($res['maxll'])/1024/1024).'M</td>
<td><a href="./login_api.php?my=zhgl&id='.$res['id'].'" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要删除此账号吗？\');">删除</a></td></tr>

';
}
}




if($my=='add'){
$kind=1;
$fwqid = '1';
$notes = '客户端生成';
$num='1';
$value=strval($_POST['value']);
$values=strval($_POST['values']);
if($num<=0){exit("<script language='javascript'>alert('生成失败，卡密数量必须大于0！');history.go(-1);</script>");}
if($value<=0){exit("<script language='javascript'>alert('生成失败，生成天数必须大于0！');history.go(-1);</script>");}
if($values<=0){exit("<script language='javascript'>alert('生成失败，流量必须大于0GB！');history.go(-1);</script>");}
$money = ($value*$dljg+$values*$dljgs)*$num;
$rmb=$row['rmb']-$money;
if($rmb>=0){
}else{
	exit("<script language='javascript'>alert('生成失败，余额不足，请联系管理员充值！');history.go(-1);</script>");
}
$sql=$DB->query("update `auth_daili` set `rmb`='$rmb' where `id`=$dlid;");
if($sql){
	
}else{
	exit("<script language='javascript'>alert('扣款失败，请联系管理员！');history.go(-1);</script>");
}
echo "您购买的帐号：";
echo "

";
for ($i = 0; $i < $num; $i++) {
$Code= rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9);
$User= rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9);
$state = '1';
$endtime = strtotime(date("Y-m-d", strtotime("+$value day")));
$maxll = daddslashes($_POST['values'])*1024*1024*1024;
$fwqid = '0';
$notes = $dlid;
$id=strtoupper(substr(md5($uin.time()),0,8).'-'.uniqid());
$sql=$DB->query("insert into `openvpn` (`iuser`,`pass`,`isent`,`irecv`,`maxll`,`i`,`starttime`,`endtime`,`fwqid`,`notes`) values ('{$User}','{$Code}',0,0,'{$maxll}','{$state}','".time()."','{$endtime}','{$fwqid}','{$notes}')");
	if($sql) {
		echo "帐号：$User";
		echo "

";
		echo "密码：$Code";
	}
}
}



if($my=='dlpz'){

echo "代理ID：".$_SESSION['dlid'];
echo "

";

echo "账户余额:".$rmb."元";
echo "

";
echo "代理VIP等级:".$v;
echo "

";
echo "代理拿货价格：".$dljg."元/天 + ".$dljgs."元/GB";
echo "

";
echo "公告:".$gonggao;

}


?>
