<?php
/**
 * 快云免流管理中心
 * by 飞跃 2017年5月6日
 */
include("../../Data/api.inc.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='../Kyun/index.php';</script>");

if( $_GET['act'] == 'net'){
$net =file_get_contents("/Data/Network");
  if($net < 1024){
	 echo $net." Bytes/s";
}elseif($net > 1048576){
  if(is_int($net)){
	echo $net/1024/1024," Mbps/s";
}else{
	echo sprintf("%.2f", $net/1024/1024)," Mbps/s";
}}else{
  if(is_int($net)){
	echo $net/1024/1024," Kbps/s";
}else{	  
	echo sprintf("%.2f", $net/1024)," Kbps/s"; 
}} } 

elseif( $_GET['act'] == 'down'){
$result=$DB->get_row("SELECT * FROM `line` where `id`='{$_GET['id']}'");
if(!$result) {
exit("<script language='javascript'>alert('亲，平台找不到此线路！');window.location.href='./index.php';</script>");}
$zs=$DB->get_row("SELECT * FROM `ky_zs`");
$fwq=$DB->get_row("SELECT * FROM `ky_fz` where `default`='1'");
$fileName = $result['name'].'.ovpn';
$name = iconv('UTF-8','GBK',$fileName);
$content = $result['content'];
$content = preg_replace("/\[ip\]/is",$fwq["ipport"],$content);
$content = preg_replace("/\[C证书\]/is",$zs["ca"],$content);
$content = preg_replace("/\[T证书\]/is",$zs["tls"],$content);
header("Content-Disposition: attachment; filename=\"" . $name . "\"");
//转义数据库特殊符号
echo htmlspecialchars_decode($content,ENT_QUOTES);   
}elseif( $_GET['act'] == 'xsu'){
$u = $_POST['user'];
$zhi = $_POST['zhi'];
$xsu = exec("Kps xsu {$u} {$zhi}");
if($xsu == 'ok'){
   die(json_encode(array('status'=>'success')));
 }else{
  die(json_encode(array('status'=>'erorr','msg'=>'操作失败，请骚后再试！')));
 }
}elseif( $_GET['act'] == 'outline'){
$u = $_GET['user'];
$dk = $_GET['opdk'];
$sha = exec("/bin/sha {$u} {$dk}");
if($sha){
   die(json_encode(array('status'=>'success')));
 }else{
  die(json_encode(array('status'=>'erorr','msg'=>'操作失败，请骚后再试！')));
 }
}elseif( $_GET['act'] == 'setweb'){
$webdk = $_GET['webdk'];
$web = exec("Kps setweb {$webdk}");
if($web == 'ok'){ 
   die(json_encode(array('status'=>'success')));
}else{
  die(json_encode(array('status'=>'erorr','msg'=>'操作失败，请骚后再试！')));
 }
}elseif( $_GET['act'] == 'setxsu'){
$limit = $_GET["limit"];
$content = "default {$limit}
total 1000";
$setxsu = file_put_contents("/etc/Kyun/bwlimitplugin.cnf",$content); 
if($setxsu){  
   die(json_encode(array('status'=>'success')));
}else{
  die(json_encode(array('status'=>'erorr','msg'=>'操作失败，请骚后再试！')));
 }
}elseif( $_GET['act'] == 'adddk' ){
$dk = $_GET['nesdk'];
$NesPort = exec("Kps adddk {$dk}");
if($NesPort == 'ok'){ 
   die(json_encode(array('status'=>'success')));
}else{
  die(json_encode(array('status'=>'erorr','msg'=>'操作失败，请骚后再试！')));
 }
}elseif( $_GET['act'] == 'mysql' ){
$mysql = exec('Kps mysql');
if($mysql == 'ok'){ 
   die(json_encode(array('status'=>'success')));
}else{
  die(json_encode(array('status'=>'erorr','msg'=>'操作失败，请骚后再试！')));
 }
}elseif( $_GET['act'] == 'httpd' ){
$httpd = exec('Kps httpd');
if($httpd == 'ok'){ 
   die(json_encode(array('status'=>'success')));
}else{
  die(json_encode(array('status'=>'erorr','msg'=>'操作失败，请骚后再试！')));
 }	
}elseif( $_GET['act'] == 'vpn' ){
$vpn = system('vpn');
if($vpn){ 
   die(json_encode(array('status'=>'success')));
}else{
  die(json_encode(array('status'=>'erorr','msg'=>'操作失败，请骚后再试！')));
 }	
}elseif( $_GET['act'] == 'fhq' ){
$fhq = exec('Kps fhq');
if($fhq == 'ok'){ 
   die(json_encode(array('status'=>'success')));
}else{
  die(json_encode(array('status'=>'erorr','msg'=>'操作失败，请骚后再试！')));
 }	
}
                  ?>