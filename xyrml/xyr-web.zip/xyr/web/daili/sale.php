<?php
/**
 * 我的推广
**/
$mod='blank';
include("../api.inc.php");
$title='我的推广';
$dlid=$_SESSION['dlid'];
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

$rs=$DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$user=$rs['user'];
$adtext=$rs['adtext'];
$adimg=$rs['adimg'];

?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head2.php';?>
<body class="page-body">
    
    <?php include 'nav.php';?>

    <div class="page-container"><!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->
            
        <div class="main-content">
                    
            
            <h3 id="layout-toggles">
                代理中心
                <br />
            </h3>
            
            <br />

            <div class="row">
                
                <div class="col-sm-12">
                    
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            下面是您的推广信息
                        </div>
                        
                        <div class="panel-body">
                            
<?php
if($my=='black3'){

    $adtext_c=$_GET['adtext'];
    $adimg_c=$_GET['adimg'];
    //echo "<script language='javascript'>alert('推荐人：".$dlid."');</script>";
    if(/*$mima<>$rs['pass'] && */$adtext_c<>""){
    $sql=$DB->query("update `auth_daili` set `adimg`='$adimg_c', `adtext`='$adtext_c' where `id`='{$dlid}'");
    if($sql){echo '<div class="alert alert-success">
                                        <button type="button" class="close">
                                          <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                                <span class="sr-only">Close</span>
                                            </button>
                                            设置成功！
                                        </div>';
                //echo "<script language='javascript'>alert('".$qq_c."');</script>";
                echo "<style>#sale{display: none;}</style>";
                                      }
    else{echo '<div class="alert alert-danger">
                                            设置失败！
                                        </div>';}
    }else{
     echo "<div class='alert alert-warning'>
                                            <strong>为".$user."更改内容失败！</strong></div>";
                                        
    }

}
?>

                            <div id="sale" class="row">
                                <div class="col-sm-6">
                                    <form action="./sale.php?" method="get" class="form-horizontal validate" role="form">
                                                <input type="text" name="user" value='.$user.' hidden />
                                                <input type="text" name="my" value="black3" hidden/>
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label" for="field-1">广告词</label>
                                          <div class="col-sm-10">
                                            <input type="text" class="form-control"id="field-1" value="<?php echo $adtext; ?>" name="adtext" data-validate="required"/>
                                          </div>
                                        </div>
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label" for="field-2">广告图</label>
                                          <div class="col-sm-10">
                                            <div class="input-group">
                                              <span class="input-group-addon">宽高自定义(单位：像素)</span>
                                               <input type="text" class="form-control"id="field-2" value="<?php echo $adimg; ?>" name="adimg" data-validate="required"/>
                                              <span class="input-group-addon"><a target="_blank" href="<?php echo $adimg;?>"><i class="linecons-search"></i></a></span>
                                            </div>
                                            <p class="text-success">请注意广告的左下角是二维码区域，设计的时候请留空位哦！如果没有设计请填写“/other/ad.jpg”</p>
                                          </div>
                                        </div>
                                        <div class="form-group">
                                          <label class="col-sm-2 control-label"></label>
                                          <div class="col-sm-10">
                                            <input type="submit" value="修改" class="btn btn-info btn-single"/>
                                          </div>
                                        </div>
                                    </form>
                                    <br>
                                    <div class="form-group-separator"></div>
                                    <br>
                                    <div class="alert alert-default">
                                    <button type="button" class="close" data-dismiss="alert">
                                      <span aria-hidden="true">×</span>
                                      <span class="sr-only">Close</span>
                                    </button>
                                    <strong>温馨提示：</strong><br>
                                    1，生成二维码可以截图下来，自制广告用！<br>
                                    2，点击广告链接，可以分享给朋友，进行推广！<br>
                                    3，图片是通过第三方平台上传后，复制文件地址粘贴至文本框即可
                                    <br><br>
                                    <span class="input-group-btn" style="display: inline-table;">
                                      <button type="button" class="btn btn-purple dropdown-toggle" data-toggle="dropdown">
                                        图片上传平台 <span class="caret"></span>
                                      </button>
                                      <ul class="dropdown-menu dropdown-purple no-spacing">
                                        <li><a target="_blank" href="https://www.niupic.com/">牛图网</a></li>
                                        <li><a target="_blank" href="http://img.hoop8.com/index.php">Hoop8</a></li>
                                        <li><a target="_blank" href="http://chuantu.biz/">Chuantu.biz</a></li>
                                      </ul>
                                    </span>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <blockquote class="blockquote blockquote-info">
                                        <p>
                                            <strong>我的推广信息</strong>
                                        </p>
                                        <br>
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div id="qrcode"></div>
                                                <a target="_blank" href="/user/reg.php?dl=<?php echo $_SESSION['dlid'];?>" class="btn btn-blue btn-icon btn-icon-standalone">
                                                    <i class="fa-anchor"></i>
                                                    <span>您的会员注册链接</span>
                                                </a>
                                            </div>
                                            <div class="col-sm-6">
                                                <div id="qrcode2"></div>
                                                <a target="_blank" href="ad.php?dl=<?php echo $_SESSION['dlid'];?>" class="btn btn-red btn-icon btn-icon-standalone">
                                                    <i class="fa-magic"></i>
                                                    <span>您的广告推广链接</span>
                                                </a>
                                            </div>
                                        </div>
                                    </blockquote> 
                                    <blockquote class="blockquote blockquote-info">
                                        <p>
                                            <strong>我的推广站点</strong>
                                        </p>
                                        <br>
                                        <div class="row">
                                            <div class="col-sm-12">
                                              <?php
          
                                              $rs=$DB->query("SELECT * FROM `website` WHERE daili='$dlid' ");
                                              while($res = $DB->fetch($rs))
                                              {
                                              ?>
                                              <a class="btn btn-secondary btn-icon bg-lg" target="_blank" href="/web/index.php?name=<?=$res['name']?>" alt="点击浏览">
                                                    <i class="fa-link"></i>
                                                    <span><?=$res['title']?></span>
                                                </a>
                                              <?php }
                                              ?>
                                            </div>
                                        </div>
                                    </blockquote> 
                                </div>
                            </div>
                            
                        </div>
                        
                    </div>
                </div>

            </div>

             <?php include("../copy2.php");?>
             
        </div>
        
    </div>
    
    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>

    <script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>

    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>
<script type="text/javascript" src="/assets/js/jquery.qrcode.min.js"></script>
<script>
jQuery('#qrcode').qrcode({
        render      : "canvas",//也可以替换为table
        width   : 172,
        height  : 172,
        text      : "http://<?php echo $_SERVER['HTTP_HOST'];?>/user/reg.php?dl=<?php echo $_SESSION['dlid'];?>"
});
jQuery('#qrcode2').qrcode({
        render      : "canvas",//也可以替换为table
        width   : 172,
        height  : 172,
        text      : "http://<?php echo $_SERVER['HTTP_HOST'];?>/daili/ad.php?dl=<?php echo $_SESSION['dlid'];?>"
});
</script>
</body>
</html><?php 