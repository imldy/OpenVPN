<?php
/**
 * 管理中心
**/
$mod = 'blank';
include "../api.inc.php";
$title = '管理中心';
include './head.php';
if ($islogin2 == 1) {
} else {
	die("<script language='javascript'>window.location.href='./login.php';</script>");
}
include './nav.php';
?>
<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
    <div class="panel panel-primary">
    <div class="panel-heading"><h3 class="panel-title">管理中心首页</h3></div>
        <ul class="list-group">
            <li class="list-group-item"><span class="glyphicon glyphicon-stats"></span> <b>平台统计：</b>共有<font color=red><?php echo $DB->count("SELECT count(*) from `openvpn` WHERE 1"); ?></font>个账号，状态正常的有<font color=red><?php echo $DB->count("SELECT count(*) from `openvpn` WHERE i=1"); ?></font>个账号</li>
            <li class="list-group-item"><span class="glyphicon glyphicon-time"></span> <b>当前时间：</b> <?php echo $date; ?></li>
        </ul>
    </div>
	<div class="panel panel-info">
	    <?php 
            $url = "http://git.oschina.net/52fancy/OpenVPN/raw/master/Notcie"; 
            $contents = file_get_contents($url); 
            //如果出现中文乱码使用下面代码 
            //$getcontent = iconv("gb2312", "utf-8",$contents); 
            echo $contents; 
        ?>
	</div>
    <div class="panel panel-info">
	    <div class="panel-heading">
		    <h3 class="panel-title">服务器信息</h3>
	    </div>
	    <ul class="list-group">
		    <li class="list-group-item">
			    <b>PHP 版本：</b><?php echo phpversion(); ?><?php if (ini_get('safe_mode')) {echo '线程安全';} else {echo '非线程安全';} ?>
		    </li>
		    <li class="list-group-item">
			    <b>MySQL 版本：</b><?php echo $DB->count("select VERSION()"); ?>
		    </li>
		    <li class="list-group-item">
			    <b>服务器软件：</b><?php echo $_SERVER['SERVER_SOFTWARE']; ?>
		    </li>		
		    <li class="list-group-item">
			    <b>程序最大运行时间：</b><?php echo ini_get('max_execution_time'); ?>s
		    </li>
		    <li class="list-group-item">
			    <b>POST许可：</b><?php echo ini_get('post_max_size'); ?>
		    </li>
		    <li class="list-group-item">
			    <b>文件上传许可：</b><?php echo ini_get('upload_max_filesize'); ?>
		    </li>
	    </ul>
    </div>
	<div class="panel panel-info">
	    <?php 
            $url = "http://git.oschina.net/52fancy/OpenVPN/raw/master/Version"; 
            $contents = file_get_contents($url); 
            //如果出现中文乱码使用下面代码 
            //$getcontent = iconv("gb2312", "utf-8",$contents); 
            echo $contents; 
        ?>
	</div>
</div>