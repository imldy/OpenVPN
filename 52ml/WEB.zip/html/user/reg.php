<?php
$mod='blank';
include("../api.inc.php");
$dlconfig=$DB->get_row("SELECT * FROM auth_config WHERE 1");
if($_POST['user'] && $_POST['pass']){
	$user=daddslashes($_POST['user']);
	$pass=daddslashes($_POST['pass']);
	$verifycode=daddslashes($_POST['verifycode']);
	$row = $DB->get_row("SELECT * FROM `openvpn` WHERE `iuser`='$user' limit 1");
	if(!is_username($user)){
		exit("<script language='javascript'>alert('用户名只能是2~20位的字母数字！');history.go(-1);</script>");
	}elseif($row){
		exit("<script language='javascript'>alert('用户名已被使用！');history.go(-1);</script>");
	}elseif(!$verifycode || $verifycode!=$_SESSION['verifycode']){
			exit("<script language='javascript'>alert('验证码不正确！');history.go(-1);</script>");
	}else{
		$DB->query("insert `openvpn`(`iuser`,`pass`,`isent`,`irecv`,`maxll`,`i`,`starttime`,`endtime`) values('{$user}','{$pass}',0,0,0,0,'".time()."','".time()."')");
		$row = $DB->get_row("SELECT * FROM `openvpn` WHERE `iuser`='$user' limit 1");
		if($row['id']){
			unset($_SESSION['verifycode']);
			exit("<script language='javascript'>alert('注册成功，请使用激活码充值使用！');window.location.href='./index.php?u={$row['iuser']}&p={$row['pass']}';</script>");	
		}else{
			exit("<script language='javascript'>alert('注册失败，请联系管理员！');history.go(-1);</script>");
		}
	}
}
	

$title='云用户注册';
include './head.php';
?>
  <div class="container" style="padding-top:70px;">
    <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
      <div class="panel panel-primary" style="border-color: #5CB85C;">
        <div class="panel-heading" style="color: #fff;background-color: #5CB85C;border-color: #5CB85C;"><h3 class="panel-title">云用户注册</h3></div>
        <div class="panel-body">
          <form action="./reg.php" method="post" class="form-horizontal" role="form">
            <div class="input-group">
              <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
              <input type="text" name="user" value="" class="form-control" placeholder="用户名" required="required"/>
            </div><br/>
            <div class="input-group">
              <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
              <input type="password" name="pass" class="form-control" placeholder="密码" required="required"/>
            </div><br/>
			<div class="input-group">
              <span class="input-group-addon"><span class="glyphicon glyphicon-unchecked"></span></span>
              <input type="text" name="verifycode" class="form-control" placeholder="验证码" required="required" style="max-width: 65%;display:inline-block;vertical-align:middle;"/>&nbsp;<img title="点击刷新" src="verifycode.php" onclick="this.src='verifycode.php?'+Math.random();" style="max-height:32px;vertical-align:middle;" class="img-rounded">
            </div><br/>
            <div class="form-group">
              <div class="col-xs-6"><input type="submit" value="注册"  class="btn btn-success form-control"/></div>
              <div class="col-xs-6"><a href="login.php" class="btn btn-info form-control"/>登陆</a></div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php footer(); ?>