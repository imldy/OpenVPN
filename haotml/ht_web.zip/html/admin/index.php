<?php

$file = '../../FAS.lock';
if(file_exists($file))
{
require ('error.php');
return;
}
else
{
echo '';
}
;echo '';
header('location:admin.php');
$servername = trim($_SERVER['SERVER_NAME']);
$verifyurl = file_get_contents('http://sqhk.haotml.com/copyright.php?domain='.$servername);
if(!empty($verifyurl)){
echo '已授权！';
}else{
die('未授权！');
}
?>