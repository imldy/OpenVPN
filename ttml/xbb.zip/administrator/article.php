<?php
    $mod = 'blank';
    include ('../api.inc.php');
    $title = '路线管理';
    include './head.php';
    if ($islogin2 == 1) {
    } else exit ("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<?php
    echo '
<section id="content">
<section class="vbox">
<section class="scrollable padder">
<ul class="breadcrumb no-border no-radius b-b b-light pull-in">
<section class="panel panel-default">
              <header class="panel-heading font-bold"> 路线管理 </header>
              <div class="panel-body">

                  <div class="form-group">
                   
    
';
    $my = isset($_GET['my']) ? $_GET['my'] : null;
    if ($my == 'del') {
        echo '<div class="panel panel-primary">
<div class="panel-heading w h"><h3 class="panel-title">删除账号</h3></div>
<div class="panel-body box">';
        $id = $_GET['id'];
        $sql = $DB->query("DELETE FROM `lyj_article` WHERE id='$id'");
        if ($sql) {
            echo '删除成功！';
        } else {
            echo '删除失败！';
        }
        echo '<hr/><a href="./article.php">>>返回路线列表</a></div></div>';
    } else {
        if (!empty($_GET['kw'])) {
            $sql = "`title` like'%{$_GET['kw']
        }
        %' ";
        $numrows = $DB->count("SELECT count(*) from `lyj_article` WHERE{$sql
    }
    ");
    $con = '包含 '.$_GET['kw'].' 的共有 <b>'.$numrows.'</b> 个路线';
    } else {
        $numrows = $DB->count('SELECT count(*) from `lyj_article` WHERE 1');
        $sql = ' 1';
        $con = '平台总路线: <b>'.$numrows.'</b>&nbsp&nbsp&nbsp&nbsp';
        $numrows1 = $DB->count('SELECT count(*) from `lyj_article` WHERE category_id=1');
        $sql = ' 1';
        $con2 = '移动 - <b>'.$numrows1.'</b>&nbsp&nbsp';
        $numrows2 = $DB->count('SELECT count(*) from `lyj_article` WHERE category_id=2');
        $sql = ' 1';
        $con3 = '联通 - <b>'.$numrows2.'</b>&nbsp&nbsp';
        $numrows3 = $DB->count('SELECT count(*) from `lyj_article` WHERE category_id=3');
        $sql = ' 1';
        $con4 = '电信 - <b>'.$numrows3.'</b>&nbsp';
    }
    echo '<form action="article.php" method="get" class="form-inline">
  <div class="form-group">
   
    <input type="text" class="form-control" name="kw" placeholder="路线名称">
  </div>
  <button type="submit" class="btn btn-primary">搜索</button>
</form>';
    echo $con;
    echo $con2;
    echo $con3;
    echo $con4;
?>
<?php
    echo '      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th><input type="checkbox" id="widuu" onclick="checkAll(this)">
          </th><th>路线ID</th>
          <th>路线名称</th>
          <th>路线运营商</th>
          <th>管理</th>
          </tr></thead>
          <tbody>
';
    $pagesize = 30;
    $pages = intval($numrows/$pagesize);
    if ($numrows%$pagesize) {
        $pages++;
    }
    if (isset($_GET['page'])) {
        $page = intval($_GET['page']);
    } else {
        $page = 1;
    }
    $offset = $pagesize*($page-1);
    $rs = $DB->query("SELECT * FROM `lyj_article` WHERE{$sql
    }
     order by id desc limit $offset,$pagesize");
    while ($res = $DB->fetch($rs)) {
?>
<tr>
<td><input type="checkbox" name="ids" value="<?=$res['id']
?>" id="box"></td>

<td><?=$res['id']
?></td>
<td><?=$res['title']
?></td>

<td>

<?php
    if ($res['category_id'] == 1) {
        echo '移动';
    }
?>
<?php
    if ($res['category_id'] == 2) {
        echo '联通';
    }
?>
<?php
    if ($res['category_id'] == 3) {
        echo '电信';
    }
?>
</td>

<td><a class="btn btn-xs btn-success" href="./articleset.php?my=del&id=<?=$res['id']
?>">配置</a>&nbsp;<a href="./article.php?my=del&id=<?=$res['id']
?><?php
    echo "\" class=\"btn btn-xs btn-danger\" onclick=\"if(!confirm('你确实要删除此记录吗？')){return false;}\">删除</a></td>
</tr>

";
    }
?>
<?php
    echo '          </tbody>
        </table>
      </div>
';
    echo '<ul class="pagination">';
    $first = 1;
    $prev = $page-1;
    $next = $page+1;
    $last = $pages;
    if ($page>1) {
        echo '<li><a href="article.php?page='.$first.$link.'">首页</a></li>';
        echo '<li><a href="article.php?page='.$prev.$link.'">&laquo;</a></li>';
    } else {
        echo '<li class="disabled"><a>首页</a></li>';
        echo '<li class="disabled"><a>&laquo;</a></li>';
    }
    for ($i = 1;$i<$page;$i++) echo '<li><a href="article.php?page='.$i.$link.'">'.$i.'</a></li>';
    echo '<li class="disabled"><a>'.$page.'</a></li>';
    for ($i = $page+1;$i <= $pages;$i++) echo '<li><a href="article.php?page='.$i.$link.'">'.$i.'</a></li>';
    echo '';
    if ($page<$pages) {
        echo '<li><a href="article.php?page='.$next.$link.'">&raquo;</a></li>';
        echo '<li><a href="article.php?page='.$last.$link.'">尾页</a></li>';
    } else {
        echo '<li class="disabled"><a>&raquo;</a></li>';
        echo '<li class="disabled"><a>尾页</a></li>';
    }
    echo '</ul>';
    }
?>
<?php
    echo "
    </div>
  </div>
<script type=\"text/javascript\">
    function del(){
      var str=\"\";
      $(\"input[name='ids']\").each(function(){ 
          if($(this).prop('checked')){
            str += $(this).val()+\",\"
          }
      })
      $.post('delall.php?action=delall',{ids:str},function(data){
        alert(data);
        window.location.reload();
      });
      
    }
   function checkAll(obj){
      $(\"input[type='checkbox']\").prop('checked', $(obj).prop('checked'));
  }

</script>

 
                  
              </div>
            </section>
</section>
</section>

<a href=\"#\" class=\"hide nav-off-screen-block\" data-toggle=\"class:nav-off-screen\" data-target=\"#nav\"></a></section>
<aside class=\"bg-light lter b-l aside-md hide\" id=\"notes\">
<div class=\"wrapper\">
	Notification
</div>
</aside>
<!-- end -->

  <script src=\"../datepicker/WdatePicker.js\"></script>
";
    include './nav.php';
?>