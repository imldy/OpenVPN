



<div id="page-container" class="header-fixed-top sidebar-visible-lg-full">
 
<div id="sidebar">
 
<div id="sidebar-brand" class="themed-background">
<a href="./" class="sidebar-title">
<i class="fa fa-thumbs-up"></i> <span class="sidebar-nav-mini-hide"><?php echo $yunname;?><strong></strong></span>
</a>
</div>
 
<div id="sidebar-scroll">
 
<div class="sidebar-content">
 
<ul class="sidebar-nav">


<li>
<a id="add" href="./addmoney.php"><i class="fa fa-plus sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">账户信息</span></a>
</li>


<?php 
if($dllx=='0')
{
echo ' <li>
<a id="web" href="./article.php"><i class="fa fa-shopping-cart sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">路线下载</span></a>
</li>';
}

if($dldiy=='0'){
echo ' 
<li>
<a id="qqlist" href="./kmlist.php"><i class="fa fa-table sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">卡密管理</span></a>
</li>
<li>
<a id="qqgl" href="./builduser.php"><i class="fa fa-qq sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">账号管理</span></a>
</li>';
}

if($dltc=='0'){
echo ' <li>
<a id="web" href="./Package.php"><i class="fa fa-shopping-cart sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">购买套餐</span></a>
</li>';
}
?>

<li>
<a id="web" href="./carduser.php"><i class="fa fa-shopping-cart sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">直冲流量</span></a>
</li>
</ul>
 
</div>
 
</div>
 
 
<div id="sidebar-extra-info" class="sidebar-content sidebar-nav-mini-hide">
<div class="progress progress-mini push-bit">
<div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%"></div>
</div>
<div class="text-center">
<small><span id="year-copy"></span> &copy; <a href="http://www.bh-yl:8888/" target="_blank"><?php echo $yunname;?></a><br/>2.5.1.1021 </small>
</div>
</div>
 
</div>
 
 
<div id="main-container">
 
<header class="navbar navbar-inverse navbar-fixed-top">
 
<ul class="nav navbar-nav-custom">
 
<li>
<a href="javascript:void(0)" onclick="App.sidebar('toggle-sidebar');this.blur();">
<i class="fa fa-ellipsis-v fa-fw animation-fadeInRight" id="sidebar-toggle-mini"></i>
<i class="fa fa-bars fa-fw animation-fadeInRight" id="sidebar-toggle-full"></i>菜单
</a>
</li>
<li>
<a href="javascript:void(0)" onclick="javascript:history.go(-1);">
<i class="fa fa-reply fa-fw animation-fadeInRight"></i> 返回
</a>
</li>
 
 
 
 
 
 
</ul>
 
 
<ul class="nav navbar-nav-custom pull-right">
 
 
 
<li class="dropdown">
<a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">
<img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $row['qq'];?>&spec=100" alt="avatar">
</a>
</li>
 
</ul>
 
</header>
<div id="page-content">
<div class="content-header">
<div class="row">
<div class="col-sm-6">
<div class="header-section">
<h2><?php echo $title ?></h2>
</div>
</div>
</div>
</div>