<link rel="shortcut icon" href="../static/index/images/favicon.ico">
<?php
header("location: ../admin/index.php"); 
?>