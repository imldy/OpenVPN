<?php @eval("//Encode by  phpjiami.com,Free user."); ?><?php

$mod='blank';
include("../api.inc.php");
$title='添加账号';
include './head.php';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
include './nav.php';
?>
     <?php
require_once ("head.php");
?>
<?php
if($_POST['name']){
	echo '<section class="panel panel-default">
              <header class="panel-heading font-bold"> 添加模式结果 </header>
              <div class="panel-body">
<div class="panel-body">'; 
$name = $_REQUEST['name']; 
$mo = $_REQUEST['mo'];   
$id=strtoupper(substr(md5($uin.time()),0,8).'-'.uniqid()); 
$sql="insert into `open` (`id`,`name`,`mo`) values ('{$id}','{$name}','{$mo}')"; 
if($DB->query($sql))
echo "成功添加一个模式"; 
else
echo "添加失败"; 
echo '<hr/><a href="./open.php">>>返回继续添加</a><br><a href="./openlist.php">>>返回模式列表</a></div></div>'; exit;  
}
?>
<section class="panel panel-default">
              <header class="panel-heading font-bold"> 添加模式 </header>
              <div class="panel-body">
          <form action="./open.php" method="post" class="form-horizontal" role="form">
              <div class="form-group"><label>名称</label> <input type="text" placeholder="输入模式名称" class="form-control" name="name" required="" aria-required="true"></div>
                                    <div class="form-group">
                                        <textarea class="form-control diff-textarea" name="mo" rows="6"></textarea>
                           
                           
                           			</div>
            <br/>
            <input type="submit" value="添加" class="btn btn-primary form-control"/>
          </form>
        </div>
      </div>
    </div>
  </div>
  <script src="../datepicker/WdatePicker.js"></script>
                  <div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
                    
                  
              </div>
            </section>
</section>
</section>

<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a></section>
<aside class="bg-light lter b-l aside-md hide" id="notes">
<div class="wrapper">
	Notification
</div>
</aside>
<!-- end -->
<?php
require_once ("foot.php");
?>
