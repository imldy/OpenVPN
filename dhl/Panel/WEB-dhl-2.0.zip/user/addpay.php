<?php
$mod = 'blank';
include "../api.inc.php";
$title = '用户中心';
include './head.php';
$u = daddslashes($_GET['user']);
$p = daddslashes($_GET['pass']);
$res = $DB->get_row("SELECT * FROM `openvpn` where `user`='{$u}' && `pass`='{$p}' limit 1");
$uid = $res['id'];
//if (!$res) {
	//header('location: login.php');
	//die;
//}
?>
  <nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">导航按钮</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="./">管理中心</a>
      </div><!-- /.navbar-header -->
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
		<li class="active">
            <a href="./buy.php?user=<?=$u?>&pass=<?=$p?>"><span class="glyphicon glyphicon-user"></span>购买流量</a>
          </li>
		<li class="active">
            <a href="./addpay.php?user=<?=$u?>&pass=<?=$p?>"><span class="glyphicon glyphicon-user"></span>用户充值</a>
          </li>
          <li class="active">
            <a href="./login.php"><span class="glyphicon glyphicon-user"></span>退出登录</a>
          </li>
        </ul>
      </div><!-- /.navbar-collapse -->
    </div><!-- /.container -->
  </nav><!-- /.navbar -->
  <div class="container" style="padding-top:70px;">
    <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
      <div class="panel panel-primary">
        <div class="panel-heading"><h3 class="panel-title">用户充值</h3></div>
        <div class="panel-body">
          <form action="./alipay.php?user=<?=$u?>&uid=<?=$uid?>" method="post" class="form-inline" role="form">
            <div class="form-group">
              <input type="text" name="total" value="" class="form-control" required/>
            </div>
            <input type="submit" value="充值" class="btn btn-primary form-control"/>
          </form>
        </div>
    </div>
  </div>
  </center><?php 