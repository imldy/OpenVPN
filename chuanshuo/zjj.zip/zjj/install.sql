-- MySQL dump 10.13  Distrib 5.5.51, for Linux (x86_64)
--
-- Host: localhost    Database: leige
-- ------------------------------------------------------
-- Server version	5.5.51

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lyj_article`
--

DROP TABLE IF EXISTS `lyj_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lyj_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '无题',
  `content` text NOT NULL,
  `visit_count` int(10) unsigned NOT NULL DEFAULT '0',
  `timeline` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='文章表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lyj_article`
--

LOCK TABLES `lyj_article` WRITE;
/*!40000 ALTER TABLE `lyj_article` DISABLE KEYS */;
INSERT INTO `lyj_article` VALUES (2,1,'移动','1',0,1471086665);
/*!40000 ALTER TABLE `lyj_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lyj_category`
--

DROP TABLE IF EXISTS `lyj_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lyj_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '默认栏目',
  `description` varchar(255) NOT NULL DEFAULT '栏目简介',
  `sortby` int(5) NOT NULL DEFAULT '0',
  `hidden` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='栏目表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lyj_category`
--

LOCK TABLES `lyj_category` WRITE;
/*!40000 ALTER TABLE `lyj_category` DISABLE KEYS */;
INSERT INTO `lyj_category` VALUES (1,'移动','',1,0),(2,'联通','',2,0),(3,'电信','',3,0);
/*!40000 ALTER TABLE `lyj_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lyj_link`
--

DROP TABLE IF EXISTS `lyj_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lyj_link` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `name` varchar(200) NOT NULL DEFAULT '链接名称',
  `description` varchar(255) NOT NULL DEFAULT '链接简介',
  `url` varchar(255) NOT NULL DEFAULT 'http://',
  `icon` varchar(255) NOT NULL DEFAULT 'http://',
  `sortby` int(5) NOT NULL DEFAULT '0',
  `hidden` int(2) NOT NULL DEFAULT '0',
  `timeline` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='友链表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lyj_link`
--

LOCK TABLES `lyj_link` WRITE;
/*!40000 ALTER TABLE `lyj_link` DISABLE KEYS */;
INSERT INTO `lyj_link` VALUES (1,1,'流控地址','链接简介','http://139.196.74.229:80/','.',1,0,0),(2,1,'卡密地址','链接简介','http://ip:port','.',0,0,1471028321),(3,1,'官方商城','链接简介','http://ip:port/','.',2,0,1471029048),(4,1,'使用说明','链接简介','http://139.196.74.229:80/shuoming.html','.',3,0,1471029100),(5,1,'背景图片','链接简介','http://图片','.',4,0,1471029221);
/*!40000 ALTER TABLE `lyj_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lyj_setting`
--

DROP TABLE IF EXISTS `lyj_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lyj_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `skey` varchar(100) NOT NULL DEFAULT '要设置的键',
  `sval` varchar(1024) NOT NULL DEFAULT '要设置的值',
  PRIMARY KEY (`id`),
  UNIQUE KEY `skey` (`skey`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='设置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lyj_setting`
--

LOCK TABLES `lyj_setting` WRITE;
/*!40000 ALTER TABLE `lyj_setting` DISABLE KEYS */;
INSERT INTO `lyj_setting` VALUES (1,'contact','qq'),(2,'seo_title','qqkey'),(3,'seo_keywords','图片地址'),(4,'seo_description','公告信息'),(5,'copyright','流控地址');
/*!40000 ALTER TABLE `lyj_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lyj_token`
--

DROP TABLE IF EXISTS `lyj_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lyj_token` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `token` varchar(32) NOT NULL,
  `expire_timeline` int(10) NOT NULL,
  `update_timeline` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='登录令牌表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lyj_token`
--

LOCK TABLES `lyj_token` WRITE;
/*!40000 ALTER TABLE `lyj_token` DISABLE KEYS */;
INSERT INTO `lyj_token` VALUES (1,1,'f826ef30ddc531f51c107a8c18d8ff8a',1473619585,1471027585),(2,2,'872125493',1473619585,1471027585);
/*!40000 ALTER TABLE `lyj_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lyj_user`
--

DROP TABLE IF EXISTS `lyj_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lyj_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account` varchar(15) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `nick` varchar(15) NOT NULL,
  `face` varchar(255) DEFAULT NULL,
  `sex` int(2) DEFAULT '0',
  `device_id` varchar(20) NOT NULL,
  `is_forbidden` int(10) NOT NULL DEFAULT '0',
  `is_app` int(2) DEFAULT '0',
  `timeline` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`account`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lyj_user`
--

LOCK TABLES `lyj_user` WRITE;
/*!40000 ALTER TABLE `lyj_user` DISABLE KEYS */;
INSERT INTO `lyj_user` VALUES (1,'root','63a9f0ea7bb98050796b649e85481845  ','Meteor','',1,'1163844562',0,0,0);
/*!40000 ALTER TABLE `lyj_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-08-14  3:51:36
