<?php
/**
 * 卡密列表
**/
$mod='blank';
include("../api.inc.php");
$title='路线下载';
include './head.php';
$dlid=$_SESSION['dlid'];
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
$row = $DB->get_row("select * from `lyj_article` where id='$id' limit 1");
include './nav.php';
$my=isset($_GET['my'])?$_GET['my']:null;
if($dllx=='0'){}else exit("<script language='javascript'>alert('路线暂时未开放下载！');history.go(-1);</script>");
?>
<div class="row wrapper wrapper-content">
    <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<section class="panel panel-default">
              <header class="panel-heading font-bold"> 路线下载 </header>
              <div class="panel-body">
<?php

$my=isset($_GET['my'])?$_GET['my']:null;



if(!empty($_GET['kw'])) {
	$sql=" `title` like'%{$_GET['kw']}%' ";
	$numrows=$DB->count("SELECT count(*) from `lyj_article` WHERE{$sql}");
	$con='包含 '.$_GET['kw'].' 的共有 <b>'.$numrows.'</b> 个路线';
}else{
	$numrows=$DB->count("SELECT count(*) from `lyj_article` WHERE 1");
	$sql=" 1";
	$con='平台总路线: <b>'.$numrows.'</b>&nbsp&nbsp&nbsp&nbsp';
	
	$numrows1=$DB->count("SELECT count(*) from `lyj_article` WHERE category_id=1");
	$sql=" 1";
	$con2='移动 - <b>'.$numrows1.'</b>&nbsp&nbsp';
	
	$numrows2=$DB->count("SELECT count(*) from `lyj_article` WHERE category_id=2");
	$sql=" 1";
	$con3='联通 - <b>'.$numrows2.'</b>&nbsp&nbsp';
	
	$numrows3=$DB->count("SELECT count(*) from `lyj_article` WHERE category_id=3");
	$sql=" 1";
	$con4='电信 - <b>'.$numrows3.'</b>&nbsp';

echo $con;
echo $con2;
echo $con3;
echo $con4;
echo '<form action="article.php" method="get" class="form-inline">
  <div class="form-group">
   
    <input type="text" class="form-control" name="kw" placeholder="路线名称">
  </div>
  <button type="submit" class="btn btn-primary">搜索</button>
</form>';
?>
      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr>
		  <th>路线ID</th>
          <th>路线名称</th>
          <th>路线运营商</th>
          <th>下载</th>
          </tr></thead>
          <tbody>
<?php
$pagesize=30;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
//$zt = array('0'=>'<font color=green>正常</font>','1'=>'<font color=red>密码错误</font>','2'=>'<font color=red>冻结</font>','3'=>'<font color=red>开启设备锁</font>');
$rs=$DB->query("SELECT * FROM `lyj_article` WHERE{$sql} order by id desc limit $offset,$pagesize");
while($res = $DB->fetch($rs))
{ ?>
<tr>



<td><?=$res['id']?></td>
<td><?=$res['title']?></td>

<td>

<?php 
if($res['category_id']==1){
echo '移动';
}
 ?>
<?php 
if($res['category_id']==2){
echo '联通';
}
 ?>
<?php 
if($res['category_id']==3){
echo '电信';
}
 ?>
</td>

<td>
<a class="btn btn-xs btn-success" href="./articleset.php?my=del&id=<?=$res['id']?>">下载</a>
</td>
</tr>

<?php }
?>
          </tbody>
        </table>
      </div>
<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="article.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="article.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="article.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="article.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="article.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="article.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
}
?>

    </div>
  </div>
</div>
 </section>