-- Adminer 4.2.2 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `line`;
CREATE TABLE `line` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `content` text NOT NULL,
  `type` text NOT NULL,
  `group` text NOT NULL,
  `show` int(11) NOT NULL,
  `label` text NOT NULL,
  `dlid` int(11) NOT NULL,
  `time` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `line` (`id`, `name`, `content`, `type`, `group`, `show`, `label`, `dlid`, `time`) VALUES
(22,	'tcp示例',	'# 凌一云免配置\n# lsuyi.cn\n# 欢迎加入煙雨如花:259282245\nsetenv IV_GUI_VER \"de.blinkt.openvpn 0.6.17\"\nmachine-readable-output\nclient\ndev tun\nproto tcp\nconnect-retry-max 5\nconnect-retry 5\nresolv-retry 60\n########免流代码########\nremote wap.sd.10086.cn 3389 tcp-client\r\nhttp-proxy-option EXT1 \"VPN 127.0.0.1:443\"\r\nhttp-proxy-option EXT1 \"POST http://wap.sd.10086.cn\"\r\nhttp-proxy-option EXT1 \"Host: wap.sd.10086.cn HTTP/1.1\"\r\nhttp-proxy [ip] 138\n########免流代码########\nresolv-retry infinite\nnobind\npersist-key\npersist-tun\n## 证书\n<ca>\n[C证书]\n</ca>\nkey-direction 1\n<tls-auth>\n[T证书]\n</tls-auth>\nauth-user-pass\nns-cert-type server\ncomp-lzo\nverb 3',	'2017-09-03',	'1',	1,	'',	0,	'1504422037'),
(157,	'udp示例-68',	'# 凌一云免配置\r\n# lsuyi.cn\r\n# 欢迎加入煙雨如花:259282245\r\nsetenv IV_GUI_VER \"de.blinkt.openvpn 0.6.17\"\r\nmachine-readable-output\r\nclient\r\ndev tun\r\nproto udp\r\nconnect-retry-max 5\r\nconnect-retry 5\r\nresolv-retry 60\r\n########免流代码########\r\nremote [ip] 68\r\n########免流代码########\r\nresolv-retry infinite\r\nnobind\r\npersist-key\r\npersist-tun\r\n## 证书\r\n<ca>\r\n[C证书]\r\n</ca>\r\nkey-direction 1\r\n<tls-auth>\r\n[T证书]\r\n</tls-auth>\r\nauth-user-pass\r\nns-cert-type server\r\ncomp-lzo\r\nverb 3',	'2017-10-10',	'4',	1,	'可破解大部分学校，不行就用53',	0,	'1506785362'),
(187,	'udp示例-53',	'# 凌一云免配置\r\n# lsuyi.cn\r\n# 欢迎加入煙雨如花:259282245\r\nsetenv IV_GUI_VER \"de.blinkt.openvpn 0.6.17\"\r\nmachine-readable-output\r\nclient\r\ndev tun\r\nproto udp\r\nconnect-retry-max 5\r\nconnect-retry 5\r\nresolv-retry 60\r\n########免流代码########\r\nremote [ip] 53\r\n########免流代码########\r\nresolv-retry infinite\r\nnobind\r\npersist-key\r\npersist-tun\r\n## 证书\r\n<ca>\r\n[C证书]\r\n</ca>\r\nkey-direction 1\r\n<tls-auth>\r\n[T证书]\r\n</tls-auth>\r\nauth-user-pass\r\nns-cert-type server\r\ncomp-lzo\r\nverb 3',	'2017-10-10',	'4',	1,	'可破解大部分学校，不行就用68',	0,	'1507619539');

-- 2017-10-13 09:55:04