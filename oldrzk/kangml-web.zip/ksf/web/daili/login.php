<?php
/**
 * 登录
**/
$mod='blank';
include("../api.inc.php");
if(isset($_POST['user']) && isset($_POST['pass'])){
	$user=daddslashes($_POST['user']);
	$pass=daddslashes($_POST['pass']);
	$row = $DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
	$dlid=$row['id'];
	if($row['active']=="1" && $dlid<>""){
		
	}else{exit("<script language='javascript'>alert('用户不存在或未激活，如已经注册请联系管理员付费激活！');history.go(-1);</script>");}
	
	if($user==$row['user'] && $pass==$row['pass']) {
		$session=md5($user.$pass.$password_hash);
		$token=authcode("{$user}\t{$session}", 'ENCODE', SYS_KEY);
		//setcookie("ol_token", $token, time() + 604800);
		$row = $DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
		$dlid=$row['id'];
		$_SESSION['dlid']=$dlid;
		@header('Content-Type: text/html; charset=UTF-8');
		exit("<script language='javascript'>alert('登陆代理中心成功！');window.location.href='./';</script>");
	}elseif ($pass != $row['pass']) {
		@header('Content-Type: text/html; charset=UTF-8');
		exit("<script language='javascript'>alert('用户名或密码不正确！');history.go(-1);</script>");
	}
}elseif(isset($_GET['logout'])){
	setcookie("ol_token", "", time() - 604800);
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('您已成功注销本次登陆！');window.location.href='./login.php';</script>");
}elseif($islogin2==1){
	exit("<script language='javascript'>alert('您已登陆！');window.location.href='./';</script>");
}

?>
 <!DOCTYPE html>
<html lang="en" class="bg-dark">
<head>
<meta charset="utf-8"/>
<title>康师傅流控代理登陆<?=$conf['name']?>
</title>
<meta name="description" content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav"/>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
<link rel="stylesheet" href="/static/index/css/app.v2.css" type="text/css"/>
<link rel="stylesheet" href="/static/index/css/font.css" type="text/css" cache="false"/>
<!--[if lt IE 9]>
<script src="/static/index/js/ie/html5shiv.js" cache="false"></script>
<script src="/static/index/js/ie/respond.min.js" cache="false"></script>
<script src="/static/index/js/ie/excanvas.js" cache="false"></script>
<![endif]-->
</head>
<body>
<section id="content" class="m-t-lg wrapper-md animated fadeInUp">
<div class="container aside-xxl">
	<a class="navbar-brand block">流控代理登陆</a>
	<section class="panel panel-default bg-white m-t-lg">
	<header class="panel-heading text-center"><strong>代理登陆系统,欢迎代理加入！</strong></header>
	
   
    
    <form action="./login.php" method="post" class="panel-body wrapper-lg">
		<input type="hidden" name="user" value="<?php echo @$_POST['user'];?>">
		<div class="form-group">
			<label class="control-label">用户名</label>
			<input type="text" name="user" placeholder="用户名" class="form-control input-lg">
		</div>
		<div class="form-group">
			<label class="control-label">密码</label>
			<input type="password" name="pass" placeholder="密码" required class="form-control input-lg">
		</div>
		
		<div class="line line-dashed">
		</div>
		<button type="submit" class="btn btn-facebook btn-block m-b-sm"value="登陆"</i> 登录</button>
		<a href="./reg.php" class="btn btn-facebook btn-block m-b-sm" > 注册</a>
		<div class="line line-dashed">
		</div>
		<p class="text-muted text-center">
		Copyright ©2016   
	    <a class href="http://kangml.com">kangml.com</a>
		 @傲慢与偏见 
		</p>
    </form>
    
	</section>
</div>
</section>
<!-- footer -->
<!-- / footer -->
<script src="/static/index/js/app.v2.js"></script>
<!-- Bootstrap --><!-- App -->
</body>
</html>

<!-- footer -->
<!-- / footer -->
<script src="/static/index/js/app.v2.js"></script>
<!-- Bootstrap --><!-- App -->
</body>
</html>
<?php footer(); ?>