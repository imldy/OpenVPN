<?php

$mod='blank';
include("../api.inc.php");

$u = daddslashes($_GET['user']);
$p = daddslashes($_GET['pass']);
$res=$DB->get_row("SELECT * FROM `openvpn` where `iuser`='$u' && `pass`='$p' limit 1");
if(!$res){
//  header('location: login.php');
        exit("<script language='javascript'>alert('未正确登录，或用户名或密码不正确！');history.go(-1);</script>");
}
if($_POST['km']){
    $km = daddslashes($_POST['km']);
    $myrow=$DB->get_row("select * from auth_kms where kind=1 and km='$km' limit 1");
    if(!$myrow){
        exit("<script language='javascript'>alert('此激活码不存在');history.go(-1);</script>");
    }elseif($myrow['isuse']==1){
        exit("<script language='javascript'>alert('此激活码已被使用');history.go(-1);</script>");
    }else{
        $duetime = ($res['endtime'] < time() ? time() : $res['endtime']) + $myrow['value']*24*60*60;
        $addll = $myrow['values']*1024*1024*1024;
        if($res['endtime'] < time()){//已到期
            $sql="update `openvpn` set `isent`='0',`irecv`='0',`maxll`='{$addll}',`endtime`='{$duetime}',`dlid`='{$myrow['daili']}',`i`='1' where `iuser`='{$u}' && `pass`='{$p}'";
            if($DB->query($sql)){
                $DB->query("update `auth_kms` set `isuse` ='1',`user` ='$u',`usetime` ='$date' where `id`='{$myrow['id']}'");
                wlog('账号激活','用户'.$u.'使用激活码'.$km.'开通账号['.$date.']');
                exit("<script language='javascript'>alert('开通成功！');history.go(-1);</script>");
            }else{
                exit("<script language='javascript'>alert('开通失败！');history.go(-1);</script>");
            }
        }else{
            $sql="update `openvpn` set `maxll`=`maxll` + '{$addll}',`endtime`='{$duetime}',`dlid`='{$myrow['daili']}',`i`='1' where `iuser`='{$u}' && `pass`='{$p}'";
            if($DB->query($sql)){
                $DB->query("update `auth_kms` set `isuse` ='1',`user` ='$u',`usetime` ='$date' where `id`='{$myrow['id']}'");
                wlog('账号激活','用户'.$u.'使用激活码'.$km.'续费账号['.$date.']');
                exit("<script language='javascript'>alert('续费成功！');history.go(-1);</script>");
            }else{
                exit("<script language='javascript'>alert('续费失败！');history.go(-1);</script>");
            }
        }
        //$duetime = ($res['endtime'] < time() ? time() : $res['endtime']) + $myrow['value']*24*60*60;
        //$addll = ($res['endtime'] < time() ? $myrow['values'] : $res['endtime']) + $myrow['values'];
        //$sql="update `{$prefix}openvpn` set `maxll`=`maxll` + '0',`endtime`='{$duetime}' where `iuser`='{$u}' && `pass`='{$p}'";
        
    }
    //if($DB->query("update `{$prefix}openvpn` set `pass`='$pass',`maxll`='$maxll',`i`='$state',`endtime`='$endtime' where iuser='$user'"))
}elseif($_POST['newpass']){
    $newpass = daddslashes($_POST['newpass']);
    if($DB->query("update `openvpn` set `pass` ='$newpass' where `iuser`='$u' && `pass`='$p' limit 1")){
        exit("<script language='javascript'>alert('密码修改成功！');history.go(-1);</script>");
    }else{
        exit("<script language='javascript'>alert('密码修改失败！');history.go(-1);</script>");
    }
}

$title='用户中心';


$config = $DB->get_row("SELECT * FROM auth_config where id='$site_id'");
$gonggao=$config['ggs'];//公告获取
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head2.php';?>
<body class="page-body">
    
    <div class="page-container"><!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->
            
        <!-- Add "fixed" class to make the sidebar fixed always to the browser viewport. -->
        <!-- Adding class "toggle-others" will keep only one menu item open at a time. -->
        <!-- Adding class "collapsed" collapse sidebar root elements and show only icons. -->
     
        <div class="main-content">
                    
            
            <!-- Xenon Counter Widget -->
            <div class="row">
                <div class="col-sm-6">
                    
                    <div class="xe-widget xe-counter" data-count=".num" data-from="0" data-to="<?php echo round($res['maxll']/1024/1024);?>" data-suffix="M" data-duration="2">
                        <div class="xe-icon">
                            <i class="linecons-cloud"></i>
                        </div>
                        <div class="xe-label">
                            <strong class="num">0</strong>
                            <span>总计流量</span>
                        </div>
                    </div>
                    
                </div>
                <div class="col-sm-6">
                    
                    <div class="xe-widget xe-counter xe-counter-blue" data-count=".num" data-from="1" data-to="<?php echo round(($res['maxll']-$res['isent']-$res['irecv'])/1024/1024);?>" data-suffix="M" data-duration="3" data-easing="false">
                        <div class="xe-icon">
                            <i class="linecons-database"></i>
                        </div>
                        <div class="xe-label">
                            <strong class="num">0</strong>
                            <span>剩余流量</span>
                        </div>
                    </div>
                
                </div>
            </div>
            
            
            <!-- Xenon Block Counter Widget -->
            <div class="row">
                <div class="col-sm-6">
                
                    <div class="xe-widget xe-counter-block" data-count=".num" data-from="0" data-to="<?php echo round((($res['maxll']-$res['isent']-$res['irecv']))/$res['maxll']*100);?>" data-suffix="%" data-duration="2">
                        <div class="xe-upper">
                            
                            <div class="xe-icon">
                                <i class="linecons-params"></i>
                            </div>
                            <div class="xe-label">
                                <strong class="num">0.0%</strong>
                                <span>流量剩余比例</span>
                            </div>
                            
                        </div>
                        <div class="xe-lower">
                            <div class="border"></div>
                            
                            <span>已经上传：<?php echo round($res['isent']/1024/1024);?>M</span>
                            <strong>已经下载：<?php echo round($res['irecv']/1024/1024);?>M</strong>
                        </div>
                    </div>
                    
                </div>

                <div class="col-sm-6">
                                <?php
                                    date_default_timezone_set('Asia/Hong_Kong');
                                    $startDate = date('Y-m-d',$res['starttime']);
                                    $endDate = date('Y-m-d',$res['endtime']);
                                     
                                    // 将日期转换为Unix时间戳
                                    $startDateStr = strtotime($startDate);
                                    $endtDateStr = strtotime($endDate);
                                    $total = $endtDateStr-$startDateStr;
                                     
                                    $now = strtotime(date('Y-m-d'));
                                    $remain = $endtDateStr-$now;
                                     
                                    //echo '为期：'.$total/(3600*24).'天<br>';
                                    //echo '剩余：'.$remain/(3600*24).'天';
                                ?>
                                <div class='xe-widget xe-counter-block xe-counter-block-purple' data-count='.num' data-from='0' data-to='<?php echo $remain/(3600*24);?>' data-suffix='天' data-duration='3'>
                                    <div class='xe-upper'>
                                        
                                        <div class='xe-icon'>
                                            <i class='linecons-calendar'></i>
                                        </div>
                                        <div class='xe-label'>
                                            <strong class='num'>0</strong>
                                            <span>剩余使用时间</span>
                                        </div>
                                        
                                    </div>
                                    <div class='xe-lower'>
                                        <div class='border'></div>
                                        <span>开通时间：<?php echo date('Y-m-d',$res['starttime']);?></span>
                                        <strong>到期时间：<?php echo date('Y-m-d',$res['endtime']);?></strong>
                                    </div>
                        
                    </div>
                    
                </div>

            </div>
            
            <div class="row">
                <div class="col-sm-12">

                    <div class="panel panel-color panel-info"><!-- Add class "collapsed" to minimize the panel -->
                        <div class="panel-heading">
                            <h3 class="panel-title">卡密充值</h3>
                            
                            <div class="panel-options">
                                <a href="#" data-toggle="panel">
                                    <span class="collapse-icon">–</span>
                                    <span class="expand-icon">+</span>
                                </a>
                            </div>
                        </div>
                        
                        <div class="panel-body">
                            
                            <p>公告：<?php echo $gonggao;?> </p>
                            <br>
                            <form action="" method="POST" id="kmcz">
                                <div class="input-group">
                                    <input type="text" placeholder="请输入卡密" class="form-control no-right-border form-focus-info" id="km" name="km">
                                    <span class="input-group-btn">
                                        <button class="btn btn-info" type="submit">马上充值</button>
                                    </span>
                                </div>
                            </form>
            
                        </div>

                    </div>
                </div>
            </div>

            <!-- Main Footer -->
            <?php include("../copy.php");?>
        </div>
        
    </div>

<?php include("js.php");?>

</body>
</html>