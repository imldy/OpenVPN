<?php
$url = $_SERVER['PHP_SELF'];
if ($islogin2 == 1) {
} else exit('<script language=\'javascript\'>window.location.href=\'./login.php\';</script>');
$urls = $_SERVER['HTTP_HOST'];//获取当前url

if($site_id==1){
	$count = $DB->count('SELECT count(*) from `openvpn` WHERE  1');
	$count2 = $DB->count('SELECT count(*) from `openvpn` WHERE  i=1');
	$countkm = $DB->count('SELECT count(*) from `auth_kms` WHERE  1');
	$countkm2 = $DB->count('SELECT count(*) from `auth_kms` WHERE  isuse=0');
}else{
	$count = $DB->count('SELECT count(*) from `openvpn` WHERE url="'.$urls.'" and 1');
	$count2 = $DB->count('SELECT count(*) from `openvpn` WHERE url="'.$urls.'" and i=1');
	$countkm = $DB->count('SELECT count(*) from `auth_kms` WHERE url="'.$urls.'" and 1');
	$countkm2 = $DB->count('SELECT count(*) from `auth_kms` WHERE url="'.$urls.'" and isuse=0');
}



$countdaili = $DB->count('SELECT count(*) from `auth_daili` WHERE 1');
$countdaili2 = $DB->count('SELECT count(*) from `auth_daili` WHERE active=0');
 ?>
<?='    <div class="wrapper">

      <header class="topnavbar-wrapper">

         <nav role="navigation" class="navbar topnavbar">

            <div class="navbar-header">
               <a href="#/" class="navbar-brand">
                  <div class="brand-logo">
                     <img src="../assets/img/logo.png" alt="App Logo" class="img-responsive">
                  </div>
                  <div class="brand-logo-collapsed">
                     <img src="../assets/img/logo-single.png" alt="App Logo" class="img-responsive">
                  </div>
               </a>
            </div>

            <div class="nav-wrapper">
               <ul class="nav navbar-nav">
                  <li>
                     <a href="#" data-trigger-resize="" data-toggle-state="aside-collapsed" class="hidden-xs">
                        <em class="fa fa-navicon"></em>
                     </a>
                     <a href="#" data-toggle-state="aside-toggled" data-no-persist="true" class="visible-xs sidebar-toggle">
                        <em class="fa fa-navicon"></em>
                     </a>
                  </li>
                  <li>
                     <a id="user-block-toggle" href="#user-block" data-toggle="collapse">
                        <em class="icon-user"></em>
                     </a>
                  </li>
                  <li>
                     <a href="passwd.php" title="修改密码">
                        <em class="icon-lock"></em>
                     </a>
                  </li>
               </ul>
               <ul class="nav navbar-nav navbar-right">

                  <li class="visible-lg">
                     <a href="#" data-toggle-fullscreen="">
                        <em class="fa fa-expand"></em>
                     </a>
                  </li>
                  <li class="dropdown dropdown-list">
                     <a href="#" data-toggle="dropdown">
                        <em class="icon-bell"></em>
                        <div class="label label-danger"></div>
                     </a>
                     <ul class="dropdown-menu animated flipInX">
                         <li>
                           <div class="list-group">
                              <a href="#" class="list-group-item">
                                 <div class="media-box">
                                    <div class="pull-left">
                                       <em class="fa fa-tasks fa-2x text-success"></em>
                                    </div>
                                    <div class="media-box-body clearfix">
									'; 
                         $url = "http://www.7kml.com/gonggao/info.html"; 
                         $contents = file_get_contents($url); 
                         //如果出现中文乱码使用下面代码 
                         //$getcontent = iconv("gb2312", "utf-8",$contents); 
                         echo $contents; 
                         ?><?='
                              </a>
                           </div>
                        </li>
                     </ul>
                  </li>
                  <li>
                     <a href="#" data-toggle-state="offsidebar-open" data-no-persist="true">
                        <em class="icon-notebook"></em>
                     </a>
                  </li>
               </ul>
            </div>

         </nav>
      </header>
      <aside class="aside">
         <div class="aside-inner">
            <nav data-sidebar-anyclick-close="" class="sidebar">
               <ul class="nav">
                  <li class="has-user-block">
                     <div id="user-block" class="collapse">
                        <div class="item user-block">
                           <div class="user-block-picture">
                              <div class="user-block-status">
                                 <img src="../assets/img/logo.png" alt="Avatar" width="60" height="60" class="img-thumbnail img-circle">
                                 <div class="circle circle-success circle-lg"></div>
                              </div>
                           </div>
                           <div class="user-block-info">
                              <span class="user-block-name">Hello</span>
                              <span class="user-block-role">超级管理员</span>
							  <span class="user-block-role"><a href="login.php?logout">退出登录</a></span>
                           </div>
                        </div>
                     </div>
                  </li>
                  <li class="nav-heading ">
                     <span>首页</span>
                  </li>
                    <li class="';echo checkIfActive('index,')?><?='">
                     <a href="index.php" title="平台首页">
                        <em class="icon-speedometer"></em>
                        <span>平台首页</span>
                     </a>
                  </li>
					';
					if($active){
					echo '
				  <li class="nav-heading ">
                     <span>服务管理</span>
                  </li>
                  <li class=" ">
                     <a href="#layout" title="服务管理" data-toggle="collapse">
                        <em class="icon-grid"></em>
                        <span>服务管理</span>
                     </a>
                     <ul id="layout" class="nav sidebar-subnav collapse">
                        <li class="sidebar-subnav-header">服务管理</li>
                    <li class="';echo checkIfActive('addfwq,')?><?='">
                           <a href="addfwq.php" title="添加服务器">
                              <span>添加服务器</span>
                           </a>
                        </li>

                            <li class="';echo checkIfActive('fwqlist,')?><?='">
                           <a href="fwqlist.php" title="服务器列表">
                              <span>服务器列表</span>
                           </a>
                        </li>
                     </ul>
                    </li>
                  <li class=" ">
                     <a href="#elements" title="平台日志" data-toggle="collapse">
                        <em class="icon-chemistry"></em>
                        <span>平台日志</span>
                     </a>
                     <ul id="elements" class="nav sidebar-subnav collapse">
                        <li class="sidebar-subnav-header">平台日志</li>
                        <li class="';echo checkIfActive('log,')?><?='">
                           <a href="log.php" title="操作记录">
                              <span>操作记录</span>
                           </a>
                        </li>
                        <li class="';echo checkIfActive('online,')?><?='">
                           <a href="online.php" title="在线用户">
                              <span>在线用户</span>
                           </a>
                        </li>
                        <li class="';echo checkIfActive('script,')?><?='">
                           <a href="script.php" title="Sweet Alert">
                              <span>实时监控日志</span>
                           </a>
                        </li>
                     </ul>
                  </li>					 
					';}echo '
				  <li class="nav-heading ">
                     <span>账号卡密管理</span>
                  </li>
                  <li class=" ">
                     <a href="#forms" title="账号管理" data-toggle="collapse">
                        <em class="icon-note"></em>
                        <span>账号管理</span>
                     </a>
                     <ul id="forms" class="nav sidebar-subnav collapse">
                        <li class="sidebar-subnav-header">账号管理</li>
                        <li class="';echo checkIfActive('pladd,')?><?='">
                           <a href="pladd.php" title="批量添加账号">
                              <span>批量添加账号</span>
                           </a>
                        </li>
                        <li class="';echo checkIfActive('addqq,')?><?='">
                           <a href="addqq.php" title="添加账号">
                              <span>添加账号</span>
                           </a>
                        </li>
                        <li class="';echo checkIfActive('qqlist,')?><?='">
                           <a href="qqlist.php" title="账号列表">
                              <span>账号列表</span>
                           </a>
                        </li>
                        </ul>
                    </li>
                  <li class=" ">
                     <a href="#charts" title="代理管理" data-toggle="collapse">
                        <em class="icon-graph"></em>
                        <span>代理管理</span>
                     </a>
                     <ul id="charts" class="nav sidebar-subnav collapse">
                        <li class="sidebar-subnav-header">代理管理</li>
                        <li class="';echo checkIfActive('daili,')?><?='">
                           <a href="daili.php" title="Flot">
                              <span>代理用户管理</span>
                           </a>
                        </li>
                        <li class="';echo checkIfActive('dlkm,')?><?='">
                           <a href="dlkm.php" title="代理充值卡密">
                              <span>代理充值卡密</span>
                           </a>
                        </li>
                        <li class="';echo checkIfActive('dlconfig,')?><?='">
                           <a href="dlconfig.php" title="代理页面管理">
                              <span>代理页面管理</span>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li class=" ">
                     <a href="#tables" title="商品管理" data-toggle="collapse">
                        <em class="icon-list"></em>
                        <span>商品管理</span>
                     </a>
                     <ul id="tables" class="nav sidebar-subnav collapse">
                        <li class="sidebar-subnav-header">商品管理</li>
                        <li class="';echo checkIfActive('kmtype,')?><?='">
                           <a href="kmtype.php" title="套餐管理">
                              <span>套餐管理</span>
                           </a>
                        </li>
                        <li class="';echo checkIfActive('kmlist,')?><?='">
                           <a href="kmlist.php" title="商品列表">
                              <span>商品列表</span>
                           </a>
                        </li>
                        <li class="';echo checkIfActive('search,')?><?='">
                           <a href="search.php" title="内容搜索">
                              <span>内容搜索</span>
                           </a>
                        </li>							
                        </ul>
                    </li>
                  <li class="nav-heading ">
                     <span>平台管理</span>
                  </li>
                  <li class=" ">
                     <a href="#maps" title="官网管理" data-toggle="collapse">
                        <em class="icon-map"></em>
                        <span>官网管理</span>
                     </a>
                     <ul id="maps" class="nav sidebar-subnav collapse">
                        <li class="sidebar-subnav-header">官网管理</li>
                        <li class="';echo checkIfActive('website,')?><?='">
                           <a href="website.php" title="基本设置">
                              <span>基本设置</span>
                           </a>
                        </li>
                        <li class="';echo checkIfActive('banner,')?><?='">
                           <a href="banner.php" title="大图设置">
                              <span>大图设置</span>
                           </a>
                        </li>
                        <li class="';echo checkIfActive('payset,')?><?='">
                           <a href="payset.php" title="支付宝设置">
                              <span>支付宝设置</span>
                           </a>
                        </li>
                        </ul>
                    </li>
                    <!--Pages-->
					';
					if($active){
                    echo '
                  <li class=" ">
                     <a href="#pages" title="分站管理" data-toggle="collapse">
                        <em class="icon-doc"></em>
                        <span>分站管理</span>
                     </a>
                     <ul id="pages" class="nav sidebar-subnav collapse">
                        <li class="sidebar-subnav-header">分站管理</li>
                        <li class="';echo checkIfActive('addfz,')?><?='">
                           <a href="addfz.php" title="添加分站">
                              <span>添加分站</span>
                           </a>
                        </li>
                        <li class="';echo checkIfActive('fzlist,')?><?='">
                           <a href="fzlist.php" title="分站管理">
                              <span>分站管理</span>
                           </a>
                        </li>
                     </ul>
                  </li>

                  <li class=" ">
                     <a href="#extras" title="草根云控v4" data-toggle="collapse">
                        <em class="fa fa-folder-open-o"></em>
                        <span>草根云控v4</span>
                     </a>
                     <ul id="extras" class="nav sidebar-subnav collapse">
                        <li class="sidebar-subnav-header">草根云控v4</li>
                        <li class=" ">
                           <a href="/app_api" title="草根云控v4">
                              <span>草根云控v4</span>
                           </a>
                        </li>						
                        </ul>
                    </li>
					 </ul>
                    <!--More Pages-->';
					}
					if($active){
                    echo '';
					}
                    echo '
					';?>
					
              
            </nav>
         </div>
      </aside>
	  
      <aside class="offsidebar hide">
         <!-- START Off Sidebar (right)-->
         <nav>
            <div role="tabpanel">
               <!-- Nav tabs-->
               <ul role="tablist" class="nav nav-tabs nav-justified">
                  <li role="presentation" class="active">
                     <a href="#app-settings" aria-controls="app-settings" role="tab" data-toggle="tab">
                        <em class="icon-equalizer fa-lg"></em>
                     </a>
                  </li>
               </ul>
               <!-- Tab panes-->
               <div class="tab-content">
                  <div id="app-settings" role="tabpanel" class="tab-pane fade in active">
                     <h3 class="text-center text-thin">网站设置</h3>
                     <div class="p">
                        <h4 class="text-muted text-thin">后台配色修改</h4>
                        <div class="table-grid mb">
                           <div class="col mb">
                              <div class="setting-color">
                                 <label data-load-css="../assets/css/theme-a.css">
                                    <input type="radio" name="setting-theme" checked="checked">
                                    <span class="icon-check"></span>
                                    <span class="split">
                                       <span class="color bg-info"></span>
                                       <span class="color bg-info-light"></span>
                                    </span>
                                    <span class="color bg-white"></span>
                                 </label>
                              </div>
                           </div>
                           <div class="col mb">
                              <div class="setting-color">
                                 <label data-load-css="../assets/css/theme-b.css">
                                    <input type="radio" name="setting-theme">
                                    <span class="icon-check"></span>
                                    <span class="split">
                                       <span class="color bg-green"></span>
                                       <span class="color bg-green-light"></span>
                                    </span>
                                    <span class="color bg-white"></span>
                                 </label>
                              </div>
                           </div>
                           <div class="col mb">
                              <div class="setting-color">
                                 <label data-load-css="../assets/css/theme-c.css">
                                    <input type="radio" name="setting-theme">
                                    <span class="icon-check"></span>
                                    <span class="split">
                                       <span class="color bg-purple"></span>
                                       <span class="color bg-purple-light"></span>
                                    </span>
                                    <span class="color bg-white"></span>
                                 </label>
                              </div>
                           </div>
                           <div class="col mb">
                              <div class="setting-color">
                                 <label data-load-css="../assets/css/theme-d.css">
                                    <input type="radio" name="setting-theme">
                                    <span class="icon-check"></span>
                                    <span class="split">
                                       <span class="color bg-danger"></span>
                                       <span class="color bg-danger-light"></span>
                                    </span>
                                    <span class="color bg-white"></span>
                                 </label>
                              </div>
                           </div>
                        </div>
                        <div class="table-grid mb">
                           <div class="col mb">
                              <div class="setting-color">
                                 <label data-load-css="../assets/css/theme-e.css">
                                    <input type="radio" name="setting-theme">
                                    <span class="icon-check"></span>
                                    <span class="split">
                                       <span class="color bg-info-dark"></span>
                                       <span class="color bg-info"></span>
                                    </span>
                                    <span class="color bg-gray-dark"></span>
                                 </label>
                              </div>
                           </div>
                           <div class="col mb">
                              <div class="setting-color">
                                 <label data-load-css="../assets/css/theme-f.css">
                                    <input type="radio" name="setting-theme">
                                    <span class="icon-check"></span>
                                    <span class="split">
                                       <span class="color bg-green-dark"></span>
                                       <span class="color bg-green"></span>
                                    </span>
                                    <span class="color bg-gray-dark"></span>
                                 </label>
                              </div>
                           </div>
                           <div class="col mb">
                              <div class="setting-color">
                                 <label data-load-css="../assets/css/theme-g.css">
                                    <input type="radio" name="setting-theme">
                                    <span class="icon-check"></span>
                                    <span class="split">
                                       <span class="color bg-purple-dark"></span>
                                       <span class="color bg-purple"></span>
                                    </span>
                                    <span class="color bg-gray-dark"></span>
                                 </label>
                              </div>
                           </div>
                           <div class="col mb">
                              <div class="setting-color">
                                 <label data-load-css="../assets/css/theme-h.css">
                                    <input type="radio" name="setting-theme">
                                    <span class="icon-check"></span>
                                    <span class="split">
                                       <span class="color bg-danger-dark"></span>
                                       <span class="color bg-danger"></span>
                                    </span>
                                    <span class="color bg-gray-dark"></span>
                                 </label>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="p">
					 <h4 class="text-muted text-thin">当前系统环境</h4>
                        <p>
                           <small class="text-muted">PHP 版本：<?php echo phpversion() ?></small>
                        </p>


                        <p>
                           <small class="text-muted">MySQL 版本：<?php echo $mysqlversion ?></small>
                        </p>
						
                        <p>
                           <small class="text-muted">服务器软件：<?php echo $_SERVER['SERVER_SOFTWARE'] ?></small>
                        </p>
						
                        <p>
                           <small class="text-muted">程序最大运行时间：<?php echo ini_get('max_execution_time') ?>s</small>
                        </p>
						
                        <p>
                           <small class="text-muted">POST许可：<?php echo ini_get('post_max_size'); ?></small>
                        </p>
                           </div>

         </nav>
         <!-- END Off Sidebar (right)-->
      </aside>					