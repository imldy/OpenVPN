
<?php

$dir = dirname(__FILE__);
$admindir = str_replace(str_replace('\\','/',R),"",str_replace('\\','/',$dir))."/";
define("ADMINDIR",$admindir);


function checkIfActive($string) {
	if(is_array($string)){
		$array = $string[0];
	}else{
		$array=explode(',',$string);
	}
	$php_self=str_replace(ADMINDIR,'', $_SERVER['PHP_SELF']);
	$php_self=str_replace('.php','',$php_self);
	if (in_array($php_self,$array)){
		return $string[1][$php_self] ;
	}
	return false;
}

				],"icon"=>"icon-wrench"];

	echo '<ul class="section">';
	
	$nav_name = "";
	foreach($section as $item){
		$s = explode(".",$item["item"]);
		$f[0][] = $s[0];
		$f[1][$s[0]] = $item["name"];
		if(is_array($item["item"])){
			foreach($item["item"] as $vo){
				$s = explode(".",$vo["item"]);
				$f[0][] = $s[0];
				$f[1][$s[0]] = $vo["name"];
			}
		}
		$active = "";
		if($isact = checkIfActive($f))
		{	
			$nav_name = $isact;
			$active = "active";
		}
		echo '<li class="item '.$active.'">';
		$f = [];
		if(is_array($item["item"])){
			echo '<a href="javascript:void(0)" class="onclick-item"><i class="icon '.$item["icon"].' nav-icon"> </i>'.$item["name"].'<i class="angle icon-angle-right"></i></a>';
			echo '<ul class="section-sub">';
			foreach($item["item"] as $vo){
				echo '<li><a href="'.$admindir.$vo["item"].'" class="nav-item">'.$vo["name"].'</a></li>';
			}
			echo '</ul>';
		}else{
			echo '<a href="'.$admindir.$item["item"].'" class="nav-item"><i class="icon '.$item["icon"].' nav-icon"> </i>'.$item["name"].'</a>';
		}
		echo '</li>';
	}
	echo '</ul>';
?>


