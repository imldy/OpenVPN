<?php
/**
 * 线路列表
**/
$mod='blank';
include("../api.inc.php");
$title='线路列表';
$dlid=$_SESSION['dlid'];
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head2.php';?>
<body class="page-body">
    
    <?php include 'nav.php';?>

    <div class="page-container"><!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->
            
        <div class="main-content">

<?php

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='del'){
echo '<div class="alert';
$id=$_GET['id'];
$sql=$DB->query("DELETE FROM `open` WHERE id='$id'");
if($sql){echo ' alert-success">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除成功！';}
else{echo ' alert-danger">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除失败！';}
echo '</div>';
}else
{
if(!empty($_GET['kw'])) {
  $sql=" `iuser`='{$_GET['kw']}'";
  $numrows=$DB->count("SELECT count(*) from `open` WHERE{$sql}");
  $con='包含 '.$_GET['kw'].' 的共有 '.$numrows.' 个线路';
}else{
  $numrows=$DB->count("SELECT count(*) from `open` WHERE 1");
  $sql=" 1";
  $con='平台共有 '.$numrows.' 个线路';
}


$row = $DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$rmb=$row['rmb'];
?>
            
            <h3 id="layout-toggles">
                代理中心
                <br />
            </h3>
            
            <br />

            <div class="row">
                
                <div class="col-sm-12">
                    
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <?php echo $con; ?>
                        </div>
                        
                        <div class="panel-body">
                            
                      <div class="table-responsive">
                      
                                  <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                                      <thead>
                                          <tr>
                                            <th>线路ID</th>
                                            <th data-priority="3">名称</th>
                                            <th data-priority="6">操作</th>
                                          </tr>
                                      </thead>
                                      <tbody>
                                        <?php
                                        $pagesize=10;
                                        $pages=intval($numrows/$pagesize);
                                        if ($numrows%$pagesize)
                                        {
                                         $pages++;
                                         }
                                        if (isset($_GET['page'])){
                                        $page=intval($_GET['page']);
                                        }
                                        else{
                                        $page=1;
                                        }
                                        $offset=$pagesize*($page - 1);
                                        //$zt = array('0'=>'<font color=green>正常</font>','1'=>'<font color=red>密码错误</font>','2'=>'<font color=red>冻结</font>','3'=>'<font color=red>开启设备锁</font>');
                                        if($rmb>0){
                                          $rs=$DB->query("SELECT * FROM `open` WHERE{$sql} order by id desc limit $offset,$pagesize");
                                        }else{
                                          
                                        }
                                        while($res = $DB->fetch($rs))
                                        { ?>
                                        <tr>
                                        <th><span class="co-name"><?=$res['id']?></span></th>
                                        <td><?=$res['name']?></td>
                                        <td><a class="btn btn-xs btn-success" href="../admin/down.php?id=<?=$res['id']?>">下载</a></td>
                                        </tr>

                                        <?php }
                                        ?>
                                      </tbody>
                                  </table>
                      
                      </div>

                      <?php
                      echo'<ul class="pagination pagination-sm">';
                      $first=1;
                      $prev=$page-1;
                      $next=$page+1;
                      $last=$pages;
                      if ($page>1)
                      {
                      echo '<li><a href="linelist.php?page='.$first.$link.'">首页</a></li>';
                      echo '<li><a href="linelist.php?page='.$prev.$link.'">&laquo;</a></li>';
                      } else {
                      echo '<li class="disabled"><a>首页</a></li>';
                      echo '<li class="disabled"><a>&laquo;</a></li>';
                      }
                      for ($i=1;$i<$page;$i++)
                      echo '<li><a href="linelist.php?page='.$i.$link.'">'.$i .'</a></li>';
                      echo '<li class="disabled"><a>'.$page.'</a></li>';
                      for ($i=$page+1;$i<=$pages;$i++)
                      echo '<li><a href="linelist.php?page='.$i.$link.'">'.$i .'</a></li>';
                      echo '';
                      if ($page<$pages)
                      {
                      echo '<li><a href="linelist.php?page='.$next.$link.'">&raquo;</a></li>';
                      echo '<li><a href="linelist.php?page='.$last.$link.'">尾页</a></li>';
                      } else {
                      echo '<li class="disabled"><a>&raquo;</a></li>';
                      echo '<li class="disabled"><a>尾页</a></li>';
                      }
                      echo'</ul>';
                      #分页
                      }
                      ?>
                            
                        </div>
                        
                    </div>
                </div>

            </div>

             <?php include("../copy2.php");?>
             
        </div>
        
    </div>
    
    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>

    <script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>

    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 