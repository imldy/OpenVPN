<?php
include("../api.inc.php");

$u = daddslashes($_GET['user']);
$p = daddslashes($_GET['pass']);
$user=$DB->get_row("SELECT * FROM `{$prefix}openvpn` where `iuser`='$u' && `pass`='$p' limit 1");
if(!$user){
	echo 账号未登录或密码错误;
	exit;
}
$res=$DB->query("SELECT * FROM `open`");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<title>线路安装</title>
<link rel="stylesheet" href="/css/amazeui.min.css"/>
</head>
<body>
<table width="10%"class="am-table am-table-bordered am-table-striped am-table-compact">
  <thead>
<?php
while($open = $DB->fetch($res)){
   echo '
 <tr class="am-active">
    <td width="50%" height="30" align="center" valign="middle" bgcolor="#FFFF66"><div align="center">
    ';
    echo $open['name'];
     echo   '</div></td>
    <td width="50%" height="30" bgcolor="#FFFF66"><div align="center"><a href="/admin/down.php?id=';
    echo $open['id'];
    echo '
    " type="button" class="am-btn am-btn-default am-round">安装</a></div></td>
  </tr>';
}
   ?>
</table>
</body>