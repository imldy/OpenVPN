<?php
/**
 * 注册
**/
$mod='blank';
include("../api.inc.php");
$dlconfig=$DB->get_row("SELECT * FROM auth_config WHERE id='$site_id'");
$tj_user=$_REQUEST['tj_user'];
$dl=$_REQUEST['dl'];
if($dl){
}else{
	$dl='0';
}
if($_POST['user'] && $_POST['pass']){
	$user=daddslashes($_POST['user']);
	$pass=daddslashes($_POST['pass']);
	$dlid=daddslashes($_POST['dlid']);
	$fwq=daddslashes($_POST['fwq']);

	if($fwq){
	}else{
		$fwq='0';
	}

	$verifycode=daddslashes($_POST['verifycode']);
	$row = $DB->get_row("SELECT * FROM `openvpn` WHERE `iuser`='$user' limit 1");

	$i=0;
	$b_time =time();

	//赠送新注册用户流量
	$rs=$DB->get_row("SELECT * FROM auth_config where id='$site_id'");
	$reg_cash_con=$rs['reg_cash'];
	$user_endtime_con=$rs['user_endtime'];

	if($reg_cash_con>0){
		$i=1;
		/**
		 * PHP里的日期加减方法
		 */
		// 第一步，假设有一个时间
		$a = date('Y-m-d');
		 
		// 第二步，获得这个日期的时间戳
		$a_time = strtotime($a);
		 
		// 第三步，获得加五个月后的时间戳
		$b_time = strtotime('+'.$user_endtime_con.' Day',$a_time);
		//echo "<script language='javascript'>alert('".$b_time."');</script>";
		 
		// 第四部，把时间戳转换回日期格式
		//$b = date('Y-m-d H:i:s',$b_time);
		//echo '这是加了3天后的日期'.$b;
		
	}


	//记录赠送流量给推荐人
	$tj_user=$_REQUEST['tj_user_c'];
	$zrs=$DB->get_row("SELECT * FROM auth_config where id='$site_id'");
	$user_cash_con=round($zrs['user_cash']/1024/1024);
	if($tj_user){
		$tj_ok=1;
		//echo "<script language='javascript'>alert('推荐人：".$tj_user."');</script>";
	}

	if(!is_username($user)){
		exit("<script language='javascript'>alert('用户名只能是2~20位的字母数字！');history.go(-1);</script>");
	}elseif($row){
		exit("<script language='javascript'>alert('用户名已被使用！');history.go(-1);</script>");
	}elseif(!$verifycode || $verifycode!=$_SESSION['verifycode']){
			exit("<script language='javascript'>alert('验证码不正确！');history.go(-1);</script>");
	}else{
		//$DB->query("insert `{$prefix}openvpn`(`iuser`,`pass`,`isent`,`irecv`,`maxll`,`i`,`starttime`,`endtime`,`fwqid`) values('{$user}','{$pass}',0,0,0,0,'".time()."','".time()."','".$fwq."')");
		$url = $_SERVER['HTTP_HOST'];
		$DB->query("insert `openvpn`(`iuser`,`pass`,`isent`,`irecv`,`maxll`,`i`,`starttime`,`endtime`,`fwqid`,`tj_user`,`tj_ok`,`dlid`,`url`) values('{$user}','{$pass}',0,0,'{$reg_cash_con}','$i','".time()."','".$b_time."','".$fwq."','".$tj_user."','".$tj_ok."','".$dlid."','".$url."')");
		$row = $DB->get_row("SELECT * FROM `openvpn` WHERE `iuser`='$user' limit 1");
		if($row['id']){
			unset($_SESSION['verifycode']);
			exit("<script language='javascript'>alert('注册成功，返回登录！');window.location.href='/user/login.php';</script>");
		}else{
			exit("<script language='javascript'>alert('注册失败，请联系管理员！');history.go(-1);</script>");
		}
	}
}

$fwqlist=$DB->query("SELECT * FROM auth_fwq");

$title='用户注册';
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body>
			
				<script type="text/javascript">
					jQuery(document).ready(function($)
					{
						// Reveal Login form
						setTimeout(function(){ $(".fade-in-effect").addClass('in'); }, 1);
						
						
						// Validation and Ajax action
						$("form#login").validate({
							rules: {
								user: {
									required: true
								},
								
								pass: {
									required: true
								},
								
								verifycode: {
									required: true
								}
							},
							
							messages: {
								user: {
									required: '此为必填项！'
								},
								
								pass: {
									required: '此为必填项！'
								},
								
								verifycode: {
									required: '请填写！'
								}
							},
							
						});
						
						// Set Form focus
						$("form#login .form-group:has(.form-control):first .form-control").focus();
					});
				</script>
				
   <div class="wrapper">
      <div class="block-center mt-xl wd-xl">
         <!-- START panel-->
         <div class="panel panel-dark panel-flat">
            <div class="panel-heading text-center">
               <a href="#">
                  <img src="../assets/img/logo.png" alt="Image" class="block-center img-rounded">
               </a>
            </div>
            <div class="panel-body">
               <p class="text-center pv"><?php
  $rs=$DB->get_row("SELECT * FROM website");
  $webtitle=$rs['title'];
   echo $webtitle
    ?></p> 
				<form action="./reg.php?tj_user_c=<?php echo $tj_user;?>" method="post" role="form" id="login" class="login-form fade-in-effect">
					
                  <div class="form-group has-feedback">
				  <label class="text-muted">请输入您的帐号</label>
                     <input id="user" name="user" type="text" placeholder="请输入您的帐号" autocomplete="off" required class="form-control">
                     <span class="fa fa-envelope form-control-feedback text-muted"></span>
                  </div>
	
                  <div class="form-group has-feedback">
				  <label class="text-muted">请输入您的密码</label>
                     <input name="pass" id="pass" type="password" placeholder="请输入您的密码" required class="form-control">
                     <span class="fa fa-lock form-control-feedback text-muted"></span>
                  </div>					
					
					<input type="text" value="<?php echo $dl ?>" name="dlid" class="hide" />

					<div class="form-group has-feedback">
					<label class="text-muted">选择服务器</label>
						
						<script type="text/javascript">
							jQuery(document).ready(function($)
							{
								$("#sboxit-1").selectBoxIt().on('open', function()
								{
									// Adding Custom Scrollbar
									$(this).data('selectBoxSelectBoxIt').list.perfectScrollbar();
								});
							});
						</script>
						
						<select class="form-control" id="sboxit-1" name="fwq">
							<?php while($v = $DB->fetch($fwqlist)): ?>
							<option value="<?php echo $v['id']; ?>"><?php echo $v['name']; ?></option>
							<?php endwhile; ?>
						</select>
							
					</div><p>

					<div class="form-group has-feedback">
					<label class="text-muted">请输入验证码<img title="点击刷新" src="../verifycode.php" onclick="this.src='../verifycode.php?'+Math.random();" style="max-height:32px;vertical-align:middle;" class="img-rounded"></label>
		            	<input type="text" id="verifycode" name="verifycode" class="form-control" placeholder="验证码" required="required"/>
						<span class="fa fa-lock form-control-feedback text-muted"></span>
		            </div>
					
						<button type="submit" class="btn btn-block btn-primary mt-lg">
							立即注册
						</button>
               <p class="pt-lg text-center">已有账号？立即登录！</p><a href="login.php" class="btn btn-block btn-default">立即登录</a>
            </div>						
					
				</form>
				

				</div>
				
			</div>


         <div class="p-lg text-center">
            <span>&copy;</span>
            <span>2016</span>
            <span>-</span>
            <span><?php
  $rs=$DB->get_row("SELECT * FROM website");
  $webtitle=$rs['title'];
   echo $webtitle
    ?></span>
         </div>
      </div>
   </div>

   <script src="../assets/modernizr/modernizr.custom.js"></script>
   <script src="../assets/jquery/dist/jquery.js"></script>
   <script src="../assets/bootstrap/dist/js/bootstrap.js"></script>
   <script src="../assets/jQuery-Storage-API/jquery.storageapi.js"></script>
   <script src="../assets/parsleyjs/dist/parsley.min.js"></script>
   <script src="../assetsjs/app.js"></script>
</body>
</html>
