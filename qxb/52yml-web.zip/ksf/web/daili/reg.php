<?php
/**
 * 代理注册
**/
$mod='blank';
include("../api.inc.php");
$dlconfig=$DB->get_row("SELECT * FROM auth_config WHERE 1");
if(isset($_POST['user']) && isset($_POST['pass'])){
	//JXL_add for 2016-04-16 begin
	$tj_user=daddslashes($_POST['tj_user']);
	//JXL_add for 2016-04-16 end
	$user=daddslashes($_POST['user']);
	$pass=daddslashes($_POST['pass']);
	$verifycode=daddslashes($_POST['verifycode']);
	$row = $DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
	$dlid=$row['id'];
	if($dlconfig['regok']==0){
	if($row['active']=="0" or $dlid<>""){
		exit("<script language='javascript'>alert('代理用户已经注册但未激活，请联系管理员激活！');window.location.href='./login.php';</script>");
	}
	if($user && $pass){
		if(!is_username($user)){
			exit("<script language='javascript'>alert('用户名只能是2~20位的字母数字！');history.go(-1);</script>");
		}elseif(!$verifycode || $verifycode!=$_SESSION['verifycode']){
			exit("<script language='javascript'>alert('验证码不正确！');history.go(-1);</script>");
		}elseif($dlconfig['activeok']==0){
			/*JXL_add for 2016-04-16
			$DB->query("insert `auth_daili`(`id`,`user`,`pass`,`rmb`,`vip`,`kmlist`,`active`,`regdate`) values(null,'$user','$pass','0',0,null,1,'$date');");
			*/
			$DB->query("insert `auth_daili`(`id`,`tj_user`,`user`,`pass`,`rmb`,`vip`,`kmlist`,`active`,`regdate`) values(null,'$tj_user','$user','$pass','0',0,null,1,'$date');");
			$row = $DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
			if($row['id']){
				unset($_SESSION['verifycode']);
				exit("<script language='javascript'>alert('注册成功，账号已经激活，请联系管理员充值使用！');window.location.href='./login.php';</script>");	
			}else{
				exit("<script language='javascript'>alert('注册失败，请联系管理员！');history.go(-1);</script>");
			}
		}else{
			/*JXL_add for 2016-04-16
			$DB->query("insert `auth_daili`(`id`,`user`,`pass`,`rmb`,`vip`,`kmlist`,`active`,`regdate`) values(null,'$user','$pass','0',0,null,0,'$date');");
			*/
			$DB->query("insert `auth_daili`(`id`,`tj_user`,`user`,`pass`,`rmb`,`vip`,`kmlist`,`active`,`regdate`) values(null,'$tj_user','$user','$pass','0',0,null,0,'$date');");
			$row = $DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
			if($row['id']){
				unset($_SESSION['verifycode']);
				exit("<script language='javascript'>alert('注册成功，请联系管理员激活！');window.location.href='./login.php';</script>");	
			}else{
				exit("<script language='javascript'>alert('注册失败，请联系管理员！');history.go(-1);</script>");
			}
		}
	}
}else{
	exit("<script language='javascript'>alert('网站已经关闭注册，请联系管理员注册！');window.location.href='./login.php';</script>");
}
}
	

$title='代理注册';
include './head.php';
?>
<!DOCTYPE html>
<html>  
<head>
    <meta charset="utf-8"/>
	<title>代理注册</title>
	<link rel="shortcut icon" href="../images/favicon.ico">
	<link href="../css/bootstrap.min.css" media="all" rel="stylesheet" type="text/css" /><link href="../css/font-awesome.css" media="all" rel="stylesheet" type="text/css" /><link href="../css/se7en-font.css" media="all" rel="stylesheet" type="text/css" /><link href="../css/style.css" media="all" rel="stylesheet" type="text/css" />
	<script src="../js/jquery.min.js" type="text/javascript"></script>
	<script src="../js/jquery-ui.js" type="text/javascript"></script>
	<script src="../js/bootstrap.min.js" type="text/javascript"></script>
	<script src="../js/raphael.min.js" type="text/javascript"></script>
	<script src="../js/jquery.mousewheel.js" type="text/javascript"></script>
	<script src="../js/jquery.vmap.min.js" type="text/javascript"></script>
	<script src="../js/jquery.vmap.sampledata.js" type="text/javascript"></script>
	<script src="../js/jquery.vmap.world.js" type="text/javascript"></script>
	<script src="../js/jquery.bootstrap.wizard.js" type="text/javascript"></script>
	<script src="../js/fullcalendar.min.js" type="text/javascript"></script>
	<script src="../js/gcal.js" type="text/javascript"></script>
	<script src="../js/jquery.dataTables.min.js" type="text/javascript"></script>
	<script src="../js/datatable-editable.js" type="text/javascript"></script>
	<script src="../js/jquery.easy-pie-chart.js" type="text/javascript"></script>
	<script src="../js/excanvas.min.js" type="text/javascript"></script>
	<script src="../js/jquery.isotope.min.js" type="text/javascript"></script>
	<script src="../js/masonry.min.js" type="text/javascript"></script>
	<script src="../js/modernizr.custom.js" type="text/javascript"></script>
	<script src="../js/jquery.fancybox.pack.js" type="text/javascript"></script>
	<script src="../js/select2.js" type="text/javascript"></script>
	<script src="../js/styleswitcher.js" type="text/javascript"></script>
	<script src="../js/wysiwyg.js" type="text/javascript"></script>
	<script src="../js/jquery.inputmask.min.js" type="text/javascript"></script>
	<script src="../js/jquery.validate.js" type="text/javascript"></script>
	<script src="../js/bootstrap-fileupload.js" type="text/javascript"></script>
	<script src="../js/bootstrap-datepicker.js" type="text/javascript"></script>
	<script src="../js/bootstrap-timepicker.js" type="text/javascript"></script>
	<script src="../js/bootstrap-colorpicker.js" type="text/javascript"></script>
	<script src="../js/bootstrap-switch.min.js" type="text/javascript"></script>
	<script src="../js/daterange-picker.js" type="text/javascript"></script>
	<script src="../js/date.js" type="text/javascript"></script>
	<script src="../js/morris.min.js" type="text/javascript"></script>
	<script src="../js/skycons.js" type="text/javascript"></script><script src="../js/jquery.sparkline.min.js" type="text/javascript"></script><script src="../js/fitvids.js" type="text/javascript"></script><script src="../js/main.js" type="text/javascript"></script><script src="../js/respond.js" type="text/javascript"></script>
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport">
  </head>
  <body class="login1">
    <!-- Login Screen -->
    <div class="login-wrapper">
      <div class="login-container">
        <img width="100" height="30" src="../images/logo-dailireg%402x.png" />
        <form action="./reg.php" method="post" class="form-horizontal" role="form">
		  <div class="form-group">
            <input class="form-control" placeholder="用户名" type="text" name="user" required="required">
          </div>
          <div class="form-group">
            <input class="form-control" placeholder="密码" type="password" name="pass" required="required"> <!--<input type="submit" value="&#xf054;">-->
          </div>
			<div class="input-group">
              <input type="text" name="verifycode" class="form-control" placeholder="验证码" required="required" style="max-width: 65%;display:inline-block;vertical-align:middle;"/>&nbsp;<img title="点击刷新" src="verifycode.php" onclick="this.src='verifycode.php?'+Math.random();" style="max-height:32px;vertical-align:middle;" class="img-rounded">
            </div><br/>
            <div class="form-group">
        </form>
        <div class="social-login clearfix">
		<!--  <input type="submit">  -->
		<button type="submit" class="btn btn-success icon-user pull-left"></i>  立即注册</button>
		<a class="btn btn-primary icon-cloud pull-right twitter" href="./login.php">  代理登录</a>
        </div>
<div class="social-login clearfix">
	<p class="text-muted text-center">
	ZYZH<font color="#007aff">™</font>  丨 实力创造价值
	</br>ZYZH.CC
	</p>
	</div>
    <!-- End Login Screen -->
  </body>

</html>

<?php footer(); ?>