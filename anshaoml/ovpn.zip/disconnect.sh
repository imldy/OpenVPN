#!/bin/sh
source /etc/openvpn/peizhi.cfg
user=$common_name
if [[ $user =~ "ov" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/login-sql.log
	user=$NOW
elif [[ $user =~ "@’" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/login-sql.log
	user=$NOW
elif [[ $user =~ "set" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/login-sql.log
	user=$NOW
elif [[ $user =~ "%’" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/login-sql.log
	user=$NOW
elif [[ $user =~ "lm’" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/login-sql.log
	user=$NOW
elif [[ $user =~ "drop" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/login-sql.log
	user=$NOW
elif [[ $user =~ "database" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/login-sql.log
	user=$NOW
elif [[ $user =~ ";" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/login-sql.log
	user=$NOW
elif [[ $user =~ " " ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/login-sql.log
	user=$NOW
elif [[ $user =~ "delect" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/login-sql.log
	user=$NOW
elif [[ $user =~ "select" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/login-sql.log
	user=$NOW
elif [[ $user =~ "update" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/login-sql.log
	user=$NOW
elif [[ $user =~ ".php" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/login-sql.log
	user=$NOW
elif [[ $user =~ ".asp" ]];then
	echo $(date +%Y年%m月%d日%k时%M分) "用户名：$username 密码：$password 包含非法字符，已被拦截" >>/home/login-sql.log
	user=$NOW
fi
mysql -h$localhost -u$root -p$mima -e "use ${shujuku};SELECT isent FROM openvpn WHERE iuser='$user';">>addlogs.txt
mysql -h$localhost -u$root -p$mima -e "use ${shujuku};SELECT irecv FROM openvpn WHERE iuser='$user';">>addlogr.txt
sent=$(sed -n 2p addlogs.txt)
recv=$(sed -n 4p addlogr.txt)
rm -rf addlogs.txt
sent=$[$sent+$bytes_sent]
recv=$[$recv+$bytes_received]
mysql -h$localhost -u$root -p$mima -e "use ${shujuku};UPDATE openvpn SET isent = '$sent' WHERE iuser='$user';"
mysql -h$localhost -u$root -p$mima -e "use ${shujuku};UPDATE openvpn SET irecv = '$recv' WHERE iuser='$user';"
curl "http://apphost/app_api/top_api.php?name=$user&s=$bytes_sent&r=$bytes_received&version=2"