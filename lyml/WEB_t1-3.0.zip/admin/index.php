<?php
/*
	后台目录跳转链接
*/

include("../Data/api.inc.php");
header('Content-Type: text/html; charset=UTF-8');
if(isset($_POST['user']) && isset($_POST['pass'])){
	$username=daddslashes($_POST['user']);
	$passwrod=daddslashes($_POST['pass']);
	// 双MD5加密
	$userA = md5($username);
	$user = md5($userA);
	$passA = md5($passwrod);
	$pass = md5($passA);
	$twopassA=daddslashes($_POST['twopass']);
	$twopass = md5($twopassA);
	if(u.$user==$adminuser && p.$pass==$adminpass) {
	  if(k.$twopass!==$admintwopass){
		exit("<script language='javascript'>alert('本地二级密码不正确！');history.go(-1);</script>");}
		$session=md5(u.$user.p.$pass.k.$twopass.$password_hash);
		$token=authcode("{$user}\t{$session}", 'ENCODE', SYS_KEY);
		setcookie("ol_token", $token, time() + 604800);
		exit("<script language='javascript'>alert('登陆管理中心成功！');window.location.href='./data';</script>");
	}else{
		exit("<script language='javascript'>alert('管理员账号或密码不正确！');history.go(-1);</script>");
	}
}elseif(isset($_GET['logout'])){
	setcookie("ol_token", "", time() - 604800);
	exit("<script language='javascript'>alert('您已成功注销本次登陆！');window.location.href='./Lyun';</script>");
}elseif($islogin2==1){
	exit("<script language='javascript'>alert('您已经登陆了哦！');window.location.href='./data';</script>");
}
exit("<script language='javascript'>window.location.href='./Lyun';</script>");
?>