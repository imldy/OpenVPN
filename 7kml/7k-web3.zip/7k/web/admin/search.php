<?php
/**
 * 搜索授权
**/
$mod='blank';
include("../api.inc.php");
$title='搜索商品';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<!-- Body -->
<body>
        <?php include 'nav.php';?>
		      <section>
         <!-- Page content-->
         <div class="content-wrapper">
            <h3><?php echo $title ?>
               <small>搜索当前平台产品</small>
            </h3>
             <div class="row">
               <div class="col-md-12">
					  		                       <div class="panel panel-default">

                        <div class="panel-body">

                      <form action="./kmlist.php" method="get" role="form" class="form-inline validate">  
                        <div class="form-group">

                        <div class="form-group">

                          <select class="form-control" name="type">
                            <option value="1">卡密</option>
                            <option value="2">账号</option>
                          </select>
                            
                        </div>

                        <div class="form-group">
                          <input type="text" class="form-control" size="25" placeholder="内容" name="kw"  data-validate="required"/>
                        </div>

                        <div class="form-group">
                          <button type="submit" class="btn btn-secondary btn-single">查询</button>
                        </div>
                        
                        </div>
                        
                      </form>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
