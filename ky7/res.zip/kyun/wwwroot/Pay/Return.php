<?php
/* * 
 * 功能：支付页面跳转同步通知页面
 * 说明：
 * 以下代码只是为了方便而提供的样例代码，商户可以根据自己网站的需要编写。
 * 该代码仅供学习和研究支付接口使用，只是提供一个参考。
 */
require('../Data/system.php');	
echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>'.admin_copy(logo).' - 支付返回接口</title></head>';

//验证信息
if($_GET['out_trade_no'] || $_GET['trade_no'] || $_GET['trade_status']){ 
/************************************************************************************/
   // 验证是否来自快支付返回
   // if($_SERVER['HTTP_REFERER'] !== 'http://kypay.top/Pay/Return.php'){
   //    die('<h4>Sorry,The current address is not from KyPay.</h4>');
   // }
/************************************************************************************/
	//检测是否为Base 64 加密
    $BaseCheck = is_base64($_GET['out_trade_no']);
    if(!$BaseCheck){ 
        die('<h4>没有这个订单号！</h4>');
    }else{
		// 解密订单号信息
	    $out_trade_no = base64_decode($_GET['out_trade_no']);
		$trade_no = base64_decode($_GET['trade_no']);	
	}
/************************************************************************************/
	//交易状态
    if($_GET['trade_status'] == 'SUCCESS') {
/************************************************************************************/		
       //检测是否存在此订单
	    $db = db('ky_buy');
		$db2 = db('openvpn');
        $row = $db->where(array('trade'=>$out_trade_no))->find();
        if(!$row){
             die('<h4>没有该订单号的信息哦</h4>');
        }elseif($row['i'] == '1'){
             die('<h4>该订单号已经处理过了哦</h4>');
        }else{
			//处理交易成功信息 
			$user = $row["user"];
			$res = db("ky_tc")->where(array('name'=>$row['tc'],'dlid'=>$row['dlid']))->find();
			$MB = $res['G']*1024*1024*1024;
			$endtime = time()+3600*24*$res['tian'];
			$info = $db2->where(array('iuser'=>$user))->update(array('isent'=>'0','irecv'=>'0','maxll'=>$MB,'i'=>'1','starttime'=>time(),'endtime'=>$endtime,'dlid'=>$row['dlid'],'tian'=>$row['tian']));
			if($info){
				$db->where(array('trade'=>$out_trade_no))->update(array('i'=>'1','trade'=>$trade_no));
				die("<script>alert('亲，恭喜你购买流量成功！');</script>");
			}else{
				die("<script>alert('购买流量失败，请联系客服！');</script>");
			}
		}
	}else{
       //验证失败
        die('<h3>未付款成功哦</h3>');
    }
}else{
   die('<h3>嗯？你想干嘛呢！！！</h3>');
}
?>