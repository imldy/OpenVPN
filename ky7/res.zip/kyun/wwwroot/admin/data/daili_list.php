<?php
/**
 *===================================
 * 项目：快云流控管理系统
 * 功能：显示代理信息和配置代理
 * 作者：by 飞跃 
 * 时间：2017年11月4日 22点48分
 * 版权：归快云免流所有
 *===================================
 */
 
// 加载系统配置文件
require("../../Data/system.php");

if($is_login == 'ok'){
$db = db("ky_dl");
$db2 = db("openvpn");
$db3 = db("ky_km");
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>代理管理 - 代理列表</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css" rel="stylesheet">
	<script src="../../assets/js/jquery.min.js"></script>
	<script src="../../assets/js/bootstrap.min.js"></script>
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">

<div class="wrapper wrapper-content animated fadeInUp">
<div class="row">
   <div class="col-sm-12">
			<div class="ibox-mulu">
      <h3> &nbsp;&nbsp; <i class="fa fa-cube fa-lg"></i> 代理管理 > 代理列表</h3>
              </div>
			  <br>		                  
<?php
if($_GET['my']){
$my=daddslashes($_GET['my']);
$user=daddslashes($_GET['user']);
if($my=="del"){
   if($db->where(array('user'=>$user))->delete()){
		echo Skip('删除代理【'.$user.'】',success);
	}else{
		echo Skip('删除代理【'.$user.'】',error);
   }
}elseif($my=="qkkm"){
  if($db3->where(array('daili'=>$_GET['id']))->delete()){
	 echo Skip('清空代理【'.$user.'】子卡密',success);
  }else{
	 echo Skip('清空代理【'.$user.'】子卡密',error); 
   }
}elseif($my=="qkuser"){
  if($db2->where(array('dlid'=>$_GET['id']))->delete()){ 
	 echo Skip('清空代理【'.$user.'】子账号',success);
  }else{
	 echo Skip('清空代理【'.$user.'】子账号',error); 
  }			
}elseif($my=="wjh"){
   if($db->where("`status`<>'ok'")->delete()){
		echo Skip('删除未激活代理',success);
	}else{
		echo Skip('删除未激活代理',error);
   }
 }
exit;
}elseif(isset($_GET['sou'])){
   $numrows = $db->where(array('user'=>$_GET['user']))->getnums();
}else{
   $numrows = $db->where(array())->getnums();
}
echo '<div class="ibox"><div class="ibox-content">
<form action="daili_list.php" method="GET" class="form-inline">
 <input type="hidden" name="sou" value="sou" />
  <div class="form-group">
    <input type="text" class="form-control" name="user" placeholder="请输入代理账号">
  </div>
  <button type="submit" class="btn btn-primary">搜索</button>
  <a href="#" class="btn btn-info">平台共有 <b>'.$numrows.'</b> 个代理</a>
  <a href="daili_list.php?my=wjh" class="btn btn-danger" onclick="return confirm(\'你确实要删除未激活代理吗？\');">删除未激活代理</a>
</form>';
 ?>
 <div class="table-responsive">
        <table class="table table-bordered table-hover">
          <thead><tr><th class="text-center">ID</th><th class="text-center">用户名</th><th class="text-center">密码</th><th class="text-center">状态</th><th class="text-center">账号</th><th class="text-center">卡密</th><th class="text-center">在线</th><th class="text-center">折扣</th><th class="text-center">账户余额</th><th class="text-center">QQ</th><th class="text-center">到期时间</th><th class="text-center">管理操作</th></tr></thead>
          <tbody>
<?php
$pagesize=30;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);
if(isset($_GET['sou'])){
    $daili_list = $db->where(array('user'=>$_GET['user']))->order('id desc')->limit($offset,$pagesize)->select();
}else{
	$daili_list = $db->where(array())->order('id desc')->limit($offset,$pagesize)->select();
}
foreach($daili_list as $res){
if($res['status']== 'ok'){
	$status = '<span class="label label-primary">已激活</span>';
}else{
	$status = '<span class="label label-warning">未激活</span>';
}
$online = $db2->where(array('online'=>'1','dlid'=>$res['id']))->getnums();
$user = $db2->where(array('dlid'=>$res['id']))->getnums();
$dlkms = $db3->where(array('daili'=>$res['id']))->getnums();
echo '<tr><td class="text-center">'.$res['id'].'</td>
<td class="text-center">'.$res['user'].'</td>
<td class="text-center">'.$res['pass'].'</td>
<td class="text-center">'.$status.'</td>
<td class="text-center">'.$user.'</td>
<td class="text-center">'.$dlkms.'</td>
<td class="text-center">'.$online.'</td>
<td class="text-center">'.$res['rebate'].' %</td>
<td class="text-center">'.$res['money'].' 元</td>
<th class="text-center">'.$res['qq'].'</th>
<td class="text-center">'.date("Y.m.d",$res['endtime']).'</td>
<td class="text-center">
<a class="btn btn-xs btn-success" href="./daili_set.php?user='.$res['user'].'">编辑</a>
<a class="btn btn-xs btn-warning" data-toggle="modal" data-target="#delete" onclick="DaiLi(\''.$res['user'].'\','.$res['id'].')">清数据</a>
<a href="./daili_list.php?my=del&user='.$res['user'].'" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要删除此代理吗？\');">删除</a></td></tr>';
}
?>
          </tbody>
        </table>
      </div>
<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="daili_list.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="daili_list.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="daili_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="daili_list.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="daili_list.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="daili_list.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
?>
    </div>              
         </div>
			  </div>
            </div>
          </div>
       </div>
<!-- 模态框（Modal） -->
<div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
					&times;
				</button>
				<h4 class="modal-title">
			  清空代理数据 <small id="DelU"></small>
			</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
                  <label for="name">请选择清空内容</label><br><br>
					<select id="dele" class="form-control">
                     <option value="qkkm">代理子卡密</option>
                     <option value="qkuser">代理子账号</option>
                 </select>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">
				   Close
				</button>
				<button onclick="Delete()" class="btn btn-primary">
					保持内容
				</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal -->
</div>
<!-- 模态框（Modal）end --> 
</body>
<script>
var username = 0;
var id = 0;

function DaiLi(user,dlid){
    username = user;
	id = dlid;
}

function Delete(){
	window.location.href='./daili_list.php?my='+$("#dele").val()+'&user='+username+'&id='+id;
}
</script>
</html>
<?php
}else{
   exit("<script>window.location.href='../Kyun/index.php';</script>");
}                 
?>