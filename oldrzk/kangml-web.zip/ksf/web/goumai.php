<?php
//$mod='blank'; 
//include("../api.inc.php");
//$shop=$DB->query("SELECT `shopUrl` FROM  `ov`.`auth_config`");
//
//echo $shop;

header("location: http://www.kangml.com");
?>