<?php
class K{
	private $XX;
	
	public function getXX(){
		return $XX;
	}
}