<?php
include "../api.inc.php";
$u = daddslashes($_GET['user']);
$p = daddslashes($_GET['pass']);
$id = daddslashes($_GET['id']);
$res = $DB->get_row("SELECT * FROM `openvpn` where `user`='{$u}' && `pass`='{$p}' limit 1");
if ($res) {
$result = $DB->get_row("SELECT * FROM `auth_price` WHERE `id`='{$id}'");
$price = $result['price'];
$day = $result['day'];
$llpg = $result['llpg'];
$result2 = $DB->get_row("SELECT * FROM `openvpn` WHERE `user`='{$u}'");
$time=strtotime(date("Y-m-d H:i:s",time()))+ $day*60*60*24 ;
$Newtime = date('Y-m-d G:i:s',$time);
$CNY = $result2['CNY'];
$ll = $result2['maxll'];
$NewCNY = $CNY-$price;
$Newll = $ll+$llpg;
if($NewCNY<'0'){
	exit("<script language='javascript'>alert('余额不足！');history.go(-1);</script>");exit;
	}else{
		$DB->query("UPDATE `openvpn` SET `CNY` = '{$NewCNY}' ,`endtime` = '{$Newtime}' , `maxll` = '{$Newll}' , `i` = '1' WHERE `user`='{$u}'"); //为该订单的会员执行加款操作
		exit("<script language='javascript'>alert('成功购买！');history.go(-1);</script>");exit;
}
}else{
	exit("<script language='javascript'>alert('账号密码有误！');history.go(-1);</script>");exit;
}
?>