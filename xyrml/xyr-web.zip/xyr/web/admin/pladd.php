<?php
$mod='blank';
include("../api.inc.php");
$title='批量添加账号';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body">

    <?php include 'set.php';?>
    
    <div class="page-container">

        <?php include 'nav.php';?>
        
        <div class="main-content">
                    
            <?php include 'info.php';?>
            
          <div class="page-title">
          <div class="title-env">
            <h1 class="title"><?php echo $title ?></h1>
            <p class="description">可以一次生成所需要的格式的帐号密码；提示：苹果没有激活模式，所以独立分开添加，必须添加结束日期</p>
          </div>
            <div class="breadcrumb-env">
            
               <ol class="breadcrumb bc-1">
                 <li>
                  <a href="index.php"><i class="fa-home"></i>首页</a>
                </li>
                <li class="active">
                      <strong><?php echo $title ?></strong>
                  </li>
              </ol>
                  
             </div>
           </div>

            <div class="row">

              <div class="col-md-12">
                        
                                  <?php

                                function getstr2($len, $chars=null)
                                {
                                  if(is_null($chars)){
                                    $chars = "0123456789";
                                  }
                                  mt_srand(10000000*(double)microtime());
                                  for($i = 0, $str = '', $lc = strlen($chars)-1; $i < $len; $i++){
                                    $str .= $chars[mt_rand(0, $lc)];  
                                  }
                                  return $str;
                                }
                                //echo getstr2(123);

                                  if($_POST['num']){

                                  $notes = daddslashes($_POST['notes']);
                                  $num = daddslashes($_POST['num']);
                                  $prefix = daddslashes($_POST['prefix']);
                                  $strlen = daddslashes($_POST['strlen']);
                                  $suffix = daddslashes($_POST['suffix']);
                                  $fwqid = daddslashes($_POST['fwqid']);
                                  $pass = daddslashes($_POST['pass']);
                                  $maxll = daddslashes($_POST['maxll'])*1024*1024;
                                  $state = daddslashes($_POST['state']);
                                  $tian = daddslashes($_POST['tian']);
                                  $endtime = strtotime($_POST['enddate']);
                                  $tian = $_POST['tian'];
                                  $by = $_POST['by'];

                                  for($x=0; $x<$num; $x++){

                                  $user = $prefix.getstr2($strlen).$suffix;

                                  if(!$DB->get_row("select * from `openvpn` where `iuser`='$user' limit 1")){
                                    $id=strtoupper(substr(md5($uin.time()),0,8).'-'.uniqid());
                                    $sql="insert into `openvpn` (`iuser`,`pass`,`isent`,`irecv`,`maxll`,`i`,`starttime`,`endtime`,`fwqid`,`notes`,`tian`,`by`) values ('{$user}','{$pass}',0,0,'{$maxll}','{$state}','".time()."','{$endtime}','{$fwqid}','{$notes}','{$tian}','{$by}')";

                                    if($DB->query($sql))
                                      echo "<div class='alert alert-success'>账号：{$user}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;密码：{$pass}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;激活天数：{$tian}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;备注：{$notes}</div><style>#pladd{display: none;}</style>";
                                    else
                                      echo '
                                                    <div class="alert alert-warning">
                                                      <button type="button" class="close">
                                                        <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                                        <span class="sr-only">Close</span>
                                                      </button>添加失败：'.$DB->error().'</div>
                                                      <style>#pladd{display: none;}</style>';
                                  }else{
                                    echo '
                                                    <div class="alert alert-danger">
                                                      <button type="button" class="close">
                                                        <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                                        <span class="sr-only">Close</span>
                                                      </button>该账号已存在！</div>
                                                      <style>#pladd{display: none;}</style>';
                                  }


                                  }

                                  }

                                  $fwqlist=$DB->query("SELECT * FROM auth_fwq");
                                  $fwqlist2=$DB->query("SELECT * FROM auth_fwq");
                                  $fwqlist3=$DB->query("SELECT * FROM auth_fwq");
                                  ?>

                        <div id="pladd">
                            <ul class="nav nav-tabs">
                              <li class="active">
                                <a href="#profile" data-toggle="tab">
                                  <span class="visible-xs">常规模式</span>
                                  <span class="hidden-xs">常规模式</span>
                                </a>
                              </li>
                              <li class="">
                                <a href="#by" data-toggle="tab">
                                  <span class="visible-xs">包月模式</span>
                                  <span class="hidden-xs">包月模式</span>
                                </a>
                              </li>
                              <li class="">
                                <a href="#home" data-toggle="tab">
                                  <span class="visible-xs">自带云端激活模式</span>
                                  <span class="hidden-xs">自带云端激活模式</span>
                                </a>
                              </li>
                            </ul>
                            
                            <div class="tab-content">
                              <div class="tab-pane" id="home">
<div class="alert alert-success">
  <button type="button" class="close" data-dismiss="alert">
    <span aria-hidden="true">×</span>
    <span class="sr-only">Close</span>
  </button>
  
  <strong>自带云端激活模式说明：</strong> 此模式支持第一次登录自带云端或者第一次登录会员中心登录后激活记录使用时间，例如设置激活30天，登录后自动激活起算使用30天！
</div>
                                    <form action="./pladd.php" method="post" role="form" class="form-horizontal validate">
                                      
                                      <div class="form-group">
                                        <label class="col-sm-2 control-label">账号个数</label>
                                        <div class="col-sm-9">
                                          <input type="text" class="form-control" id="field-1" placeholder="请输入个数" name="num" data-validate="required,number">
                                        </div>
                                      </div>

                                      <div class="form-group">
                                        <label class="col-sm-2 control-label">帐号格式</label>
                                        <div class="col-sm-9">
                                          <div class="row">
                                            <div class="col-sm-4">
                                              <input type="text" class="form-control" id="field-1" placeholder="账号前缀" name="prefix" data-validate="required">
                                            </div>
                                            <div class="col-sm-4">
                                              <input type="text" class="form-control" id="field-1" placeholder="随机数长度" name="strlen" data-validate="required,number">
                                            </div>
                                            <div class="col-sm-4">
                                              <input type="text" class="form-control" id="field-1" placeholder="账号后缀" name="suffix">
                                            </div>
                                          </div>
                                        </div>
                                      </div>

                                      <div class="form-group">
                                        <label class="col-sm-2 control-label">帐号密码</label>
                                        <div class="col-sm-9">
                                          <input type="text" class="form-control" id="field-1" placeholder="请输入密码" name="pass" data-validate="required">
                                        </div>
                                      </div>									  <input type="radio" class="hide" name="state" checked="" value="1">
                                      <!--div class="form-group">
                                        <label class="col-sm-2 control-label">是否开通</label>
                                        <div class="col-sm-9">
                                            <label class="radio-inline">
                                              <input type="radio" name="state" checked="" value="1">
                                              开通
                                            </label>
                                            <label class="radio-inline">
                                              <input type="radio" name="state" value="0">
                                              禁用
                                            </label>
                                        </div>
                                      </div-->  

                                      <div class="form-group">
                                        <label class="col-sm-2 control-label">开通流量</label>
                                        <div class="col-sm-9">
                                          <div class="input-group">
                                            <input type="text" class="form-control" name="maxll" data-validate="required,number">
                                            <span class="input-group-addon">MB</span> 
                                          </div>
                                        </div>
                                      </div>

                                    <div class="form-group">
                                      <label class="col-sm-2 control-label">激活天数</label>
                                      <div class="col-sm-9">
                                        <input type="text" class="form-control" id="field-1" placeholder="请输入使用天数" name="tian" data-validate="required">
                                      </div>
                                    </div>  
                                    <input type="text" class="hide" name="enddate" value="2147483647" data-validate="required,number">
                                      <div class="form-group">

                                        <label class="col-sm-2 control-label">选择服务器</label>
                                        <div class="col-sm-9">
                                          <select class="form-control" name="fwqid">
                                          <?php while($v = $DB->fetch($fwqlist)): ?>
                                            <option value="<?php echo $v['id']; ?>"><?php echo $v['name']; ?></option>
                                          <?php endwhile; ?>
                                          </select>
                                        </div>
                                          
                                      </div>

                                      <div class="form-group">
                                        <label class="col-sm-2 control-label">账户备注</label>
                                        <div class="col-sm-9">
                                          <input type="text" class="form-control" id="field-1" placeholder="请输入备注" name="notes">
                                        </div>
                                      </div>  

                                      <div class="form-group">
                                        <label class="col-sm-2 control-label"></label>
                                        <div class="col-sm-9">
                                          <button type="submit" type="button" class="btn btn-info btn-block">批量生成账号</button>
                                        </div>
                                      </div>
                                      
                                    </form>
                              </div>
                              <div class="tab-pane active" id="profile">

                                    <form action="./pladd.php" method="post" role="form" class="form-horizontal validate">
                                      
                                      <div class="form-group">
                                        <label class="col-sm-2 control-label">账号个数</label>
                                        <div class="col-sm-9">
                                          <input type="text" class="form-control" id="field-1" placeholder="请输入个数" name="num" data-validate="required,number">
                                        </div>
                                      </div>

                                      <div class="form-group">
                                        <label class="col-sm-2 control-label">帐号格式</label>
                                        <div class="col-sm-9">
                                          <div class="row">
                                            <div class="col-sm-4">
                                              <input type="text" class="form-control" id="field-1" placeholder="账号前缀" name="prefix" data-validate="required">
                                            </div>
                                            <div class="col-sm-4">
                                              <input type="text" class="form-control" id="field-1" placeholder="随机数长度" name="strlen" data-validate="required,number">
                                            </div>
                                            <div class="col-sm-4">
                                              <input type="text" class="form-control" id="field-1" placeholder="账号后缀" name="suffix">
                                            </div>
                                          </div>
                                        </div>
                                      </div>

                                      <div class="form-group">
                                        <label class="col-sm-2 control-label">帐号密码</label>
                                        <div class="col-sm-9">
                                          <input type="text" class="form-control" id="field-1" placeholder="请输入密码" name="pass" data-validate="required">
                                        </div>
                                      </div>  

                                      <div class="form-group">
                                        <label class="col-sm-2 control-label">是否开通</label>
                                        <div class="col-sm-9">
                                            <label class="radio-inline">
                                              <input type="radio" name="state" checked="" value="1">
                                              开通
                                            </label>
                                            <label class="radio-inline">
                                              <input type="radio" name="state" value="0">
                                              禁用
                                            </label>
                                        </div>
                                      </div>  

                                      <div class="form-group">
                                        <label class="col-sm-2 control-label">开通流量</label>
                                        <div class="col-sm-9">
                                          <div class="input-group">
                                            <input type="text" class="form-control" name="maxll" data-validate="required,number">
                                            <span class="input-group-addon">MB</span> 
                                          </div>
                                        </div>
                                      </div>

                                      <div class="form-group">
                                        <label class="col-sm-2 control-label">到期日期</label>
                                        
                                        <div class="col-sm-9">
                                          <div class="input-group">
                                            <input type="text" class="form-control datepicker" data-format="yyyy/mm/dd " name="enddate" data-validate="required,date">
                                            
                                            <div class="input-group-addon">
                                              <a href="#"><i class="linecons-calendar"></i></a>
                                            </div>
                                          </div>
                                        </div>
                                      </div>

                                      <div class="form-group">

                                        <label class="col-sm-2 control-label">选择服务器</label>
                                        <div class="col-sm-9">
                                          <select class="form-control" name="fwqid">
                                          <?php while($v = $DB->fetch($fwqlist2)): ?>
                                            <option value="<?php echo $v['id']; ?>"><?php echo $v['name']; ?></option>
                                          <?php endwhile; ?>
                                          </select>
                                        </div>
                                          
                                      </div>

                                      <div class="form-group">
                                        <label class="col-sm-2 control-label">账户备注</label>
                                        <div class="col-sm-9">
                                          <input type="text" class="form-control" id="field-1" placeholder="请输入备注" name="notes">
                                        </div>
                                      </div>  

                                      <div class="form-group">
                                        <label class="col-sm-2 control-label"></label>
                                        <div class="col-sm-9">
                                          <button type="submit" type="button" class="btn btn-info btn-block">批量生成账号</button>
                                        </div>
                                      </div>
                                      
                                    </form>
                              </div>
                              <div class="tab-pane" id="by">
<div class="alert alert-success">
  <button type="button" class="close" data-dismiss="alert">
    <span aria-hidden="true">×</span>
    <span class="sr-only">Close</span>
  </button>
  
  <strong>包月模式说明：</strong> 包月需人工激活使用，可以让会员登录会员中心自动激活，或者管理员/代理通过帐号列表点击激活！
</div>
                                    <form action="./pladd.php" method="post" role="form" class="form-horizontal validate">
                                      
                                      <div class="form-group">
                                        <label class="col-sm-2 control-label">账号个数</label>
                                        <div class="col-sm-9">
                                          <input type="text" class="form-control" id="field-1" placeholder="请输入个数" name="num" data-validate="required,number">
                                        </div>
                                      </div>

                                      <div class="form-group">
                                        <label class="col-sm-2 control-label">帐号格式</label>
                                        <div class="col-sm-9">
                                          <div class="row">
                                            <div class="col-sm-4">
                                              <input type="text" class="form-control" id="field-1" placeholder="账号前缀" name="prefix" data-validate="required">
                                            </div>
                                            <div class="col-sm-4">
                                              <input type="text" class="form-control" id="field-1" placeholder="随机数长度" name="strlen" data-validate="required,number">
                                            </div>
                                            <div class="col-sm-4">
                                              <input type="text" class="form-control" id="field-1" placeholder="账号后缀" name="suffix">
                                            </div>
                                          </div>
                                        </div>
                                      </div>

                                      <div class="form-group">
                                        <label class="col-sm-2 control-label">帐号密码</label>
                                        <div class="col-sm-9">
                                          <input type="text" class="form-control" id="field-1" placeholder="请输入密码" name="pass" data-validate="required">
                                        </div>
                                      </div>  
									  <input type="radio" class="hide" name="state" checked="" value="0">
                                      <!--div class="form-group">
                                        <label class="col-sm-2 control-label">是否开通</label>
                                        <div class="col-sm-9">
                                            <label class="radio-inline">
                                              <input type="radio" name="state" checked="" value="1">
                                              开通
                                            </label>
                                            <label class="radio-inline">
                                              <input type="radio" name="state" value="0">
                                              禁用
                                            </label>
                                        </div>
                                      </div-->  

                                    <input type="text" class="hide" name="maxll" value="1000000" data-validate="required,number,min[1]">
                                    <input type="text" class="hide" name="by" value="1" data-validate="required,number,min[1]">

                                    <div class="form-group">
                                      <label class="col-sm-2 control-label">激活几个月？</label>
                                      <div class="col-sm-9">
                                        <select class="form-control" name="tian">
                                          <option value="30">1个月</option>
                                          <option value="60">2个月</option>
                                          <option value="90">3个月</option>
                                          <option value="120">4个月</option>
                                          <option value="150">5个月</option>
                                          <option value="180">6个月</option>
                                          <option value="210">7个月</option>
                                          <option value="240">8个月</option>
                                          <option value="270">9个月</option>
                                          <option value="300">10个月</option>
                                          <option value="330">11个月</option>
                                          <option value="365">12个月</option>
                                        </select>

                                      </div>
                                    </div>  

                                      <div class="form-group">

                                        <label class="col-sm-2 control-label">选择服务器</label>
                                        <div class="col-sm-9">
                                          <select class="form-control" name="fwqid">
                                          <?php while($v = $DB->fetch($fwqlist3)): ?>
                                            <option value="<?php echo $v['id']; ?>"><?php echo $v['name']; ?></option>
                                          <?php endwhile; ?>
                                          </select>
                                        </div>
                                          
                                      </div>

                                      <div class="form-group">
                                        <label class="col-sm-2 control-label">账户备注</label>
                                        <div class="col-sm-9">
                                          <input type="text" class="form-control" id="field-1" placeholder="请输入备注" name="notes">
                                        </div>
                                      </div>  

                                      <div class="form-group">
                                        <label class="col-sm-2 control-label"></label>
                                        <div class="col-sm-9">
                                          <button type="submit" type="button" class="btn btn-info btn-block">批量生成账号</button>
                                        </div>
                                      </div>
                                      
                                    </form>
                              </div>
                            </div>
                        
                        </div>
                        
                      </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
        </div>
        
        </div>
        
    </div>

  <!-- Bottom Scripts -->
  <script src="../assets/js/bootstrap.min.js"></script>
  <script src="../assets/js/TweenMax.min.js"></script>
  <script src="../assets/js/resizeable.js"></script>
  <script src="../assets/js/joinable.js"></script>
  <script src="../assets/js/xenon-api.js"></script>
  <script src="../assets/js/xenon-toggles.js"></script>

  <!-- Imported scripts on this page -->
  <script src="../assets/js/datepicker/bootstrap-datepicker.js"></script>

  <script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>

  <!-- JavaScripts initializations and stuff -->
  <script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 