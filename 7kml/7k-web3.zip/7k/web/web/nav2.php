
<link href="css/style_1.css" rel="stylesheet"> 
<div class="main-nav">
  <div class="container">
	<div class="navbar-header">
	  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
		<span class="sr-only">Toggle navigation</span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
	  </button>
	  <a class="navbar-brand" href="index.html">
		<h1><img class="img-responsive" src="images/logo.png" alt="logo"></h1>
	  </a>                    
	</div>
	<div class="collapse navbar-collapse">
	  <ul class="nav navbar-nav navbar-right">                 
		<li class="scroll active"><a href="/index.php#home">网站首页</a></li>
		<li class="scroll"><a href="/index.php#services">产品介绍</a></li> 
		<li class="scroll"><a href="/index.php#about-us">软件安装</a></li>                     
		<li class="scroll"><a href="/index.php#portfolio">常见问题</a></li>
		<li class="scroll"><a href="/index.php#team">产品购买</a></li>
        <li><a target="_blank" href="/user/login.php" class="btn btn-primary btn-sm">登录</a></li>
        <li><a target="_blank" href="/user/reg.php" class="btn btn-primary btn-sm">注册</a></li>      
	  </ul>
	</div>
  </div>
</div><!--/#main-nav-->