<?php
    $mod = 'blank';
    include ('../api.inc.php');
    $title = '代理套餐';
    include './head.php';
    if ($islogin2 == 1) {
    } else exit ("<script language='javascript'>window.location.href='./login.php';</script>");
    $fwqlist = $DB->query('SELECT * FROM auth_fwq');
    $numrows1 = $DB->count('SELECT count(*) from `auth_Package` WHERE 1') +1;
?>
<?php
    echo '<section id="content">
<section class="vbox">
<section class="scrollable padder">
<ul class="breadcrumb no-border no-radius b-b b-light pull-in">
<section class="panel panel-default">
              <header class="panel-heading font-bold"> 套餐管理 </header>
              <div class="panel-body">
';
    if ($my == 'del') {
        echo '<div class="panel panel-success">
<div class="panel-heading w h"><h3 class="panel-title">删除套餐</h3></div>
<div class="panel-body box">';
        $id = $_GET['id'];
        $sql = $DB->query("DELETE FROM auth_Package WHERE id='$id'");
        if ($sql) {
            echo '删除成功！';
        } else {
            echo '删除失败！';
        }
        echo '<hr/><a href="./dltc.php">>>返回套餐列表</a></div></div>';
    }
    if ($my == 'add') {
        $name = strval($_POST['name']);
        $tips = strval($_POST['tips']);
        $rmb = intval($_POST['rmb']);
        $endtime = intval($_POST['endtime']);
        $GB = intval($_POST['GB']);
        $ID = intval($_POST['ID']);
        if (!$DB->get_row("select * from `auth_Package` where `id`='$id' limit 1")) {
            $id = strtoupper(substr(md5($uin.time()), 0, 8) .'-'.uniqid());
            $sql = "insert into `auth_Package` (`id`,`name`,`tips`,`rmb`,`endtime`,`GB`) values ({$ID
        }
        ,'{$name
    }
    ','{$tips
    }
    ','{$rmb
    }
    ','{$endtime
    }
    ','{$GB
    }
    ')";
    if ($DB->query($sql)) echo '添加成功:'.$name;
    else echo '添加失败：'.$DB->error();
    } else {
        echo "<script>alert('该套餐已存在！');history.go(-1);</script>";
    }
    echo '<hr/><a href="./dltc.php">>>返回继续添加</a><br><a href="./dltc.php">>>返回套餐列表</a></div></div>';
    exit;
    }
?><?php
    echo '      
          <form action="./dltc.php?my=add" method="post" class="form-horizontal" role="form">
            <div class="input-group">
              <span class="input-group-addon">套餐ID</span>
			  <input type="text" name="ID" value="';
    echo $numrows1;
?><?php
    echo '" class="form-control" required>
            </div><br/>
            <div class="input-group">
              <span class="input-group-addon">套餐名称</span>
			  <input type="text" name="name" value="" class="form-control" required>
            </div><br/>
			<div class="input-group">
              <span class="input-group-addon">套餐介绍</span>
			  <input type="text" name="tips" value="" class="form-control" required>
            </div><br/>
			<div class="input-group">
              <span class="input-group-addon">套餐价钱</span>
			  <input type="text" name="rmb" value="0.00" class="form-control" required>
            </div><br/>
			<div class="input-group">
              <span class="input-group-addon">套餐日期</span>
			  <input type="text" name="endtime" value="" class="form-control" required>
            </div><br/>
			<div class="input-group">
              <span class="input-group-addon">套餐流量(G)</span>
			  <input type="text" name="GB" value="" class="form-control" required>
            </div><br/>
            <input type="submit" value="添加" class="btn btn-primary form-control"/>
          </form>


';
    $numrows = $DB->count('SELECT count(*) from `auth_Package` WHERE 1');
    $sql = ' 1';
    $con = '平台共有 <b>'.$numrows.'</b> 个卡密';
?>
<?php
    echo '      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th>序号</th><th>名称</th><th>介绍</th><th>日期</th><th>流量</th><th>金额</th><th>操作</th></tr></thead>
          <tbody>
';
    $pagesize = 30;
    $pages = intval($numrows/$pagesize);
    if ($numrows%$pagesize) {
        $pages++;
    }
    if (isset($_GET['page'])) {
        $page = intval($_GET['page']);
    } else {
        $page = 1;
    }
    $offset = $pagesize*($page-1);
    $rs = $DB->query("SELECT * FROM `auth_Package` WHERE{$sql
    }
     order by id desc limit $offset,$pagesize");
    while ($res = $DB->fetch($rs)) {
        echo '
<tr>
<td><b>'.$res['id'].'</b></td>

<td><b>'.$res['name'].'</b></td>

<td><b>'.$res['tips'].'</b></td>

<td><b>'.$res['endtime'].'/天</b></td>

<td><b>'.$res['GB'].'/Gb</b></td>

<td><b>'.$res['rmb'].'/元</b></td>


<td><a href="./dltc.php?my=del&id='.$res['id']."\" class=\"btn btn-xs btn-danger\" onclick=\"return confirm('你确实要删除此套餐吗？');\">删除</a></td></tr>";
    }
?>
<?php
    echo '
    </div>
  </div>
</section>
</section>
</section>
<!-- end -->
';
    include './nav.php';
?>