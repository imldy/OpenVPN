<?php
/**
 * 凌云免流管理中心
 * by 天木兮 2018年10月15日
 */
include("../../Data/api.inc.php");
$dlid=$_SESSION['dlid'];
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='../Lyun';</script>");
$res=$DB->get_row("SELECT * FROM auth_daili where `id`='{$dlid}'");
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title> - 修改客服</title>
    <meta name="keywords" content="">
    <meta name="description" content="">

    <link rel="shortcut icon" href="../favicon.ico"> 
	<link href="../../assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="../../assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="../../assets/css/animate.css" rel="stylesheet">
    <link href="../../assets/css/style.css?v=4.1.0" rel="stylesheet">

</head>

<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-sm-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>修改客服 <small>修改软件客服</small></h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
<?php
if($_POST["name"]){	
echo '<div class="panel-heading w h"><h3 class="panel-title">修改客服结果</h3></div>
<div class="panel-body box">';
$name=$_POST["name"];
$qq=$_POST["qq"];
$html=$_POST["html"];
$sql="update `auth_daili` set `name`='{$name}',`qq`='{$qq}',`html`='{$html}' where `id`='{$dlid}'";
if ($DB->query($sql)){ 
echo '<div class="box">恭喜亲，成功修改软件客服</div>';}
else{echo'<div class="box">噢，修改客服失败,请稍后重新尝试.</div>';}
echo '<hr/><a href="./app_qq.php" class="btn btn-success">返回修改客服</a></div>';
exit;}
?>
                        <form action="./app_qq.php" method="post" class="form-horizontal m-t">
						  <div class="form-group has-warning">
                                <label class="col-sm-2 control-label">客服名字</label>
                                <div class="col-sm-3">
                                    <input type="text" class="form-control" value="<?php echo $res['name'];?>" name="name" required="required"/>
                                </div>
								<label class="col-sm-2 control-label">客服QQ</label>
                                <div class="col-sm-3">
                                    <input type="text" class="form-control" value="<?php echo $res['qq'];?>" name="qq" required="required"/>
                                </div>
                            </div>
							 <div class="hr-line-dashed"></div>
						    <div class="form-group has-success"> 
                                <label class="col-sm-2 control-label">客服内容：</label>
                                 <div class="col-sm-8">
                                   <textarea class="form-control" rows="6" name="html"><?php echo $res[html];?></textarea>
                                 </div>
								</div>
							  <div class="hr-line-dashed"></div>
                            <div class="form-group">
                                <div class="col-sm-4 col-sm-offset-2"> 
                                    <button class="btn btn-primary" type="submit">保存内容</button>
                                </div>
                            </div>
                        </form>					
                    </div>
                </div>
            </div>
        </div>

    </div>

</body>

</html>
